# 插链任务说明书

## 任务目标

对集成了 3 个 AES 加密核的 RISC-V 处理器 `openE902_with_aes_core` 执行 Internal Scan 与 Wrapper Scan 插入。Dofile 中必须**原样引用**项目平台模板 `e902_platform.tcl`（不得修改模板文件，也不得拷贝改写），并在引用之后按本说明书进行调整。

## 输入文件

- `input/lib/sky130_hd.lib`：sky130 HD 标准单元库。
- `input/lib/aes_cipher_top_liberty.lib`：AES 加密核的时序模型（宏单元，`dont_touch`）。
- `input/netlist/open_aes_core_in_e902.v`：门级网表（top=`openE902_with_aes_core`），其中 AES 加密核以黑盒形式例化。
- `input/ctl/aes_cipher_top.ctl`：模块 `aes_cipher_top`（即 AES 加密核）的内部扫描结构描述。
- `input/e902_platform.tcl`：平台统一插链模板（只读）。

## 设计信息

- 处理器时钟为 `pll_core_cpuclk`，JTAG 时钟为 `pad_had_jtg_tclk`；`pad_yy_test_mode` 是测试模式信号，同时充当扫描使能。
- AES 加密核共例化了 3 个实例，分别是 `U_AES_CIPHER_TOP_0`、`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`。
- 设计中存在大量 ICG。在 DRC 仿真时，ICG 内部的锁存器（latch）会产生 TIE0/TIE1 类提示。

## 关于平台模板

模板已经完成以下配置：时钟、扫描使能、CLIC 控制器的扫描排除与回收、70 条内部链与 15 条 wrapper 链；wrapper 默认风格为 dedicated。模板末尾保留了一段从早期项目沿用的**端口级 wrapper 例外**配置，该配置在本项目中不再适用。

## 要求

1. **加密核**：3 个 AES 加密核均为已签核的硬核。在芯片级测试时，它们通过各自 CTL 所描述的内部扫描链**单独**进行测试；其内部扫描结构既不能被顶层 wrapper 复用为 wrapper 单元，也不能被重新组织。请使用工具的 IP 机制对它们进行声明。
2. **IP 分组**：测试计划将加密核划分为两组，需在设计中进行登记：

   - `aes_grp_a`：包含 `U_AES_CIPHER_TOP_0`
   - `aes_grp_b`：包含 `U_AES_CIPHER_TOP_1` 和 `U_AES_CIPHER_TOP_2`

   本轮不为上述任一分组单独配置 wrapper。
3. **wrapper**：本项目中所有端口统一采用 dedicated wrapper，任何端口都不得复用功能寄存器作为 wrapper 单元。模板中的端口级例外配置必须撤销（不能保留原配置后再追加一条相反配置来覆盖）。
4. **DRC 提示**：ICG 内部锁存器引起的 TIE0 / TIE1 类提示属于正常现象，按项目规范不作为违例上报；其余规则维持默认设置。

## 输出要求

产物输出至 `output/golden/output/`，包括：

- `e902_aes_scan.v`
- `e902_aes_scan.ctl`
- `e902_aes_scan.def`

报告输出至 `output/golden/report/`，包括：

- `drc.rpt`
- `black_box.rpt`
- `dft_ip_group.rpt`
- `scan_drc_rule_handling.rpt`
- `scan_cfg.rpt`
- `wrapper_cfg.rpt`
- `wrapper_implementation.rpt`
- `scan_signal.rpt`
- `scan_chain.rpt`
- `scan_chain_cell.rpt`
- `insertion_info.rpt`

另外，需在日志中打印工具版本信息。