# 插链任务说明书

## 任务目标

针对包含 3 个 AES 加密核的 RISC-V 处理器 `openE902_with_aes_core`，进行 Internal Scan 与 Wrapper Scan 的插入工作。Dofile 中须**原样引用**项目平台模板 `e902_platform.tcl`（禁止改动模板文件，亦禁止复制后改写），随后依据本说明书完成后续调整。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130_hd.lib` | sky130 HD 标准单元库 |
| `input/lib/aes_cipher_top_liberty.lib` | AES 加密核时序模型（宏单元，`dont_touch`） |
| `input/netlist/open_aes_core_in_e902.v` | 门级网表（top=`openE902_with_aes_core`），AES 加密核以黑盒形式例化 |
| `input/ctl/aes_cipher_top.ctl` | AES 加密核（模块 `aes_cipher_top`）的内部扫描结构描述 |
| `input/e902_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

- 处理器时钟 `pll_core_cpuclk`、JTAG 时钟 `pad_had_jtg_tclk`；测试模式信号 `pad_yy_test_mode` 兼作扫描使能
- AES 加密核共 3 个实例：`U_AES_CIPHER_TOP_0`、`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`
- 设计中存在大量 ICG，DRC 仿真时 ICG 内部 latch 会产生 TIE0/TIE1 类提示

## 关于平台模板

模板中已配置好时钟、扫描使能、CLIC 控制器的扫描排除与回收，并完成 70 条内部链与 15 条 wrapper 链的设置，wrapper 默认采用 dedicated 风格。模板末尾存在一段沿用自早期项目的**端口级 wrapper 例外**配置，本项目不再需要。

## 要求

1. **加密核**：3 个 AES 加密核属于已签核的硬核，芯片级测试时借助各自 CTL 描述的内部扫描链**单独**完成测试；顶层 wrapper 不得复用它们的内部扫描结构作为 wrapper 单元，也不得对其重新组织。请依据工具的 IP 机制对它们进行声明。
2. **IP 分组**：测试计划将加密核划分为两组，需在设计中进行登记：
   - `aes_grp_a`：`U_AES_CIPHER_TOP_0`
   - `aes_grp_b`：`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`

   本轮不为各组单独配置 wrapper。
3. **wrapper**：本项目所有端口一律采用 dedicated wrapper，禁止任何端口复用功能寄存器作为 wrapper 单元。模板中的端口级例外配置必须撤销（不允许保留后再追加一条相反配置来覆盖）。
4. **DRC 提示**：ICG 内部 latch 引发的 TIE0 / TIE1 类提示为正常现象，依照项目规范不作为违例上报；其余规则维持默认设置。

## 输出要求

- 产物（`output/golden/output/`）：`e902_aes_scan.v`、`e902_aes_scan.ctl`、`e902_aes_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`black_box.rpt`、`dft_ip_group.rpt`、`scan_drc_rule_handling.rpt`、`scan_cfg.rpt`、`wrapper_cfg.rpt`、`wrapper_implementation.rpt`、`scan_signal.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`insertion_info.rpt`
- 在日志中输出工具版本信息