# 平台统一插链模板（openE902 + AES 衍生项目共用，只读）
set_scan_signal -type clock -port pll_core_cpuclk -off_state 0
set_scan_signal -type clock -port pad_had_jtg_tclk -off_state 0
set_scan_signal -type scan_enable -port pad_yy_test_mode -off_state 0
set_scan_element false x_cr_tcipif_top/x_cr_clic_top/x_cr_clic_ctrl
set_scan_element true x_cr_tcipif_top/x_cr_clic_top/x_cr_clic_ctrl/mintthresh*
set_wrapper_cfg enable -style dedicated
set_scan_cfg -chain_count 70 -mix_clocks true -max_length 100
set_wrapper_cfg -chain_count 15 -max_length 100
# 中断类输入复用功能寄存器做 wrapper（早期项目的面积优化）
set_wrapper_cfg -port {pad_cpu_nmi pad_cpu_ext_int_b pad_cpu_wakeup_event} -style shared
