# 平台统一插链模板（des3 项目共用，只读）
set_scan_signal -type clock -port clk

# scan_enable — decrypt 端口复用为 scan enable
set_scan_signal -type scan_enable -port decrypt

# wrapper 时钟 — 复用 clk 端口
set_scan_signal -type wrapper_clock -port clk

# wrapper enable 信号 — 网表中不存在，工具会自动创建
set_scan_signal -type wrp_in_shift_en  -port wrapper_in_shift_en
set_scan_signal -type wrp_out_shift_en -port wrapper_out_shift_en
set_scan_signal -type wrp_in_capture_en  -port wrapper_in_cap_en
set_scan_signal -type wrp_out_capture_en -port wrapper_out_cap_en

# ── 内部扫描链配置 ────────────────────────────────────────────────────────
set_scan_cfg -max_length 100 \
    -internal_clocks single \
    -mix_clocks false \
    -mix_edges true \
    -add_lockup true \
    -replace true \
    -respect_sff_se_connection true \
    -insert_terminal_lockup true \
    -si_port_format "scan_data_in_%d" \
    -so_port_format "scan_data_out_%d"

# ── Wrapper 配置 ──────────────────────────────────────────────────────────

# 注册用户自定义 dedicated wrapper cell
add_dedicated_wrapper_cell_type -design_name dedicated_wrp_cell \
    -interface { \
        shift_clk   my_shift_clk   h \
        capture_en  my_capture_en  h \
        shift_en    my_shift_en    h \
        cti         my_cti         h \
        cto         my_cto         h \
        cfi         my_cfi         h \
        cfo         my_cfo         h \
    }

# 全局默认 wrapper 配置
# 注意: -max_length、-mix_cell、-reuse_threshold、-depth_threshold、
# -mix_internal_clocks、-input_shift_enable 等参数仅在全局配置（不带 -port）生效
set_wrapper_cfg enable \
    -style shared \
    -shared_cell_type WC_S1 \
    -max_length 100 \
    -mix_cell true \
    -reuse_threshold 64 \
    -depth_threshold 16 \
    -mix_internal_clocks true \
    -input_shift_enable  wrapper_in_shift_en \
    -output_shift_enable wrapper_out_shift_en \
    -input_capture_enable  wrapper_in_cap_en \
    -output_capture_enable wrapper_out_cap_en

# 按端口分别设置 wrapper 策略:
#   key1 → none  风格，不插入 wrapper cell
#   key2 → dedicated 风格，使用用户自定义 dedicated cell
#   key3 → shared 风格，使用 WC_S1

# key1 → none style
set_wrapper_cfg \
    -style none \
    -port key1

# key2 → dedicated style, 用户自定义 dedicated cell
set_wrapper_cfg \
    -style dedicated \
    -dedicated_cell_type user_defined \
    -port key2

# key3 → shared style, WC_S1 cell
set_wrapper_cfg \
    -style shared \
    -shared_cell_type WC_S1 \
    -port key3

# ── 设置 scan segment ─────────────────────────────────────────────────────
# 共 280 个 segment，覆盖 5544 个 FF

# --- length 34 (56 segments, ShiftRegID 168-223, key_c → key_c[33]) ---
for {set i 0} {$i < 56} {incr i} {
    set si "key_c_r_reg[0][$i]/SCD"
    set se "key_c_r_reg[0][$i]/SCE"
    set so "key_c_r_reg[33][$i]/Q"
    set_scan_segment seg[expr {168 + $i}] -lockup_exists false \
        -access [list scan_enable $se scan_data_in $si scan_data_out $so]
}

# --- length 17 (56 segments, ShiftRegID 224-279, key_b → key_b[16]) ---
for {set i 0} {$i < 56} {incr i} {
    set si "key_b_r_reg[0][$i]/SCD"
    set se "key_b_r_reg[0][$i]/SCE"
    set so "key_b_r_reg[16][$i]/Q"
    set_scan_segment seg[expr {224 + $i}] -lockup_exists false \
        -access [list scan_enable $se scan_data_in $si scan_data_out $so]
}

# --- length 16 (168 segments, ShiftRegID 0-167, u2/u1/u0 key_r → uk/K_r14) ---
# u2/key_r_reg: 56 segments (ShiftRegID 0-55)
for {set i 0} {$i < 56} {incr i} {
    set si "u2/key_r_reg[$i]/SCD"
    set se "u2/key_r_reg[$i]/SCE"
    set so "u2/uk/K_r14_reg[$i]/Q"
    set_scan_segment seg$i -lockup_exists false \
        -access [list scan_enable $se scan_data_in $si scan_data_out $so]
}
# u1/key_r_reg: 56 segments (ShiftRegID 56-111)
for {set i 0} {$i < 56} {incr i} {
    set si "u1/key_r_reg[$i]/SCD"
    set se "u1/key_r_reg[$i]/SCE"
    set so "u1/uk/K_r14_reg[$i]/Q"
    set_scan_segment seg[expr {56 + $i}] -lockup_exists false \
        -access [list scan_enable $se scan_data_in $si scan_data_out $so]
}
# u0/key_r_reg: 56 segments (ShiftRegID 112-167)
for {set i 0} {$i < 56} {incr i} {
    set si "u0/key_r_reg[$i]/SCD"
    set se "u0/key_r_reg[$i]/SCE"
    set so "u0/uk/K_r14_reg[$i]/Q"
    set_scan_segment seg[expr {112 + $i}] -lockup_exists false \
        -access [list scan_enable $se scan_data_in $si scan_data_out $so]
}


# ── DRC 检查和扫描链预插 ─────────────────────────────────────────────────────────────
# 前 4 位输入寄存器保留给功能 bypass，不复用为 shared wrapper cell
set_wrapper_cfg -exclude {u0/desIn_r_reg[0] u0/desIn_r_reg[1] u0/desIn_r_reg[2] u0/desIn_r_reg[3]}
