# 插链任务说明书

## 任务目标

`spi_top`（SPI 控制器）的扫描链插入工作分为两个阶段。第一阶段已由其他同事完成，内容为：为时钟分频模块 `clgen` 建立一条扫描链，并将工程保存为数据库。本任务属于**第二阶段**，需直接在该数据库基础上继续操作，完成剩余部分的扫描链插入。

## 输入文件

- `input/db/spi_stage1.db` —— 第一阶段工程数据库，其中包含库信息、第一阶段网表以及部分扫描信号定义。**应直接加载该数据库**，切勿重新读入库与网表。
- `input/netlist/spi_top_partial.v` —— 第一阶段导出的网表，仅用于查看参考。
- `input/lib/sky130.lib` —— 标准单元库，仅用于查看参考。

## 设计信息

### 端口功能

| 端口 | 功能 |
|---|---|
| `wb_clk_i` | WISHBONE 时钟，驱动全部寄存器 |
| `wb_rst_i` | 异步复位，高有效 |
| `wb_adr_i[4:0]`、`wb_dat_i[31:0]`、`wb_sel_i[3:0]` | WISHBONE 地址、写数据、字节选择 |
| `wb_we_i`、`wb_stb_i`、`wb_cyc_i` | WISHBONE 写使能、选通、周期（数据控制信号） |
| `wb_dat_o`、`wb_ack_o`、`wb_err_o`、`wb_int_o` | WISHBONE 输出 |
| `ss_pad_o`、`sclk_pad_o`、`mosi_pad_o`、`miso_pad_i` | SPI 主接口 |
| `test_se`、`scan_in_clgen`、`scan_out_clgen` | 第一阶段新增的扫描端口 |

- 时序单元总计 364 个。其中 `clgen` 内的 19 个已替换为扫描单元并串接成一条链（`scan_in_clgen` → … → `scan_out_clgen`，由 `test_se` 使能）；剩余 345 个仍为非扫描 DFF（`dfrtp_1`、`dfstp_2`）。

### 第一阶段遗留情况

- 数据库中已有的扫描信号定义**未经审核**，需对照上文端口功能表逐项检查，撤销所有与端口功能不一致的定义。
- 第一阶段调试时曾临时加入一个输入端口：其名称以 `dbg_` 开头，且**未连接任何逻辑**（悬空，没有驱动）。交付前必须将该端口从设计中删除。

## 要求

1. 新增输入端口 `test_mode`，在扫描链插入期间需保持为 1。
2. 扫描使能信号 `test_se` 同时作用于扫描单元与时钟门控，其 off 态为 0。
3. 第一阶段建立的 clgen 扫描链必须**原样保留**（不得重新拆分或重新串接），在工具中将其标识为已存在的扫描链，链名为 `clgen_chain`。
4. 其余 DFF 替换为对应的扫描 FF；扫描链**总条数**为 4（含 `clgen_chain`）；不同时钟不得混在同一条链上；插入 lockup 锁存器；新建链的 SI/SO 端口分别命名为 `scan_data_in_<n>` 与 `scan_data_out_<n>`。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`，以及插链后的数据库 `post_scan.db`。
- 报告（`output/golden/report/`）：`scan_signal_loaded.rpt`（加载数据库后、做任何修改之前生成的信号报告）、`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`。
- 在日志中打印工具版本信息。