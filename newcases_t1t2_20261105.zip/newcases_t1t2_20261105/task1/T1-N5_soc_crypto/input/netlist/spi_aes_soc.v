// spi_aes_soc —— 能力用例合成顶层：SPI 控制器 + 2 个 AES 加密硬核（黑盒，内部扫描见 ctl/aes_cipher_top.ctl）
module spi_aes_soc (wb_clk_i, wb_rst_i, wb_adr_i, wb_dat_i, wb_dat_o, wb_sel_i, wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_err_o, wb_int_o, ss_pad_o, sclk_pad_o, mosi_pad_o, miso_pad_i);
  input wb_clk_i;
  input wb_rst_i;
  input [4:0] wb_adr_i;
  input [31:0] wb_dat_i;
  output [31:0] wb_dat_o;
  input [3:0] wb_sel_i;
  input wb_we_i;
  input wb_stb_i;
  input wb_cyc_i;
  output wb_ack_o;
  output wb_err_o;
  output wb_int_o;
  output [7:0] ss_pad_o;
  output sclk_pad_o;
  output mosi_pad_o;
  input miso_pad_i;
  spi_top u_spi (.wb_clk_i(wb_clk_i), .wb_rst_i(wb_rst_i), .wb_adr_i(wb_adr_i), .wb_dat_i(wb_dat_i), .wb_dat_o(wb_dat_o), .wb_sel_i(wb_sel_i), .wb_we_i(wb_we_i), .wb_stb_i(wb_stb_i), .wb_cyc_i(wb_cyc_i), .wb_ack_o(wb_ack_o), .wb_err_o(wb_err_o), .wb_int_o(wb_int_o), .ss_pad_o(ss_pad_o), .sclk_pad_o(sclk_pad_o), .mosi_pad_o(mosi_pad_o), .miso_pad_i(miso_pad_i));
  aes_cipher_top U_AES_0 (.clk(wb_clk_i));
  aes_cipher_top U_AES_1 (.clk(wb_clk_i));
endmodule
