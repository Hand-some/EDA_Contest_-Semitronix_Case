# 插链任务说明书

## 任务目标

对小型安全 SoC `spi_aes_soc` 进行 Internal Scan 插入。该 SoC 包含一个 SPI 控制器与两个 AES 加密核。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/lib/aes_cipher_top_liberty.lib` | AES 加密核时序模型（宏单元） |
| `input/netlist/spi_top.v` | SPI 控制器门级网表（模块 `spi_top` 及子模块） |
| `input/netlist/spi_aes_soc.v` | SoC 顶层（top=`spi_aes_soc`） |
| `input/ctl/aes_cipher_top.ctl` | AES 加密核（模块 `aes_cipher_top`）内部扫描结构描述 |

## 设计信息

- 顶层端口与 SPI 控制器一致：WISHBONE 从接口（时钟 `wb_clk_i`、复位 `wb_rst_i` 高有效）与 SPI 主接口
- 顶层例化：`u_spi`（SPI 控制器，364 个可扫描 FF：`dfrtp_1`、`dfstp_2`）、`U_AES_0`、`U_AES_1`（AES 加密核，内部已有扫描链）

## 要求

1. 新增扫描使能端口 `test_se`，同时控制扫描单元与可能存在的时钟门控；扫描期间时钟、复位保持非激活。
2. 4 条扫描链，单链不超过 200，不混时钟，插 lockup，DFF 替换为对应的扫描 FF；SI/SO 端口命名为 `scan_data_in_<n>` / `scan_data_out_<n>`。
3. **加密核**：两个 AES 加密核在芯片级走独立的测试通道，用各自 CTL 中的内部链单独测试；**片级扫描链只能包含 SPI 控制器的触发器**，不得串入加密核的内部链。请按工具的 IP 机制声明它们，并把两者登记为一个 IP 组 `aes_grp`（顺序 `U_AES_0`、`U_AES_1`）。
4. **扫描接口时序**：封装测试接口要求每条扫描链的**第一个**时序单元为下降沿触发、**最后一个**时序单元为上升沿触发；不满足时由工具在顶层 `spi_aes_soc` 自动插入重定时寄存器。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`black_box.rpt`、`dft_ip_group.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息