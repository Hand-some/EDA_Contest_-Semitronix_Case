# 平台统一插链模板（各 AC97 衍生项目共用，只读）
set_scan_signal -type clock -port clk_i -off_state 0
set_scan_signal -type clock -port bit_clk_pad_i -off_state 0
set_scan_signal -type reset -port rst_i -off_state 1
set_scan_cfg -add_lockup true \
    -replace true \
    -mix_edges false \
    -si_port_format "scan_data_in_%d" \
    -so_port_format "scan_data_out_%d"
add_scan_partition rx_fifo_partition -include {u9 u10 u11}
add_scan_partition tx_fifo_partition -include {u3 u4 u5 u6 u7 u8}
add_scan_partition rx_serdes_partition -include {u1}
add_scan_partition tx_serdes_partition -include {u0}
add_scan_partition reg_partition -include {u13}
add_scan_partition wb_partition -include {u12}
add_scan_partition ctrl_partition -include {u2 u14 u15 u16 u17 u18 u19 u20 u21 u22 u23 u24 u25 u26}
set_current_scan_partition rx_fifo_partition
set_scan_cfg -chain_count 2 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_rx_fifo
set_current_scan_partition tx_fifo_partition
set_scan_cfg -chain_count 4 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_tx_fifo
set_current_scan_partition rx_serdes_partition
set_scan_cfg -chain_count 2 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_serdes
set_current_scan_partition tx_serdes_partition
set_scan_cfg -chain_count 1 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_serdes
set_current_scan_partition reg_partition
set_scan_cfg -chain_count 1 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_ctrl
set_current_scan_partition wb_partition
set_scan_cfg -chain_count 1 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_ctrl
set_current_scan_partition ctrl_partition
set_scan_cfg -chain_count 2 -max_length 300 -mix_clocks false
set_scan_signal -type scan_enable -port se_ctrl
set_current_scan_partition Default_Partition
# 调试用：寄存器堆单独成链
add_scan_chain dbg_chain -include_elements {u13}
