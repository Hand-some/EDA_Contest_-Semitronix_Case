# 插链任务说明书

## 任务目标

对 AC97 音频控制器 `ac97_top` 执行完整 Scan Insertion。必须在 Dofile 中**原样引用**项目平台模板 `ac97_platform.tcl`（不得修改模板文件，也不得拷贝改写），再在其后按本说明书调整。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/ac97_ctrl.v` | 门级网表（pre-scan，top=`ac97_top`） |
| `input/ac97_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

- 共 2,229 个可扫描 FF；时钟 `clk_i`（系统 / WISHBONE 时钟）、`bit_clk_pad_i`（AC-Link 串行位时钟）；复位 `rst_i`
- 子模块实例：

| 实例 | 功能 |
|---|---|
| `u0` | AC-Link 串行输出（并→串） |
| `u1` | AC-Link 串行输入（串→并） |
| `u2` | Codec 帧同步控制器：产生 SYNC 并管理超时计数；内部同时含 `clk_i` 与 `bit_clk_pad_i` 两个时钟域的寄存器 |
| `u3`~`u8` | 6 路输出 FIFO |
| `u9`~`u11` | 3 路输入 FIFO |
| `u12` | WISHBONE 接口 |
| `u13` | 配置寄存器堆 |
| `u14`~`u26` | 中断、DMA 请求、复位同步等控制逻辑 |

- 测试模式下 `clk_i` 与 `bit_clk_pad_i` 由同一个测试时钟驱动。
- 设计中有 1 处时钟接到触发器数据端（DFTR10），允许保留；其余 DRC 必须为 0。

## 关于平台模板

模板已完成时钟/复位、全局 scan_cfg（含 SI/SO 命名）以及按功能划分的 7 个分区及其链数、链长、scan_enable。模板是在调试阶段整理出来的，正式插链**不得保留任何仅用于调试的扫描结构**，请检查模板内容并撤销此类配置。

## 调整要求

1. **串并转换分区合并**：串行输出、串行输入两部分合并为一个分区 `serdes_partition`，2 条链，单链不超过 300，允许混时钟，扫描使能 `se_serdes`；模板中原来分别对应这两部分的分区必须移除。
2. **Codec 帧同步控制器专用链**：该模块的全部寄存器单独组成一条扫描链 `soc_chain`（成员由工具决定顺序），使用两个**新增的专用顶层端口** `si_soc`（扫描输入）、`so_soc`（扫描输出），扫描使能与控制类逻辑共用 `se_ctrl`。
3. 该模块内两个时钟在测试模式下同源，链内跨时钟处不得插入 lockup latch；请按模块（实例）表达这一点（组名 `soc_skew`）。
4. 其余分区沿用模板。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`，以及 `ac97.ctl`、`ac97.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`scan_partition.rpt`
- 在日志中打印工具版本信息
