# 平台统一插链模板（各项目共用，请勿修改本文件）
set_scan_cell_mapping  sky130_fd_sc_hd__dfxtp_1  sky130_fd_sc_hd__sdfxtp_1
set_scan_cell_mapping  sky130_fd_sc_hd__dfrtp_1  sky130_fd_sc_hd__sdfrtp_1
set_scan_cell_mapping  sky130_fd_sc_hd__dfstp_2  sky130_fd_sc_hd__sdfstp_2
set_scan_cell_mapping  sky130_fd_sc_hd__dfsbp_1  sky130_fd_sc_hd__sdfsbp_1
set_scan_signal  -type clock  -port wb_clk_i       -off_state 0
set_scan_signal  -type clock  -port mtx_clk_pad_i  -off_state 0
set_scan_signal  -type clock  -port mrx_clk_pad_i  -off_state 0
set_scan_signal  -type clock  -port mcoll_pad_i    -off_state 0
set_scan_signal  -type reset  -port wb_rst_i       -off_state 0
set_scan_cfg  -internal_clocks multi  -add_lockup true  -mix_edges false
set_scan_drc_rule_handling {DFTR-TIE1} Ignore
add_scan_partition  wb_partition  -clocks {wb_clk_i}
add_scan_partition  tx_partition  -clocks {mtx_clk_pad_i}
add_scan_partition  rx_partition  -clocks {mrx_clk_pad_i}
set_current_scan_partition  wb_partition
set_scan_cfg  -chain_count 34  -max_length 300  -mix_clocks false
set_scan_signal  -type scan_enable  -port se_wb
set_current_scan_partition  tx_partition
set_scan_cfg  -chain_count 1  -max_length 300  -mix_clocks false
set_scan_signal  -type scan_enable  -port se_tx
set_current_scan_partition  rx_partition
set_scan_cfg  -chain_count 1  -max_length 300  -mix_clocks false
set_scan_signal  -type scan_enable  -port se_rx
set_current_scan_partition  Default_Partition
set_scan_signal  -type scan_enable  -port test_se
