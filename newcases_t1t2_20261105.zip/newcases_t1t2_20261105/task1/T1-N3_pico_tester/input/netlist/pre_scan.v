/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Thu Aug  6 15:19:48 2026
/////////////////////////////////////////////////////////////


module SNPS_CLOCK_GATE_HIGH_picorv32_0 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_45 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_44 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_43 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_42 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_41 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_40 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_39 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_38 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_37 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_36 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_35 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_34 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_33 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_32 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_31 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_30 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_29 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_28 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_27 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_26 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_25 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_24 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_23 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_22 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_21 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_20 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_19 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_18 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_17 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_16 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_15 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_14 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_13 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_12 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_11 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_10 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_9 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_8 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_7 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_4 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_3 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_2 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_picorv32_1 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  sky130_fd_sc_hd__sdlclkp_1 latch ( .CLK(CLK), .GATE(EN), .SCE(TE), .GCLK(
        ENCLK) );
endmodule


module picorv32_DW01_add_0 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   n1;
  wire   [31:1] carry;

  sky130_fd_sc_hd__fa_1 U1_31 ( .A(A[31]), .B(B[31]), .CIN(carry[31]), .SUM(
        SUM[31]) );
  sky130_fd_sc_hd__fa_1 U1_1 ( .A(A[1]), .B(B[1]), .CIN(n1), .COUT(carry[2]), 
        .SUM(SUM[1]) );
  sky130_fd_sc_hd__fa_1 U1_2 ( .A(A[2]), .B(B[2]), .CIN(carry[2]), .COUT(
        carry[3]), .SUM(SUM[2]) );
  sky130_fd_sc_hd__fa_1 U1_4 ( .A(A[4]), .B(B[4]), .CIN(carry[4]), .COUT(
        carry[5]), .SUM(SUM[4]) );
  sky130_fd_sc_hd__fa_1 U1_5 ( .A(A[5]), .B(B[5]), .CIN(carry[5]), .COUT(
        carry[6]), .SUM(SUM[5]) );
  sky130_fd_sc_hd__fa_1 U1_6 ( .A(A[6]), .B(B[6]), .CIN(carry[6]), .COUT(
        carry[7]), .SUM(SUM[6]) );
  sky130_fd_sc_hd__fa_1 U1_7 ( .A(A[7]), .B(B[7]), .CIN(carry[7]), .COUT(
        carry[8]), .SUM(SUM[7]) );
  sky130_fd_sc_hd__fa_1 U1_8 ( .A(A[8]), .B(B[8]), .CIN(carry[8]), .COUT(
        carry[9]), .SUM(SUM[8]) );
  sky130_fd_sc_hd__fa_1 U1_9 ( .A(A[9]), .B(B[9]), .CIN(carry[9]), .COUT(
        carry[10]), .SUM(SUM[9]) );
  sky130_fd_sc_hd__fa_1 U1_10 ( .A(A[10]), .B(B[10]), .CIN(carry[10]), .COUT(
        carry[11]), .SUM(SUM[10]) );
  sky130_fd_sc_hd__fa_1 U1_11 ( .A(A[11]), .B(B[11]), .CIN(carry[11]), .COUT(
        carry[12]), .SUM(SUM[11]) );
  sky130_fd_sc_hd__fa_1 U1_12 ( .A(A[12]), .B(B[12]), .CIN(carry[12]), .COUT(
        carry[13]), .SUM(SUM[12]) );
  sky130_fd_sc_hd__fa_1 U1_13 ( .A(A[13]), .B(B[13]), .CIN(carry[13]), .COUT(
        carry[14]), .SUM(SUM[13]) );
  sky130_fd_sc_hd__fa_1 U1_14 ( .A(A[14]), .B(B[14]), .CIN(carry[14]), .COUT(
        carry[15]), .SUM(SUM[14]) );
  sky130_fd_sc_hd__fa_1 U1_16 ( .A(A[16]), .B(B[16]), .CIN(carry[16]), .COUT(
        carry[17]), .SUM(SUM[16]) );
  sky130_fd_sc_hd__fa_1 U1_17 ( .A(A[17]), .B(B[17]), .CIN(carry[17]), .COUT(
        carry[18]), .SUM(SUM[17]) );
  sky130_fd_sc_hd__fa_1 U1_18 ( .A(A[18]), .B(B[18]), .CIN(carry[18]), .COUT(
        carry[19]), .SUM(SUM[18]) );
  sky130_fd_sc_hd__fa_1 U1_19 ( .A(A[19]), .B(B[19]), .CIN(carry[19]), .COUT(
        carry[20]), .SUM(SUM[19]) );
  sky130_fd_sc_hd__fa_1 U1_20 ( .A(A[20]), .B(B[20]), .CIN(carry[20]), .COUT(
        carry[21]), .SUM(SUM[20]) );
  sky130_fd_sc_hd__fa_1 U1_21 ( .A(A[21]), .B(B[21]), .CIN(carry[21]), .COUT(
        carry[22]), .SUM(SUM[21]) );
  sky130_fd_sc_hd__fa_1 U1_22 ( .A(A[22]), .B(B[22]), .CIN(carry[22]), .COUT(
        carry[23]), .SUM(SUM[22]) );
  sky130_fd_sc_hd__fa_1 U1_23 ( .A(A[23]), .B(B[23]), .CIN(carry[23]), .COUT(
        carry[24]), .SUM(SUM[23]) );
  sky130_fd_sc_hd__fa_1 U1_24 ( .A(A[24]), .B(B[24]), .CIN(carry[24]), .COUT(
        carry[25]), .SUM(SUM[24]) );
  sky130_fd_sc_hd__fa_1 U1_25 ( .A(A[25]), .B(B[25]), .CIN(carry[25]), .COUT(
        carry[26]), .SUM(SUM[25]) );
  sky130_fd_sc_hd__fa_1 U1_26 ( .A(A[26]), .B(B[26]), .CIN(carry[26]), .COUT(
        carry[27]), .SUM(SUM[26]) );
  sky130_fd_sc_hd__fa_1 U1_27 ( .A(A[27]), .B(B[27]), .CIN(carry[27]), .COUT(
        carry[28]), .SUM(SUM[27]) );
  sky130_fd_sc_hd__fa_1 U1_28 ( .A(A[28]), .B(B[28]), .CIN(carry[28]), .COUT(
        carry[29]), .SUM(SUM[28]) );
  sky130_fd_sc_hd__fa_1 U1_29 ( .A(A[29]), .B(B[29]), .CIN(carry[29]), .COUT(
        carry[30]), .SUM(SUM[29]) );
  sky130_fd_sc_hd__fa_1 U1_30 ( .A(A[30]), .B(B[30]), .CIN(carry[30]), .COUT(
        carry[31]), .SUM(SUM[30]) );
  sky130_fd_sc_hd__fa_1 U1_3 ( .A(A[3]), .B(B[3]), .CIN(carry[3]), .COUT(
        carry[4]), .SUM(SUM[3]) );
  sky130_fd_sc_hd__fa_1 U1_15 ( .A(A[15]), .B(B[15]), .CIN(carry[15]), .COUT(
        carry[16]), .SUM(SUM[15]) );
  sky130_fd_sc_hd__and2_1 U1 ( .A(B[0]), .B(A[0]), .X(n1) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(B[0]), .B(A[0]), .X(SUM[0]) );
endmodule


module picorv32_DW01_add_1 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   \A[0] , n1;
  wire   [31:1] carry;
  assign SUM[0] = \A[0] ;
  assign \A[0]  = A[0];

  sky130_fd_sc_hd__fa_1 U1_2 ( .A(A[2]), .B(B[2]), .CIN(n1), .COUT(carry[3]), 
        .SUM(SUM[2]) );
  sky130_fd_sc_hd__fa_1 U1_30 ( .A(A[30]), .B(B[30]), .CIN(carry[30]), .COUT(
        carry[31]), .SUM(SUM[30]) );
  sky130_fd_sc_hd__fa_1 U1_29 ( .A(A[29]), .B(B[29]), .CIN(carry[29]), .COUT(
        carry[30]), .SUM(SUM[29]) );
  sky130_fd_sc_hd__fa_1 U1_28 ( .A(A[28]), .B(B[28]), .CIN(carry[28]), .COUT(
        carry[29]), .SUM(SUM[28]) );
  sky130_fd_sc_hd__fa_1 U1_27 ( .A(A[27]), .B(B[27]), .CIN(carry[27]), .COUT(
        carry[28]), .SUM(SUM[27]) );
  sky130_fd_sc_hd__fa_1 U1_26 ( .A(A[26]), .B(B[26]), .CIN(carry[26]), .COUT(
        carry[27]), .SUM(SUM[26]) );
  sky130_fd_sc_hd__fa_1 U1_25 ( .A(A[25]), .B(B[25]), .CIN(carry[25]), .COUT(
        carry[26]), .SUM(SUM[25]) );
  sky130_fd_sc_hd__fa_1 U1_24 ( .A(A[24]), .B(B[24]), .CIN(carry[24]), .COUT(
        carry[25]), .SUM(SUM[24]) );
  sky130_fd_sc_hd__fa_1 U1_23 ( .A(A[23]), .B(B[23]), .CIN(carry[23]), .COUT(
        carry[24]), .SUM(SUM[23]) );
  sky130_fd_sc_hd__fa_1 U1_22 ( .A(A[22]), .B(B[22]), .CIN(carry[22]), .COUT(
        carry[23]), .SUM(SUM[22]) );
  sky130_fd_sc_hd__fa_1 U1_21 ( .A(A[21]), .B(B[21]), .CIN(carry[21]), .COUT(
        carry[22]), .SUM(SUM[21]) );
  sky130_fd_sc_hd__fa_1 U1_20 ( .A(A[20]), .B(B[20]), .CIN(carry[20]), .COUT(
        carry[21]), .SUM(SUM[20]) );
  sky130_fd_sc_hd__fa_1 U1_19 ( .A(A[19]), .B(B[19]), .CIN(carry[19]), .COUT(
        carry[20]), .SUM(SUM[19]) );
  sky130_fd_sc_hd__fa_1 U1_18 ( .A(A[18]), .B(B[18]), .CIN(carry[18]), .COUT(
        carry[19]), .SUM(SUM[18]) );
  sky130_fd_sc_hd__fa_1 U1_17 ( .A(A[17]), .B(B[17]), .CIN(carry[17]), .COUT(
        carry[18]), .SUM(SUM[17]) );
  sky130_fd_sc_hd__fa_1 U1_16 ( .A(A[16]), .B(B[16]), .CIN(carry[16]), .COUT(
        carry[17]), .SUM(SUM[16]) );
  sky130_fd_sc_hd__fa_1 U1_15 ( .A(A[15]), .B(B[15]), .CIN(carry[15]), .COUT(
        carry[16]), .SUM(SUM[15]) );
  sky130_fd_sc_hd__fa_1 U1_14 ( .A(A[14]), .B(B[14]), .CIN(carry[14]), .COUT(
        carry[15]), .SUM(SUM[14]) );
  sky130_fd_sc_hd__fa_1 U1_13 ( .A(A[13]), .B(B[13]), .CIN(carry[13]), .COUT(
        carry[14]), .SUM(SUM[13]) );
  sky130_fd_sc_hd__fa_1 U1_12 ( .A(A[12]), .B(B[12]), .CIN(carry[12]), .COUT(
        carry[13]), .SUM(SUM[12]) );
  sky130_fd_sc_hd__fa_1 U1_11 ( .A(A[11]), .B(B[11]), .CIN(carry[11]), .COUT(
        carry[12]), .SUM(SUM[11]) );
  sky130_fd_sc_hd__fa_1 U1_10 ( .A(A[10]), .B(B[10]), .CIN(carry[10]), .COUT(
        carry[11]), .SUM(SUM[10]) );
  sky130_fd_sc_hd__fa_1 U1_9 ( .A(A[9]), .B(B[9]), .CIN(carry[9]), .COUT(
        carry[10]), .SUM(SUM[9]) );
  sky130_fd_sc_hd__fa_1 U1_8 ( .A(A[8]), .B(B[8]), .CIN(carry[8]), .COUT(
        carry[9]), .SUM(SUM[8]) );
  sky130_fd_sc_hd__fa_1 U1_7 ( .A(A[7]), .B(B[7]), .CIN(carry[7]), .COUT(
        carry[8]), .SUM(SUM[7]) );
  sky130_fd_sc_hd__fa_1 U1_6 ( .A(A[6]), .B(B[6]), .CIN(carry[6]), .COUT(
        carry[7]), .SUM(SUM[6]) );
  sky130_fd_sc_hd__fa_1 U1_5 ( .A(A[5]), .B(B[5]), .CIN(carry[5]), .COUT(
        carry[6]), .SUM(SUM[5]) );
  sky130_fd_sc_hd__fa_1 U1_4 ( .A(A[4]), .B(B[4]), .CIN(carry[4]), .COUT(
        carry[5]), .SUM(SUM[4]) );
  sky130_fd_sc_hd__fa_1 U1_3 ( .A(A[3]), .B(B[3]), .CIN(carry[3]), .COUT(
        carry[4]), .SUM(SUM[3]) );
  sky130_fd_sc_hd__fa_1 U1_31 ( .A(A[31]), .B(B[31]), .CIN(carry[31]), .SUM(
        SUM[31]) );
  sky130_fd_sc_hd__and2_1 U1 ( .A(B[1]), .B(A[1]), .X(n1) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(B[1]), .B(A[1]), .X(SUM[1]) );
endmodule


module picorv32_DW01_inc_0 ( A, SUM );
  input [63:0] A;
  output [63:0] SUM;

  wire   [63:2] carry;

  sky130_fd_sc_hd__ha_1 U1_1_62 ( .A(A[62]), .B(carry[62]), .COUT(carry[63]), 
        .SUM(SUM[62]) );
  sky130_fd_sc_hd__ha_1 U1_1_61 ( .A(A[61]), .B(carry[61]), .COUT(carry[62]), 
        .SUM(SUM[61]) );
  sky130_fd_sc_hd__ha_1 U1_1_60 ( .A(A[60]), .B(carry[60]), .COUT(carry[61]), 
        .SUM(SUM[60]) );
  sky130_fd_sc_hd__ha_1 U1_1_59 ( .A(A[59]), .B(carry[59]), .COUT(carry[60]), 
        .SUM(SUM[59]) );
  sky130_fd_sc_hd__ha_1 U1_1_58 ( .A(A[58]), .B(carry[58]), .COUT(carry[59]), 
        .SUM(SUM[58]) );
  sky130_fd_sc_hd__ha_1 U1_1_57 ( .A(A[57]), .B(carry[57]), .COUT(carry[58]), 
        .SUM(SUM[57]) );
  sky130_fd_sc_hd__ha_1 U1_1_56 ( .A(A[56]), .B(carry[56]), .COUT(carry[57]), 
        .SUM(SUM[56]) );
  sky130_fd_sc_hd__ha_1 U1_1_55 ( .A(A[55]), .B(carry[55]), .COUT(carry[56]), 
        .SUM(SUM[55]) );
  sky130_fd_sc_hd__ha_1 U1_1_54 ( .A(A[54]), .B(carry[54]), .COUT(carry[55]), 
        .SUM(SUM[54]) );
  sky130_fd_sc_hd__ha_1 U1_1_53 ( .A(A[53]), .B(carry[53]), .COUT(carry[54]), 
        .SUM(SUM[53]) );
  sky130_fd_sc_hd__ha_1 U1_1_52 ( .A(A[52]), .B(carry[52]), .COUT(carry[53]), 
        .SUM(SUM[52]) );
  sky130_fd_sc_hd__ha_1 U1_1_51 ( .A(A[51]), .B(carry[51]), .COUT(carry[52]), 
        .SUM(SUM[51]) );
  sky130_fd_sc_hd__ha_1 U1_1_50 ( .A(A[50]), .B(carry[50]), .COUT(carry[51]), 
        .SUM(SUM[50]) );
  sky130_fd_sc_hd__ha_1 U1_1_49 ( .A(A[49]), .B(carry[49]), .COUT(carry[50]), 
        .SUM(SUM[49]) );
  sky130_fd_sc_hd__ha_1 U1_1_48 ( .A(A[48]), .B(carry[48]), .COUT(carry[49]), 
        .SUM(SUM[48]) );
  sky130_fd_sc_hd__ha_1 U1_1_47 ( .A(A[47]), .B(carry[47]), .COUT(carry[48]), 
        .SUM(SUM[47]) );
  sky130_fd_sc_hd__ha_1 U1_1_46 ( .A(A[46]), .B(carry[46]), .COUT(carry[47]), 
        .SUM(SUM[46]) );
  sky130_fd_sc_hd__ha_1 U1_1_45 ( .A(A[45]), .B(carry[45]), .COUT(carry[46]), 
        .SUM(SUM[45]) );
  sky130_fd_sc_hd__ha_1 U1_1_44 ( .A(A[44]), .B(carry[44]), .COUT(carry[45]), 
        .SUM(SUM[44]) );
  sky130_fd_sc_hd__ha_1 U1_1_43 ( .A(A[43]), .B(carry[43]), .COUT(carry[44]), 
        .SUM(SUM[43]) );
  sky130_fd_sc_hd__ha_1 U1_1_42 ( .A(A[42]), .B(carry[42]), .COUT(carry[43]), 
        .SUM(SUM[42]) );
  sky130_fd_sc_hd__ha_1 U1_1_41 ( .A(A[41]), .B(carry[41]), .COUT(carry[42]), 
        .SUM(SUM[41]) );
  sky130_fd_sc_hd__ha_1 U1_1_40 ( .A(A[40]), .B(carry[40]), .COUT(carry[41]), 
        .SUM(SUM[40]) );
  sky130_fd_sc_hd__ha_1 U1_1_39 ( .A(A[39]), .B(carry[39]), .COUT(carry[40]), 
        .SUM(SUM[39]) );
  sky130_fd_sc_hd__ha_1 U1_1_38 ( .A(A[38]), .B(carry[38]), .COUT(carry[39]), 
        .SUM(SUM[38]) );
  sky130_fd_sc_hd__ha_1 U1_1_37 ( .A(A[37]), .B(carry[37]), .COUT(carry[38]), 
        .SUM(SUM[37]) );
  sky130_fd_sc_hd__ha_1 U1_1_36 ( .A(A[36]), .B(carry[36]), .COUT(carry[37]), 
        .SUM(SUM[36]) );
  sky130_fd_sc_hd__ha_1 U1_1_35 ( .A(A[35]), .B(carry[35]), .COUT(carry[36]), 
        .SUM(SUM[35]) );
  sky130_fd_sc_hd__ha_1 U1_1_34 ( .A(A[34]), .B(carry[34]), .COUT(carry[35]), 
        .SUM(SUM[34]) );
  sky130_fd_sc_hd__ha_1 U1_1_33 ( .A(A[33]), .B(carry[33]), .COUT(carry[34]), 
        .SUM(SUM[33]) );
  sky130_fd_sc_hd__ha_1 U1_1_32 ( .A(A[32]), .B(carry[32]), .COUT(carry[33]), 
        .SUM(SUM[32]) );
  sky130_fd_sc_hd__ha_1 U1_1_31 ( .A(A[31]), .B(carry[31]), .COUT(carry[32]), 
        .SUM(SUM[31]) );
  sky130_fd_sc_hd__ha_1 U1_1_30 ( .A(A[30]), .B(carry[30]), .COUT(carry[31]), 
        .SUM(SUM[30]) );
  sky130_fd_sc_hd__ha_1 U1_1_29 ( .A(A[29]), .B(carry[29]), .COUT(carry[30]), 
        .SUM(SUM[29]) );
  sky130_fd_sc_hd__ha_1 U1_1_28 ( .A(A[28]), .B(carry[28]), .COUT(carry[29]), 
        .SUM(SUM[28]) );
  sky130_fd_sc_hd__ha_1 U1_1_27 ( .A(A[27]), .B(carry[27]), .COUT(carry[28]), 
        .SUM(SUM[27]) );
  sky130_fd_sc_hd__ha_1 U1_1_26 ( .A(A[26]), .B(carry[26]), .COUT(carry[27]), 
        .SUM(SUM[26]) );
  sky130_fd_sc_hd__ha_1 U1_1_25 ( .A(A[25]), .B(carry[25]), .COUT(carry[26]), 
        .SUM(SUM[25]) );
  sky130_fd_sc_hd__ha_1 U1_1_24 ( .A(A[24]), .B(carry[24]), .COUT(carry[25]), 
        .SUM(SUM[24]) );
  sky130_fd_sc_hd__ha_1 U1_1_23 ( .A(A[23]), .B(carry[23]), .COUT(carry[24]), 
        .SUM(SUM[23]) );
  sky130_fd_sc_hd__ha_1 U1_1_22 ( .A(A[22]), .B(carry[22]), .COUT(carry[23]), 
        .SUM(SUM[22]) );
  sky130_fd_sc_hd__ha_1 U1_1_21 ( .A(A[21]), .B(carry[21]), .COUT(carry[22]), 
        .SUM(SUM[21]) );
  sky130_fd_sc_hd__ha_1 U1_1_20 ( .A(A[20]), .B(carry[20]), .COUT(carry[21]), 
        .SUM(SUM[20]) );
  sky130_fd_sc_hd__ha_1 U1_1_19 ( .A(A[19]), .B(carry[19]), .COUT(carry[20]), 
        .SUM(SUM[19]) );
  sky130_fd_sc_hd__ha_1 U1_1_18 ( .A(A[18]), .B(carry[18]), .COUT(carry[19]), 
        .SUM(SUM[18]) );
  sky130_fd_sc_hd__ha_1 U1_1_17 ( .A(A[17]), .B(carry[17]), .COUT(carry[18]), 
        .SUM(SUM[17]) );
  sky130_fd_sc_hd__ha_1 U1_1_16 ( .A(A[16]), .B(carry[16]), .COUT(carry[17]), 
        .SUM(SUM[16]) );
  sky130_fd_sc_hd__ha_1 U1_1_15 ( .A(A[15]), .B(carry[15]), .COUT(carry[16]), 
        .SUM(SUM[15]) );
  sky130_fd_sc_hd__ha_1 U1_1_14 ( .A(A[14]), .B(carry[14]), .COUT(carry[15]), 
        .SUM(SUM[14]) );
  sky130_fd_sc_hd__ha_1 U1_1_13 ( .A(A[13]), .B(carry[13]), .COUT(carry[14]), 
        .SUM(SUM[13]) );
  sky130_fd_sc_hd__ha_1 U1_1_12 ( .A(A[12]), .B(carry[12]), .COUT(carry[13]), 
        .SUM(SUM[12]) );
  sky130_fd_sc_hd__ha_1 U1_1_11 ( .A(A[11]), .B(carry[11]), .COUT(carry[12]), 
        .SUM(SUM[11]) );
  sky130_fd_sc_hd__ha_1 U1_1_10 ( .A(A[10]), .B(carry[10]), .COUT(carry[11]), 
        .SUM(SUM[10]) );
  sky130_fd_sc_hd__ha_1 U1_1_9 ( .A(A[9]), .B(carry[9]), .COUT(carry[10]), 
        .SUM(SUM[9]) );
  sky130_fd_sc_hd__ha_1 U1_1_8 ( .A(A[8]), .B(carry[8]), .COUT(carry[9]), 
        .SUM(SUM[8]) );
  sky130_fd_sc_hd__ha_1 U1_1_7 ( .A(A[7]), .B(carry[7]), .COUT(carry[8]), 
        .SUM(SUM[7]) );
  sky130_fd_sc_hd__ha_1 U1_1_6 ( .A(A[6]), .B(carry[6]), .COUT(carry[7]), 
        .SUM(SUM[6]) );
  sky130_fd_sc_hd__ha_1 U1_1_5 ( .A(A[5]), .B(carry[5]), .COUT(carry[6]), 
        .SUM(SUM[5]) );
  sky130_fd_sc_hd__ha_1 U1_1_4 ( .A(A[4]), .B(carry[4]), .COUT(carry[5]), 
        .SUM(SUM[4]) );
  sky130_fd_sc_hd__ha_1 U1_1_3 ( .A(A[3]), .B(carry[3]), .COUT(carry[4]), 
        .SUM(SUM[3]) );
  sky130_fd_sc_hd__ha_1 U1_1_2 ( .A(A[2]), .B(carry[2]), .COUT(carry[3]), 
        .SUM(SUM[2]) );
  sky130_fd_sc_hd__ha_1 U1_1_1 ( .A(A[1]), .B(A[0]), .COUT(carry[2]), .SUM(
        SUM[1]) );
  sky130_fd_sc_hd__inv_2 U1 ( .A(A[0]), .Y(SUM[0]) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(carry[63]), .B(A[63]), .X(SUM[63]) );
endmodule


module picorv32_DW01_add_2 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   \A[0] , n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14,
         n15, n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28;
  assign SUM[1] = A[1];
  assign SUM[0] = \A[0] ;
  assign \A[0]  = A[0];

  sky130_fd_sc_hd__and2_0 U1 ( .A(A[3]), .B(A[2]), .X(n1) );
  sky130_fd_sc_hd__and2_0 U2 ( .A(A[4]), .B(n1), .X(n2) );
  sky130_fd_sc_hd__and2_0 U3 ( .A(A[5]), .B(n2), .X(n3) );
  sky130_fd_sc_hd__and2_0 U4 ( .A(A[6]), .B(n3), .X(n4) );
  sky130_fd_sc_hd__and2_0 U5 ( .A(A[7]), .B(n4), .X(n5) );
  sky130_fd_sc_hd__and2_0 U6 ( .A(A[8]), .B(n5), .X(n6) );
  sky130_fd_sc_hd__and2_0 U7 ( .A(A[9]), .B(n6), .X(n7) );
  sky130_fd_sc_hd__and2_0 U8 ( .A(A[10]), .B(n7), .X(n8) );
  sky130_fd_sc_hd__and2_0 U9 ( .A(A[11]), .B(n8), .X(n9) );
  sky130_fd_sc_hd__and2_0 U10 ( .A(A[12]), .B(n9), .X(n10) );
  sky130_fd_sc_hd__and2_0 U11 ( .A(A[13]), .B(n10), .X(n11) );
  sky130_fd_sc_hd__and2_0 U12 ( .A(A[14]), .B(n11), .X(n12) );
  sky130_fd_sc_hd__and2_0 U13 ( .A(A[15]), .B(n12), .X(n13) );
  sky130_fd_sc_hd__and2_0 U14 ( .A(A[16]), .B(n13), .X(n14) );
  sky130_fd_sc_hd__and2_0 U15 ( .A(A[17]), .B(n14), .X(n15) );
  sky130_fd_sc_hd__and2_0 U16 ( .A(A[18]), .B(n15), .X(n16) );
  sky130_fd_sc_hd__and2_0 U17 ( .A(A[19]), .B(n16), .X(n17) );
  sky130_fd_sc_hd__and2_0 U18 ( .A(A[20]), .B(n17), .X(n18) );
  sky130_fd_sc_hd__and2_0 U19 ( .A(A[21]), .B(n18), .X(n19) );
  sky130_fd_sc_hd__and2_0 U20 ( .A(A[22]), .B(n19), .X(n20) );
  sky130_fd_sc_hd__and2_0 U21 ( .A(A[23]), .B(n20), .X(n21) );
  sky130_fd_sc_hd__and2_0 U22 ( .A(A[24]), .B(n21), .X(n22) );
  sky130_fd_sc_hd__and2_0 U23 ( .A(A[25]), .B(n22), .X(n23) );
  sky130_fd_sc_hd__and2_0 U24 ( .A(A[26]), .B(n23), .X(n24) );
  sky130_fd_sc_hd__and2_0 U25 ( .A(A[27]), .B(n24), .X(n25) );
  sky130_fd_sc_hd__and2_0 U26 ( .A(A[28]), .B(n25), .X(n26) );
  sky130_fd_sc_hd__and2_0 U27 ( .A(A[29]), .B(n26), .X(n27) );
  sky130_fd_sc_hd__and2_0 U28 ( .A(A[30]), .B(n27), .X(n28) );
  sky130_fd_sc_hd__inv_2 U29 ( .A(A[2]), .Y(SUM[2]) );
  sky130_fd_sc_hd__xor2_1 U30 ( .A(A[31]), .B(n28), .X(SUM[31]) );
  sky130_fd_sc_hd__xor2_1 U31 ( .A(A[30]), .B(n27), .X(SUM[30]) );
  sky130_fd_sc_hd__xor2_1 U32 ( .A(A[29]), .B(n26), .X(SUM[29]) );
  sky130_fd_sc_hd__xor2_1 U33 ( .A(A[28]), .B(n25), .X(SUM[28]) );
  sky130_fd_sc_hd__xor2_1 U34 ( .A(A[27]), .B(n24), .X(SUM[27]) );
  sky130_fd_sc_hd__xor2_1 U35 ( .A(A[26]), .B(n23), .X(SUM[26]) );
  sky130_fd_sc_hd__xor2_1 U36 ( .A(A[25]), .B(n22), .X(SUM[25]) );
  sky130_fd_sc_hd__xor2_1 U37 ( .A(A[24]), .B(n21), .X(SUM[24]) );
  sky130_fd_sc_hd__xor2_1 U38 ( .A(A[23]), .B(n20), .X(SUM[23]) );
  sky130_fd_sc_hd__xor2_1 U39 ( .A(A[22]), .B(n19), .X(SUM[22]) );
  sky130_fd_sc_hd__xor2_1 U40 ( .A(A[21]), .B(n18), .X(SUM[21]) );
  sky130_fd_sc_hd__xor2_1 U41 ( .A(A[20]), .B(n17), .X(SUM[20]) );
  sky130_fd_sc_hd__xor2_1 U42 ( .A(A[19]), .B(n16), .X(SUM[19]) );
  sky130_fd_sc_hd__xor2_1 U43 ( .A(A[18]), .B(n15), .X(SUM[18]) );
  sky130_fd_sc_hd__xor2_1 U44 ( .A(A[17]), .B(n14), .X(SUM[17]) );
  sky130_fd_sc_hd__xor2_1 U45 ( .A(A[16]), .B(n13), .X(SUM[16]) );
  sky130_fd_sc_hd__xor2_1 U46 ( .A(A[15]), .B(n12), .X(SUM[15]) );
  sky130_fd_sc_hd__xor2_1 U47 ( .A(A[14]), .B(n11), .X(SUM[14]) );
  sky130_fd_sc_hd__xor2_1 U48 ( .A(A[13]), .B(n10), .X(SUM[13]) );
  sky130_fd_sc_hd__xor2_1 U49 ( .A(A[12]), .B(n9), .X(SUM[12]) );
  sky130_fd_sc_hd__xor2_1 U50 ( .A(A[11]), .B(n8), .X(SUM[11]) );
  sky130_fd_sc_hd__xor2_1 U51 ( .A(A[10]), .B(n7), .X(SUM[10]) );
  sky130_fd_sc_hd__xor2_1 U52 ( .A(A[9]), .B(n6), .X(SUM[9]) );
  sky130_fd_sc_hd__xor2_1 U53 ( .A(A[8]), .B(n5), .X(SUM[8]) );
  sky130_fd_sc_hd__xor2_1 U54 ( .A(A[7]), .B(n4), .X(SUM[7]) );
  sky130_fd_sc_hd__xor2_1 U55 ( .A(A[6]), .B(n3), .X(SUM[6]) );
  sky130_fd_sc_hd__xor2_1 U56 ( .A(A[5]), .B(n2), .X(SUM[5]) );
  sky130_fd_sc_hd__xor2_1 U57 ( .A(A[4]), .B(n1), .X(SUM[4]) );
  sky130_fd_sc_hd__xor2_1 U58 ( .A(A[3]), .B(A[2]), .X(SUM[3]) );
endmodule


module picorv32_DW01_inc_1 ( A, SUM );
  input [63:0] A;
  output [63:0] SUM;

  wire   [63:2] carry;

  sky130_fd_sc_hd__ha_1 U1_1_62 ( .A(A[62]), .B(carry[62]), .COUT(carry[63]), 
        .SUM(SUM[62]) );
  sky130_fd_sc_hd__ha_1 U1_1_61 ( .A(A[61]), .B(carry[61]), .COUT(carry[62]), 
        .SUM(SUM[61]) );
  sky130_fd_sc_hd__ha_1 U1_1_60 ( .A(A[60]), .B(carry[60]), .COUT(carry[61]), 
        .SUM(SUM[60]) );
  sky130_fd_sc_hd__ha_1 U1_1_59 ( .A(A[59]), .B(carry[59]), .COUT(carry[60]), 
        .SUM(SUM[59]) );
  sky130_fd_sc_hd__ha_1 U1_1_58 ( .A(A[58]), .B(carry[58]), .COUT(carry[59]), 
        .SUM(SUM[58]) );
  sky130_fd_sc_hd__ha_1 U1_1_57 ( .A(A[57]), .B(carry[57]), .COUT(carry[58]), 
        .SUM(SUM[57]) );
  sky130_fd_sc_hd__ha_1 U1_1_56 ( .A(A[56]), .B(carry[56]), .COUT(carry[57]), 
        .SUM(SUM[56]) );
  sky130_fd_sc_hd__ha_1 U1_1_55 ( .A(A[55]), .B(carry[55]), .COUT(carry[56]), 
        .SUM(SUM[55]) );
  sky130_fd_sc_hd__ha_1 U1_1_54 ( .A(A[54]), .B(carry[54]), .COUT(carry[55]), 
        .SUM(SUM[54]) );
  sky130_fd_sc_hd__ha_1 U1_1_53 ( .A(A[53]), .B(carry[53]), .COUT(carry[54]), 
        .SUM(SUM[53]) );
  sky130_fd_sc_hd__ha_1 U1_1_52 ( .A(A[52]), .B(carry[52]), .COUT(carry[53]), 
        .SUM(SUM[52]) );
  sky130_fd_sc_hd__ha_1 U1_1_51 ( .A(A[51]), .B(carry[51]), .COUT(carry[52]), 
        .SUM(SUM[51]) );
  sky130_fd_sc_hd__ha_1 U1_1_50 ( .A(A[50]), .B(carry[50]), .COUT(carry[51]), 
        .SUM(SUM[50]) );
  sky130_fd_sc_hd__ha_1 U1_1_49 ( .A(A[49]), .B(carry[49]), .COUT(carry[50]), 
        .SUM(SUM[49]) );
  sky130_fd_sc_hd__ha_1 U1_1_48 ( .A(A[48]), .B(carry[48]), .COUT(carry[49]), 
        .SUM(SUM[48]) );
  sky130_fd_sc_hd__ha_1 U1_1_47 ( .A(A[47]), .B(carry[47]), .COUT(carry[48]), 
        .SUM(SUM[47]) );
  sky130_fd_sc_hd__ha_1 U1_1_46 ( .A(A[46]), .B(carry[46]), .COUT(carry[47]), 
        .SUM(SUM[46]) );
  sky130_fd_sc_hd__ha_1 U1_1_45 ( .A(A[45]), .B(carry[45]), .COUT(carry[46]), 
        .SUM(SUM[45]) );
  sky130_fd_sc_hd__ha_1 U1_1_44 ( .A(A[44]), .B(carry[44]), .COUT(carry[45]), 
        .SUM(SUM[44]) );
  sky130_fd_sc_hd__ha_1 U1_1_43 ( .A(A[43]), .B(carry[43]), .COUT(carry[44]), 
        .SUM(SUM[43]) );
  sky130_fd_sc_hd__ha_1 U1_1_42 ( .A(A[42]), .B(carry[42]), .COUT(carry[43]), 
        .SUM(SUM[42]) );
  sky130_fd_sc_hd__ha_1 U1_1_41 ( .A(A[41]), .B(carry[41]), .COUT(carry[42]), 
        .SUM(SUM[41]) );
  sky130_fd_sc_hd__ha_1 U1_1_40 ( .A(A[40]), .B(carry[40]), .COUT(carry[41]), 
        .SUM(SUM[40]) );
  sky130_fd_sc_hd__ha_1 U1_1_39 ( .A(A[39]), .B(carry[39]), .COUT(carry[40]), 
        .SUM(SUM[39]) );
  sky130_fd_sc_hd__ha_1 U1_1_38 ( .A(A[38]), .B(carry[38]), .COUT(carry[39]), 
        .SUM(SUM[38]) );
  sky130_fd_sc_hd__ha_1 U1_1_37 ( .A(A[37]), .B(carry[37]), .COUT(carry[38]), 
        .SUM(SUM[37]) );
  sky130_fd_sc_hd__ha_1 U1_1_36 ( .A(A[36]), .B(carry[36]), .COUT(carry[37]), 
        .SUM(SUM[36]) );
  sky130_fd_sc_hd__ha_1 U1_1_35 ( .A(A[35]), .B(carry[35]), .COUT(carry[36]), 
        .SUM(SUM[35]) );
  sky130_fd_sc_hd__ha_1 U1_1_34 ( .A(A[34]), .B(carry[34]), .COUT(carry[35]), 
        .SUM(SUM[34]) );
  sky130_fd_sc_hd__ha_1 U1_1_33 ( .A(A[33]), .B(carry[33]), .COUT(carry[34]), 
        .SUM(SUM[33]) );
  sky130_fd_sc_hd__ha_1 U1_1_32 ( .A(A[32]), .B(carry[32]), .COUT(carry[33]), 
        .SUM(SUM[32]) );
  sky130_fd_sc_hd__ha_1 U1_1_31 ( .A(A[31]), .B(carry[31]), .COUT(carry[32]), 
        .SUM(SUM[31]) );
  sky130_fd_sc_hd__ha_1 U1_1_30 ( .A(A[30]), .B(carry[30]), .COUT(carry[31]), 
        .SUM(SUM[30]) );
  sky130_fd_sc_hd__ha_1 U1_1_29 ( .A(A[29]), .B(carry[29]), .COUT(carry[30]), 
        .SUM(SUM[29]) );
  sky130_fd_sc_hd__ha_1 U1_1_28 ( .A(A[28]), .B(carry[28]), .COUT(carry[29]), 
        .SUM(SUM[28]) );
  sky130_fd_sc_hd__ha_1 U1_1_27 ( .A(A[27]), .B(carry[27]), .COUT(carry[28]), 
        .SUM(SUM[27]) );
  sky130_fd_sc_hd__ha_1 U1_1_26 ( .A(A[26]), .B(carry[26]), .COUT(carry[27]), 
        .SUM(SUM[26]) );
  sky130_fd_sc_hd__ha_1 U1_1_25 ( .A(A[25]), .B(carry[25]), .COUT(carry[26]), 
        .SUM(SUM[25]) );
  sky130_fd_sc_hd__ha_1 U1_1_24 ( .A(A[24]), .B(carry[24]), .COUT(carry[25]), 
        .SUM(SUM[24]) );
  sky130_fd_sc_hd__ha_1 U1_1_23 ( .A(A[23]), .B(carry[23]), .COUT(carry[24]), 
        .SUM(SUM[23]) );
  sky130_fd_sc_hd__ha_1 U1_1_22 ( .A(A[22]), .B(carry[22]), .COUT(carry[23]), 
        .SUM(SUM[22]) );
  sky130_fd_sc_hd__ha_1 U1_1_21 ( .A(A[21]), .B(carry[21]), .COUT(carry[22]), 
        .SUM(SUM[21]) );
  sky130_fd_sc_hd__ha_1 U1_1_20 ( .A(A[20]), .B(carry[20]), .COUT(carry[21]), 
        .SUM(SUM[20]) );
  sky130_fd_sc_hd__ha_1 U1_1_19 ( .A(A[19]), .B(carry[19]), .COUT(carry[20]), 
        .SUM(SUM[19]) );
  sky130_fd_sc_hd__ha_1 U1_1_18 ( .A(A[18]), .B(carry[18]), .COUT(carry[19]), 
        .SUM(SUM[18]) );
  sky130_fd_sc_hd__ha_1 U1_1_17 ( .A(A[17]), .B(carry[17]), .COUT(carry[18]), 
        .SUM(SUM[17]) );
  sky130_fd_sc_hd__ha_1 U1_1_16 ( .A(A[16]), .B(carry[16]), .COUT(carry[17]), 
        .SUM(SUM[16]) );
  sky130_fd_sc_hd__ha_1 U1_1_15 ( .A(A[15]), .B(carry[15]), .COUT(carry[16]), 
        .SUM(SUM[15]) );
  sky130_fd_sc_hd__ha_1 U1_1_14 ( .A(A[14]), .B(carry[14]), .COUT(carry[15]), 
        .SUM(SUM[14]) );
  sky130_fd_sc_hd__ha_1 U1_1_13 ( .A(A[13]), .B(carry[13]), .COUT(carry[14]), 
        .SUM(SUM[13]) );
  sky130_fd_sc_hd__ha_1 U1_1_12 ( .A(A[12]), .B(carry[12]), .COUT(carry[13]), 
        .SUM(SUM[12]) );
  sky130_fd_sc_hd__ha_1 U1_1_11 ( .A(A[11]), .B(carry[11]), .COUT(carry[12]), 
        .SUM(SUM[11]) );
  sky130_fd_sc_hd__ha_1 U1_1_10 ( .A(A[10]), .B(carry[10]), .COUT(carry[11]), 
        .SUM(SUM[10]) );
  sky130_fd_sc_hd__ha_1 U1_1_9 ( .A(A[9]), .B(carry[9]), .COUT(carry[10]), 
        .SUM(SUM[9]) );
  sky130_fd_sc_hd__ha_1 U1_1_8 ( .A(A[8]), .B(carry[8]), .COUT(carry[9]), 
        .SUM(SUM[8]) );
  sky130_fd_sc_hd__ha_1 U1_1_7 ( .A(A[7]), .B(carry[7]), .COUT(carry[8]), 
        .SUM(SUM[7]) );
  sky130_fd_sc_hd__ha_1 U1_1_6 ( .A(A[6]), .B(carry[6]), .COUT(carry[7]), 
        .SUM(SUM[6]) );
  sky130_fd_sc_hd__ha_1 U1_1_5 ( .A(A[5]), .B(carry[5]), .COUT(carry[6]), 
        .SUM(SUM[5]) );
  sky130_fd_sc_hd__ha_1 U1_1_4 ( .A(A[4]), .B(carry[4]), .COUT(carry[5]), 
        .SUM(SUM[4]) );
  sky130_fd_sc_hd__ha_1 U1_1_3 ( .A(A[3]), .B(carry[3]), .COUT(carry[4]), 
        .SUM(SUM[3]) );
  sky130_fd_sc_hd__ha_1 U1_1_2 ( .A(A[2]), .B(carry[2]), .COUT(carry[3]), 
        .SUM(SUM[2]) );
  sky130_fd_sc_hd__ha_1 U1_1_1 ( .A(A[1]), .B(A[0]), .COUT(carry[2]), .SUM(
        SUM[1]) );
  sky130_fd_sc_hd__inv_2 U1 ( .A(A[0]), .Y(SUM[0]) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(carry[63]), .B(A[63]), .X(SUM[63]) );
endmodule


module picorv32_DW01_add_3 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   \A[0] , n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14,
         n15, n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28;
  assign SUM[1] = A[1];
  assign SUM[0] = \A[0] ;
  assign \A[0]  = A[0];

  sky130_fd_sc_hd__inv_2 U1 ( .A(A[2]), .Y(SUM[2]) );
  sky130_fd_sc_hd__xnor2_1 U2 ( .A(A[31]), .B(n28), .Y(SUM[31]) );
  sky130_fd_sc_hd__and2_0 U3 ( .A(A[3]), .B(A[2]), .X(n1) );
  sky130_fd_sc_hd__and2_0 U4 ( .A(A[4]), .B(n1), .X(n2) );
  sky130_fd_sc_hd__and2_0 U5 ( .A(A[5]), .B(n2), .X(n3) );
  sky130_fd_sc_hd__and2_0 U6 ( .A(A[6]), .B(n3), .X(n4) );
  sky130_fd_sc_hd__and2_0 U7 ( .A(A[7]), .B(n4), .X(n5) );
  sky130_fd_sc_hd__and2_0 U8 ( .A(A[8]), .B(n5), .X(n6) );
  sky130_fd_sc_hd__and2_0 U9 ( .A(A[9]), .B(n6), .X(n7) );
  sky130_fd_sc_hd__and2_0 U10 ( .A(A[10]), .B(n7), .X(n8) );
  sky130_fd_sc_hd__and2_0 U11 ( .A(A[11]), .B(n8), .X(n9) );
  sky130_fd_sc_hd__and2_0 U12 ( .A(A[12]), .B(n9), .X(n10) );
  sky130_fd_sc_hd__and2_0 U13 ( .A(A[13]), .B(n10), .X(n11) );
  sky130_fd_sc_hd__and2_0 U14 ( .A(A[14]), .B(n11), .X(n12) );
  sky130_fd_sc_hd__and2_0 U15 ( .A(A[15]), .B(n12), .X(n13) );
  sky130_fd_sc_hd__and2_0 U16 ( .A(A[16]), .B(n13), .X(n14) );
  sky130_fd_sc_hd__and2_0 U17 ( .A(A[17]), .B(n14), .X(n15) );
  sky130_fd_sc_hd__and2_0 U18 ( .A(A[18]), .B(n15), .X(n16) );
  sky130_fd_sc_hd__and2_0 U19 ( .A(A[19]), .B(n16), .X(n17) );
  sky130_fd_sc_hd__and2_0 U20 ( .A(A[20]), .B(n17), .X(n18) );
  sky130_fd_sc_hd__and2_0 U21 ( .A(A[21]), .B(n18), .X(n19) );
  sky130_fd_sc_hd__and2_0 U22 ( .A(A[22]), .B(n19), .X(n20) );
  sky130_fd_sc_hd__and2_0 U23 ( .A(A[23]), .B(n20), .X(n21) );
  sky130_fd_sc_hd__and2_0 U24 ( .A(A[24]), .B(n21), .X(n22) );
  sky130_fd_sc_hd__and2_0 U25 ( .A(A[25]), .B(n22), .X(n23) );
  sky130_fd_sc_hd__and2_0 U26 ( .A(A[26]), .B(n23), .X(n24) );
  sky130_fd_sc_hd__and2_0 U27 ( .A(A[27]), .B(n24), .X(n25) );
  sky130_fd_sc_hd__and2_0 U28 ( .A(A[28]), .B(n25), .X(n26) );
  sky130_fd_sc_hd__and2_0 U29 ( .A(A[29]), .B(n26), .X(n27) );
  sky130_fd_sc_hd__xor2_1 U30 ( .A(A[30]), .B(n27), .X(SUM[30]) );
  sky130_fd_sc_hd__nand2_1 U31 ( .A(A[30]), .B(n27), .Y(n28) );
  sky130_fd_sc_hd__xor2_1 U32 ( .A(A[29]), .B(n26), .X(SUM[29]) );
  sky130_fd_sc_hd__xor2_1 U33 ( .A(A[28]), .B(n25), .X(SUM[28]) );
  sky130_fd_sc_hd__xor2_1 U34 ( .A(A[27]), .B(n24), .X(SUM[27]) );
  sky130_fd_sc_hd__xor2_1 U35 ( .A(A[26]), .B(n23), .X(SUM[26]) );
  sky130_fd_sc_hd__xor2_1 U36 ( .A(A[25]), .B(n22), .X(SUM[25]) );
  sky130_fd_sc_hd__xor2_1 U37 ( .A(A[24]), .B(n21), .X(SUM[24]) );
  sky130_fd_sc_hd__xor2_1 U38 ( .A(A[23]), .B(n20), .X(SUM[23]) );
  sky130_fd_sc_hd__xor2_1 U39 ( .A(A[22]), .B(n19), .X(SUM[22]) );
  sky130_fd_sc_hd__xor2_1 U40 ( .A(A[21]), .B(n18), .X(SUM[21]) );
  sky130_fd_sc_hd__xor2_1 U41 ( .A(A[20]), .B(n17), .X(SUM[20]) );
  sky130_fd_sc_hd__xor2_1 U42 ( .A(A[19]), .B(n16), .X(SUM[19]) );
  sky130_fd_sc_hd__xor2_1 U43 ( .A(A[18]), .B(n15), .X(SUM[18]) );
  sky130_fd_sc_hd__xor2_1 U44 ( .A(A[17]), .B(n14), .X(SUM[17]) );
  sky130_fd_sc_hd__xor2_1 U45 ( .A(A[16]), .B(n13), .X(SUM[16]) );
  sky130_fd_sc_hd__xor2_1 U46 ( .A(A[15]), .B(n12), .X(SUM[15]) );
  sky130_fd_sc_hd__xor2_1 U47 ( .A(A[14]), .B(n11), .X(SUM[14]) );
  sky130_fd_sc_hd__xor2_1 U48 ( .A(A[13]), .B(n10), .X(SUM[13]) );
  sky130_fd_sc_hd__xor2_1 U49 ( .A(A[12]), .B(n9), .X(SUM[12]) );
  sky130_fd_sc_hd__xor2_1 U50 ( .A(A[11]), .B(n8), .X(SUM[11]) );
  sky130_fd_sc_hd__xor2_1 U51 ( .A(A[10]), .B(n7), .X(SUM[10]) );
  sky130_fd_sc_hd__xor2_1 U52 ( .A(A[9]), .B(n6), .X(SUM[9]) );
  sky130_fd_sc_hd__xor2_1 U53 ( .A(A[8]), .B(n5), .X(SUM[8]) );
  sky130_fd_sc_hd__xor2_1 U54 ( .A(A[7]), .B(n4), .X(SUM[7]) );
  sky130_fd_sc_hd__xor2_1 U55 ( .A(A[6]), .B(n3), .X(SUM[6]) );
  sky130_fd_sc_hd__xor2_1 U56 ( .A(A[5]), .B(n2), .X(SUM[5]) );
  sky130_fd_sc_hd__xor2_1 U57 ( .A(A[4]), .B(n1), .X(SUM[4]) );
  sky130_fd_sc_hd__xor2_1 U58 ( .A(A[3]), .B(A[2]), .X(SUM[3]) );
endmodule


module picorv32_DW01_add_4 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   n1;
  wire   [31:1] carry;

  sky130_fd_sc_hd__fa_1 U1_31 ( .A(A[31]), .B(B[31]), .CIN(carry[31]), .SUM(
        SUM[31]) );
  sky130_fd_sc_hd__fa_1 U1_1 ( .A(A[1]), .B(B[1]), .CIN(n1), .COUT(carry[2]), 
        .SUM(SUM[1]) );
  sky130_fd_sc_hd__fa_1 U1_29 ( .A(A[29]), .B(B[29]), .CIN(carry[29]), .COUT(
        carry[30]), .SUM(SUM[29]) );
  sky130_fd_sc_hd__fa_1 U1_30 ( .A(A[30]), .B(B[30]), .CIN(carry[30]), .COUT(
        carry[31]), .SUM(SUM[30]) );
  sky130_fd_sc_hd__fa_1 U1_28 ( .A(A[28]), .B(B[28]), .CIN(carry[28]), .COUT(
        carry[29]), .SUM(SUM[28]) );
  sky130_fd_sc_hd__fa_1 U1_27 ( .A(A[27]), .B(B[27]), .CIN(carry[27]), .COUT(
        carry[28]), .SUM(SUM[27]) );
  sky130_fd_sc_hd__fa_1 U1_26 ( .A(A[26]), .B(B[26]), .CIN(carry[26]), .COUT(
        carry[27]), .SUM(SUM[26]) );
  sky130_fd_sc_hd__fa_1 U1_25 ( .A(A[25]), .B(B[25]), .CIN(carry[25]), .COUT(
        carry[26]), .SUM(SUM[25]) );
  sky130_fd_sc_hd__fa_1 U1_24 ( .A(A[24]), .B(B[24]), .CIN(carry[24]), .COUT(
        carry[25]), .SUM(SUM[24]) );
  sky130_fd_sc_hd__fa_1 U1_23 ( .A(A[23]), .B(B[23]), .CIN(carry[23]), .COUT(
        carry[24]), .SUM(SUM[23]) );
  sky130_fd_sc_hd__fa_1 U1_22 ( .A(A[22]), .B(B[22]), .CIN(carry[22]), .COUT(
        carry[23]), .SUM(SUM[22]) );
  sky130_fd_sc_hd__fa_1 U1_21 ( .A(A[21]), .B(B[21]), .CIN(carry[21]), .COUT(
        carry[22]), .SUM(SUM[21]) );
  sky130_fd_sc_hd__fa_1 U1_20 ( .A(A[20]), .B(B[20]), .CIN(carry[20]), .COUT(
        carry[21]), .SUM(SUM[20]) );
  sky130_fd_sc_hd__fa_1 U1_19 ( .A(A[19]), .B(B[19]), .CIN(carry[19]), .COUT(
        carry[20]), .SUM(SUM[19]) );
  sky130_fd_sc_hd__fa_1 U1_18 ( .A(A[18]), .B(B[18]), .CIN(carry[18]), .COUT(
        carry[19]), .SUM(SUM[18]) );
  sky130_fd_sc_hd__fa_1 U1_17 ( .A(A[17]), .B(B[17]), .CIN(carry[17]), .COUT(
        carry[18]), .SUM(SUM[17]) );
  sky130_fd_sc_hd__fa_1 U1_16 ( .A(A[16]), .B(B[16]), .CIN(carry[16]), .COUT(
        carry[17]), .SUM(SUM[16]) );
  sky130_fd_sc_hd__fa_1 U1_15 ( .A(A[15]), .B(B[15]), .CIN(carry[15]), .COUT(
        carry[16]), .SUM(SUM[15]) );
  sky130_fd_sc_hd__fa_1 U1_14 ( .A(A[14]), .B(B[14]), .CIN(carry[14]), .COUT(
        carry[15]), .SUM(SUM[14]) );
  sky130_fd_sc_hd__fa_1 U1_13 ( .A(A[13]), .B(B[13]), .CIN(carry[13]), .COUT(
        carry[14]), .SUM(SUM[13]) );
  sky130_fd_sc_hd__fa_1 U1_12 ( .A(A[12]), .B(B[12]), .CIN(carry[12]), .COUT(
        carry[13]), .SUM(SUM[12]) );
  sky130_fd_sc_hd__fa_1 U1_11 ( .A(A[11]), .B(B[11]), .CIN(carry[11]), .COUT(
        carry[12]), .SUM(SUM[11]) );
  sky130_fd_sc_hd__fa_1 U1_10 ( .A(A[10]), .B(B[10]), .CIN(carry[10]), .COUT(
        carry[11]), .SUM(SUM[10]) );
  sky130_fd_sc_hd__fa_1 U1_9 ( .A(A[9]), .B(B[9]), .CIN(carry[9]), .COUT(
        carry[10]), .SUM(SUM[9]) );
  sky130_fd_sc_hd__fa_1 U1_8 ( .A(A[8]), .B(B[8]), .CIN(carry[8]), .COUT(
        carry[9]), .SUM(SUM[8]) );
  sky130_fd_sc_hd__fa_1 U1_7 ( .A(A[7]), .B(B[7]), .CIN(carry[7]), .COUT(
        carry[8]), .SUM(SUM[7]) );
  sky130_fd_sc_hd__fa_1 U1_6 ( .A(A[6]), .B(B[6]), .CIN(carry[6]), .COUT(
        carry[7]), .SUM(SUM[6]) );
  sky130_fd_sc_hd__fa_1 U1_5 ( .A(A[5]), .B(B[5]), .CIN(carry[5]), .COUT(
        carry[6]), .SUM(SUM[5]) );
  sky130_fd_sc_hd__fa_1 U1_4 ( .A(A[4]), .B(B[4]), .CIN(carry[4]), .COUT(
        carry[5]), .SUM(SUM[4]) );
  sky130_fd_sc_hd__fa_1 U1_3 ( .A(A[3]), .B(B[3]), .CIN(carry[3]), .COUT(
        carry[4]), .SUM(SUM[3]) );
  sky130_fd_sc_hd__fa_1 U1_2 ( .A(A[2]), .B(B[2]), .CIN(carry[2]), .COUT(
        carry[3]), .SUM(SUM[2]) );
  sky130_fd_sc_hd__and2_1 U1 ( .A(B[0]), .B(A[0]), .X(n1) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(B[0]), .B(A[0]), .X(SUM[0]) );
endmodule


module picorv32_DW01_sub_1 ( A, B, CI, DIFF, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33;
  wire   [32:0] carry;

  sky130_fd_sc_hd__fa_1 U2_31 ( .A(A[31]), .B(n2), .CIN(carry[31]), .SUM(
        DIFF[31]) );
  sky130_fd_sc_hd__fa_1 U2_1 ( .A(A[1]), .B(n31), .CIN(carry[1]), .COUT(
        carry[2]), .SUM(DIFF[1]) );
  sky130_fd_sc_hd__fa_1 U2_29 ( .A(A[29]), .B(n4), .CIN(carry[29]), .COUT(
        carry[30]), .SUM(DIFF[29]) );
  sky130_fd_sc_hd__fa_1 U2_30 ( .A(A[30]), .B(n3), .CIN(carry[30]), .COUT(
        carry[31]), .SUM(DIFF[30]) );
  sky130_fd_sc_hd__fa_1 U2_28 ( .A(A[28]), .B(n5), .CIN(carry[28]), .COUT(
        carry[29]), .SUM(DIFF[28]) );
  sky130_fd_sc_hd__fa_1 U2_27 ( .A(A[27]), .B(n6), .CIN(carry[27]), .COUT(
        carry[28]), .SUM(DIFF[27]) );
  sky130_fd_sc_hd__fa_1 U2_26 ( .A(A[26]), .B(n7), .CIN(carry[26]), .COUT(
        carry[27]), .SUM(DIFF[26]) );
  sky130_fd_sc_hd__fa_1 U2_25 ( .A(A[25]), .B(n8), .CIN(carry[25]), .COUT(
        carry[26]), .SUM(DIFF[25]) );
  sky130_fd_sc_hd__fa_1 U2_24 ( .A(A[24]), .B(n9), .CIN(carry[24]), .COUT(
        carry[25]), .SUM(DIFF[24]) );
  sky130_fd_sc_hd__fa_1 U2_23 ( .A(A[23]), .B(n10), .CIN(carry[23]), .COUT(
        carry[24]), .SUM(DIFF[23]) );
  sky130_fd_sc_hd__fa_1 U2_22 ( .A(A[22]), .B(n11), .CIN(carry[22]), .COUT(
        carry[23]), .SUM(DIFF[22]) );
  sky130_fd_sc_hd__fa_1 U2_21 ( .A(A[21]), .B(n12), .CIN(carry[21]), .COUT(
        carry[22]), .SUM(DIFF[21]) );
  sky130_fd_sc_hd__fa_1 U2_20 ( .A(A[20]), .B(n13), .CIN(carry[20]), .COUT(
        carry[21]), .SUM(DIFF[20]) );
  sky130_fd_sc_hd__fa_1 U2_19 ( .A(A[19]), .B(n14), .CIN(carry[19]), .COUT(
        carry[20]), .SUM(DIFF[19]) );
  sky130_fd_sc_hd__fa_1 U2_18 ( .A(A[18]), .B(n15), .CIN(carry[18]), .COUT(
        carry[19]), .SUM(DIFF[18]) );
  sky130_fd_sc_hd__fa_1 U2_17 ( .A(A[17]), .B(n16), .CIN(carry[17]), .COUT(
        carry[18]), .SUM(DIFF[17]) );
  sky130_fd_sc_hd__fa_1 U2_16 ( .A(A[16]), .B(n17), .CIN(carry[16]), .COUT(
        carry[17]), .SUM(DIFF[16]) );
  sky130_fd_sc_hd__fa_1 U2_15 ( .A(A[15]), .B(n18), .CIN(carry[15]), .COUT(
        carry[16]), .SUM(DIFF[15]) );
  sky130_fd_sc_hd__fa_1 U2_14 ( .A(A[14]), .B(n19), .CIN(carry[14]), .COUT(
        carry[15]), .SUM(DIFF[14]) );
  sky130_fd_sc_hd__fa_1 U2_13 ( .A(A[13]), .B(n20), .CIN(carry[13]), .COUT(
        carry[14]), .SUM(DIFF[13]) );
  sky130_fd_sc_hd__fa_1 U2_12 ( .A(A[12]), .B(n21), .CIN(carry[12]), .COUT(
        carry[13]), .SUM(DIFF[12]) );
  sky130_fd_sc_hd__fa_1 U2_11 ( .A(A[11]), .B(n32), .CIN(carry[11]), .COUT(
        carry[12]), .SUM(DIFF[11]) );
  sky130_fd_sc_hd__fa_1 U2_10 ( .A(A[10]), .B(n22), .CIN(carry[10]), .COUT(
        carry[11]), .SUM(DIFF[10]) );
  sky130_fd_sc_hd__fa_1 U2_9 ( .A(A[9]), .B(n23), .CIN(carry[9]), .COUT(
        carry[10]), .SUM(DIFF[9]) );
  sky130_fd_sc_hd__fa_1 U2_8 ( .A(A[8]), .B(n24), .CIN(carry[8]), .COUT(
        carry[9]), .SUM(DIFF[8]) );
  sky130_fd_sc_hd__fa_1 U2_7 ( .A(A[7]), .B(n25), .CIN(carry[7]), .COUT(
        carry[8]), .SUM(DIFF[7]) );
  sky130_fd_sc_hd__fa_1 U2_6 ( .A(A[6]), .B(n26), .CIN(carry[6]), .COUT(
        carry[7]), .SUM(DIFF[6]) );
  sky130_fd_sc_hd__fa_1 U2_5 ( .A(A[5]), .B(n27), .CIN(carry[5]), .COUT(
        carry[6]), .SUM(DIFF[5]) );
  sky130_fd_sc_hd__fa_1 U2_4 ( .A(A[4]), .B(n28), .CIN(carry[4]), .COUT(
        carry[5]), .SUM(DIFF[4]) );
  sky130_fd_sc_hd__fa_1 U2_3 ( .A(A[3]), .B(n29), .CIN(carry[3]), .COUT(
        carry[4]), .SUM(DIFF[3]) );
  sky130_fd_sc_hd__fa_1 U2_2 ( .A(A[2]), .B(n30), .CIN(carry[2]), .COUT(
        carry[3]), .SUM(DIFF[2]) );
  sky130_fd_sc_hd__inv_2 U1 ( .A(B[2]), .Y(n30) );
  sky130_fd_sc_hd__inv_2 U2 ( .A(B[3]), .Y(n29) );
  sky130_fd_sc_hd__inv_2 U3 ( .A(B[4]), .Y(n28) );
  sky130_fd_sc_hd__inv_2 U4 ( .A(B[5]), .Y(n27) );
  sky130_fd_sc_hd__inv_2 U5 ( .A(B[6]), .Y(n26) );
  sky130_fd_sc_hd__inv_2 U6 ( .A(B[7]), .Y(n25) );
  sky130_fd_sc_hd__inv_2 U7 ( .A(B[8]), .Y(n24) );
  sky130_fd_sc_hd__inv_2 U8 ( .A(B[9]), .Y(n23) );
  sky130_fd_sc_hd__inv_2 U9 ( .A(B[10]), .Y(n22) );
  sky130_fd_sc_hd__inv_2 U10 ( .A(B[11]), .Y(n32) );
  sky130_fd_sc_hd__inv_2 U11 ( .A(B[12]), .Y(n21) );
  sky130_fd_sc_hd__inv_2 U12 ( .A(B[13]), .Y(n20) );
  sky130_fd_sc_hd__inv_2 U13 ( .A(B[14]), .Y(n19) );
  sky130_fd_sc_hd__inv_2 U14 ( .A(B[15]), .Y(n18) );
  sky130_fd_sc_hd__inv_2 U15 ( .A(B[16]), .Y(n17) );
  sky130_fd_sc_hd__inv_2 U16 ( .A(B[17]), .Y(n16) );
  sky130_fd_sc_hd__inv_2 U17 ( .A(B[18]), .Y(n15) );
  sky130_fd_sc_hd__inv_2 U18 ( .A(B[19]), .Y(n14) );
  sky130_fd_sc_hd__inv_2 U19 ( .A(B[20]), .Y(n13) );
  sky130_fd_sc_hd__inv_2 U20 ( .A(B[21]), .Y(n12) );
  sky130_fd_sc_hd__inv_2 U21 ( .A(B[22]), .Y(n11) );
  sky130_fd_sc_hd__inv_2 U22 ( .A(B[23]), .Y(n10) );
  sky130_fd_sc_hd__inv_2 U23 ( .A(B[24]), .Y(n9) );
  sky130_fd_sc_hd__inv_2 U24 ( .A(B[25]), .Y(n8) );
  sky130_fd_sc_hd__inv_2 U25 ( .A(B[26]), .Y(n7) );
  sky130_fd_sc_hd__inv_2 U26 ( .A(B[27]), .Y(n6) );
  sky130_fd_sc_hd__inv_2 U27 ( .A(B[28]), .Y(n5) );
  sky130_fd_sc_hd__inv_2 U28 ( .A(B[30]), .Y(n3) );
  sky130_fd_sc_hd__inv_2 U29 ( .A(B[29]), .Y(n4) );
  sky130_fd_sc_hd__inv_2 U30 ( .A(B[1]), .Y(n31) );
  sky130_fd_sc_hd__inv_2 U31 ( .A(B[0]), .Y(n33) );
  sky130_fd_sc_hd__inv_2 U32 ( .A(A[0]), .Y(n1) );
  sky130_fd_sc_hd__inv_2 U33 ( .A(B[31]), .Y(n2) );
  sky130_fd_sc_hd__nand2_1 U34 ( .A(B[0]), .B(n1), .Y(carry[1]) );
  sky130_fd_sc_hd__xnor2_1 U35 ( .A(n33), .B(A[0]), .Y(DIFF[0]) );
endmodule


module picorv32_DW01_add_5 ( A, B, CI, SUM, CO );
  input [31:0] A;
  input [31:0] B;
  output [31:0] SUM;
  input CI;
  output CO;
  wire   n1;
  wire   [31:1] carry;

  sky130_fd_sc_hd__fa_1 U1_1 ( .A(A[1]), .B(B[1]), .CIN(n1), .COUT(carry[2]), 
        .SUM(SUM[1]) );
  sky130_fd_sc_hd__fa_1 U1_30 ( .A(A[30]), .B(B[30]), .CIN(carry[30]), .COUT(
        carry[31]), .SUM(SUM[30]) );
  sky130_fd_sc_hd__fa_1 U1_29 ( .A(A[29]), .B(B[29]), .CIN(carry[29]), .COUT(
        carry[30]), .SUM(SUM[29]) );
  sky130_fd_sc_hd__fa_1 U1_28 ( .A(A[28]), .B(B[28]), .CIN(carry[28]), .COUT(
        carry[29]), .SUM(SUM[28]) );
  sky130_fd_sc_hd__fa_1 U1_27 ( .A(A[27]), .B(B[27]), .CIN(carry[27]), .COUT(
        carry[28]), .SUM(SUM[27]) );
  sky130_fd_sc_hd__fa_1 U1_26 ( .A(A[26]), .B(B[26]), .CIN(carry[26]), .COUT(
        carry[27]), .SUM(SUM[26]) );
  sky130_fd_sc_hd__fa_1 U1_25 ( .A(A[25]), .B(B[25]), .CIN(carry[25]), .COUT(
        carry[26]), .SUM(SUM[25]) );
  sky130_fd_sc_hd__fa_1 U1_24 ( .A(A[24]), .B(B[24]), .CIN(carry[24]), .COUT(
        carry[25]), .SUM(SUM[24]) );
  sky130_fd_sc_hd__fa_1 U1_23 ( .A(A[23]), .B(B[23]), .CIN(carry[23]), .COUT(
        carry[24]), .SUM(SUM[23]) );
  sky130_fd_sc_hd__fa_1 U1_22 ( .A(A[22]), .B(B[22]), .CIN(carry[22]), .COUT(
        carry[23]), .SUM(SUM[22]) );
  sky130_fd_sc_hd__fa_1 U1_21 ( .A(A[21]), .B(B[21]), .CIN(carry[21]), .COUT(
        carry[22]), .SUM(SUM[21]) );
  sky130_fd_sc_hd__fa_1 U1_20 ( .A(A[20]), .B(B[20]), .CIN(carry[20]), .COUT(
        carry[21]), .SUM(SUM[20]) );
  sky130_fd_sc_hd__fa_1 U1_19 ( .A(A[19]), .B(B[19]), .CIN(carry[19]), .COUT(
        carry[20]), .SUM(SUM[19]) );
  sky130_fd_sc_hd__fa_1 U1_18 ( .A(A[18]), .B(B[18]), .CIN(carry[18]), .COUT(
        carry[19]), .SUM(SUM[18]) );
  sky130_fd_sc_hd__fa_1 U1_17 ( .A(A[17]), .B(B[17]), .CIN(carry[17]), .COUT(
        carry[18]), .SUM(SUM[17]) );
  sky130_fd_sc_hd__fa_1 U1_16 ( .A(A[16]), .B(B[16]), .CIN(carry[16]), .COUT(
        carry[17]), .SUM(SUM[16]) );
  sky130_fd_sc_hd__fa_1 U1_15 ( .A(A[15]), .B(B[15]), .CIN(carry[15]), .COUT(
        carry[16]), .SUM(SUM[15]) );
  sky130_fd_sc_hd__fa_1 U1_14 ( .A(A[14]), .B(B[14]), .CIN(carry[14]), .COUT(
        carry[15]), .SUM(SUM[14]) );
  sky130_fd_sc_hd__fa_1 U1_13 ( .A(A[13]), .B(B[13]), .CIN(carry[13]), .COUT(
        carry[14]), .SUM(SUM[13]) );
  sky130_fd_sc_hd__fa_1 U1_12 ( .A(A[12]), .B(B[12]), .CIN(carry[12]), .COUT(
        carry[13]), .SUM(SUM[12]) );
  sky130_fd_sc_hd__fa_1 U1_11 ( .A(A[11]), .B(B[11]), .CIN(carry[11]), .COUT(
        carry[12]), .SUM(SUM[11]) );
  sky130_fd_sc_hd__fa_1 U1_10 ( .A(A[10]), .B(B[10]), .CIN(carry[10]), .COUT(
        carry[11]), .SUM(SUM[10]) );
  sky130_fd_sc_hd__fa_1 U1_9 ( .A(A[9]), .B(B[9]), .CIN(carry[9]), .COUT(
        carry[10]), .SUM(SUM[9]) );
  sky130_fd_sc_hd__fa_1 U1_8 ( .A(A[8]), .B(B[8]), .CIN(carry[8]), .COUT(
        carry[9]), .SUM(SUM[8]) );
  sky130_fd_sc_hd__fa_1 U1_7 ( .A(A[7]), .B(B[7]), .CIN(carry[7]), .COUT(
        carry[8]), .SUM(SUM[7]) );
  sky130_fd_sc_hd__fa_1 U1_6 ( .A(A[6]), .B(B[6]), .CIN(carry[6]), .COUT(
        carry[7]), .SUM(SUM[6]) );
  sky130_fd_sc_hd__fa_1 U1_5 ( .A(A[5]), .B(B[5]), .CIN(carry[5]), .COUT(
        carry[6]), .SUM(SUM[5]) );
  sky130_fd_sc_hd__fa_1 U1_4 ( .A(A[4]), .B(B[4]), .CIN(carry[4]), .COUT(
        carry[5]), .SUM(SUM[4]) );
  sky130_fd_sc_hd__fa_1 U1_3 ( .A(A[3]), .B(B[3]), .CIN(carry[3]), .COUT(
        carry[4]), .SUM(SUM[3]) );
  sky130_fd_sc_hd__fa_1 U1_2 ( .A(A[2]), .B(B[2]), .CIN(carry[2]), .COUT(
        carry[3]), .SUM(SUM[2]) );
  sky130_fd_sc_hd__fa_1 U1_31 ( .A(A[31]), .B(B[31]), .CIN(carry[31]), .SUM(
        SUM[31]) );
  sky130_fd_sc_hd__and2_1 U1 ( .A(B[0]), .B(A[0]), .X(n1) );
  sky130_fd_sc_hd__xor2_1 U2 ( .A(B[0]), .B(A[0]), .X(SUM[0]) );
endmodule


module picorv32_DW01_cmp6_0 ( A, B, TC, LT, GT, EQ, LE, GE, NE );
  input [31:0] A;
  input [31:0] B;
  input TC;
  output LT, GT, EQ, LE, GE, NE;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44,
         n45, n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58,
         n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72,
         n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86,
         n87, n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99, n100,
         n101, n102, n103, n104, n105;

  sky130_fd_sc_hd__inv_2 U1 ( .A(B[31]), .Y(n2) );
  sky130_fd_sc_hd__inv_2 U2 ( .A(B[1]), .Y(n30) );
  sky130_fd_sc_hd__inv_2 U3 ( .A(A[1]), .Y(n32) );
  sky130_fd_sc_hd__inv_2 U4 ( .A(A[30]), .Y(n1) );
  sky130_fd_sc_hd__inv_2 U5 ( .A(B[9]), .Y(n22) );
  sky130_fd_sc_hd__inv_2 U6 ( .A(B[11]), .Y(n31) );
  sky130_fd_sc_hd__inv_2 U7 ( .A(B[13]), .Y(n19) );
  sky130_fd_sc_hd__inv_2 U8 ( .A(B[15]), .Y(n17) );
  sky130_fd_sc_hd__inv_2 U9 ( .A(B[8]), .Y(n23) );
  sky130_fd_sc_hd__inv_2 U10 ( .A(B[10]), .Y(n21) );
  sky130_fd_sc_hd__inv_2 U11 ( .A(B[12]), .Y(n20) );
  sky130_fd_sc_hd__inv_2 U12 ( .A(B[14]), .Y(n18) );
  sky130_fd_sc_hd__inv_2 U13 ( .A(B[28]), .Y(n4) );
  sky130_fd_sc_hd__inv_2 U14 ( .A(B[3]), .Y(n28) );
  sky130_fd_sc_hd__inv_2 U15 ( .A(B[5]), .Y(n26) );
  sky130_fd_sc_hd__inv_2 U16 ( .A(B[7]), .Y(n24) );
  sky130_fd_sc_hd__inv_2 U17 ( .A(B[2]), .Y(n29) );
  sky130_fd_sc_hd__inv_2 U18 ( .A(B[4]), .Y(n27) );
  sky130_fd_sc_hd__inv_2 U19 ( .A(B[6]), .Y(n25) );
  sky130_fd_sc_hd__inv_2 U20 ( .A(B[29]), .Y(n3) );
  sky130_fd_sc_hd__inv_2 U21 ( .A(B[17]), .Y(n15) );
  sky130_fd_sc_hd__inv_2 U22 ( .A(B[19]), .Y(n13) );
  sky130_fd_sc_hd__inv_2 U23 ( .A(B[21]), .Y(n11) );
  sky130_fd_sc_hd__inv_2 U24 ( .A(B[23]), .Y(n9) );
  sky130_fd_sc_hd__inv_2 U25 ( .A(B[25]), .Y(n7) );
  sky130_fd_sc_hd__inv_2 U26 ( .A(B[16]), .Y(n16) );
  sky130_fd_sc_hd__inv_2 U27 ( .A(B[18]), .Y(n14) );
  sky130_fd_sc_hd__inv_2 U28 ( .A(B[20]), .Y(n12) );
  sky130_fd_sc_hd__inv_2 U29 ( .A(B[22]), .Y(n10) );
  sky130_fd_sc_hd__inv_2 U30 ( .A(B[24]), .Y(n8) );
  sky130_fd_sc_hd__inv_2 U31 ( .A(B[26]), .Y(n6) );
  sky130_fd_sc_hd__inv_2 U32 ( .A(B[27]), .Y(n5) );
  sky130_fd_sc_hd__nor4_1 U33 ( .A(n33), .B(n34), .C(n35), .D(n36), .Y(EQ) );
  sky130_fd_sc_hd__nand4_1 U34 ( .A(n37), .B(n38), .C(n39), .D(n40), .Y(n36)
         );
  sky130_fd_sc_hd__o22ai_1 U35 ( .A1(A[1]), .A2(n41), .B1(n41), .B2(n30), .Y(
        n37) );
  sky130_fd_sc_hd__nor2b_1 U36 ( .B_N(A[0]), .A(B[0]), .Y(n41) );
  sky130_fd_sc_hd__nand4_1 U37 ( .A(n42), .B(n43), .C(n44), .D(n45), .Y(n35)
         );
  sky130_fd_sc_hd__nand2_1 U38 ( .A(n46), .B(n47), .Y(n34) );
  sky130_fd_sc_hd__and4_1 U39 ( .A(n48), .B(n49), .C(n50), .D(n51), .X(n47) );
  sky130_fd_sc_hd__and4_1 U40 ( .A(n52), .B(n53), .C(n54), .D(n55), .X(n46) );
  sky130_fd_sc_hd__nand4_1 U41 ( .A(n56), .B(n57), .C(n58), .D(n59), .Y(n33)
         );
  sky130_fd_sc_hd__nor4bb_1 U42 ( .C_N(n60), .D_N(n61), .A(LT), .B(n62), .Y(
        n59) );
  sky130_fd_sc_hd__o22ai_1 U43 ( .A1(A[31]), .A2(n2), .B1(n62), .B2(n63), .Y(
        LT) );
  sky130_fd_sc_hd__a32oi_1 U44 ( .A1(n38), .A2(n39), .A3(n64), .B1(B[30]), 
        .B2(n1), .Y(n63) );
  sky130_fd_sc_hd__o221ai_1 U45 ( .A1(A[28]), .A2(n4), .B1(A[29]), .B2(n3), 
        .C1(n65), .Y(n64) );
  sky130_fd_sc_hd__nand3_1 U46 ( .A(n40), .B(n42), .C(n66), .Y(n65) );
  sky130_fd_sc_hd__o221ai_1 U47 ( .A1(A[26]), .A2(n6), .B1(A[27]), .B2(n5), 
        .C1(n67), .Y(n66) );
  sky130_fd_sc_hd__nand3_1 U48 ( .A(n43), .B(n44), .C(n68), .Y(n67) );
  sky130_fd_sc_hd__o221ai_1 U49 ( .A1(A[24]), .A2(n8), .B1(A[25]), .B2(n7), 
        .C1(n69), .Y(n68) );
  sky130_fd_sc_hd__nand3_1 U50 ( .A(n45), .B(n55), .C(n70), .Y(n69) );
  sky130_fd_sc_hd__o221ai_1 U51 ( .A1(A[22]), .A2(n10), .B1(A[23]), .B2(n9), 
        .C1(n71), .Y(n70) );
  sky130_fd_sc_hd__nand3_1 U52 ( .A(n54), .B(n53), .C(n72), .Y(n71) );
  sky130_fd_sc_hd__o221ai_1 U53 ( .A1(A[20]), .A2(n12), .B1(A[21]), .B2(n11), 
        .C1(n73), .Y(n72) );
  sky130_fd_sc_hd__nand3_1 U54 ( .A(n52), .B(n51), .C(n74), .Y(n73) );
  sky130_fd_sc_hd__o221ai_1 U55 ( .A1(A[18]), .A2(n14), .B1(A[19]), .B2(n13), 
        .C1(n75), .Y(n74) );
  sky130_fd_sc_hd__nand3_1 U56 ( .A(n50), .B(n49), .C(n76), .Y(n75) );
  sky130_fd_sc_hd__o221ai_1 U57 ( .A1(A[16]), .A2(n16), .B1(A[17]), .B2(n15), 
        .C1(n77), .Y(n76) );
  sky130_fd_sc_hd__nand3_1 U58 ( .A(n48), .B(n78), .C(n79), .Y(n77) );
  sky130_fd_sc_hd__o221ai_1 U59 ( .A1(A[14]), .A2(n18), .B1(A[15]), .B2(n17), 
        .C1(n80), .Y(n79) );
  sky130_fd_sc_hd__nand3_1 U60 ( .A(n81), .B(n82), .C(n83), .Y(n80) );
  sky130_fd_sc_hd__o221ai_1 U61 ( .A1(A[12]), .A2(n20), .B1(A[13]), .B2(n19), 
        .C1(n84), .Y(n83) );
  sky130_fd_sc_hd__nand3_1 U62 ( .A(n85), .B(n86), .C(n87), .Y(n84) );
  sky130_fd_sc_hd__o221ai_1 U63 ( .A1(A[10]), .A2(n21), .B1(A[11]), .B2(n31), 
        .C1(n88), .Y(n87) );
  sky130_fd_sc_hd__nand3_1 U64 ( .A(n89), .B(n90), .C(n91), .Y(n88) );
  sky130_fd_sc_hd__o221ai_1 U65 ( .A1(A[8]), .A2(n23), .B1(A[9]), .B2(n22), 
        .C1(n92), .Y(n91) );
  sky130_fd_sc_hd__nand3_1 U66 ( .A(n93), .B(n94), .C(n95), .Y(n92) );
  sky130_fd_sc_hd__o221ai_1 U67 ( .A1(A[6]), .A2(n25), .B1(A[7]), .B2(n24), 
        .C1(n96), .Y(n95) );
  sky130_fd_sc_hd__nand3_1 U68 ( .A(n97), .B(n98), .C(n99), .Y(n96) );
  sky130_fd_sc_hd__o221ai_1 U69 ( .A1(A[4]), .A2(n27), .B1(A[5]), .B2(n26), 
        .C1(n100), .Y(n99) );
  sky130_fd_sc_hd__nand3_1 U70 ( .A(n101), .B(n61), .C(n102), .Y(n100) );
  sky130_fd_sc_hd__o221ai_1 U71 ( .A1(A[2]), .A2(n29), .B1(A[3]), .B2(n28), 
        .C1(n103), .Y(n102) );
  sky130_fd_sc_hd__o221ai_1 U72 ( .A1(B[1]), .A2(n104), .B1(n105), .B2(n32), 
        .C1(n60), .Y(n103) );
  sky130_fd_sc_hd__nor2b_1 U73 ( .B_N(n105), .A(A[1]), .Y(n104) );
  sky130_fd_sc_hd__nor2b_1 U74 ( .B_N(B[0]), .A(A[0]), .Y(n105) );
  sky130_fd_sc_hd__nand2_1 U75 ( .A(A[16]), .B(n16), .Y(n48) );
  sky130_fd_sc_hd__nand2_1 U76 ( .A(A[17]), .B(n15), .Y(n49) );
  sky130_fd_sc_hd__nand2_1 U77 ( .A(A[18]), .B(n14), .Y(n50) );
  sky130_fd_sc_hd__nand2_1 U78 ( .A(A[19]), .B(n13), .Y(n51) );
  sky130_fd_sc_hd__nand2_1 U79 ( .A(A[20]), .B(n12), .Y(n52) );
  sky130_fd_sc_hd__nand2_1 U80 ( .A(A[21]), .B(n11), .Y(n53) );
  sky130_fd_sc_hd__nand2_1 U81 ( .A(A[22]), .B(n10), .Y(n54) );
  sky130_fd_sc_hd__nand2_1 U82 ( .A(A[23]), .B(n9), .Y(n55) );
  sky130_fd_sc_hd__nand2_1 U83 ( .A(A[24]), .B(n8), .Y(n45) );
  sky130_fd_sc_hd__nand2_1 U84 ( .A(A[25]), .B(n7), .Y(n44) );
  sky130_fd_sc_hd__nand2_1 U85 ( .A(A[26]), .B(n6), .Y(n43) );
  sky130_fd_sc_hd__nand2_1 U86 ( .A(A[27]), .B(n5), .Y(n42) );
  sky130_fd_sc_hd__nand2_1 U87 ( .A(A[28]), .B(n4), .Y(n40) );
  sky130_fd_sc_hd__or2_0 U88 ( .A(B[30]), .B(n1), .X(n39) );
  sky130_fd_sc_hd__nand2_1 U89 ( .A(A[29]), .B(n3), .Y(n38) );
  sky130_fd_sc_hd__nor2b_1 U90 ( .B_N(A[31]), .A(B[31]), .Y(n62) );
  sky130_fd_sc_hd__nand2_1 U91 ( .A(A[3]), .B(n28), .Y(n61) );
  sky130_fd_sc_hd__nand2_1 U92 ( .A(A[2]), .B(n29), .Y(n60) );
  sky130_fd_sc_hd__and4_1 U93 ( .A(n101), .B(n98), .C(n97), .D(n94), .X(n58)
         );
  sky130_fd_sc_hd__nand2_1 U94 ( .A(A[7]), .B(n24), .Y(n94) );
  sky130_fd_sc_hd__nand2_1 U95 ( .A(A[6]), .B(n25), .Y(n97) );
  sky130_fd_sc_hd__nand2_1 U96 ( .A(A[5]), .B(n26), .Y(n98) );
  sky130_fd_sc_hd__nand2_1 U97 ( .A(A[4]), .B(n27), .Y(n101) );
  sky130_fd_sc_hd__and4_1 U98 ( .A(n93), .B(n90), .C(n89), .D(n86), .X(n57) );
  sky130_fd_sc_hd__nand2_1 U99 ( .A(A[11]), .B(n31), .Y(n86) );
  sky130_fd_sc_hd__nand2_1 U100 ( .A(A[10]), .B(n21), .Y(n89) );
  sky130_fd_sc_hd__nand2_1 U101 ( .A(A[9]), .B(n22), .Y(n90) );
  sky130_fd_sc_hd__nand2_1 U102 ( .A(A[8]), .B(n23), .Y(n93) );
  sky130_fd_sc_hd__and4_1 U103 ( .A(n85), .B(n82), .C(n81), .D(n78), .X(n56)
         );
  sky130_fd_sc_hd__nand2_1 U104 ( .A(A[15]), .B(n17), .Y(n78) );
  sky130_fd_sc_hd__nand2_1 U105 ( .A(A[14]), .B(n18), .Y(n81) );
  sky130_fd_sc_hd__nand2_1 U106 ( .A(A[13]), .B(n19), .Y(n82) );
  sky130_fd_sc_hd__nand2_1 U107 ( .A(A[12]), .B(n20), .Y(n85) );
endmodule


module picorv32 ( clk, resetn, trap, mem_valid, mem_instr, mem_ready, mem_addr, 
        mem_wdata, mem_wstrb, mem_rdata, mem_la_read, mem_la_write, 
        mem_la_addr, mem_la_wdata, mem_la_wstrb, pcpi_valid, pcpi_insn, 
        pcpi_rs1, pcpi_rs2, pcpi_wr, pcpi_rd, pcpi_wait, pcpi_ready, irq, eoi, 
        trace_valid, trace_data );
  output [31:0] mem_addr;
  output [31:0] mem_wdata;
  output [3:0] mem_wstrb;
  input [31:0] mem_rdata;
  output [31:0] mem_la_addr;
  output [31:0] mem_la_wdata;
  output [3:0] mem_la_wstrb;
  output [31:0] pcpi_insn;
  output [31:0] pcpi_rs1;
  output [31:0] pcpi_rs2;
  input [31:0] pcpi_rd;
  input [31:0] irq;
  output [31:0] eoi;
  output [35:0] trace_data;
  input clk, resetn, mem_ready, pcpi_wr, pcpi_wait, pcpi_ready;
  output trap, mem_valid, mem_instr, mem_la_read, mem_la_write, pcpi_valid,
         trace_valid;
  wire   N31, N82, N83, N84, N85, N86, N87, N88, N89, N90, N91, n12,
         mem_do_rinst, mem_do_prefetch, mem_do_rdata, mem_do_wdata, N142, N143,
         N144, N145, N146, N147, N148, N149, N150, N151, N152, N153, N154,
         N155, N156, N157, N158, N159, N160, N161, N162, N163, N164, N165,
         N166, N167, N168, N169, N170, N171, N172, N173, N174, N175, N176,
         N177, N178, N179, N180, N181, N182, N183, N184, N185, N186, N187,
         N188, N189, N190, N191, N192, N193, N194, N195, N196, N197, N198,
         N199, N200, N201, N202, N239, N240, N241, N242, N249, N250, instr_lui,
         instr_auipc, instr_jal, instr_jalr, instr_beq, instr_bne, instr_blt,
         instr_bge, instr_bltu, instr_bgeu, instr_lb, instr_lh, instr_lw,
         instr_lbu, instr_lhu, instr_sb, instr_sh, instr_sw, instr_addi,
         instr_slti, instr_sltiu, instr_xori, instr_ori, instr_andi,
         instr_slli, instr_srli, instr_srai, instr_add, instr_sub, instr_sll,
         instr_slt, instr_sltu, instr_xor, instr_srl, instr_sra, instr_or,
         instr_and, instr_rdcycle, instr_rdcycleh, instr_rdinstr,
         instr_rdinstrh, instr_fence, is_beq_bne_blt_bge_bltu_bgeu,
         is_lb_lh_lw_lbu_lhu, is_sb_sh_sw, is_alu_reg_imm, is_alu_reg_reg,
         N252, is_lui_auipc_jal, is_lui_auipc_jal_jalr_addi_add_sub, N254,
         is_slti_blt_slt, N256, is_lbu_lhu_lw, is_compare, N258, N259,
         decoder_trigger, decoder_pseudo_trigger, N268, N269, N270, N271, N272,
         N273, N274, N275, N282, N283, N284, N295, N296, N297, N298, N300,
         is_slli_srli_srai, N301, is_jalr_addi_slti_sltiu_xori_ori_andi, N302,
         is_sll_srl_sra, N311, N312, N313, N314, N315, N316, N317, N318, N319,
         N320, N321, N322, N323, N324, N325, N326, N327, N328, N329, N330,
         N331, N332, N333, N334, N335, N336, N337, N338, N339, N340, N341,
         N342, N343, N345, N350, N351, N352, N353, N354, N355, N356, N357,
         N358, N359, N360, N361, N362, N363, N364, N365, N366, N367, N368,
         N369, N370, N371, N372, N373, N374, latched_store, latched_branch,
         N389, N390, N391, N392, N393, N394, N395, N396, N397, N398, N399,
         N400, N401, N402, N403, N404, N405, N406, N407, N408, N409, N410,
         N411, N412, N413, N414, N415, N416, N417, N418, N419, N420, N421,
         N422, N423, N424, N425, N426, N427, N428, N429, N430, N431, N432,
         N433, N434, N435, N436, N437, N438, N439, N440, N441, N442, N443,
         N444, N445, N446, N447, N448, N449, N450, N451, N452, alu_eq, alu_ltu,
         latched_stalu, N584, N585, N586, N587, N588, N589, N590, N591, N592,
         N593, N594, N595, N596, N597, N598, N599, N600, N601, N602, N603,
         N604, N605, N606, N607, N608, N609, N610, N611, N612, N613, N614,
         N615, N652, N653, N654, N655, N656, N657, N658, N659, N660, N661,
         N662, N663, N664, N665, N666, N667, N668, N669, N670, N671, N672,
         N673, N674, N675, N676, N677, N678, N679, N680, N681, N682,
         \cpuregs[0][31] , \cpuregs[0][30] , \cpuregs[0][29] ,
         \cpuregs[0][28] , \cpuregs[0][27] , \cpuregs[0][26] ,
         \cpuregs[0][25] , \cpuregs[0][24] , \cpuregs[0][23] ,
         \cpuregs[0][22] , \cpuregs[0][21] , \cpuregs[0][20] ,
         \cpuregs[0][19] , \cpuregs[0][18] , \cpuregs[0][17] ,
         \cpuregs[0][16] , \cpuregs[0][15] , \cpuregs[0][14] ,
         \cpuregs[0][13] , \cpuregs[0][12] , \cpuregs[0][11] ,
         \cpuregs[0][10] , \cpuregs[0][9] , \cpuregs[0][8] , \cpuregs[0][7] ,
         \cpuregs[0][6] , \cpuregs[0][5] , \cpuregs[0][4] , \cpuregs[0][3] ,
         \cpuregs[0][2] , \cpuregs[0][1] , \cpuregs[0][0] , \cpuregs[1][31] ,
         \cpuregs[1][30] , \cpuregs[1][29] , \cpuregs[1][28] ,
         \cpuregs[1][27] , \cpuregs[1][26] , \cpuregs[1][25] ,
         \cpuregs[1][24] , \cpuregs[1][23] , \cpuregs[1][22] ,
         \cpuregs[1][21] , \cpuregs[1][20] , \cpuregs[1][19] ,
         \cpuregs[1][18] , \cpuregs[1][17] , \cpuregs[1][16] ,
         \cpuregs[1][15] , \cpuregs[1][14] , \cpuregs[1][13] ,
         \cpuregs[1][12] , \cpuregs[1][11] , \cpuregs[1][10] , \cpuregs[1][9] ,
         \cpuregs[1][8] , \cpuregs[1][7] , \cpuregs[1][6] , \cpuregs[1][5] ,
         \cpuregs[1][4] , \cpuregs[1][3] , \cpuregs[1][2] , \cpuregs[1][1] ,
         \cpuregs[1][0] , \cpuregs[2][31] , \cpuregs[2][30] , \cpuregs[2][29] ,
         \cpuregs[2][28] , \cpuregs[2][27] , \cpuregs[2][26] ,
         \cpuregs[2][25] , \cpuregs[2][24] , \cpuregs[2][23] ,
         \cpuregs[2][22] , \cpuregs[2][21] , \cpuregs[2][20] ,
         \cpuregs[2][19] , \cpuregs[2][18] , \cpuregs[2][17] ,
         \cpuregs[2][16] , \cpuregs[2][15] , \cpuregs[2][14] ,
         \cpuregs[2][13] , \cpuregs[2][12] , \cpuregs[2][11] ,
         \cpuregs[2][10] , \cpuregs[2][9] , \cpuregs[2][8] , \cpuregs[2][7] ,
         \cpuregs[2][6] , \cpuregs[2][5] , \cpuregs[2][4] , \cpuregs[2][3] ,
         \cpuregs[2][2] , \cpuregs[2][1] , \cpuregs[2][0] , \cpuregs[3][31] ,
         \cpuregs[3][30] , \cpuregs[3][29] , \cpuregs[3][28] ,
         \cpuregs[3][27] , \cpuregs[3][26] , \cpuregs[3][25] ,
         \cpuregs[3][24] , \cpuregs[3][23] , \cpuregs[3][22] ,
         \cpuregs[3][21] , \cpuregs[3][20] , \cpuregs[3][19] ,
         \cpuregs[3][18] , \cpuregs[3][17] , \cpuregs[3][16] ,
         \cpuregs[3][15] , \cpuregs[3][14] , \cpuregs[3][13] ,
         \cpuregs[3][12] , \cpuregs[3][11] , \cpuregs[3][10] , \cpuregs[3][9] ,
         \cpuregs[3][8] , \cpuregs[3][7] , \cpuregs[3][6] , \cpuregs[3][5] ,
         \cpuregs[3][4] , \cpuregs[3][3] , \cpuregs[3][2] , \cpuregs[3][1] ,
         \cpuregs[3][0] , \cpuregs[4][31] , \cpuregs[4][30] , \cpuregs[4][29] ,
         \cpuregs[4][28] , \cpuregs[4][27] , \cpuregs[4][26] ,
         \cpuregs[4][25] , \cpuregs[4][24] , \cpuregs[4][23] ,
         \cpuregs[4][22] , \cpuregs[4][21] , \cpuregs[4][20] ,
         \cpuregs[4][19] , \cpuregs[4][18] , \cpuregs[4][17] ,
         \cpuregs[4][16] , \cpuregs[4][15] , \cpuregs[4][14] ,
         \cpuregs[4][13] , \cpuregs[4][12] , \cpuregs[4][11] ,
         \cpuregs[4][10] , \cpuregs[4][9] , \cpuregs[4][8] , \cpuregs[4][7] ,
         \cpuregs[4][6] , \cpuregs[4][5] , \cpuregs[4][4] , \cpuregs[4][3] ,
         \cpuregs[4][2] , \cpuregs[4][1] , \cpuregs[4][0] , \cpuregs[5][31] ,
         \cpuregs[5][30] , \cpuregs[5][29] , \cpuregs[5][28] ,
         \cpuregs[5][27] , \cpuregs[5][26] , \cpuregs[5][25] ,
         \cpuregs[5][24] , \cpuregs[5][23] , \cpuregs[5][22] ,
         \cpuregs[5][21] , \cpuregs[5][20] , \cpuregs[5][19] ,
         \cpuregs[5][18] , \cpuregs[5][17] , \cpuregs[5][16] ,
         \cpuregs[5][15] , \cpuregs[5][14] , \cpuregs[5][13] ,
         \cpuregs[5][12] , \cpuregs[5][11] , \cpuregs[5][10] , \cpuregs[5][9] ,
         \cpuregs[5][8] , \cpuregs[5][7] , \cpuregs[5][6] , \cpuregs[5][5] ,
         \cpuregs[5][4] , \cpuregs[5][3] , \cpuregs[5][2] , \cpuregs[5][1] ,
         \cpuregs[5][0] , \cpuregs[6][31] , \cpuregs[6][30] , \cpuregs[6][29] ,
         \cpuregs[6][28] , \cpuregs[6][27] , \cpuregs[6][26] ,
         \cpuregs[6][25] , \cpuregs[6][24] , \cpuregs[6][23] ,
         \cpuregs[6][22] , \cpuregs[6][21] , \cpuregs[6][20] ,
         \cpuregs[6][19] , \cpuregs[6][18] , \cpuregs[6][17] ,
         \cpuregs[6][16] , \cpuregs[6][15] , \cpuregs[6][14] ,
         \cpuregs[6][13] , \cpuregs[6][12] , \cpuregs[6][11] ,
         \cpuregs[6][10] , \cpuregs[6][9] , \cpuregs[6][8] , \cpuregs[6][7] ,
         \cpuregs[6][6] , \cpuregs[6][5] , \cpuregs[6][4] , \cpuregs[6][3] ,
         \cpuregs[6][2] , \cpuregs[6][1] , \cpuregs[6][0] , \cpuregs[7][31] ,
         \cpuregs[7][30] , \cpuregs[7][29] , \cpuregs[7][28] ,
         \cpuregs[7][27] , \cpuregs[7][26] , \cpuregs[7][25] ,
         \cpuregs[7][24] , \cpuregs[7][23] , \cpuregs[7][22] ,
         \cpuregs[7][21] , \cpuregs[7][20] , \cpuregs[7][19] ,
         \cpuregs[7][18] , \cpuregs[7][17] , \cpuregs[7][16] ,
         \cpuregs[7][15] , \cpuregs[7][14] , \cpuregs[7][13] ,
         \cpuregs[7][12] , \cpuregs[7][11] , \cpuregs[7][10] , \cpuregs[7][9] ,
         \cpuregs[7][8] , \cpuregs[7][7] , \cpuregs[7][6] , \cpuregs[7][5] ,
         \cpuregs[7][4] , \cpuregs[7][3] , \cpuregs[7][2] , \cpuregs[7][1] ,
         \cpuregs[7][0] , \cpuregs[8][31] , \cpuregs[8][30] , \cpuregs[8][29] ,
         \cpuregs[8][28] , \cpuregs[8][27] , \cpuregs[8][26] ,
         \cpuregs[8][25] , \cpuregs[8][24] , \cpuregs[8][23] ,
         \cpuregs[8][22] , \cpuregs[8][21] , \cpuregs[8][20] ,
         \cpuregs[8][19] , \cpuregs[8][18] , \cpuregs[8][17] ,
         \cpuregs[8][16] , \cpuregs[8][15] , \cpuregs[8][14] ,
         \cpuregs[8][13] , \cpuregs[8][12] , \cpuregs[8][11] ,
         \cpuregs[8][10] , \cpuregs[8][9] , \cpuregs[8][8] , \cpuregs[8][7] ,
         \cpuregs[8][6] , \cpuregs[8][5] , \cpuregs[8][4] , \cpuregs[8][3] ,
         \cpuregs[8][2] , \cpuregs[8][1] , \cpuregs[8][0] , \cpuregs[9][31] ,
         \cpuregs[9][30] , \cpuregs[9][29] , \cpuregs[9][28] ,
         \cpuregs[9][27] , \cpuregs[9][26] , \cpuregs[9][25] ,
         \cpuregs[9][24] , \cpuregs[9][23] , \cpuregs[9][22] ,
         \cpuregs[9][21] , \cpuregs[9][20] , \cpuregs[9][19] ,
         \cpuregs[9][18] , \cpuregs[9][17] , \cpuregs[9][16] ,
         \cpuregs[9][15] , \cpuregs[9][14] , \cpuregs[9][13] ,
         \cpuregs[9][12] , \cpuregs[9][11] , \cpuregs[9][10] , \cpuregs[9][9] ,
         \cpuregs[9][8] , \cpuregs[9][7] , \cpuregs[9][6] , \cpuregs[9][5] ,
         \cpuregs[9][4] , \cpuregs[9][3] , \cpuregs[9][2] , \cpuregs[9][1] ,
         \cpuregs[9][0] , \cpuregs[10][31] , \cpuregs[10][30] ,
         \cpuregs[10][29] , \cpuregs[10][28] , \cpuregs[10][27] ,
         \cpuregs[10][26] , \cpuregs[10][25] , \cpuregs[10][24] ,
         \cpuregs[10][23] , \cpuregs[10][22] , \cpuregs[10][21] ,
         \cpuregs[10][20] , \cpuregs[10][19] , \cpuregs[10][18] ,
         \cpuregs[10][17] , \cpuregs[10][16] , \cpuregs[10][15] ,
         \cpuregs[10][14] , \cpuregs[10][13] , \cpuregs[10][12] ,
         \cpuregs[10][11] , \cpuregs[10][10] , \cpuregs[10][9] ,
         \cpuregs[10][8] , \cpuregs[10][7] , \cpuregs[10][6] ,
         \cpuregs[10][5] , \cpuregs[10][4] , \cpuregs[10][3] ,
         \cpuregs[10][2] , \cpuregs[10][1] , \cpuregs[10][0] ,
         \cpuregs[11][31] , \cpuregs[11][30] , \cpuregs[11][29] ,
         \cpuregs[11][28] , \cpuregs[11][27] , \cpuregs[11][26] ,
         \cpuregs[11][25] , \cpuregs[11][24] , \cpuregs[11][23] ,
         \cpuregs[11][22] , \cpuregs[11][21] , \cpuregs[11][20] ,
         \cpuregs[11][19] , \cpuregs[11][18] , \cpuregs[11][17] ,
         \cpuregs[11][16] , \cpuregs[11][15] , \cpuregs[11][14] ,
         \cpuregs[11][13] , \cpuregs[11][12] , \cpuregs[11][11] ,
         \cpuregs[11][10] , \cpuregs[11][9] , \cpuregs[11][8] ,
         \cpuregs[11][7] , \cpuregs[11][6] , \cpuregs[11][5] ,
         \cpuregs[11][4] , \cpuregs[11][3] , \cpuregs[11][2] ,
         \cpuregs[11][1] , \cpuregs[11][0] , \cpuregs[12][31] ,
         \cpuregs[12][30] , \cpuregs[12][29] , \cpuregs[12][28] ,
         \cpuregs[12][27] , \cpuregs[12][26] , \cpuregs[12][25] ,
         \cpuregs[12][24] , \cpuregs[12][23] , \cpuregs[12][22] ,
         \cpuregs[12][21] , \cpuregs[12][20] , \cpuregs[12][19] ,
         \cpuregs[12][18] , \cpuregs[12][17] , \cpuregs[12][16] ,
         \cpuregs[12][15] , \cpuregs[12][14] , \cpuregs[12][13] ,
         \cpuregs[12][12] , \cpuregs[12][11] , \cpuregs[12][10] ,
         \cpuregs[12][9] , \cpuregs[12][8] , \cpuregs[12][7] ,
         \cpuregs[12][6] , \cpuregs[12][5] , \cpuregs[12][4] ,
         \cpuregs[12][3] , \cpuregs[12][2] , \cpuregs[12][1] ,
         \cpuregs[12][0] , \cpuregs[13][31] , \cpuregs[13][30] ,
         \cpuregs[13][29] , \cpuregs[13][28] , \cpuregs[13][27] ,
         \cpuregs[13][26] , \cpuregs[13][25] , \cpuregs[13][24] ,
         \cpuregs[13][23] , \cpuregs[13][22] , \cpuregs[13][21] ,
         \cpuregs[13][20] , \cpuregs[13][19] , \cpuregs[13][18] ,
         \cpuregs[13][17] , \cpuregs[13][16] , \cpuregs[13][15] ,
         \cpuregs[13][14] , \cpuregs[13][13] , \cpuregs[13][12] ,
         \cpuregs[13][11] , \cpuregs[13][10] , \cpuregs[13][9] ,
         \cpuregs[13][8] , \cpuregs[13][7] , \cpuregs[13][6] ,
         \cpuregs[13][5] , \cpuregs[13][4] , \cpuregs[13][3] ,
         \cpuregs[13][2] , \cpuregs[13][1] , \cpuregs[13][0] ,
         \cpuregs[14][31] , \cpuregs[14][30] , \cpuregs[14][29] ,
         \cpuregs[14][28] , \cpuregs[14][27] , \cpuregs[14][26] ,
         \cpuregs[14][25] , \cpuregs[14][24] , \cpuregs[14][23] ,
         \cpuregs[14][22] , \cpuregs[14][21] , \cpuregs[14][20] ,
         \cpuregs[14][19] , \cpuregs[14][18] , \cpuregs[14][17] ,
         \cpuregs[14][16] , \cpuregs[14][15] , \cpuregs[14][14] ,
         \cpuregs[14][13] , \cpuregs[14][12] , \cpuregs[14][11] ,
         \cpuregs[14][10] , \cpuregs[14][9] , \cpuregs[14][8] ,
         \cpuregs[14][7] , \cpuregs[14][6] , \cpuregs[14][5] ,
         \cpuregs[14][4] , \cpuregs[14][3] , \cpuregs[14][2] ,
         \cpuregs[14][1] , \cpuregs[14][0] , \cpuregs[15][31] ,
         \cpuregs[15][30] , \cpuregs[15][29] , \cpuregs[15][28] ,
         \cpuregs[15][27] , \cpuregs[15][26] , \cpuregs[15][25] ,
         \cpuregs[15][24] , \cpuregs[15][23] , \cpuregs[15][22] ,
         \cpuregs[15][21] , \cpuregs[15][20] , \cpuregs[15][19] ,
         \cpuregs[15][18] , \cpuregs[15][17] , \cpuregs[15][16] ,
         \cpuregs[15][15] , \cpuregs[15][14] , \cpuregs[15][13] ,
         \cpuregs[15][12] , \cpuregs[15][11] , \cpuregs[15][10] ,
         \cpuregs[15][9] , \cpuregs[15][8] , \cpuregs[15][7] ,
         \cpuregs[15][6] , \cpuregs[15][5] , \cpuregs[15][4] ,
         \cpuregs[15][3] , \cpuregs[15][2] , \cpuregs[15][1] ,
         \cpuregs[15][0] , \cpuregs[16][31] , \cpuregs[16][30] ,
         \cpuregs[16][29] , \cpuregs[16][28] , \cpuregs[16][27] ,
         \cpuregs[16][26] , \cpuregs[16][25] , \cpuregs[16][24] ,
         \cpuregs[16][23] , \cpuregs[16][22] , \cpuregs[16][21] ,
         \cpuregs[16][20] , \cpuregs[16][19] , \cpuregs[16][18] ,
         \cpuregs[16][17] , \cpuregs[16][16] , \cpuregs[16][15] ,
         \cpuregs[16][14] , \cpuregs[16][13] , \cpuregs[16][12] ,
         \cpuregs[16][11] , \cpuregs[16][10] , \cpuregs[16][9] ,
         \cpuregs[16][8] , \cpuregs[16][7] , \cpuregs[16][6] ,
         \cpuregs[16][5] , \cpuregs[16][4] , \cpuregs[16][3] ,
         \cpuregs[16][2] , \cpuregs[16][1] , \cpuregs[16][0] ,
         \cpuregs[17][31] , \cpuregs[17][30] , \cpuregs[17][29] ,
         \cpuregs[17][28] , \cpuregs[17][27] , \cpuregs[17][26] ,
         \cpuregs[17][25] , \cpuregs[17][24] , \cpuregs[17][23] ,
         \cpuregs[17][22] , \cpuregs[17][21] , \cpuregs[17][20] ,
         \cpuregs[17][19] , \cpuregs[17][18] , \cpuregs[17][17] ,
         \cpuregs[17][16] , \cpuregs[17][15] , \cpuregs[17][14] ,
         \cpuregs[17][13] , \cpuregs[17][12] , \cpuregs[17][11] ,
         \cpuregs[17][10] , \cpuregs[17][9] , \cpuregs[17][8] ,
         \cpuregs[17][7] , \cpuregs[17][6] , \cpuregs[17][5] ,
         \cpuregs[17][4] , \cpuregs[17][3] , \cpuregs[17][2] ,
         \cpuregs[17][1] , \cpuregs[17][0] , \cpuregs[18][31] ,
         \cpuregs[18][30] , \cpuregs[18][29] , \cpuregs[18][28] ,
         \cpuregs[18][27] , \cpuregs[18][26] , \cpuregs[18][25] ,
         \cpuregs[18][24] , \cpuregs[18][23] , \cpuregs[18][22] ,
         \cpuregs[18][21] , \cpuregs[18][20] , \cpuregs[18][19] ,
         \cpuregs[18][18] , \cpuregs[18][17] , \cpuregs[18][16] ,
         \cpuregs[18][15] , \cpuregs[18][14] , \cpuregs[18][13] ,
         \cpuregs[18][12] , \cpuregs[18][11] , \cpuregs[18][10] ,
         \cpuregs[18][9] , \cpuregs[18][8] , \cpuregs[18][7] ,
         \cpuregs[18][6] , \cpuregs[18][5] , \cpuregs[18][4] ,
         \cpuregs[18][3] , \cpuregs[18][2] , \cpuregs[18][1] ,
         \cpuregs[18][0] , \cpuregs[19][31] , \cpuregs[19][30] ,
         \cpuregs[19][29] , \cpuregs[19][28] , \cpuregs[19][27] ,
         \cpuregs[19][26] , \cpuregs[19][25] , \cpuregs[19][24] ,
         \cpuregs[19][23] , \cpuregs[19][22] , \cpuregs[19][21] ,
         \cpuregs[19][20] , \cpuregs[19][19] , \cpuregs[19][18] ,
         \cpuregs[19][17] , \cpuregs[19][16] , \cpuregs[19][15] ,
         \cpuregs[19][14] , \cpuregs[19][13] , \cpuregs[19][12] ,
         \cpuregs[19][11] , \cpuregs[19][10] , \cpuregs[19][9] ,
         \cpuregs[19][8] , \cpuregs[19][7] , \cpuregs[19][6] ,
         \cpuregs[19][5] , \cpuregs[19][4] , \cpuregs[19][3] ,
         \cpuregs[19][2] , \cpuregs[19][1] , \cpuregs[19][0] ,
         \cpuregs[20][31] , \cpuregs[20][30] , \cpuregs[20][29] ,
         \cpuregs[20][28] , \cpuregs[20][27] , \cpuregs[20][26] ,
         \cpuregs[20][25] , \cpuregs[20][24] , \cpuregs[20][23] ,
         \cpuregs[20][22] , \cpuregs[20][21] , \cpuregs[20][20] ,
         \cpuregs[20][19] , \cpuregs[20][18] , \cpuregs[20][17] ,
         \cpuregs[20][16] , \cpuregs[20][15] , \cpuregs[20][14] ,
         \cpuregs[20][13] , \cpuregs[20][12] , \cpuregs[20][11] ,
         \cpuregs[20][10] , \cpuregs[20][9] , \cpuregs[20][8] ,
         \cpuregs[20][7] , \cpuregs[20][6] , \cpuregs[20][5] ,
         \cpuregs[20][4] , \cpuregs[20][3] , \cpuregs[20][2] ,
         \cpuregs[20][1] , \cpuregs[20][0] , \cpuregs[21][31] ,
         \cpuregs[21][30] , \cpuregs[21][29] , \cpuregs[21][28] ,
         \cpuregs[21][27] , \cpuregs[21][26] , \cpuregs[21][25] ,
         \cpuregs[21][24] , \cpuregs[21][23] , \cpuregs[21][22] ,
         \cpuregs[21][21] , \cpuregs[21][20] , \cpuregs[21][19] ,
         \cpuregs[21][18] , \cpuregs[21][17] , \cpuregs[21][16] ,
         \cpuregs[21][15] , \cpuregs[21][14] , \cpuregs[21][13] ,
         \cpuregs[21][12] , \cpuregs[21][11] , \cpuregs[21][10] ,
         \cpuregs[21][9] , \cpuregs[21][8] , \cpuregs[21][7] ,
         \cpuregs[21][6] , \cpuregs[21][5] , \cpuregs[21][4] ,
         \cpuregs[21][3] , \cpuregs[21][2] , \cpuregs[21][1] ,
         \cpuregs[21][0] , \cpuregs[22][31] , \cpuregs[22][30] ,
         \cpuregs[22][29] , \cpuregs[22][28] , \cpuregs[22][27] ,
         \cpuregs[22][26] , \cpuregs[22][25] , \cpuregs[22][24] ,
         \cpuregs[22][23] , \cpuregs[22][22] , \cpuregs[22][21] ,
         \cpuregs[22][20] , \cpuregs[22][19] , \cpuregs[22][18] ,
         \cpuregs[22][17] , \cpuregs[22][16] , \cpuregs[22][15] ,
         \cpuregs[22][14] , \cpuregs[22][13] , \cpuregs[22][12] ,
         \cpuregs[22][11] , \cpuregs[22][10] , \cpuregs[22][9] ,
         \cpuregs[22][8] , \cpuregs[22][7] , \cpuregs[22][6] ,
         \cpuregs[22][5] , \cpuregs[22][4] , \cpuregs[22][3] ,
         \cpuregs[22][2] , \cpuregs[22][1] , \cpuregs[22][0] ,
         \cpuregs[23][31] , \cpuregs[23][30] , \cpuregs[23][29] ,
         \cpuregs[23][28] , \cpuregs[23][27] , \cpuregs[23][26] ,
         \cpuregs[23][25] , \cpuregs[23][24] , \cpuregs[23][23] ,
         \cpuregs[23][22] , \cpuregs[23][21] , \cpuregs[23][20] ,
         \cpuregs[23][19] , \cpuregs[23][18] , \cpuregs[23][17] ,
         \cpuregs[23][16] , \cpuregs[23][15] , \cpuregs[23][14] ,
         \cpuregs[23][13] , \cpuregs[23][12] , \cpuregs[23][11] ,
         \cpuregs[23][10] , \cpuregs[23][9] , \cpuregs[23][8] ,
         \cpuregs[23][7] , \cpuregs[23][6] , \cpuregs[23][5] ,
         \cpuregs[23][4] , \cpuregs[23][3] , \cpuregs[23][2] ,
         \cpuregs[23][1] , \cpuregs[23][0] , \cpuregs[24][31] ,
         \cpuregs[24][30] , \cpuregs[24][29] , \cpuregs[24][28] ,
         \cpuregs[24][27] , \cpuregs[24][26] , \cpuregs[24][25] ,
         \cpuregs[24][24] , \cpuregs[24][23] , \cpuregs[24][22] ,
         \cpuregs[24][21] , \cpuregs[24][20] , \cpuregs[24][19] ,
         \cpuregs[24][18] , \cpuregs[24][17] , \cpuregs[24][16] ,
         \cpuregs[24][15] , \cpuregs[24][14] , \cpuregs[24][13] ,
         \cpuregs[24][12] , \cpuregs[24][11] , \cpuregs[24][10] ,
         \cpuregs[24][9] , \cpuregs[24][8] , \cpuregs[24][7] ,
         \cpuregs[24][6] , \cpuregs[24][5] , \cpuregs[24][4] ,
         \cpuregs[24][3] , \cpuregs[24][2] , \cpuregs[24][1] ,
         \cpuregs[24][0] , \cpuregs[25][31] , \cpuregs[25][30] ,
         \cpuregs[25][29] , \cpuregs[25][28] , \cpuregs[25][27] ,
         \cpuregs[25][26] , \cpuregs[25][25] , \cpuregs[25][24] ,
         \cpuregs[25][23] , \cpuregs[25][22] , \cpuregs[25][21] ,
         \cpuregs[25][20] , \cpuregs[25][19] , \cpuregs[25][18] ,
         \cpuregs[25][17] , \cpuregs[25][16] , \cpuregs[25][15] ,
         \cpuregs[25][14] , \cpuregs[25][13] , \cpuregs[25][12] ,
         \cpuregs[25][11] , \cpuregs[25][10] , \cpuregs[25][9] ,
         \cpuregs[25][8] , \cpuregs[25][7] , \cpuregs[25][6] ,
         \cpuregs[25][5] , \cpuregs[25][4] , \cpuregs[25][3] ,
         \cpuregs[25][2] , \cpuregs[25][1] , \cpuregs[25][0] ,
         \cpuregs[26][31] , \cpuregs[26][30] , \cpuregs[26][29] ,
         \cpuregs[26][28] , \cpuregs[26][27] , \cpuregs[26][26] ,
         \cpuregs[26][25] , \cpuregs[26][24] , \cpuregs[26][23] ,
         \cpuregs[26][22] , \cpuregs[26][21] , \cpuregs[26][20] ,
         \cpuregs[26][19] , \cpuregs[26][18] , \cpuregs[26][17] ,
         \cpuregs[26][16] , \cpuregs[26][15] , \cpuregs[26][14] ,
         \cpuregs[26][13] , \cpuregs[26][12] , \cpuregs[26][11] ,
         \cpuregs[26][10] , \cpuregs[26][9] , \cpuregs[26][8] ,
         \cpuregs[26][7] , \cpuregs[26][6] , \cpuregs[26][5] ,
         \cpuregs[26][4] , \cpuregs[26][3] , \cpuregs[26][2] ,
         \cpuregs[26][1] , \cpuregs[26][0] , \cpuregs[27][31] ,
         \cpuregs[27][30] , \cpuregs[27][29] , \cpuregs[27][28] ,
         \cpuregs[27][27] , \cpuregs[27][26] , \cpuregs[27][25] ,
         \cpuregs[27][24] , \cpuregs[27][23] , \cpuregs[27][22] ,
         \cpuregs[27][21] , \cpuregs[27][20] , \cpuregs[27][19] ,
         \cpuregs[27][18] , \cpuregs[27][17] , \cpuregs[27][16] ,
         \cpuregs[27][15] , \cpuregs[27][14] , \cpuregs[27][13] ,
         \cpuregs[27][12] , \cpuregs[27][11] , \cpuregs[27][10] ,
         \cpuregs[27][9] , \cpuregs[27][8] , \cpuregs[27][7] ,
         \cpuregs[27][6] , \cpuregs[27][5] , \cpuregs[27][4] ,
         \cpuregs[27][3] , \cpuregs[27][2] , \cpuregs[27][1] ,
         \cpuregs[27][0] , \cpuregs[28][31] , \cpuregs[28][30] ,
         \cpuregs[28][29] , \cpuregs[28][28] , \cpuregs[28][27] ,
         \cpuregs[28][26] , \cpuregs[28][25] , \cpuregs[28][24] ,
         \cpuregs[28][23] , \cpuregs[28][22] , \cpuregs[28][21] ,
         \cpuregs[28][20] , \cpuregs[28][19] , \cpuregs[28][18] ,
         \cpuregs[28][17] , \cpuregs[28][16] , \cpuregs[28][15] ,
         \cpuregs[28][14] , \cpuregs[28][13] , \cpuregs[28][12] ,
         \cpuregs[28][11] , \cpuregs[28][10] , \cpuregs[28][9] ,
         \cpuregs[28][8] , \cpuregs[28][7] , \cpuregs[28][6] ,
         \cpuregs[28][5] , \cpuregs[28][4] , \cpuregs[28][3] ,
         \cpuregs[28][2] , \cpuregs[28][1] , \cpuregs[28][0] ,
         \cpuregs[29][31] , \cpuregs[29][30] , \cpuregs[29][29] ,
         \cpuregs[29][28] , \cpuregs[29][27] , \cpuregs[29][26] ,
         \cpuregs[29][25] , \cpuregs[29][24] , \cpuregs[29][23] ,
         \cpuregs[29][22] , \cpuregs[29][21] , \cpuregs[29][20] ,
         \cpuregs[29][19] , \cpuregs[29][18] , \cpuregs[29][17] ,
         \cpuregs[29][16] , \cpuregs[29][15] , \cpuregs[29][14] ,
         \cpuregs[29][13] , \cpuregs[29][12] , \cpuregs[29][11] ,
         \cpuregs[29][10] , \cpuregs[29][9] , \cpuregs[29][8] ,
         \cpuregs[29][7] , \cpuregs[29][6] , \cpuregs[29][5] ,
         \cpuregs[29][4] , \cpuregs[29][3] , \cpuregs[29][2] ,
         \cpuregs[29][1] , \cpuregs[29][0] , \cpuregs[30][31] ,
         \cpuregs[30][30] , \cpuregs[30][29] , \cpuregs[30][28] ,
         \cpuregs[30][27] , \cpuregs[30][26] , \cpuregs[30][25] ,
         \cpuregs[30][24] , \cpuregs[30][23] , \cpuregs[30][22] ,
         \cpuregs[30][21] , \cpuregs[30][20] , \cpuregs[30][19] ,
         \cpuregs[30][18] , \cpuregs[30][17] , \cpuregs[30][16] ,
         \cpuregs[30][15] , \cpuregs[30][14] , \cpuregs[30][13] ,
         \cpuregs[30][12] , \cpuregs[30][11] , \cpuregs[30][10] ,
         \cpuregs[30][9] , \cpuregs[30][8] , \cpuregs[30][7] ,
         \cpuregs[30][6] , \cpuregs[30][5] , \cpuregs[30][4] ,
         \cpuregs[30][3] , \cpuregs[30][2] , \cpuregs[30][1] ,
         \cpuregs[30][0] , \cpuregs[31][31] , \cpuregs[31][30] ,
         \cpuregs[31][29] , \cpuregs[31][28] , \cpuregs[31][27] ,
         \cpuregs[31][26] , \cpuregs[31][25] , \cpuregs[31][24] ,
         \cpuregs[31][23] , \cpuregs[31][22] , \cpuregs[31][21] ,
         \cpuregs[31][20] , \cpuregs[31][19] , \cpuregs[31][18] ,
         \cpuregs[31][17] , \cpuregs[31][16] , \cpuregs[31][15] ,
         \cpuregs[31][14] , \cpuregs[31][13] , \cpuregs[31][12] ,
         \cpuregs[31][11] , \cpuregs[31][10] , \cpuregs[31][9] ,
         \cpuregs[31][8] , \cpuregs[31][7] , \cpuregs[31][6] ,
         \cpuregs[31][5] , \cpuregs[31][4] , \cpuregs[31][3] ,
         \cpuregs[31][2] , \cpuregs[31][1] , \cpuregs[31][0] , N718, N719,
         N720, N721, N722, N723, N724, N725, N726, N727, N728, N729, N730,
         N731, N732, N733, N734, N735, N736, N737, N738, N739, N740, N741,
         N742, N743, N744, N745, N746, N747, N748, N752, N753, N754, N755,
         N756, N757, N758, N759, N760, N761, N762, N763, N764, N765, N766,
         N767, N768, N769, N770, N771, N772, N773, N774, N775, N776, N777,
         N778, N779, N780, N781, N782, N783, N786, N787, N788, N789, N790,
         N791, N792, N793, N794, N795, N796, N797, N798, N799, N800, N801,
         N802, N803, N804, N805, N806, N807, N808, N809, N810, N811, N812,
         N813, N814, N815, N816, N817, N819, N820, N821, N822, N823, N824,
         N825, N826, N827, N828, N829, N830, N831, N832, N833, N834, N835,
         N836, N837, N838, N839, N840, N841, N842, N843, N844, N845, N846,
         N847, N848, N849, N850, N851, N852, N853, N854, N855, N856, N857,
         N858, N859, N860, N861, N862, N863, N864, N865, N866, N867, N868,
         N869, N870, N871, N872, N873, N874, N875, N876, N877, N878, N879,
         N880, N881, N882, N883, N884, N885, N886, N887, N888, N889, N890,
         N891, N892, N893, N894, N895, N896, N897, N898, N899, N900, N901,
         N902, N903, N904, N905, N906, N907, N908, N909, N910, N911, N912,
         N913, N914, N915, N916, N917, N918, N919, N920, N921, N922, N923,
         N924, N925, N926, N927, N928, N929, N930, N931, N932, N933, N934,
         N935, N936, N937, N938, N939, N940, N941, N942, N943, N944, N945,
         N946, latched_is_lu, latched_is_lh, N1088, N1089, N1090, N1091, N1092,
         N1093, N1094, N1095, N1096, N1097, N1098, N1099, N1100, N1101, N1102,
         N1103, N1104, N1105, N1106, N1107, N1108, N1109, N1110, N1111, N1112,
         N1113, N1114, N1115, N1116, N1117, N1118, N1119, N1122, N1123, N1124,
         N1125, N1126, N1127, N1128, N1129, N1130, N1131, N1132, N1133, N1134,
         N1135, N1136, N1137, N1138, N1139, N1140, N1141, N1142, N1143, N1144,
         N1145, N1146, N1147, N1148, N1149, N1150, N1151, N1152, N1153, N1154,
         N1155, N1156, N1157, N1158, N1159, N1160, N1161, N1162, N1163, N1164,
         N1165, N1166, N1167, N1168, N1169, N1170, N1171, N1172, N1173, N1174,
         N1175, N1176, N1177, N1178, N1179, N1180, N1181, N1182, N1183, N1184,
         N1185, N1186, N1187, N1188, N1189, N1190, N1191, N1192, N1193, N1194,
         N1195, N1196, N1197, N1198, N1199, N1200, N1201, N1202, N1203, N1204,
         N1205, N1206, N1207, N1208, N1209, N1210, N1211, N1212, N1213, N1214,
         N1215, N1216, N1217, N1219, N1220, N1221, N1222, N1223, N1224, N1225,
         N1226, N1227, N1228, N1229, N1230, N1231, N1232, N1233, N1234, N1235,
         N1236, N1237, N1238, N1239, N1240, N1241, N1242, N1243, N1244, N1245,
         N1246, N1247, N1248, N1249, N1250, N1483, N1484, N1485, N1486, N1487,
         N1488, N1489, N1490, N1491, N1492, N1493, N1494, N1495, N1496, N1497,
         N1498, N1499, N1500, N1501, N1502, N1503, N1504, N1505, N1506, N1507,
         N1508, N1509, N1510, N1511, N1512, N1513, N1514, N1563, N1564, N1657,
         N1658, N1659, N1660, N1661, N1662, N1663, N1664, N1665, N1666, N1667,
         N1668, N1669, N1670, N1671, N1672, N1673, N1674, N1675, N1676, N1677,
         N1678, N1679, N1680, N1681, N1682, N1683, N1684, N1685, N1686, N1687,
         N1688, N1792, N1793, N1794, N1795, N1796, N1808, N1809, N1810, N1811,
         N1812, N1813, N1814, N1815, N1816, N1817, N1818, N1819, N1820, N1821,
         N1822, N1823, N1824, N1825, N1826, N1827, N1828, N1829, N1830, N1831,
         N1832, N1833, N1834, N1835, N1836, N1837, N1838, N1841, N1842, N1843,
         N1844, N1845, N1846, N1847, N1848, N1849, N1850, N1851, N1852, N1853,
         N1854, N1855, N1856, N1857, N1858, N1859, N1860, N1861, N1862, N1863,
         N1864, N1865, N1866, N1867, N1868, N1869, N1870, N1871, N1872, N1873,
         N1874, N1875, N1876, N1877, N1878, N1879, N1880, N1881, N1882, N1883,
         N1884, N1885, N1886, N1887, N1888, N1889, N1890, N1891, N1892, N1893,
         N1894, N1895, N1896, N1897, N1898, N1899, N1900, N1901, N1902, N1903,
         N1904, N1905, N1906, N1907, N1908, N1909, N1948, N1949, N1950, N1951,
         N1952, N1953, N1954, N1955, N1956, N1957, N1958, N1959, N1960, N1961,
         N1962, N1963, N1964, N1965, N1966, N1967, N1968, N1969, N1970, N1971,
         N1972, N1973, N1974, N1975, N1976, N1977, N1978, N1979, N1980, N1981,
         N1982, N1983, N1984, N1985, N1986, N1987, N1988, N1989, N1990, N1991,
         N1992, N1993, N1994, N1995, N1996, N1997, N1998, N1999, N2000, N2001,
         N2002, N2003, N2004, N2005, N2006, N2007, N2008, N2009, N2010, N2011,
         N2012, N2013, N2014, N2015, N2016, N2017, N2018, N2019, N2020, N2021,
         N2022, N2023, N2024, N2025, N2026, N2027, N2028, N2029, N2030, N2031,
         N2032, N2033, N2034, N2035, N2036, N2037, N2038, N2039, N2040, N2041,
         N2042, N2043, N2044, N2064, N2068, N2069, N2071, N2072, N2074, N2108,
         N2109, N2110, N2111, N2112, N2113, N2114, N2115, net420, net469,
         net480, net485, net490, net495, net500, net505, net510, net515,
         net520, net525, net530, net535, net540, net545, net550, net555,
         net560, net565, net570, net575, net580, net585, net590, net595,
         net600, net605, net610, net615, net620, net625, net630, net635,
         net640, net645, net650, net655, net660, net665, net670, net685,
         net690, net695, net700, n1021, n1022, n1023, n1024, n1025, n1026,
         n1027, n1028, n1029, n1030, n1031, n1032, n1033, n1034, n1035, n1036,
         n1037, n1038, n1039, n1040, n1041, n1042, n1043, n1044, n1045, n1046,
         n1047, n1048, n1049, n1050, n1051, n1052, n1053, n1054, n1055, n1056,
         n1057, n1058, n1059, n1060, n1061, n1062, n1063, n1064, n1065, n1066,
         n1067, n1068, n1069, n1070, n1071, n1072, n1073, n1074, n1075, n1076,
         n1077, n1078, n1079, n1080, n1081, n1082, n1083, n1084, n1085, n1086,
         n1087, n1088, n1089, n1090, n1091, n1092, n1093, n1094, n1095, n1096,
         n1097, n1098, n1099, n1100, n1101, n1102, n1103, n1104, n1105, n1106,
         n1107, n1108, n1109, n1110, n1111, n1112, n1113, n1114, n1115, n1116,
         n1117, n1118, n1119, n1120, n1121, n1122, n1123, n1124, n1125, n1126,
         n1127, n1128, n1129, n1130, n1131, n1132, n1133, n1134, n1135, n1136,
         n1137, n1138, n1139, n1140, n1141, n1142, n1143, n1144, n1145, n1146,
         n1147, n1148, n1149, n1150, n1151, n1152, n1153, n1154, n1155, n1156,
         n1157, n1158, n1159, n1160, n1161, n1162, n1163, n1164, n1165, n1166,
         n1167, n1168, n1169, n1170, n1171, n1172, n1173, n1174, n1175, n1176,
         n1177, n1178, n1179, n1180, n1181, n1182, n1183, n1184, n1185, n1186,
         n1187, n1188, n1189, n1190, n1191, n1192, n1193, n1194, n1195, n1196,
         n1197, n1198, n1199, n1200, n1201, n1202, n1203, n1204, n1205, n1206,
         n1207, n1208, n1209, n1210, n1211, n1212, n1213, n1214, n1215, n1216,
         n1217, n1218, n1219, n1220, n1221, n1222, n1223, n1224, n1225, n1226,
         n1227, n1228, n1229, n1230, n1231, n1232, n1233, n1234, n1235, n1236,
         n1237, n1238, n1239, n1240, n1241, n1242, n1243, n1244, n1245, n1246,
         n1247, n1248, n1249, n1250, n1251, n1252, n1253, n1254, n1255, n1256,
         n1257, n1258, n1259, n1260, n1261, n1262, n1263, n1264, n1265, n1266,
         n1267, n1268, n1269, n1270, n1271, n1272, n1273, n1274, n1275, n1276,
         n1277, n1278, n1279, n1280, n1281, n1282, n1283, n1284, n1285, n1286,
         n1287, n1288, n1289, n1290, n1291, n1292, n1293, n1294, n1295, n1296,
         n1297, n1298, n1299, n1300, n1301, n1302, n1303, n1304, n1305, n1306,
         n1307, n1308, n1309, n1310, n1311, n1312, n1313, n1314, n1315, n1316,
         n1317, n1318, n1319, n1320, n1321, n1322, n1323, n1324, n1325, n1326,
         n1327, n1328, n1329, n1330, n1331, n1332, n1333, n1334, n1335, n1336,
         n1337, n1338, n1339, n1340, n1341, n1342, n1343, n1344, n1345, n1346,
         n1347, n1348, n1349, n1350, n1351, n1352, n1353, n1354, n1355, n1356,
         n1357, n1358, n1359, n1360, n1361, n1362, n1363, n1364, n1365, n1366,
         n1367, n1368, n1369, n1370, n1371, n1372, n1373, n1374, n1375, n1376,
         n1377, n1378, n1379, n1380, n1381, n1382, n1383, n1384, n1385, n1386,
         n1387, n1388, n1389, n1390, n1391, n1392, n1393, n1394, n1395, n1396,
         n1397, n1398, n1399, n1400, n1401, n1402, n1403, n1404, n1405, n1406,
         n1407, n1408, n1409, n1410, n1411, n1412, n1413, n1414, n1415, n1416,
         n1417, n1418, n1419, n1420, n1421, n1422, n1423, n1424, n1425, n1426,
         n1427, n1428, n1429, n1430, n1431, n1432, n1433, n1434, n1435, n1436,
         n1437, n1438, n1439, n1440, n1441, n1442, n1443, n1444, n1445, n1446,
         n1447, n1448, n1449, n1450, n1451, n1452, n1453, n1454, n1455, n1456,
         n1457, n1458, n1459, n1460, n1461, n1462, n1463, n1464, n1465, n1466,
         n1467, n1468, n1469, n1470, n1471, n1472, n1473, n1474, n1475, n1476,
         n1477, n1478, n1479, n1480, n1481, n1482, n1483, n1484, n1485, n1486,
         n1487, n1488, n1489, n1490, n1491, n1492, n1493, n1494, n1495, n1496,
         n1497, n1498, n1499, n1500, n1501, n1502, n1503, n1504, n1505, n1506,
         n1507, n1508, n1509, n1510, n1511, n1512, n1513, n1514, n1515, n1516,
         n1517, n1518, n1519, n1520, n1521, n1522, n1523, n1524, n1525, n1526,
         n1527, n1528, n1529, n1530, n1531, n1532, n1533, n1534, n1535, n1536,
         n1537, n1538, n1539, n1540, n1541, n1542, n1543, n1544, n1545, n1546,
         n1547, n1548, n1549, n1550, n1551, n1552, n1553, n1554, n1555, n1556,
         n1557, n1558, n1559, n1560, n1561, n1562, n1563, n1564, n1565, n1566,
         n1567, n1568, n1569, n1570, n1571, n1572, n1573, n1574, n1575, n1576,
         n1577, n1578, n1579, n1580, n1581, n1582, n1583, n1584, n1585, n1586,
         n1587, n1588, n1589, n1590, n1591, n1592, n1593, n1594, n1595, n1596,
         n1597, n1598, n1599, n1600, n1601, n1602, n1603, n1604, n1605, n1606,
         n1607, n1608, n1609, n1610, n1611, n1612, n1613, n1614, n1615, n1616,
         n1617, n1618, n1619, n1620, n1621, n1622, n1623, n1624, n1625, n1626,
         n1627, n1628, n1629, n1630, n1631, n1632, n1633, n1634, n1635, n1636,
         n1637, n1638, n1639, n1640, n1641, n1642, n1643, n1644, n1645, n1646,
         n1647, n1648, n1649, n1650, n1651, n1652, n1653, n1654, n1655, n1656,
         n1657, n1658, n1659, n1660, n1661, n1662, n1663, n1664, n1665, n1666,
         n1667, n1668, n1669, n1670, n1671, n1672, n1673, n1674, n1675, n1676,
         n1677, n1678, n1679, n1680, n1681, n1682, n1683, n1684, n1685, n1686,
         n1687, n1688, n1689, n1690, n1691, n1692, n1693, n1694, n1695, n1696,
         n1697, n1698, n1699, n1700, n1701, n1702, n1703, n1704, n1705, n1706,
         n1707, n1708, n1709, n1710, n1711, n1712, n1713, n1714, n1715, n1716,
         n1717, n1718, n1719, n1720, n1721, n1722, n1723, n1724, n1725, n1726,
         n1727, n1728, n1729, n1730, n1731, n1732, n1733, n1734, n1735, n1736,
         n1737, n1738, n1739, n1740, n1741, n1742, n1743, n1744, n1745, n1746,
         n1747, n1748, n1749, n1750, n1751, n1752, n1753, n1754, n1755, n1756,
         n1757, n1758, n1759, n1760, n1761, n1762, n1763, n1764, n1765, n1766,
         n1767, n1768, n1769, n1770, n1771, n1772, n1773, n1774, n1775, n1776,
         n1777, n1778, n1779, n1780, n1781, n1782, n1783, n1784, n1785, n1786,
         n1787, n1788, n1789, n1790, n1791, n1792, n1793, n1794, n1795, n1796,
         n1797, n1798, n1799, n1800, n1801, n1802, n1803, n1804, n1805, n1806,
         n1807, n1808, n1809, n1810, n1811, n1812, n1813, n1814, n1815, n1816,
         n1817, n1818, n1819, n1820, n1821, n1822, n1823, n1824, n1825, n1826,
         n1827, n1828, n1829, n1830, n1831, n1832, n1833, n1834, n1835, n1836,
         n1837, n1838, n1839, n1840, n1841, n1842, n1843, n1844, n1845, n1846,
         n1847, n1848, n1849, n1850, n1851, n1852, n1853, n1854, n1855, n1856,
         n1857, n1858, n1859, n1860, n1861, n1862, n1863, n1864, n1865, n1866,
         n1867, n1868, n1869, n1870, n1871, n1872, n1873, n1874, n1875, n1876,
         n1877, n1878, n1879, n1880, n1881, n1882, n1883, n1884, n1885, n1886,
         n1887, n1888, n1889, n1890, n1891, n1892, n1893, n1894, n1895, n1896,
         n1897, n1898, n1899, n1900, n1901, n1902, n1903, n1904, n1905, n1906,
         n1907, n1908, n1909, n1910, n1911, n1912, n1913, n1914, n1915, n1916,
         n1917, n1918, n1919, n1920, n1921, n1922, n1923, n1924, n1925, n1926,
         n1927, n1928, n1929, n1930, n1931, n1932, n1933, n1934, n1935, n1936,
         n1937, n1938, n1939, n1940, n1941, n1942, n1943, n1944, n1945, n1946,
         n1947, n1948, n1949, n1950, n1951, n1952, n1953, n1954, n1955, n1956,
         n1957, n1958, n1959, n1960, n1961, n1962, n1963, n1964, n1965, n1966,
         n1967, n1968, n1969, n1970, n1971, n1972, n1973, n1974, n1975, n1976,
         n1977, n1978, n1979, n1980, n1981, n1982, n1983, n1984, n1985, n1986,
         n1987, n1988, n1989, n1990, n1991, n1992, n1993, n1994, n1995, n1996,
         n1997, n1998, n1999, n2000, n2001, n2002, n2003, n2004, n2005, n2006,
         n2007, n2008, n2009, n2010, n2011, n2012, n2013, n2014, n2015, n2016,
         n2017, n2018, n2019, n2020, n2021, n2022, n2023, n2024, n2025, n2026,
         n2027, n2028, n2029, n2030, n2031, n2032, n2033, n2034, n2035, n2036,
         n2037, n2038, n2039, n2040, n2041, n2042, n2043, n2044, n2045, n2046,
         n2047, n2048, n2049, n2050, n2051, n2052, n2053, n2054, n2055, n2056,
         n2057, n2058, n2059, n2060, n2061, n2062, n2063, n2064, n2065, n2066,
         n2067, n2068, n2069, n2070, n2071, n2072, n2073, n2074, n2075, n2076,
         n2077, n2078, n2079, n2080, n2081, n2082, n2083, n2084, n2085, n2086,
         n2087, n2088, n2089, n2090, n2091, n2092, n2093, n2094, n2095, n2096,
         n2097, n2098, n2099, n2100, n2101, n2102, n2103, n2104, n2105, n2106,
         n2107, n2108, n2109, n2110, n2111, n2112, n2113, n2114, n2115, n2116,
         n2117, n2118, n2119, n2120, n2121, n2122, n2123, n2124, n2125, n2126,
         n2127, n2128, n2129, n2130, n2131, n2132, n2133, n2134, n2135, n2136,
         n2137, n2138, n2139, n2140, n2141, n2142, n2143, n2144, n2145, n2146,
         n2147, n2148, n2149, n2150, n2151, n2152, n2153, n2154, n2155, n2156,
         n2157, n2158, n2159, n2160, n2161, n2162, n2163, n2164, n2165, n2166,
         n2167, n2168, n2169, n2170, n2171, n2172, n2173, n2174, n2175, n2176,
         n2177, n2178, n2179, n2180, n2181, n2182, n2183, n2184, n2185, n2186,
         n2187, n2188, n2189, n2190, n2191, n2192, n2193, n2194, n2195, n2196,
         n2197, n2198, n2199, n2200, n2201, n2202, n2203, n2204, n2205, n2206,
         n2207, n2208, n2209, n2210, n2211, n2212, n2213, n2214, n2215, n2216,
         n2217, n2218, n2219, n2220, n2221, n2222, n2223, n2224, n2225, n2226,
         n2227, n2228, n2229, n2230, n2231, n2232, n2233, n2234, n2235, n2236,
         n2237, n2238, n2239, n2240, n2241, n2242, n2243, n2244, n2245, n2246,
         n2247, n2248, n2249, n2250, n2251, n2252, n2253, n2254, n2255, n2256,
         n2257, n2258, n2259, n2260, n2261, n2262, n2263, n2264, n2265, n2266,
         n2267, n2268, n2269, n2270, n2271, n2272, n2273, n2274, n2275, n2276,
         n2277, n2278, n2279, n2280, n2281, n2282, n2283, n2284, n2285, n2286,
         n2287, n2288, n2289, n2290, n2291, n2292, n2293, n2294, n2295, n2296,
         n2297, n2298, n2299, n2300, n2301, n2302, n2303, n2304, n2305, n2306,
         n2307, n2308, n2309, n2310, n2311, n2312, n2313, n2314, n2315, n2316,
         n2317, n2318, n2319, n2320, n2321, n2322, n2323, n2324, n2325, n2326,
         n2327, n2328, n2329, n2330, n2331, n2332, n2333, n2334, n2335, n2336,
         n2337, n2338, n2339, n2340, n2341, n2342, n2343, n2344, n2345, n2346,
         n2347, n2348, n2349, n2350, n2351, n2352, n2353, n2354, n2355, n2356,
         n2357, n2358, n2359, n2360, n2361, n2362, n2363, n2364, n2365, n2366,
         n2367, n2368, n2369, n2370, n2371, n2372, n2373, n2374, n2375, n2376,
         n2377, n2378, n2379, n2380, n2381, n2382, n2383, n2384, n2385, n2386,
         n2387, n2388, n2389, n2390, n2391, n2392, n2393, n2394, n2395, n2396,
         n2397, n2398, n2399, n2400, n2401, n2402, n2403, n2404, n2405, n2406,
         n2407, n2408, n2409, n2410, n2411, n2412, n2413, n2414, n2415, n2416,
         n2417, n2418, n2419, n2420, n2421, n2422, n2423, n2424, n2425, n2426,
         n2427, n2428, n2429, n2430, n2431, n2432, n2433, n2434, n2435, n2436,
         n2437, n2438, n2439, n2440, n2441, n2442, n2443, n2444, n2445, n2446,
         n2447, n2448, n2449, n2450, n2451, n2452, n2453, n2454, n2455, n2456,
         n2457, n2458, n2459, n2460, n2461, n2462, n2463, n2464, n2465, n2466,
         n2467, n2468, n2469, n2470, n2471, n2472, n2473, n2474, n2475, n2476,
         n2477, n2478, n2479, n2480, n2481, n2482, n2483, n2484, n2485, n2486,
         n2487, n2488, n2489, n2490, n2491, n2492, n2493, n2494, n2495, n2496,
         n2497, n2498, n2499, n2500, n2501, n2502, n2503, n2504, n2505, n2506,
         n2507, n2508, n2509, n2510, n2511, n2512, n2513, n2514, n2515, n2516,
         n2517, n2518, n2519, n2520, n2521, n2522, n2523, n2524, n2525, n2526,
         n2527, n2528, n2529, n2530, n2531, n2532, n2533, n2534, n2535, n2536,
         n2537, n2538, n2539, n2540, n2541, n2542, n2543, n2544, n2545, n2546,
         n2547, n2548, n2549, n2550, n2551, n2552, n2553, n2554, n2555, n2556,
         n2557, n2558, n2559, n2560, n2561, n2562, n2563, n2564, n2565, n2566,
         n2567, n2568, n2569, n2570, n2571, n2572, n2573, n2574, n2575, n2576,
         n2577, n2578, n2579, n2580, n2581, n2582, n2583, n2584, n2585, n2586,
         n2587, n2588, n2589, n2590, n2591, n2592, n2593, n2594, n2595, n2596,
         n2597, n2598, n2599, n2600, n2601, n2602, n2603, n2604, n2605, n2606,
         n2607, n2608, n2609, n2610, n2611, n2612, n2613, n2614, n2615, n2616,
         n2617, n2618, n2619, n2620, n2621, n2622, n2623, n2624, n2625, n2626,
         n2627, n2628, n2629, n2630, n2631, n2632, n2633, n2634, n2635, n2636,
         n2637, n2638, n2639, n2640, n2641, n2642, n2643, n2644, n2645, n2646,
         n2647, n2648, n2649, n2650, n2651, n2652, n2653, n2654, n2655, n2656,
         n2657, n2658, n2659, n2660, n2661, n2662, n2663, n2664, n2665, n2666,
         n2667, n2668, n2669, n2670, n2671, n2672, n2673, n2674, n2675, n2676,
         n2677, n2678, n2679, n2680, n2681, n2682, n2683, n2684, n2685, n2686,
         n2687, n2688, n2689, n2690, n2691, n2692, n2693, n2694, n2695, n2696,
         n2697, n2698, n2699, n2700, n2701, n2702, n2703, n2704, n2705, n2706,
         n2707, n2708, n2709, n2710, n2711, n2712, n2713, n2714, n2715, n2716,
         n2717, n2718, n2719, n2720, n2721, n2722, n2723, n2724, n2725, n2726,
         n2727, n2728, n2729, n2730, n2731, n2732, n2733, n2734, n2735, n2736,
         n2737, n2738, n2739, n2740, n2741, n2742, n2743, n2744, n2745, n2746,
         n2747, n2748, n2749, n2750, n2751, n2752, n2753, n2754, n2755, n2756,
         n2757, n2758, n2759, n2760, n2761, n2762, n2763, n2764, n2765, n2766,
         n2767, n2768, n2769, n2770, n2771, n2772, n2773, n2774, n2775, n2776,
         n2777, n2778, n2779, n2780, n2781, n2782, n2783, n2784, n2785, n2786,
         n2787, n2788, n2789, n2790, n2791, n2792, n2793, n2794, n2795, n2796,
         n2797, n2798, n2799, n2800, n2801, n2802, n2803, n2804, n2805, n2806,
         n2807, n2808, n2809, n2810, n2811, n2812, n2813, n2814, n2815, n2816,
         n2817, n2818, n2819, n2820, n2821, n2822, n2823, n2824, n2825, n2826,
         n2827, n2828, n2829, n2830, n2831, n2832, n2833, n2834, n2835, n2836,
         n2837, n2838, n2839, n2840, n2841, n2842, n2843, n2844, n2845, n2846,
         n2847, n2848, n2849, n2850, n2851, n2852, n2853, n2854, n2855, n2856,
         n2857, n2858, n2859, n2860, n2861, n2862, n2863, n2864, n2865, n2866,
         n2867, n2868, n2869, n2870, n2871, n2872, n2873, n2874, n2875, n2876,
         n2877, n2878, n2879, n2880, n2881, n2882, n2883, n2884, n2885, n2886,
         n2887, n2888, n2889, n2890, n2891, n2892, n2893, n2894, n2895, n2896,
         n2897, n2898, n2899, n2900, n2901, n2902, n2903, n2904, n2905, n2906,
         n2907, n2908, n2909, n2910, n2911, n2912, n2913, n2914, n2915, n2916,
         n2917, n2918, n2919, n2920, n2921, n2922, n2923, n2924, n2925, n2926,
         n2927, n2928, n2929, n2930, n2931, n2932, n2933, n2934, n2935, n2936,
         n2937, n2938, n2939, n2940, n2941, n2942, n2943, n2944, n2945, n2946,
         n2947, n2948, n2949, n2950, n2951, n2952, n2953, n2954, n2955, n2956,
         n2957, n2958, n2959, n2960, n2961, n2962, n2963, n2964, n2965, n2966,
         n2967, n2968, n2969, n2970, n2971, n2972, n2973, n2974, n2975, n2976,
         n2977, n2978, n2979, n2980, n2981, n2982, n2983, n2984, n2985, n2986,
         n2987, n2988, n2989, n2990, n2991, n2992, n2993, n2994, n2995, n2996,
         n2997, n2998, n2999, n3000, n3001, n3002, n3003, n3004, n3005, n3006,
         n3007, n3008, n3009, n3010, n3011, n3012, n3013, n3014, n3015, n3016,
         n3017, n3018, n3019, n3020, n3021, n3022, n3023, n3024, n3025, n3026,
         n3027, n3028, n3029, n3030, n3031, n3032, n3033, n3034, n3035, n3036,
         n3037, n3038, n3039, n3040, n3041, n3042, n3043, n3044, n3045, n3046,
         n3047, n3048, n3049, n3050, n3051, n3052, n3053, n3054, n3055, n3056,
         n3057, n3058, n3059, n3060, n3061, n3062, n3063, n3064, n3065, n3066,
         n3067, n3068, n3069, n3070, n3071, n3072, n3073, n3074, n3075, n3076,
         n3077, n3078, n3079, n3080, n3081, n3082, n3083, n3084, n3085, n3086,
         n3087, n3088, n3089, n3090, n3091, n3092, n3093, n3094, n3095, n3096,
         n3097, n3098, n3099, n3100, n3101, n3102, n3103, n3104, n3105, n3106,
         n3107, n3108, n3109, n3110, n3111, n3112, n3113, n3114, n3115, n3116,
         n3117, n3118, n3119, n3120, n3121, n3122, n3123, n3124, n3125, n3126,
         n3127, n3128, n3129, n3130, n3131, n3132, n3133, n3134, n3135, n3136,
         n3137, n3138, n3139, n3140, n3141, n3142, n3143, n3144, n3145, n3146,
         n3147, n3148, n3149, n3150, n3151, n3152, n3153, n3154, n3155, n3156,
         n3157, n3158, n3159, n3160, n3161, n3162, n3163, n3164, n3165, n3166,
         n3167, n3168, n3169, n3170, n3171, n3172, n3173, n3174, n3175, n3176,
         n3177, n3178, n3179, n3180, n3181, n3182, n3183, n3184, n3185, n3186,
         n3187, n3188, n3189, n3190, n3191, n3192, n3193, n3194, n3195, n3196,
         n3197, n3198, n3199, n3200, n3201, n3202, n3203, n3204, n3205, n3206,
         n3207, n3208, n3209, n3210, n3211, n3212, n3213, n3214, n3215, n3216,
         n3217, n3218, n3219, n3220, n3221, n3222, n3223, n3224, n3225, n3226,
         n3227, n3228, n3229, n3230, n3231, n3232, n3233, n3234, n3235, n3236,
         n3237, n3238, n3239, n3240, n3241, n3242, n3243, n3244, n3245, n3246,
         n3247, n3248, n3249, n3250, n3251, n3252, n3253, n3254, n3255, n3256,
         n3257, n3258, n3259, n3260, n3261, n3262, n3263, n3264, n3265, n3266,
         n3267, n3268, n3269, n3270, n3271, n3272, n3273, n3274, n3275, n3276,
         n3277, n3278, n3279, n3280, n3281, n3282, n3283, n3284, n3285, n3286,
         n3287, n3288, n3289, n3290, n3291, n3292, n3293, n3294, n3295, n3296,
         n3297, n3298, n3299, n3300, n3301, n3302, n3303, n3304, n3305, n3306,
         n3307, n3308, n3309, n3310, n3311, n3312, n3313, n3314, n3315, n3316,
         n3317, n3318, n3319, n3320, n3321, n3322, n3323, n3324, n3325, n3326,
         n3327, n3328, n3329, n3330, n3331, n3332, n3333, n3334, n3335, n3336,
         n3337, n3338, n3339, n3340, n3341, n3342, n3343, n3344, n3345, n3346,
         n3347, n3348, n3349, n3350, n3351, n3352, n3353, n3354, n3355, n3356,
         n3357, n3358, n3359, n3360, n3361, n3362, n3363, n3364, n3365, n3366,
         n3367, n3368, n3369, n3370, n3371, n3372, n3373, n3374, n3375, n3376,
         n3377, n3378, n3379, n3380, n3381, n3382, n3383, n3384, n3385, n3386,
         n3387, n3388, n3389, n3390, n3391, n3392, n3393, n3394, n3395, n3396,
         n3397, n3398, n3399, n3400, n3401, n3402, n3403, n3404, n3405, n3406,
         n3407, n3408, n3409, n3410, n3411, n3412, n3413, n3414, n3415, n3416,
         n3417, n3418, n3419, n3420, n3421, n3422, n3423, n3424, n3425, n3426,
         n3427, n3428, n3429, n3430, n3431, n3432, n3433, n3434, n3435, n3436,
         n3437, n3438, n3439, n3440, n3441, n3442, n3443, n3444, n3445, n3446,
         n3447, n3448, n3449, n3450, n3451, n3452, n3453, n3454, n3455, n3456,
         n3457, n3458, n3459, n3460, n3461, n3462, n3463, n3464, n3465, n3466,
         n3467, n3468, n3469, n3470, n3471, n3472, n3473, n3474, n3475, n3476,
         n3477, n3478, n3479, n3480, n3481, n3482, n3483, n3484, n3485, n3486,
         n3487, n3488, n3489, n3490, n3491, n3492, n3493, n3494, n3495, n3496,
         n3497, n3498, n3499, n3500, n3501, n3502, n3503, n3504, n3505, n3506,
         n3507, n3508, n3509, n3510, n3511, n3512, n3513, n3514, n3515, n3516,
         n3517, n3518, n3519, n3520, n3521, n3522, n3523, n3524, n3525, n3526,
         n3527, n3528, n3529, n3530, n3531, n3532, n3533, n3534, n3535, n3536,
         n3537, n3538, n3539, n3540, n3541, n3542, n3543, n3544, n3545, n3546,
         n3547, n3548, n3549, n3550, n3551, n3552, n3553, n3554, n3555, n3556,
         n3557, n3558, n3559, n3560, n3561, n3562, n3563, n3564, n3565, n3566,
         n3567, n3568, n3569, n3570, n3571, n3572;
  wire   [1:0] mem_state;
  wire   [31:0] mem_rdata_latched_noshuffle;
  wire   [31:0] mem_rdata_q;
  wire   [1:0] mem_wordsize;
  wire   [31:0] mem_rdata_word;
  wire   [31:0] decoded_imm;
  wire   [4:0] decoded_rd;
  wire   [31:0] decoded_imm_j;
  wire   [7:0] cpu_state;
  wire   [31:0] reg_out;
  wire   [31:0] reg_next_pc;
  wire   [31:0] alu_out;
  wire   [31:0] reg_pc;
  wire   [31:0] alu_out_q;
  wire   [4:0] latched_rd;
  wire   [63:0] count_cycle;
  wire   [63:0] count_instr;
  wire   [4:0] reg_sh;
  assign N31 = resetn;
  assign trace_data[0] = n12;
  assign trace_data[1] = n12;
  assign trace_data[2] = n12;
  assign trace_data[3] = n12;
  assign trace_data[4] = n12;
  assign trace_data[5] = n12;
  assign trace_data[6] = n12;
  assign trace_data[7] = n12;
  assign trace_data[8] = n12;
  assign trace_data[9] = n12;
  assign trace_data[10] = n12;
  assign trace_data[11] = n12;
  assign trace_data[12] = n12;
  assign trace_data[13] = n12;
  assign trace_data[14] = n12;
  assign trace_data[15] = n12;
  assign trace_data[16] = n12;
  assign trace_data[17] = n12;
  assign trace_data[18] = n12;
  assign trace_data[19] = n12;
  assign trace_data[20] = n12;
  assign trace_data[21] = n12;
  assign trace_data[22] = n12;
  assign trace_data[23] = n12;
  assign trace_data[24] = n12;
  assign trace_data[25] = n12;
  assign trace_data[26] = n12;
  assign trace_data[27] = n12;
  assign trace_data[28] = n12;
  assign trace_data[29] = n12;
  assign trace_data[30] = n12;
  assign trace_data[31] = n12;
  assign trace_data[32] = n12;
  assign trace_data[33] = n12;
  assign trace_data[34] = n12;
  assign trace_data[35] = n12;
  assign trace_valid = n12;
  assign eoi[0] = n12;
  assign eoi[1] = n12;
  assign eoi[2] = n12;
  assign eoi[3] = n12;
  assign eoi[4] = n12;
  assign eoi[5] = n12;
  assign eoi[6] = n12;
  assign eoi[7] = n12;
  assign eoi[8] = n12;
  assign eoi[9] = n12;
  assign eoi[10] = n12;
  assign eoi[11] = n12;
  assign eoi[12] = n12;
  assign eoi[13] = n12;
  assign eoi[14] = n12;
  assign eoi[15] = n12;
  assign eoi[16] = n12;
  assign eoi[17] = n12;
  assign eoi[18] = n12;
  assign eoi[19] = n12;
  assign eoi[20] = n12;
  assign eoi[21] = n12;
  assign eoi[22] = n12;
  assign eoi[23] = n12;
  assign eoi[24] = n12;
  assign eoi[25] = n12;
  assign eoi[26] = n12;
  assign eoi[27] = n12;
  assign eoi[28] = n12;
  assign eoi[29] = n12;
  assign eoi[30] = n12;
  assign eoi[31] = n12;
  assign pcpi_insn[0] = n12;
  assign pcpi_insn[1] = n12;
  assign pcpi_insn[2] = n12;
  assign pcpi_insn[3] = n12;
  assign pcpi_insn[4] = n12;
  assign pcpi_insn[5] = n12;
  assign pcpi_insn[6] = n12;
  assign pcpi_insn[7] = n12;
  assign pcpi_insn[8] = n12;
  assign pcpi_insn[9] = n12;
  assign pcpi_insn[10] = n12;
  assign pcpi_insn[11] = n12;
  assign pcpi_insn[12] = n12;
  assign pcpi_insn[13] = n12;
  assign pcpi_insn[14] = n12;
  assign pcpi_insn[15] = n12;
  assign pcpi_insn[16] = n12;
  assign pcpi_insn[17] = n12;
  assign pcpi_insn[18] = n12;
  assign pcpi_insn[19] = n12;
  assign pcpi_insn[20] = n12;
  assign pcpi_insn[21] = n12;
  assign pcpi_insn[22] = n12;
  assign pcpi_insn[23] = n12;
  assign pcpi_insn[24] = n12;
  assign pcpi_insn[25] = n12;
  assign pcpi_insn[26] = n12;
  assign pcpi_insn[27] = n12;
  assign pcpi_insn[28] = n12;
  assign pcpi_insn[29] = n12;
  assign pcpi_insn[30] = n12;
  assign pcpi_insn[31] = n12;
  assign pcpi_valid = n12;
  assign mem_addr[0] = n12;
  assign mem_addr[1] = n12;
  assign mem_la_addr[0] = n12;
  assign mem_la_addr[1] = n12;

  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[1]  ( .GATE(N142), .D(N172), 
        .Q(mem_rdata_word[1]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[0]  ( .GATE(N142), .D(pcpi_rs2[0]), .Q(mem_la_wdata[0]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[31]  ( .GATE(N142), .D(N202), 
        .Q(mem_rdata_word[31]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[30]  ( .GATE(N142), .D(N201), 
        .Q(mem_rdata_word[30]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[29]  ( .GATE(N142), .D(N200), 
        .Q(mem_rdata_word[29]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[28]  ( .GATE(N142), .D(N199), 
        .Q(mem_rdata_word[28]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[27]  ( .GATE(N142), .D(N198), 
        .Q(mem_rdata_word[27]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[26]  ( .GATE(N142), .D(N197), 
        .Q(mem_rdata_word[26]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[25]  ( .GATE(N142), .D(N196), 
        .Q(mem_rdata_word[25]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[24]  ( .GATE(N142), .D(N195), 
        .Q(mem_rdata_word[24]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[23]  ( .GATE(N142), .D(N194), 
        .Q(mem_rdata_word[23]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[22]  ( .GATE(N142), .D(N193), 
        .Q(mem_rdata_word[22]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[21]  ( .GATE(N142), .D(N192), 
        .Q(mem_rdata_word[21]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[20]  ( .GATE(N142), .D(N191), 
        .Q(mem_rdata_word[20]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[19]  ( .GATE(N142), .D(N190), 
        .Q(mem_rdata_word[19]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[18]  ( .GATE(N142), .D(N189), 
        .Q(mem_rdata_word[18]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[17]  ( .GATE(N142), .D(N188), 
        .Q(mem_rdata_word[17]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[16]  ( .GATE(N142), .D(N187), 
        .Q(mem_rdata_word[16]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[15]  ( .GATE(N142), .D(N186), 
        .Q(mem_rdata_word[15]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[14]  ( .GATE(N142), .D(N185), 
        .Q(mem_rdata_word[14]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[13]  ( .GATE(N142), .D(N184), 
        .Q(mem_rdata_word[13]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[12]  ( .GATE(N142), .D(N183), 
        .Q(mem_rdata_word[12]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[11]  ( .GATE(N142), .D(N182), 
        .Q(mem_rdata_word[11]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[10]  ( .GATE(N142), .D(N181), 
        .Q(mem_rdata_word[10]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[9]  ( .GATE(N142), .D(N180), 
        .Q(mem_rdata_word[9]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[8]  ( .GATE(N142), .D(N179), 
        .Q(mem_rdata_word[8]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[7]  ( .GATE(N142), .D(N178), 
        .Q(mem_rdata_word[7]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[6]  ( .GATE(N142), .D(N177), 
        .Q(mem_rdata_word[6]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[5]  ( .GATE(N142), .D(N176), 
        .Q(mem_rdata_word[5]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[4]  ( .GATE(N142), .D(N175), 
        .Q(mem_rdata_word[4]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[3]  ( .GATE(N142), .D(N174), 
        .Q(mem_rdata_word[3]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[2]  ( .GATE(N142), .D(N173), 
        .Q(mem_rdata_word[2]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wstrb_reg[3]  ( .GATE(N142), .D(N170), .Q(
        mem_la_wstrb[3]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wstrb_reg[2]  ( .GATE(N142), .D(N169), .Q(
        mem_la_wstrb[2]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wstrb_reg[1]  ( .GATE(N142), .D(N168), .Q(
        mem_la_wstrb[1]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wstrb_reg[0]  ( .GATE(N142), .D(N167), .Q(
        mem_la_wstrb[0]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[31]  ( .GATE(N142), .D(N166), .Q(
        mem_la_wdata[31]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[30]  ( .GATE(N142), .D(N165), .Q(
        mem_la_wdata[30]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[29]  ( .GATE(N142), .D(N164), .Q(
        mem_la_wdata[29]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[28]  ( .GATE(N142), .D(N163), .Q(
        mem_la_wdata[28]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[27]  ( .GATE(N142), .D(N162), .Q(
        mem_la_wdata[27]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[26]  ( .GATE(N142), .D(N161), .Q(
        mem_la_wdata[26]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[25]  ( .GATE(N142), .D(N160), .Q(
        mem_la_wdata[25]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[24]  ( .GATE(N142), .D(N159), .Q(
        mem_la_wdata[24]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[23]  ( .GATE(N142), .D(N158), .Q(
        mem_la_wdata[23]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[22]  ( .GATE(N142), .D(N157), .Q(
        mem_la_wdata[22]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[21]  ( .GATE(N142), .D(N156), .Q(
        mem_la_wdata[21]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[20]  ( .GATE(N142), .D(N155), .Q(
        mem_la_wdata[20]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[19]  ( .GATE(N142), .D(N154), .Q(
        mem_la_wdata[19]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[18]  ( .GATE(N142), .D(N153), .Q(
        mem_la_wdata[18]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[17]  ( .GATE(N142), .D(N152), .Q(
        mem_la_wdata[17]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[16]  ( .GATE(N142), .D(N151), .Q(
        mem_la_wdata[16]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[7]  ( .GATE(N142), .D(pcpi_rs2[7]), .Q(mem_la_wdata[7]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[6]  ( .GATE(N142), .D(pcpi_rs2[6]), .Q(mem_la_wdata[6]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[5]  ( .GATE(N142), .D(pcpi_rs2[5]), .Q(mem_la_wdata[5]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[4]  ( .GATE(N142), .D(pcpi_rs2[4]), .Q(mem_la_wdata[4]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[3]  ( .GATE(N142), .D(pcpi_rs2[3]), .Q(mem_la_wdata[3]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[2]  ( .GATE(N142), .D(pcpi_rs2[2]), .Q(mem_la_wdata[2]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[1]  ( .GATE(N142), .D(pcpi_rs2[1]), .Q(mem_la_wdata[1]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[15]  ( .GATE(N142), .D(N150), .Q(
        mem_la_wdata[15]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[14]  ( .GATE(N142), .D(N149), .Q(
        mem_la_wdata[14]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[13]  ( .GATE(N142), .D(N148), .Q(
        mem_la_wdata[13]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[12]  ( .GATE(N142), .D(N147), .Q(
        mem_la_wdata[12]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[11]  ( .GATE(N142), .D(N146), .Q(
        mem_la_wdata[11]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[10]  ( .GATE(N142), .D(N145), .Q(
        mem_la_wdata[10]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[9]  ( .GATE(N142), .D(N144), .Q(
        mem_la_wdata[9]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_la_wdata_reg[8]  ( .GATE(N142), .D(N143), .Q(
        mem_la_wdata[8]) );
  sky130_fd_sc_hd__dlxtp_1 \mem_rdata_word_reg[0]  ( .GATE(N142), .D(N171), 
        .Q(mem_rdata_word[0]) );
  SNPS_CLOCK_GATE_HIGH_picorv32_0 clk_gate_mem_rdata_q_reg ( .CLK(n1046), .EN(
        n3571), .ENCLK(net469), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_45 clk_gate_mem_addr_reg ( .CLK(n1043), .EN(
        N249), .ENCLK(net480), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_44 clk_gate_mem_wdata_reg ( .CLK(n1043), .EN(
        N250), .ENCLK(net485), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_43 clk_gate_compressed_instr_reg ( .CLK(n1043), 
        .EN(N258), .ENCLK(net490), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_42 clk_gate_decoded_imm_reg ( .CLK(n1043), 
        .EN(N343), .ENCLK(net495), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_41 clk_gate_instr_beq_reg ( .CLK(n1043), .EN(
        N351), .ENCLK(net500), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_40 \clk_gate_cpuregs_reg[1]  ( .CLK(n1043), 
        .EN(N748), .ENCLK(net505), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_39 \clk_gate_cpuregs_reg[2]  ( .CLK(n1043), 
        .EN(N747), .ENCLK(net510), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_38 \clk_gate_cpuregs_reg[3]  ( .CLK(n1043), 
        .EN(N746), .ENCLK(net515), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_37 \clk_gate_cpuregs_reg[4]  ( .CLK(n1043), 
        .EN(N745), .ENCLK(net520), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_36 \clk_gate_cpuregs_reg[5]  ( .CLK(n1043), 
        .EN(N744), .ENCLK(net525), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_35 \clk_gate_cpuregs_reg[6]  ( .CLK(n1043), 
        .EN(N743), .ENCLK(net530), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_34 \clk_gate_cpuregs_reg[7]  ( .CLK(n1043), 
        .EN(N742), .ENCLK(net535), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_33 \clk_gate_cpuregs_reg[8]  ( .CLK(n1044), 
        .EN(N741), .ENCLK(net540), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_32 \clk_gate_cpuregs_reg[9]  ( .CLK(n1044), 
        .EN(N740), .ENCLK(net545), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_31 \clk_gate_cpuregs_reg[10]  ( .CLK(n1044), 
        .EN(N739), .ENCLK(net550), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_30 \clk_gate_cpuregs_reg[11]  ( .CLK(n1043), 
        .EN(N738), .ENCLK(net555), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_29 \clk_gate_cpuregs_reg[12]  ( .CLK(n1044), 
        .EN(N737), .ENCLK(net560), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_28 \clk_gate_cpuregs_reg[13]  ( .CLK(n1044), 
        .EN(N736), .ENCLK(net565), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_27 \clk_gate_cpuregs_reg[14]  ( .CLK(n1044), 
        .EN(N735), .ENCLK(net570), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_26 \clk_gate_cpuregs_reg[15]  ( .CLK(n1044), 
        .EN(N734), .ENCLK(net575), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_25 \clk_gate_cpuregs_reg[16]  ( .CLK(n1044), 
        .EN(N733), .ENCLK(net580), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_24 \clk_gate_cpuregs_reg[17]  ( .CLK(n1044), 
        .EN(N732), .ENCLK(net585), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_23 \clk_gate_cpuregs_reg[18]  ( .CLK(n1044), 
        .EN(N731), .ENCLK(net590), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_22 \clk_gate_cpuregs_reg[19]  ( .CLK(n1044), 
        .EN(N730), .ENCLK(net595), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_21 \clk_gate_cpuregs_reg[20]  ( .CLK(n1044), 
        .EN(N729), .ENCLK(net600), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_20 \clk_gate_cpuregs_reg[21]  ( .CLK(n1045), 
        .EN(N728), .ENCLK(net605), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_19 \clk_gate_cpuregs_reg[22]  ( .CLK(n1045), 
        .EN(N727), .ENCLK(net610), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_18 \clk_gate_cpuregs_reg[23]  ( .CLK(n1045), 
        .EN(N726), .ENCLK(net615), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_17 \clk_gate_cpuregs_reg[24]  ( .CLK(n1045), 
        .EN(N725), .ENCLK(net620), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_16 \clk_gate_cpuregs_reg[25]  ( .CLK(n1045), 
        .EN(N724), .ENCLK(net625), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_15 \clk_gate_cpuregs_reg[26]  ( .CLK(n1044), 
        .EN(N723), .ENCLK(net630), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_14 \clk_gate_cpuregs_reg[27]  ( .CLK(n1045), 
        .EN(N722), .ENCLK(net635), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_13 \clk_gate_cpuregs_reg[28]  ( .CLK(n1045), 
        .EN(N721), .ENCLK(net640), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_12 \clk_gate_cpuregs_reg[29]  ( .CLK(n1045), 
        .EN(N720), .ENCLK(net645), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_11 \clk_gate_cpuregs_reg[30]  ( .CLK(n1045), 
        .EN(N719), .ENCLK(net650), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_10 \clk_gate_cpuregs_reg[31]  ( .CLK(n1045), 
        .EN(N718), .ENCLK(net655), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_9 clk_gate_reg_op2_reg ( .CLK(n1045), .EN(
        N2072), .ENCLK(net660), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_8 clk_gate_reg_pc_reg ( .CLK(n1045), .EN(n3538), .ENCLK(net665), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_7 clk_gate_count_instr_reg ( .CLK(n1045), .EN(
        N1980), .ENCLK(net670), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_4 clk_gate_cpu_state_reg ( .CLK(n1046), .EN(
        N2108), .ENCLK(net685), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_3 clk_gate_latched_rd_reg ( .CLK(n1046), .EN(
        N2069), .ENCLK(net690), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_2 clk_gate_reg_op1_reg ( .CLK(n1046), .EN(
        N2071), .ENCLK(net695), .TE(n12) );
  SNPS_CLOCK_GATE_HIGH_picorv32_1 clk_gate_mem_wordsize_reg ( .CLK(n1046), 
        .EN(net420), .ENCLK(net700), .TE(n12) );
  picorv32_DW01_add_0 add_1806 ( .A(reg_pc), .B(decoded_imm), .CI(n12), .SUM({
        N1514, N1513, N1512, N1511, N1510, N1509, N1508, N1507, N1506, N1505, 
        N1504, N1503, N1502, N1501, N1500, N1499, N1498, N1497, N1496, N1495, 
        N1494, N1493, N1492, N1491, N1490, N1489, N1488, N1487, N1486, N1485, 
        N1484, N1483}) );
  picorv32_DW01_add_1 add_1569 ( .A({N1119, N1118, N1117, N1116, N1115, N1114, 
        N1113, N1112, N1111, N1110, N1109, N1108, N1107, N1106, N1105, N1104, 
        N1103, N1102, N1101, N1100, N1099, N1098, N1097, N1096, N1095, N1094, 
        N1093, N1092, N1091, N1090, N1089, N1088}), .B({decoded_imm_j[31:1], 
        n12}), .CI(n12), .SUM({N1250, N1249, N1248, N1247, N1246, N1245, N1244, 
        N1243, N1242, N1241, N1240, N1239, N1238, N1237, N1236, N1235, N1234, 
        N1233, N1232, N1231, N1230, N1229, N1228, N1227, N1226, N1225, N1224, 
        N1223, N1222, N1221, N1220, N1219}) );
  picorv32_DW01_inc_0 add_1564 ( .A(count_instr), .SUM({N1217, N1216, N1215, 
        N1214, N1213, N1212, N1211, N1210, N1209, N1208, N1207, N1206, N1205, 
        N1204, N1203, N1202, N1201, N1200, N1199, N1198, N1197, N1196, N1195, 
        N1194, N1193, N1192, N1191, N1190, N1189, N1188, N1187, N1186, N1185, 
        N1184, N1183, N1182, N1181, N1180, N1179, N1178, N1177, N1176, N1175, 
        N1174, N1173, N1172, N1171, N1170, N1169, N1168, N1167, N1166, N1165, 
        N1164, N1163, N1162, N1161, N1160, N1159, N1158, N1157, N1156, N1155, 
        N1154}) );
  picorv32_DW01_add_2 add_1560 ( .A({N1119, N1118, N1117, N1116, N1115, N1114, 
        N1113, N1112, N1111, N1110, N1109, N1108, N1107, N1106, N1105, N1104, 
        N1103, N1102, N1101, N1100, N1099, N1098, N1097, N1096, N1095, N1094, 
        N1093, N1092, N1091, N1090, N1089, N1088}), .B({n12, n12, n12, n12, 
        n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, 
        n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n1042, n12, n12}), .CI(n12), .SUM({N1153, N1152, N1151, N1150, N1149, N1148, N1147, N1146, 
        N1145, N1144, N1143, N1142, N1141, N1140, N1139, N1138, N1137, N1136, 
        N1135, N1134, N1133, N1132, N1131, N1130, N1129, N1128, N1127, N1126, 
        N1125, N1124, N1123, N1122}) );
  picorv32_DW01_inc_1 add_1433 ( .A(count_cycle), .SUM({N882, N881, N880, N879, 
        N878, N877, N876, N875, N874, N873, N872, N871, N870, N869, N868, N867, 
        N866, N865, N864, N863, N862, N861, N860, N859, N858, N857, N856, N855, 
        N854, N853, N852, N851, N850, N849, N848, N847, N846, N845, N844, N843, 
        N842, N841, N840, N839, N838, N837, N836, N835, N834, N833, N832, N831, 
        N830, N829, N828, N827, N826, N825, N824, N823, N822, N821, N820, N819}) );
  picorv32_DW01_add_3 add_1317 ( .A(reg_pc), .B({n12, n12, n12, n12, n12, n12, 
        n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, n12, 
        n12, n12, n12, n12, n12, n12, n12, n12, n12, n1042, n12, n12}), .CI(
        n12), .SUM({N615, N614, N613, N612, N611, N610, N609, N608, N607, N606, 
        N605, N604, N603, N602, N601, N600, N599, N598, N597, N596, N595, N594, 
        N593, N592, N591, N590, N589, N588, N587, N586, N585, N584}) );
  picorv32_DW01_add_4 add_1240 ( .A(pcpi_rs1), .B(pcpi_rs2), .CI(n12), .SUM({
        N452, N451, N450, N449, N448, N447, N446, N445, N444, N443, N442, N441, 
        N440, N439, N438, N437, N436, N435, N434, N433, N432, N431, N430, N429, 
        N428, N427, N426, N425, N424, N423, N422, N421}) );
  picorv32_DW01_sub_1 sub_1240 ( .A(pcpi_rs1), .B(pcpi_rs2), .CI(n12), .DIFF({
        N420, N419, N418, N417, N416, N415, N414, N413, N412, N411, N410, N409, 
        N408, N407, N406, N405, N404, N403, N402, N401, N400, N399, N398, N397, 
        N396, N395, N394, N393, N392, N391, N390, N389}) );
  picorv32_DW01_add_5 r322 ( .A(pcpi_rs1), .B(decoded_imm), .CI(n12), .SUM({
        N1688, N1687, N1686, N1685, N1684, N1683, N1682, N1681, N1680, N1679, 
        N1678, N1677, N1676, N1675, N1674, N1673, N1672, N1671, N1670, N1669, 
        N1668, N1667, N1666, N1665, N1664, N1663, N1662, N1661, N1660, N1659, 
        N1658, N1657}) );
  picorv32_DW01_cmp6_0 r312 ( .A(pcpi_rs1), .B(pcpi_rs2), .TC(n12), .LT(
        alu_ltu), .EQ(alu_eq) );
  sky130_fd_sc_hd__dfxtp_1 latched_is_lh_reg ( .D(n3536), .CLK(n1046), .Q(
        latched_is_lh) );
  sky130_fd_sc_hd__dfxtp_1 latched_is_lu_reg ( .D(n3535), .CLK(n1046), .Q(
        latched_is_lu) );
  sky130_fd_sc_hd__dfxtp_1 instr_blt_reg ( .D(N354), .CLK(net500), .Q(
        instr_blt) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[0]  ( .D(N1948), .CLK(net665), .Q(
        reg_next_pc[0]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rd_reg[0]  ( .D(
        mem_rdata_latched_noshuffle[7]), .CLK(net490), .Q(decoded_rd[0]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rd_reg[2]  ( .D(
        mem_rdata_latched_noshuffle[9]), .CLK(net490), .Q(decoded_rd[2]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rd_reg[1]  ( .D(
        mem_rdata_latched_noshuffle[8]), .CLK(net490), .Q(decoded_rd[1]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rd_reg[4]  ( .D(
        mem_rdata_latched_noshuffle[11]), .CLK(net490), .Q(decoded_rd[4]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rd_reg[3]  ( .D(
        mem_rdata_latched_noshuffle[10]), .CLK(net490), .Q(decoded_rd[3]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[1]  ( .D(N1949), .CLK(net665), .Q(
        reg_next_pc[1]) );
  sky130_fd_sc_hd__dfxtp_1 instr_bltu_reg ( .D(N356), .CLK(net500), .Q(
        instr_bltu) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[0]  ( .D(alu_out[0]), .CLK(n1052), 
        .Q(alu_out_q[0]) );
  sky130_fd_sc_hd__dfxtp_1 is_lbu_lhu_lw_reg ( .D(N256), .CLK(n1046), .Q(
        is_lbu_lhu_lw) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[0]  ( .D(N1878), .CLK(n1046), .Q(
        reg_out[0]) );
  sky130_fd_sc_hd__dfxtp_1 instr_add_reg ( .D(N364), .CLK(net500), .Q(
        instr_add) );
  sky130_fd_sc_hd__dfxtp_1 decoder_pseudo_trigger_reg ( .D(N2068), .CLK(n1046), 
        .Q(decoder_pseudo_trigger) );
  sky130_fd_sc_hd__dfxtp_1 instr_srl_reg ( .D(N370), .CLK(net500), .Q(
        instr_srl) );
  sky130_fd_sc_hd__dfxtp_1 instr_and_reg ( .D(N373), .CLK(net500), .Q(
        instr_and) );
  sky130_fd_sc_hd__dfxtp_1 instr_slli_reg ( .D(N282), .CLK(net495), .Q(
        instr_slli) );
  sky130_fd_sc_hd__dfxtp_1 instr_auipc_reg ( .D(n1040), .CLK(net490), .Q(
        instr_auipc) );
  sky130_fd_sc_hd__dfxtp_1 instr_sll_reg ( .D(N366), .CLK(net500), .Q(
        instr_sll) );
  sky130_fd_sc_hd__dfxtp_1 instr_rdinstrh_reg ( .D(N298), .CLK(net495), .Q(
        instr_rdinstrh) );
  sky130_fd_sc_hd__dfxtp_1 instr_srli_reg ( .D(N283), .CLK(net495), .Q(
        instr_srli) );
  sky130_fd_sc_hd__dfxtp_1 instr_andi_reg ( .D(N363), .CLK(net500), .Q(
        instr_andi) );
  sky130_fd_sc_hd__dfxtp_1 instr_fence_reg ( .D(N374), .CLK(net500), .Q(
        instr_fence) );
  sky130_fd_sc_hd__dfxtp_1 instr_sw_reg ( .D(N275), .CLK(net495), .Q(instr_sw)
         );
  sky130_fd_sc_hd__dfxtp_1 trap_reg ( .D(N2064), .CLK(n1046), .Q(trap) );
  sky130_fd_sc_hd__dfxtp_1 instr_addi_reg ( .D(N358), .CLK(net500), .Q(
        instr_addi) );
  sky130_fd_sc_hd__dfxtp_1 instr_lbu_reg ( .D(N271), .CLK(net495), .Q(
        instr_lbu) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wordsize_reg[0]  ( .D(n1033), .CLK(net700), 
        .Q(mem_wordsize[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[11]  ( .D(mem_rdata[11]), .CLK(
        net469), .Q(mem_rdata_q[11]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[10]  ( .D(mem_rdata[10]), .CLK(
        net469), .Q(mem_rdata_q[10]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[9]  ( .D(mem_rdata[9]), .CLK(
        net469), .Q(mem_rdata_q[9]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[8]  ( .D(mem_rdata[8]), .CLK(
        net469), .Q(mem_rdata_q[8]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[6]  ( .D(mem_rdata[6]), .CLK(
        net469), .Q(mem_rdata_q[6]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[5]  ( .D(mem_rdata[5]), .CLK(
        net469), .Q(mem_rdata_q[5]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[4]  ( .D(mem_rdata[4]), .CLK(
        net469), .Q(mem_rdata_q[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[30]  ( .D(N1978), .CLK(net665), 
        .Q(reg_next_pc[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[3]  ( .D(N1951), .CLK(net665), .Q(
        reg_next_pc[3]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[5]  ( .D(N1953), .CLK(net665), .Q(
        reg_next_pc[5]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[6]  ( .D(N1954), .CLK(net665), .Q(
        reg_next_pc[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[8]  ( .D(N1956), .CLK(net665), .Q(
        reg_next_pc[8]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[9]  ( .D(N1957), .CLK(net665), .Q(
        reg_next_pc[9]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[10]  ( .D(N1958), .CLK(net665), 
        .Q(reg_next_pc[10]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[11]  ( .D(N1959), .CLK(net665), 
        .Q(reg_next_pc[11]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[12]  ( .D(N1960), .CLK(net665), 
        .Q(reg_next_pc[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[13]  ( .D(N1961), .CLK(net665), 
        .Q(reg_next_pc[13]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[14]  ( .D(N1962), .CLK(net665), 
        .Q(reg_next_pc[14]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[15]  ( .D(N1963), .CLK(net665), 
        .Q(reg_next_pc[15]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[16]  ( .D(N1964), .CLK(net665), 
        .Q(reg_next_pc[16]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[17]  ( .D(N1965), .CLK(net665), 
        .Q(reg_next_pc[17]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[18]  ( .D(N1966), .CLK(net665), 
        .Q(reg_next_pc[18]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[19]  ( .D(N1967), .CLK(net665), 
        .Q(reg_next_pc[19]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[20]  ( .D(N1968), .CLK(net665), 
        .Q(reg_next_pc[20]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[21]  ( .D(N1969), .CLK(net665), 
        .Q(reg_next_pc[21]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[22]  ( .D(N1970), .CLK(net665), 
        .Q(reg_next_pc[22]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[23]  ( .D(N1971), .CLK(net665), 
        .Q(reg_next_pc[23]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[24]  ( .D(N1972), .CLK(net665), 
        .Q(reg_next_pc[24]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[25]  ( .D(N1973), .CLK(net665), 
        .Q(reg_next_pc[25]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[26]  ( .D(N1974), .CLK(net665), 
        .Q(reg_next_pc[26]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[27]  ( .D(N1975), .CLK(net665), 
        .Q(reg_next_pc[27]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[28]  ( .D(N1976), .CLK(net665), 
        .Q(reg_next_pc[28]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[29]  ( .D(N1977), .CLK(net665), 
        .Q(reg_next_pc[29]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[7]  ( .D(N1955), .CLK(net665), .Q(
        reg_next_pc[7]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[31]  ( .D(N1979), .CLK(net665), 
        .Q(reg_next_pc[31]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[4]  ( .D(N1952), .CLK(net665), .Q(
        reg_next_pc[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_next_pc_reg[2]  ( .D(N1950), .CLK(net665), .Q(
        reg_next_pc[2]) );
  sky130_fd_sc_hd__dfxtp_1 is_slti_blt_slt_reg ( .D(N254), .CLK(n1046), .Q(
        is_slti_blt_slt) );
  sky130_fd_sc_hd__dfxtp_1 instr_or_reg ( .D(N372), .CLK(net500), .Q(instr_or)
         );
  sky130_fd_sc_hd__dfxtp_1 instr_ori_reg ( .D(N362), .CLK(net500), .Q(
        instr_ori) );
  sky130_fd_sc_hd__dfxtp_1 instr_srai_reg ( .D(N284), .CLK(net495), .Q(
        instr_srai) );
  sky130_fd_sc_hd__dfxtp_1 is_jalr_addi_slti_sltiu_xori_ori_andi_reg ( .D(N301), .CLK(net495), .Q(is_jalr_addi_slti_sltiu_xori_ori_andi) );
  sky130_fd_sc_hd__dfxtp_1 instr_rdcycleh_reg ( .D(N296), .CLK(net495), .Q(
        instr_rdcycleh) );
  sky130_fd_sc_hd__dfxtp_1 instr_lb_reg ( .D(N268), .CLK(net495), .Q(instr_lb)
         );
  sky130_fd_sc_hd__dfxtp_1 instr_lhu_reg ( .D(N272), .CLK(net495), .Q(
        instr_lhu) );
  sky130_fd_sc_hd__dfxtp_1 is_sll_srl_sra_reg ( .D(N302), .CLK(net495), .Q(
        is_sll_srl_sra) );
  sky130_fd_sc_hd__dfxtp_1 instr_lw_reg ( .D(N270), .CLK(net495), .Q(instr_lw)
         );
  sky130_fd_sc_hd__dfxtp_1 mem_valid_reg ( .D(n1029), .CLK(n1046), .Q(
        mem_valid) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[4]  ( .D(alu_out[4]), .CLK(n1052), 
        .Q(alu_out_q[4]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[29]  ( .D(alu_out[29]), .CLK(n1052), 
        .Q(alu_out_q[29]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[28]  ( .D(alu_out[28]), .CLK(n1052), 
        .Q(alu_out_q[28]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[30]  ( .D(alu_out[30]), .CLK(n1052), 
        .Q(alu_out_q[30]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[3]  ( .D(alu_out[3]), .CLK(n1052), 
        .Q(alu_out_q[3]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[2]  ( .D(alu_out[2]), .CLK(n1052), 
        .Q(alu_out_q[2]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[7]  ( .D(alu_out[7]), .CLK(n1047), 
        .Q(alu_out_q[7]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[5]  ( .D(alu_out[5]), .CLK(n1047), 
        .Q(alu_out_q[5]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[6]  ( .D(alu_out[6]), .CLK(n1047), 
        .Q(alu_out_q[6]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[8]  ( .D(alu_out[8]), .CLK(n1047), 
        .Q(alu_out_q[8]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[9]  ( .D(alu_out[9]), .CLK(n1047), 
        .Q(alu_out_q[9]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[10]  ( .D(alu_out[10]), .CLK(n1047), 
        .Q(alu_out_q[10]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[11]  ( .D(alu_out[11]), .CLK(n1047), 
        .Q(alu_out_q[11]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[12]  ( .D(alu_out[12]), .CLK(n1047), 
        .Q(alu_out_q[12]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[13]  ( .D(alu_out[13]), .CLK(n1047), 
        .Q(alu_out_q[13]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[14]  ( .D(alu_out[14]), .CLK(n1047), 
        .Q(alu_out_q[14]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[15]  ( .D(alu_out[15]), .CLK(n1047), 
        .Q(alu_out_q[15]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[16]  ( .D(alu_out[16]), .CLK(n1047), 
        .Q(alu_out_q[16]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[17]  ( .D(alu_out[17]), .CLK(n1047), 
        .Q(alu_out_q[17]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[18]  ( .D(alu_out[18]), .CLK(n1048), 
        .Q(alu_out_q[18]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[19]  ( .D(alu_out[19]), .CLK(n1048), 
        .Q(alu_out_q[19]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[20]  ( .D(alu_out[20]), .CLK(n1048), 
        .Q(alu_out_q[20]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[21]  ( .D(alu_out[21]), .CLK(n1048), 
        .Q(alu_out_q[21]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[22]  ( .D(alu_out[22]), .CLK(n1048), 
        .Q(alu_out_q[22]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[23]  ( .D(alu_out[23]), .CLK(n1048), 
        .Q(alu_out_q[23]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[24]  ( .D(alu_out[24]), .CLK(n1048), 
        .Q(alu_out_q[24]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[25]  ( .D(alu_out[25]), .CLK(n1048), 
        .Q(alu_out_q[25]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[26]  ( .D(alu_out[26]), .CLK(n1048), 
        .Q(alu_out_q[26]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[27]  ( .D(alu_out[27]), .CLK(n1048), 
        .Q(alu_out_q[27]) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[31]  ( .D(alu_out[31]), .CLK(n1048), 
        .Q(alu_out_q[31]) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][31]  ( .D(N682), .CLK(net650), .Q(
        \cpuregs[30][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][31]  ( .D(N682), .CLK(net640), .Q(
        \cpuregs[28][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][31]  ( .D(N682), .CLK(net630), .Q(
        \cpuregs[26][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][31]  ( .D(N682), .CLK(net620), .Q(
        \cpuregs[24][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][31]  ( .D(N682), .CLK(net610), .Q(
        \cpuregs[22][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][31]  ( .D(N682), .CLK(net600), .Q(
        \cpuregs[20][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][31]  ( .D(N682), .CLK(net590), .Q(
        \cpuregs[18][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][31]  ( .D(N682), .CLK(net580), .Q(
        \cpuregs[16][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][31]  ( .D(N682), .CLK(net570), .Q(
        \cpuregs[14][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][31]  ( .D(N682), .CLK(net560), .Q(
        \cpuregs[12][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][31]  ( .D(N682), .CLK(net550), .Q(
        \cpuregs[10][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][31]  ( .D(N682), .CLK(net540), .Q(
        \cpuregs[8][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][31]  ( .D(N682), .CLK(net530), .Q(
        \cpuregs[6][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][31]  ( .D(N682), .CLK(net520), .Q(
        \cpuregs[4][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][31]  ( .D(N682), .CLK(net510), .Q(
        \cpuregs[2][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][30]  ( .D(N681), .CLK(net650), .Q(
        \cpuregs[30][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][30]  ( .D(N681), .CLK(net640), .Q(
        \cpuregs[28][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][30]  ( .D(N681), .CLK(net630), .Q(
        \cpuregs[26][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][30]  ( .D(N681), .CLK(net620), .Q(
        \cpuregs[24][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][30]  ( .D(N681), .CLK(net610), .Q(
        \cpuregs[22][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][30]  ( .D(N681), .CLK(net600), .Q(
        \cpuregs[20][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][30]  ( .D(N681), .CLK(net590), .Q(
        \cpuregs[18][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][30]  ( .D(N681), .CLK(net580), .Q(
        \cpuregs[16][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][30]  ( .D(N681), .CLK(net570), .Q(
        \cpuregs[14][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][30]  ( .D(N681), .CLK(net560), .Q(
        \cpuregs[12][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][30]  ( .D(N681), .CLK(net550), .Q(
        \cpuregs[10][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][30]  ( .D(N681), .CLK(net540), .Q(
        \cpuregs[8][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][30]  ( .D(N681), .CLK(net530), .Q(
        \cpuregs[6][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][30]  ( .D(N681), .CLK(net520), .Q(
        \cpuregs[4][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][30]  ( .D(N681), .CLK(net510), .Q(
        \cpuregs[2][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][29]  ( .D(N680), .CLK(net650), .Q(
        \cpuregs[30][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][29]  ( .D(N680), .CLK(net640), .Q(
        \cpuregs[28][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][29]  ( .D(N680), .CLK(net630), .Q(
        \cpuregs[26][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][29]  ( .D(N680), .CLK(net620), .Q(
        \cpuregs[24][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][29]  ( .D(N680), .CLK(net610), .Q(
        \cpuregs[22][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][29]  ( .D(N680), .CLK(net600), .Q(
        \cpuregs[20][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][29]  ( .D(N680), .CLK(net590), .Q(
        \cpuregs[18][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][29]  ( .D(N680), .CLK(net580), .Q(
        \cpuregs[16][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][29]  ( .D(N680), .CLK(net570), .Q(
        \cpuregs[14][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][29]  ( .D(N680), .CLK(net560), .Q(
        \cpuregs[12][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][29]  ( .D(N680), .CLK(net550), .Q(
        \cpuregs[10][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][29]  ( .D(N680), .CLK(net540), .Q(
        \cpuregs[8][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][29]  ( .D(N680), .CLK(net530), .Q(
        \cpuregs[6][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][29]  ( .D(N680), .CLK(net520), .Q(
        \cpuregs[4][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][29]  ( .D(N680), .CLK(net510), .Q(
        \cpuregs[2][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][28]  ( .D(N679), .CLK(net650), .Q(
        \cpuregs[30][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][28]  ( .D(N679), .CLK(net640), .Q(
        \cpuregs[28][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][28]  ( .D(N679), .CLK(net630), .Q(
        \cpuregs[26][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][28]  ( .D(N679), .CLK(net620), .Q(
        \cpuregs[24][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][28]  ( .D(N679), .CLK(net610), .Q(
        \cpuregs[22][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][28]  ( .D(N679), .CLK(net600), .Q(
        \cpuregs[20][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][28]  ( .D(N679), .CLK(net590), .Q(
        \cpuregs[18][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][28]  ( .D(N679), .CLK(net580), .Q(
        \cpuregs[16][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][28]  ( .D(N679), .CLK(net570), .Q(
        \cpuregs[14][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][28]  ( .D(N679), .CLK(net560), .Q(
        \cpuregs[12][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][28]  ( .D(N679), .CLK(net550), .Q(
        \cpuregs[10][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][28]  ( .D(N679), .CLK(net540), .Q(
        \cpuregs[8][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][28]  ( .D(N679), .CLK(net530), .Q(
        \cpuregs[6][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][28]  ( .D(N679), .CLK(net520), .Q(
        \cpuregs[4][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][28]  ( .D(N679), .CLK(net510), .Q(
        \cpuregs[2][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][27]  ( .D(N678), .CLK(net650), .Q(
        \cpuregs[30][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][27]  ( .D(N678), .CLK(net640), .Q(
        \cpuregs[28][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][27]  ( .D(N678), .CLK(net630), .Q(
        \cpuregs[26][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][27]  ( .D(N678), .CLK(net620), .Q(
        \cpuregs[24][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][27]  ( .D(N678), .CLK(net610), .Q(
        \cpuregs[22][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][27]  ( .D(N678), .CLK(net600), .Q(
        \cpuregs[20][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][27]  ( .D(N678), .CLK(net590), .Q(
        \cpuregs[18][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][27]  ( .D(N678), .CLK(net580), .Q(
        \cpuregs[16][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][27]  ( .D(N678), .CLK(net570), .Q(
        \cpuregs[14][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][27]  ( .D(N678), .CLK(net560), .Q(
        \cpuregs[12][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][27]  ( .D(N678), .CLK(net550), .Q(
        \cpuregs[10][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][27]  ( .D(N678), .CLK(net540), .Q(
        \cpuregs[8][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][27]  ( .D(N678), .CLK(net530), .Q(
        \cpuregs[6][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][27]  ( .D(N678), .CLK(net520), .Q(
        \cpuregs[4][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][27]  ( .D(N678), .CLK(net510), .Q(
        \cpuregs[2][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][26]  ( .D(N677), .CLK(net650), .Q(
        \cpuregs[30][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][26]  ( .D(N677), .CLK(net640), .Q(
        \cpuregs[28][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][26]  ( .D(N677), .CLK(net630), .Q(
        \cpuregs[26][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][26]  ( .D(N677), .CLK(net620), .Q(
        \cpuregs[24][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][26]  ( .D(N677), .CLK(net610), .Q(
        \cpuregs[22][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][26]  ( .D(N677), .CLK(net600), .Q(
        \cpuregs[20][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][26]  ( .D(N677), .CLK(net590), .Q(
        \cpuregs[18][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][26]  ( .D(N677), .CLK(net580), .Q(
        \cpuregs[16][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][26]  ( .D(N677), .CLK(net570), .Q(
        \cpuregs[14][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][26]  ( .D(N677), .CLK(net560), .Q(
        \cpuregs[12][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][26]  ( .D(N677), .CLK(net550), .Q(
        \cpuregs[10][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][26]  ( .D(N677), .CLK(net540), .Q(
        \cpuregs[8][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][26]  ( .D(N677), .CLK(net530), .Q(
        \cpuregs[6][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][26]  ( .D(N677), .CLK(net520), .Q(
        \cpuregs[4][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][26]  ( .D(N677), .CLK(net510), .Q(
        \cpuregs[2][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][25]  ( .D(N676), .CLK(net650), .Q(
        \cpuregs[30][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][25]  ( .D(N676), .CLK(net640), .Q(
        \cpuregs[28][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][25]  ( .D(N676), .CLK(net630), .Q(
        \cpuregs[26][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][25]  ( .D(N676), .CLK(net620), .Q(
        \cpuregs[24][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][25]  ( .D(N676), .CLK(net610), .Q(
        \cpuregs[22][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][25]  ( .D(N676), .CLK(net600), .Q(
        \cpuregs[20][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][25]  ( .D(N676), .CLK(net590), .Q(
        \cpuregs[18][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][25]  ( .D(N676), .CLK(net580), .Q(
        \cpuregs[16][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][25]  ( .D(N676), .CLK(net570), .Q(
        \cpuregs[14][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][25]  ( .D(N676), .CLK(net560), .Q(
        \cpuregs[12][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][25]  ( .D(N676), .CLK(net550), .Q(
        \cpuregs[10][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][25]  ( .D(N676), .CLK(net540), .Q(
        \cpuregs[8][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][25]  ( .D(N676), .CLK(net530), .Q(
        \cpuregs[6][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][25]  ( .D(N676), .CLK(net520), .Q(
        \cpuregs[4][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][25]  ( .D(N676), .CLK(net510), .Q(
        \cpuregs[2][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][24]  ( .D(N675), .CLK(net650), .Q(
        \cpuregs[30][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][24]  ( .D(N675), .CLK(net640), .Q(
        \cpuregs[28][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][24]  ( .D(N675), .CLK(net630), .Q(
        \cpuregs[26][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][24]  ( .D(N675), .CLK(net620), .Q(
        \cpuregs[24][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][24]  ( .D(N675), .CLK(net610), .Q(
        \cpuregs[22][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][24]  ( .D(N675), .CLK(net600), .Q(
        \cpuregs[20][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][24]  ( .D(N675), .CLK(net590), .Q(
        \cpuregs[18][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][24]  ( .D(N675), .CLK(net580), .Q(
        \cpuregs[16][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][24]  ( .D(N675), .CLK(net570), .Q(
        \cpuregs[14][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][24]  ( .D(N675), .CLK(net560), .Q(
        \cpuregs[12][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][24]  ( .D(N675), .CLK(net550), .Q(
        \cpuregs[10][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][24]  ( .D(N675), .CLK(net540), .Q(
        \cpuregs[8][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][24]  ( .D(N675), .CLK(net530), .Q(
        \cpuregs[6][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][24]  ( .D(N675), .CLK(net520), .Q(
        \cpuregs[4][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][24]  ( .D(N675), .CLK(net510), .Q(
        \cpuregs[2][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][23]  ( .D(N674), .CLK(net650), .Q(
        \cpuregs[30][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][23]  ( .D(N674), .CLK(net640), .Q(
        \cpuregs[28][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][23]  ( .D(N674), .CLK(net630), .Q(
        \cpuregs[26][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][23]  ( .D(N674), .CLK(net620), .Q(
        \cpuregs[24][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][23]  ( .D(N674), .CLK(net610), .Q(
        \cpuregs[22][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][23]  ( .D(N674), .CLK(net600), .Q(
        \cpuregs[20][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][23]  ( .D(N674), .CLK(net590), .Q(
        \cpuregs[18][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][23]  ( .D(N674), .CLK(net580), .Q(
        \cpuregs[16][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][23]  ( .D(N674), .CLK(net570), .Q(
        \cpuregs[14][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][23]  ( .D(N674), .CLK(net560), .Q(
        \cpuregs[12][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][23]  ( .D(N674), .CLK(net550), .Q(
        \cpuregs[10][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][23]  ( .D(N674), .CLK(net540), .Q(
        \cpuregs[8][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][23]  ( .D(N674), .CLK(net530), .Q(
        \cpuregs[6][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][23]  ( .D(N674), .CLK(net520), .Q(
        \cpuregs[4][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][23]  ( .D(N674), .CLK(net510), .Q(
        \cpuregs[2][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][22]  ( .D(N673), .CLK(net650), .Q(
        \cpuregs[30][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][22]  ( .D(N673), .CLK(net640), .Q(
        \cpuregs[28][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][22]  ( .D(N673), .CLK(net630), .Q(
        \cpuregs[26][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][22]  ( .D(N673), .CLK(net620), .Q(
        \cpuregs[24][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][22]  ( .D(N673), .CLK(net610), .Q(
        \cpuregs[22][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][22]  ( .D(N673), .CLK(net600), .Q(
        \cpuregs[20][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][22]  ( .D(N673), .CLK(net590), .Q(
        \cpuregs[18][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][22]  ( .D(N673), .CLK(net580), .Q(
        \cpuregs[16][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][22]  ( .D(N673), .CLK(net570), .Q(
        \cpuregs[14][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][22]  ( .D(N673), .CLK(net560), .Q(
        \cpuregs[12][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][22]  ( .D(N673), .CLK(net550), .Q(
        \cpuregs[10][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][22]  ( .D(N673), .CLK(net540), .Q(
        \cpuregs[8][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][22]  ( .D(N673), .CLK(net530), .Q(
        \cpuregs[6][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][22]  ( .D(N673), .CLK(net520), .Q(
        \cpuregs[4][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][22]  ( .D(N673), .CLK(net510), .Q(
        \cpuregs[2][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][21]  ( .D(N672), .CLK(net650), .Q(
        \cpuregs[30][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][21]  ( .D(N672), .CLK(net640), .Q(
        \cpuregs[28][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][21]  ( .D(N672), .CLK(net630), .Q(
        \cpuregs[26][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][21]  ( .D(N672), .CLK(net620), .Q(
        \cpuregs[24][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][21]  ( .D(N672), .CLK(net610), .Q(
        \cpuregs[22][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][21]  ( .D(N672), .CLK(net600), .Q(
        \cpuregs[20][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][21]  ( .D(N672), .CLK(net590), .Q(
        \cpuregs[18][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][21]  ( .D(N672), .CLK(net580), .Q(
        \cpuregs[16][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][21]  ( .D(N672), .CLK(net570), .Q(
        \cpuregs[14][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][21]  ( .D(N672), .CLK(net560), .Q(
        \cpuregs[12][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][21]  ( .D(N672), .CLK(net550), .Q(
        \cpuregs[10][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][21]  ( .D(N672), .CLK(net540), .Q(
        \cpuregs[8][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][21]  ( .D(N672), .CLK(net530), .Q(
        \cpuregs[6][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][21]  ( .D(N672), .CLK(net520), .Q(
        \cpuregs[4][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][21]  ( .D(N672), .CLK(net510), .Q(
        \cpuregs[2][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][20]  ( .D(N671), .CLK(net650), .Q(
        \cpuregs[30][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][20]  ( .D(N671), .CLK(net640), .Q(
        \cpuregs[28][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][20]  ( .D(N671), .CLK(net630), .Q(
        \cpuregs[26][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][20]  ( .D(N671), .CLK(net620), .Q(
        \cpuregs[24][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][20]  ( .D(N671), .CLK(net610), .Q(
        \cpuregs[22][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][20]  ( .D(N671), .CLK(net600), .Q(
        \cpuregs[20][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][20]  ( .D(N671), .CLK(net590), .Q(
        \cpuregs[18][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][20]  ( .D(N671), .CLK(net580), .Q(
        \cpuregs[16][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][20]  ( .D(N671), .CLK(net570), .Q(
        \cpuregs[14][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][20]  ( .D(N671), .CLK(net560), .Q(
        \cpuregs[12][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][20]  ( .D(N671), .CLK(net550), .Q(
        \cpuregs[10][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][20]  ( .D(N671), .CLK(net540), .Q(
        \cpuregs[8][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][20]  ( .D(N671), .CLK(net530), .Q(
        \cpuregs[6][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][20]  ( .D(N671), .CLK(net520), .Q(
        \cpuregs[4][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][20]  ( .D(N671), .CLK(net510), .Q(
        \cpuregs[2][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][19]  ( .D(N670), .CLK(net650), .Q(
        \cpuregs[30][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][19]  ( .D(N670), .CLK(net640), .Q(
        \cpuregs[28][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][19]  ( .D(N670), .CLK(net630), .Q(
        \cpuregs[26][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][19]  ( .D(N670), .CLK(net620), .Q(
        \cpuregs[24][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][19]  ( .D(N670), .CLK(net610), .Q(
        \cpuregs[22][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][19]  ( .D(N670), .CLK(net600), .Q(
        \cpuregs[20][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][19]  ( .D(N670), .CLK(net590), .Q(
        \cpuregs[18][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][19]  ( .D(N670), .CLK(net580), .Q(
        \cpuregs[16][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][19]  ( .D(N670), .CLK(net570), .Q(
        \cpuregs[14][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][19]  ( .D(N670), .CLK(net560), .Q(
        \cpuregs[12][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][19]  ( .D(N670), .CLK(net550), .Q(
        \cpuregs[10][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][19]  ( .D(N670), .CLK(net540), .Q(
        \cpuregs[8][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][19]  ( .D(N670), .CLK(net530), .Q(
        \cpuregs[6][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][19]  ( .D(N670), .CLK(net520), .Q(
        \cpuregs[4][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][19]  ( .D(N670), .CLK(net510), .Q(
        \cpuregs[2][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][18]  ( .D(N669), .CLK(net650), .Q(
        \cpuregs[30][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][18]  ( .D(N669), .CLK(net640), .Q(
        \cpuregs[28][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][18]  ( .D(N669), .CLK(net630), .Q(
        \cpuregs[26][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][18]  ( .D(N669), .CLK(net620), .Q(
        \cpuregs[24][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][18]  ( .D(N669), .CLK(net610), .Q(
        \cpuregs[22][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][18]  ( .D(N669), .CLK(net600), .Q(
        \cpuregs[20][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][18]  ( .D(N669), .CLK(net590), .Q(
        \cpuregs[18][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][18]  ( .D(N669), .CLK(net580), .Q(
        \cpuregs[16][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][18]  ( .D(N669), .CLK(net570), .Q(
        \cpuregs[14][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][18]  ( .D(N669), .CLK(net560), .Q(
        \cpuregs[12][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][18]  ( .D(N669), .CLK(net550), .Q(
        \cpuregs[10][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][18]  ( .D(N669), .CLK(net540), .Q(
        \cpuregs[8][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][18]  ( .D(N669), .CLK(net530), .Q(
        \cpuregs[6][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][18]  ( .D(N669), .CLK(net520), .Q(
        \cpuregs[4][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][18]  ( .D(N669), .CLK(net510), .Q(
        \cpuregs[2][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][17]  ( .D(N668), .CLK(net650), .Q(
        \cpuregs[30][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][17]  ( .D(N668), .CLK(net640), .Q(
        \cpuregs[28][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][17]  ( .D(N668), .CLK(net630), .Q(
        \cpuregs[26][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][17]  ( .D(N668), .CLK(net620), .Q(
        \cpuregs[24][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][17]  ( .D(N668), .CLK(net610), .Q(
        \cpuregs[22][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][17]  ( .D(N668), .CLK(net600), .Q(
        \cpuregs[20][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][17]  ( .D(N668), .CLK(net590), .Q(
        \cpuregs[18][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][17]  ( .D(N668), .CLK(net580), .Q(
        \cpuregs[16][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][17]  ( .D(N668), .CLK(net570), .Q(
        \cpuregs[14][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][17]  ( .D(N668), .CLK(net560), .Q(
        \cpuregs[12][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][17]  ( .D(N668), .CLK(net550), .Q(
        \cpuregs[10][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][17]  ( .D(N668), .CLK(net540), .Q(
        \cpuregs[8][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][17]  ( .D(N668), .CLK(net530), .Q(
        \cpuregs[6][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][17]  ( .D(N668), .CLK(net520), .Q(
        \cpuregs[4][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][17]  ( .D(N668), .CLK(net510), .Q(
        \cpuregs[2][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][16]  ( .D(N667), .CLK(net650), .Q(
        \cpuregs[30][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][16]  ( .D(N667), .CLK(net640), .Q(
        \cpuregs[28][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][16]  ( .D(N667), .CLK(net630), .Q(
        \cpuregs[26][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][16]  ( .D(N667), .CLK(net620), .Q(
        \cpuregs[24][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][16]  ( .D(N667), .CLK(net610), .Q(
        \cpuregs[22][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][16]  ( .D(N667), .CLK(net600), .Q(
        \cpuregs[20][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][16]  ( .D(N667), .CLK(net590), .Q(
        \cpuregs[18][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][16]  ( .D(N667), .CLK(net580), .Q(
        \cpuregs[16][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][16]  ( .D(N667), .CLK(net570), .Q(
        \cpuregs[14][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][16]  ( .D(N667), .CLK(net560), .Q(
        \cpuregs[12][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][16]  ( .D(N667), .CLK(net550), .Q(
        \cpuregs[10][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][16]  ( .D(N667), .CLK(net540), .Q(
        \cpuregs[8][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][16]  ( .D(N667), .CLK(net530), .Q(
        \cpuregs[6][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][16]  ( .D(N667), .CLK(net520), .Q(
        \cpuregs[4][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][16]  ( .D(N667), .CLK(net510), .Q(
        \cpuregs[2][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][15]  ( .D(N666), .CLK(net650), .Q(
        \cpuregs[30][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][15]  ( .D(N666), .CLK(net640), .Q(
        \cpuregs[28][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][15]  ( .D(N666), .CLK(net630), .Q(
        \cpuregs[26][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][15]  ( .D(N666), .CLK(net620), .Q(
        \cpuregs[24][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][15]  ( .D(N666), .CLK(net610), .Q(
        \cpuregs[22][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][15]  ( .D(N666), .CLK(net600), .Q(
        \cpuregs[20][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][15]  ( .D(N666), .CLK(net590), .Q(
        \cpuregs[18][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][15]  ( .D(N666), .CLK(net580), .Q(
        \cpuregs[16][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][15]  ( .D(N666), .CLK(net570), .Q(
        \cpuregs[14][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][15]  ( .D(N666), .CLK(net560), .Q(
        \cpuregs[12][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][15]  ( .D(N666), .CLK(net550), .Q(
        \cpuregs[10][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][15]  ( .D(N666), .CLK(net540), .Q(
        \cpuregs[8][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][15]  ( .D(N666), .CLK(net530), .Q(
        \cpuregs[6][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][15]  ( .D(N666), .CLK(net520), .Q(
        \cpuregs[4][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][15]  ( .D(N666), .CLK(net510), .Q(
        \cpuregs[2][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][14]  ( .D(N665), .CLK(net650), .Q(
        \cpuregs[30][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][14]  ( .D(N665), .CLK(net640), .Q(
        \cpuregs[28][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][14]  ( .D(N665), .CLK(net630), .Q(
        \cpuregs[26][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][14]  ( .D(N665), .CLK(net620), .Q(
        \cpuregs[24][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][14]  ( .D(N665), .CLK(net610), .Q(
        \cpuregs[22][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][14]  ( .D(N665), .CLK(net600), .Q(
        \cpuregs[20][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][14]  ( .D(N665), .CLK(net590), .Q(
        \cpuregs[18][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][14]  ( .D(N665), .CLK(net580), .Q(
        \cpuregs[16][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][14]  ( .D(N665), .CLK(net570), .Q(
        \cpuregs[14][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][14]  ( .D(N665), .CLK(net560), .Q(
        \cpuregs[12][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][14]  ( .D(N665), .CLK(net550), .Q(
        \cpuregs[10][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][14]  ( .D(N665), .CLK(net540), .Q(
        \cpuregs[8][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][14]  ( .D(N665), .CLK(net530), .Q(
        \cpuregs[6][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][14]  ( .D(N665), .CLK(net520), .Q(
        \cpuregs[4][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][14]  ( .D(N665), .CLK(net510), .Q(
        \cpuregs[2][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][13]  ( .D(N664), .CLK(net650), .Q(
        \cpuregs[30][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][13]  ( .D(N664), .CLK(net640), .Q(
        \cpuregs[28][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][13]  ( .D(N664), .CLK(net630), .Q(
        \cpuregs[26][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][13]  ( .D(N664), .CLK(net620), .Q(
        \cpuregs[24][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][13]  ( .D(N664), .CLK(net610), .Q(
        \cpuregs[22][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][13]  ( .D(N664), .CLK(net600), .Q(
        \cpuregs[20][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][13]  ( .D(N664), .CLK(net590), .Q(
        \cpuregs[18][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][13]  ( .D(N664), .CLK(net580), .Q(
        \cpuregs[16][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][13]  ( .D(N664), .CLK(net570), .Q(
        \cpuregs[14][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][13]  ( .D(N664), .CLK(net560), .Q(
        \cpuregs[12][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][13]  ( .D(N664), .CLK(net550), .Q(
        \cpuregs[10][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][13]  ( .D(N664), .CLK(net540), .Q(
        \cpuregs[8][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][13]  ( .D(N664), .CLK(net530), .Q(
        \cpuregs[6][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][13]  ( .D(N664), .CLK(net520), .Q(
        \cpuregs[4][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][13]  ( .D(N664), .CLK(net510), .Q(
        \cpuregs[2][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][12]  ( .D(N663), .CLK(net650), .Q(
        \cpuregs[30][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][12]  ( .D(N663), .CLK(net640), .Q(
        \cpuregs[28][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][12]  ( .D(N663), .CLK(net630), .Q(
        \cpuregs[26][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][12]  ( .D(N663), .CLK(net620), .Q(
        \cpuregs[24][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][12]  ( .D(N663), .CLK(net610), .Q(
        \cpuregs[22][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][12]  ( .D(N663), .CLK(net600), .Q(
        \cpuregs[20][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][12]  ( .D(N663), .CLK(net590), .Q(
        \cpuregs[18][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][12]  ( .D(N663), .CLK(net580), .Q(
        \cpuregs[16][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][12]  ( .D(N663), .CLK(net570), .Q(
        \cpuregs[14][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][12]  ( .D(N663), .CLK(net560), .Q(
        \cpuregs[12][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][12]  ( .D(N663), .CLK(net550), .Q(
        \cpuregs[10][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][12]  ( .D(N663), .CLK(net540), .Q(
        \cpuregs[8][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][12]  ( .D(N663), .CLK(net530), .Q(
        \cpuregs[6][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][12]  ( .D(N663), .CLK(net520), .Q(
        \cpuregs[4][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][12]  ( .D(N663), .CLK(net510), .Q(
        \cpuregs[2][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][11]  ( .D(N662), .CLK(net650), .Q(
        \cpuregs[30][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][11]  ( .D(N662), .CLK(net640), .Q(
        \cpuregs[28][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][11]  ( .D(N662), .CLK(net630), .Q(
        \cpuregs[26][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][11]  ( .D(N662), .CLK(net620), .Q(
        \cpuregs[24][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][11]  ( .D(N662), .CLK(net610), .Q(
        \cpuregs[22][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][11]  ( .D(N662), .CLK(net600), .Q(
        \cpuregs[20][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][11]  ( .D(N662), .CLK(net590), .Q(
        \cpuregs[18][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][11]  ( .D(N662), .CLK(net580), .Q(
        \cpuregs[16][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][11]  ( .D(N662), .CLK(net570), .Q(
        \cpuregs[14][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][11]  ( .D(N662), .CLK(net560), .Q(
        \cpuregs[12][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][11]  ( .D(N662), .CLK(net550), .Q(
        \cpuregs[10][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][11]  ( .D(N662), .CLK(net540), .Q(
        \cpuregs[8][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][11]  ( .D(N662), .CLK(net530), .Q(
        \cpuregs[6][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][11]  ( .D(N662), .CLK(net520), .Q(
        \cpuregs[4][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][11]  ( .D(N662), .CLK(net510), .Q(
        \cpuregs[2][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][10]  ( .D(N661), .CLK(net650), .Q(
        \cpuregs[30][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][10]  ( .D(N661), .CLK(net640), .Q(
        \cpuregs[28][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][10]  ( .D(N661), .CLK(net630), .Q(
        \cpuregs[26][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][10]  ( .D(N661), .CLK(net620), .Q(
        \cpuregs[24][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][10]  ( .D(N661), .CLK(net610), .Q(
        \cpuregs[22][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][10]  ( .D(N661), .CLK(net600), .Q(
        \cpuregs[20][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][10]  ( .D(N661), .CLK(net590), .Q(
        \cpuregs[18][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][10]  ( .D(N661), .CLK(net580), .Q(
        \cpuregs[16][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][10]  ( .D(N661), .CLK(net570), .Q(
        \cpuregs[14][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][10]  ( .D(N661), .CLK(net560), .Q(
        \cpuregs[12][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][10]  ( .D(N661), .CLK(net550), .Q(
        \cpuregs[10][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][10]  ( .D(N661), .CLK(net540), .Q(
        \cpuregs[8][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][10]  ( .D(N661), .CLK(net530), .Q(
        \cpuregs[6][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][10]  ( .D(N661), .CLK(net520), .Q(
        \cpuregs[4][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][10]  ( .D(N661), .CLK(net510), .Q(
        \cpuregs[2][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][9]  ( .D(N660), .CLK(net650), .Q(
        \cpuregs[30][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][9]  ( .D(N660), .CLK(net640), .Q(
        \cpuregs[28][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][9]  ( .D(N660), .CLK(net630), .Q(
        \cpuregs[26][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][9]  ( .D(N660), .CLK(net620), .Q(
        \cpuregs[24][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][9]  ( .D(N660), .CLK(net610), .Q(
        \cpuregs[22][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][9]  ( .D(N660), .CLK(net600), .Q(
        \cpuregs[20][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][9]  ( .D(N660), .CLK(net590), .Q(
        \cpuregs[18][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][9]  ( .D(N660), .CLK(net580), .Q(
        \cpuregs[16][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][9]  ( .D(N660), .CLK(net570), .Q(
        \cpuregs[14][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][9]  ( .D(N660), .CLK(net560), .Q(
        \cpuregs[12][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][9]  ( .D(N660), .CLK(net550), .Q(
        \cpuregs[10][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][9]  ( .D(N660), .CLK(net540), .Q(
        \cpuregs[8][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][9]  ( .D(N660), .CLK(net530), .Q(
        \cpuregs[6][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][9]  ( .D(N660), .CLK(net520), .Q(
        \cpuregs[4][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][9]  ( .D(N660), .CLK(net510), .Q(
        \cpuregs[2][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][8]  ( .D(N659), .CLK(net650), .Q(
        \cpuregs[30][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][8]  ( .D(N659), .CLK(net640), .Q(
        \cpuregs[28][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][8]  ( .D(N659), .CLK(net630), .Q(
        \cpuregs[26][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][8]  ( .D(N659), .CLK(net620), .Q(
        \cpuregs[24][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][8]  ( .D(N659), .CLK(net610), .Q(
        \cpuregs[22][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][8]  ( .D(N659), .CLK(net600), .Q(
        \cpuregs[20][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][8]  ( .D(N659), .CLK(net590), .Q(
        \cpuregs[18][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][8]  ( .D(N659), .CLK(net580), .Q(
        \cpuregs[16][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][8]  ( .D(N659), .CLK(net570), .Q(
        \cpuregs[14][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][8]  ( .D(N659), .CLK(net560), .Q(
        \cpuregs[12][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][8]  ( .D(N659), .CLK(net550), .Q(
        \cpuregs[10][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][8]  ( .D(N659), .CLK(net540), .Q(
        \cpuregs[8][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][8]  ( .D(N659), .CLK(net530), .Q(
        \cpuregs[6][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][8]  ( .D(N659), .CLK(net520), .Q(
        \cpuregs[4][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][8]  ( .D(N659), .CLK(net510), .Q(
        \cpuregs[2][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][7]  ( .D(N658), .CLK(net650), .Q(
        \cpuregs[30][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][7]  ( .D(N658), .CLK(net640), .Q(
        \cpuregs[28][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][7]  ( .D(N658), .CLK(net630), .Q(
        \cpuregs[26][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][7]  ( .D(N658), .CLK(net620), .Q(
        \cpuregs[24][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][7]  ( .D(N658), .CLK(net610), .Q(
        \cpuregs[22][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][7]  ( .D(N658), .CLK(net600), .Q(
        \cpuregs[20][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][7]  ( .D(N658), .CLK(net590), .Q(
        \cpuregs[18][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][7]  ( .D(N658), .CLK(net580), .Q(
        \cpuregs[16][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][7]  ( .D(N658), .CLK(net570), .Q(
        \cpuregs[14][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][7]  ( .D(N658), .CLK(net560), .Q(
        \cpuregs[12][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][7]  ( .D(N658), .CLK(net550), .Q(
        \cpuregs[10][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][7]  ( .D(N658), .CLK(net540), .Q(
        \cpuregs[8][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][7]  ( .D(N658), .CLK(net530), .Q(
        \cpuregs[6][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][7]  ( .D(N658), .CLK(net520), .Q(
        \cpuregs[4][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][7]  ( .D(N658), .CLK(net510), .Q(
        \cpuregs[2][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][6]  ( .D(N657), .CLK(net650), .Q(
        \cpuregs[30][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][6]  ( .D(N657), .CLK(net640), .Q(
        \cpuregs[28][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][6]  ( .D(N657), .CLK(net630), .Q(
        \cpuregs[26][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][6]  ( .D(N657), .CLK(net620), .Q(
        \cpuregs[24][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][6]  ( .D(N657), .CLK(net610), .Q(
        \cpuregs[22][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][6]  ( .D(N657), .CLK(net600), .Q(
        \cpuregs[20][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][6]  ( .D(N657), .CLK(net590), .Q(
        \cpuregs[18][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][6]  ( .D(N657), .CLK(net580), .Q(
        \cpuregs[16][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][6]  ( .D(N657), .CLK(net570), .Q(
        \cpuregs[14][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][6]  ( .D(N657), .CLK(net560), .Q(
        \cpuregs[12][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][6]  ( .D(N657), .CLK(net550), .Q(
        \cpuregs[10][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][6]  ( .D(N657), .CLK(net540), .Q(
        \cpuregs[8][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][6]  ( .D(N657), .CLK(net530), .Q(
        \cpuregs[6][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][6]  ( .D(N657), .CLK(net520), .Q(
        \cpuregs[4][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][6]  ( .D(N657), .CLK(net510), .Q(
        \cpuregs[2][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][5]  ( .D(N656), .CLK(net650), .Q(
        \cpuregs[30][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][5]  ( .D(N656), .CLK(net640), .Q(
        \cpuregs[28][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][5]  ( .D(N656), .CLK(net630), .Q(
        \cpuregs[26][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][5]  ( .D(N656), .CLK(net620), .Q(
        \cpuregs[24][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][5]  ( .D(N656), .CLK(net610), .Q(
        \cpuregs[22][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][5]  ( .D(N656), .CLK(net600), .Q(
        \cpuregs[20][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][5]  ( .D(N656), .CLK(net590), .Q(
        \cpuregs[18][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][5]  ( .D(N656), .CLK(net580), .Q(
        \cpuregs[16][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][5]  ( .D(N656), .CLK(net570), .Q(
        \cpuregs[14][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][5]  ( .D(N656), .CLK(net560), .Q(
        \cpuregs[12][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][5]  ( .D(N656), .CLK(net550), .Q(
        \cpuregs[10][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][5]  ( .D(N656), .CLK(net540), .Q(
        \cpuregs[8][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][5]  ( .D(N656), .CLK(net530), .Q(
        \cpuregs[6][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][5]  ( .D(N656), .CLK(net520), .Q(
        \cpuregs[4][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][5]  ( .D(N656), .CLK(net510), .Q(
        \cpuregs[2][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][4]  ( .D(N655), .CLK(net650), .Q(
        \cpuregs[30][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][4]  ( .D(N655), .CLK(net640), .Q(
        \cpuregs[28][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][4]  ( .D(N655), .CLK(net630), .Q(
        \cpuregs[26][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][4]  ( .D(N655), .CLK(net620), .Q(
        \cpuregs[24][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][4]  ( .D(N655), .CLK(net610), .Q(
        \cpuregs[22][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][4]  ( .D(N655), .CLK(net600), .Q(
        \cpuregs[20][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][4]  ( .D(N655), .CLK(net590), .Q(
        \cpuregs[18][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][4]  ( .D(N655), .CLK(net580), .Q(
        \cpuregs[16][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][4]  ( .D(N655), .CLK(net570), .Q(
        \cpuregs[14][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][4]  ( .D(N655), .CLK(net560), .Q(
        \cpuregs[12][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][4]  ( .D(N655), .CLK(net550), .Q(
        \cpuregs[10][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][4]  ( .D(N655), .CLK(net540), .Q(
        \cpuregs[8][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][4]  ( .D(N655), .CLK(net530), .Q(
        \cpuregs[6][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][4]  ( .D(N655), .CLK(net520), .Q(
        \cpuregs[4][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][4]  ( .D(N655), .CLK(net510), .Q(
        \cpuregs[2][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][3]  ( .D(N654), .CLK(net650), .Q(
        \cpuregs[30][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][3]  ( .D(N654), .CLK(net640), .Q(
        \cpuregs[28][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][3]  ( .D(N654), .CLK(net630), .Q(
        \cpuregs[26][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][3]  ( .D(N654), .CLK(net620), .Q(
        \cpuregs[24][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][3]  ( .D(N654), .CLK(net610), .Q(
        \cpuregs[22][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][3]  ( .D(N654), .CLK(net600), .Q(
        \cpuregs[20][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][3]  ( .D(N654), .CLK(net590), .Q(
        \cpuregs[18][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][3]  ( .D(N654), .CLK(net580), .Q(
        \cpuregs[16][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][3]  ( .D(N654), .CLK(net570), .Q(
        \cpuregs[14][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][3]  ( .D(N654), .CLK(net560), .Q(
        \cpuregs[12][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][3]  ( .D(N654), .CLK(net550), .Q(
        \cpuregs[10][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][3]  ( .D(N654), .CLK(net540), .Q(
        \cpuregs[8][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][3]  ( .D(N654), .CLK(net530), .Q(
        \cpuregs[6][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][3]  ( .D(N654), .CLK(net520), .Q(
        \cpuregs[4][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][3]  ( .D(N654), .CLK(net510), .Q(
        \cpuregs[2][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][2]  ( .D(N653), .CLK(net650), .Q(
        \cpuregs[30][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][2]  ( .D(N653), .CLK(net640), .Q(
        \cpuregs[28][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][2]  ( .D(N653), .CLK(net630), .Q(
        \cpuregs[26][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][2]  ( .D(N653), .CLK(net620), .Q(
        \cpuregs[24][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][2]  ( .D(N653), .CLK(net610), .Q(
        \cpuregs[22][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][2]  ( .D(N653), .CLK(net600), .Q(
        \cpuregs[20][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][2]  ( .D(N653), .CLK(net590), .Q(
        \cpuregs[18][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][2]  ( .D(N653), .CLK(net580), .Q(
        \cpuregs[16][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][2]  ( .D(N653), .CLK(net570), .Q(
        \cpuregs[14][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][2]  ( .D(N653), .CLK(net560), .Q(
        \cpuregs[12][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][2]  ( .D(N653), .CLK(net550), .Q(
        \cpuregs[10][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][2]  ( .D(N653), .CLK(net540), .Q(
        \cpuregs[8][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][2]  ( .D(N653), .CLK(net530), .Q(
        \cpuregs[6][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][2]  ( .D(N653), .CLK(net520), .Q(
        \cpuregs[4][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][2]  ( .D(N653), .CLK(net510), .Q(
        \cpuregs[2][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][1]  ( .D(N652), .CLK(net650), .Q(
        \cpuregs[30][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][1]  ( .D(N652), .CLK(net640), .Q(
        \cpuregs[28][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][1]  ( .D(N652), .CLK(net630), .Q(
        \cpuregs[26][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][1]  ( .D(N652), .CLK(net620), .Q(
        \cpuregs[24][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][1]  ( .D(N652), .CLK(net610), .Q(
        \cpuregs[22][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][1]  ( .D(N652), .CLK(net600), .Q(
        \cpuregs[20][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][1]  ( .D(N652), .CLK(net590), .Q(
        \cpuregs[18][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][1]  ( .D(N652), .CLK(net580), .Q(
        \cpuregs[16][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][1]  ( .D(N652), .CLK(net570), .Q(
        \cpuregs[14][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][1]  ( .D(N652), .CLK(net560), .Q(
        \cpuregs[12][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][1]  ( .D(N652), .CLK(net550), .Q(
        \cpuregs[10][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][1]  ( .D(N652), .CLK(net540), .Q(
        \cpuregs[8][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][1]  ( .D(N652), .CLK(net530), .Q(
        \cpuregs[6][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][1]  ( .D(N652), .CLK(net520), .Q(
        \cpuregs[4][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][1]  ( .D(N652), .CLK(net510), .Q(
        \cpuregs[2][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[2][0]  ( .D(n3572), .CLK(net510), .Q(
        \cpuregs[2][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[4][0]  ( .D(n3572), .CLK(net520), .Q(
        \cpuregs[4][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[6][0]  ( .D(n3572), .CLK(net530), .Q(
        \cpuregs[6][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[8][0]  ( .D(n3572), .CLK(net540), .Q(
        \cpuregs[8][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[10][0]  ( .D(n3572), .CLK(net550), .Q(
        \cpuregs[10][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[12][0]  ( .D(n3572), .CLK(net560), .Q(
        \cpuregs[12][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[14][0]  ( .D(n3572), .CLK(net570), .Q(
        \cpuregs[14][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[16][0]  ( .D(n3572), .CLK(net580), .Q(
        \cpuregs[16][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[18][0]  ( .D(n3572), .CLK(net590), .Q(
        \cpuregs[18][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[20][0]  ( .D(n3572), .CLK(net600), .Q(
        \cpuregs[20][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[22][0]  ( .D(n3572), .CLK(net610), .Q(
        \cpuregs[22][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[24][0]  ( .D(n3572), .CLK(net620), .Q(
        \cpuregs[24][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[26][0]  ( .D(n3572), .CLK(net630), .Q(
        \cpuregs[26][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[28][0]  ( .D(n3572), .CLK(net640), .Q(
        \cpuregs[28][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[30][0]  ( .D(n3572), .CLK(net650), .Q(
        \cpuregs[30][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \reg_sh_reg[1]  ( .D(N1874), .CLK(n1047), .Q(N1564)
         );
  sky130_fd_sc_hd__dfxtp_1 instr_slti_reg ( .D(N359), .CLK(net500), .Q(
        instr_slti) );
  sky130_fd_sc_hd__dfxtp_1 \alu_out_q_reg[1]  ( .D(alu_out[1]), .CLK(n1052), 
        .Q(alu_out_q[1]) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][31]  ( .D(N682), .CLK(net655), .Q(
        \cpuregs[31][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][31]  ( .D(N682), .CLK(net645), .Q(
        \cpuregs[29][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][31]  ( .D(N682), .CLK(net635), .Q(
        \cpuregs[27][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][31]  ( .D(N682), .CLK(net625), .Q(
        \cpuregs[25][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][31]  ( .D(N682), .CLK(net615), .Q(
        \cpuregs[23][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][31]  ( .D(N682), .CLK(net605), .Q(
        \cpuregs[21][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][31]  ( .D(N682), .CLK(net595), .Q(
        \cpuregs[19][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][31]  ( .D(N682), .CLK(net585), .Q(
        \cpuregs[17][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][31]  ( .D(N682), .CLK(net575), .Q(
        \cpuregs[15][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][31]  ( .D(N682), .CLK(net565), .Q(
        \cpuregs[13][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][31]  ( .D(N682), .CLK(net555), .Q(
        \cpuregs[11][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][31]  ( .D(N682), .CLK(net545), .Q(
        \cpuregs[9][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][31]  ( .D(N682), .CLK(net535), .Q(
        \cpuregs[7][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][31]  ( .D(N682), .CLK(net525), .Q(
        \cpuregs[5][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][31]  ( .D(N682), .CLK(net515), .Q(
        \cpuregs[3][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][31]  ( .D(N682), .CLK(net505), .Q(
        \cpuregs[1][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][30]  ( .D(N681), .CLK(net655), .Q(
        \cpuregs[31][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][30]  ( .D(N681), .CLK(net645), .Q(
        \cpuregs[29][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][30]  ( .D(N681), .CLK(net635), .Q(
        \cpuregs[27][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][30]  ( .D(N681), .CLK(net625), .Q(
        \cpuregs[25][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][30]  ( .D(N681), .CLK(net615), .Q(
        \cpuregs[23][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][30]  ( .D(N681), .CLK(net605), .Q(
        \cpuregs[21][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][30]  ( .D(N681), .CLK(net595), .Q(
        \cpuregs[19][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][30]  ( .D(N681), .CLK(net585), .Q(
        \cpuregs[17][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][30]  ( .D(N681), .CLK(net575), .Q(
        \cpuregs[15][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][30]  ( .D(N681), .CLK(net565), .Q(
        \cpuregs[13][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][30]  ( .D(N681), .CLK(net555), .Q(
        \cpuregs[11][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][30]  ( .D(N681), .CLK(net545), .Q(
        \cpuregs[9][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][30]  ( .D(N681), .CLK(net535), .Q(
        \cpuregs[7][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][30]  ( .D(N681), .CLK(net525), .Q(
        \cpuregs[5][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][30]  ( .D(N681), .CLK(net515), .Q(
        \cpuregs[3][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][30]  ( .D(N681), .CLK(net505), .Q(
        \cpuregs[1][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][29]  ( .D(N680), .CLK(net655), .Q(
        \cpuregs[31][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][29]  ( .D(N680), .CLK(net645), .Q(
        \cpuregs[29][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][29]  ( .D(N680), .CLK(net635), .Q(
        \cpuregs[27][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][29]  ( .D(N680), .CLK(net625), .Q(
        \cpuregs[25][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][29]  ( .D(N680), .CLK(net615), .Q(
        \cpuregs[23][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][29]  ( .D(N680), .CLK(net605), .Q(
        \cpuregs[21][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][29]  ( .D(N680), .CLK(net595), .Q(
        \cpuregs[19][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][29]  ( .D(N680), .CLK(net585), .Q(
        \cpuregs[17][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][29]  ( .D(N680), .CLK(net575), .Q(
        \cpuregs[15][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][29]  ( .D(N680), .CLK(net565), .Q(
        \cpuregs[13][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][29]  ( .D(N680), .CLK(net555), .Q(
        \cpuregs[11][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][29]  ( .D(N680), .CLK(net545), .Q(
        \cpuregs[9][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][29]  ( .D(N680), .CLK(net535), .Q(
        \cpuregs[7][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][29]  ( .D(N680), .CLK(net525), .Q(
        \cpuregs[5][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][29]  ( .D(N680), .CLK(net515), .Q(
        \cpuregs[3][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][29]  ( .D(N680), .CLK(net505), .Q(
        \cpuregs[1][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][28]  ( .D(N679), .CLK(net655), .Q(
        \cpuregs[31][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][28]  ( .D(N679), .CLK(net645), .Q(
        \cpuregs[29][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][28]  ( .D(N679), .CLK(net635), .Q(
        \cpuregs[27][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][28]  ( .D(N679), .CLK(net625), .Q(
        \cpuregs[25][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][28]  ( .D(N679), .CLK(net615), .Q(
        \cpuregs[23][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][28]  ( .D(N679), .CLK(net605), .Q(
        \cpuregs[21][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][28]  ( .D(N679), .CLK(net595), .Q(
        \cpuregs[19][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][28]  ( .D(N679), .CLK(net585), .Q(
        \cpuregs[17][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][28]  ( .D(N679), .CLK(net575), .Q(
        \cpuregs[15][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][28]  ( .D(N679), .CLK(net565), .Q(
        \cpuregs[13][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][28]  ( .D(N679), .CLK(net555), .Q(
        \cpuregs[11][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][28]  ( .D(N679), .CLK(net545), .Q(
        \cpuregs[9][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][28]  ( .D(N679), .CLK(net535), .Q(
        \cpuregs[7][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][28]  ( .D(N679), .CLK(net525), .Q(
        \cpuregs[5][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][28]  ( .D(N679), .CLK(net515), .Q(
        \cpuregs[3][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][28]  ( .D(N679), .CLK(net505), .Q(
        \cpuregs[1][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][27]  ( .D(N678), .CLK(net655), .Q(
        \cpuregs[31][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][27]  ( .D(N678), .CLK(net645), .Q(
        \cpuregs[29][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][27]  ( .D(N678), .CLK(net635), .Q(
        \cpuregs[27][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][27]  ( .D(N678), .CLK(net625), .Q(
        \cpuregs[25][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][27]  ( .D(N678), .CLK(net615), .Q(
        \cpuregs[23][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][27]  ( .D(N678), .CLK(net605), .Q(
        \cpuregs[21][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][27]  ( .D(N678), .CLK(net595), .Q(
        \cpuregs[19][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][27]  ( .D(N678), .CLK(net585), .Q(
        \cpuregs[17][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][27]  ( .D(N678), .CLK(net575), .Q(
        \cpuregs[15][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][27]  ( .D(N678), .CLK(net565), .Q(
        \cpuregs[13][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][27]  ( .D(N678), .CLK(net555), .Q(
        \cpuregs[11][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][27]  ( .D(N678), .CLK(net545), .Q(
        \cpuregs[9][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][27]  ( .D(N678), .CLK(net535), .Q(
        \cpuregs[7][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][27]  ( .D(N678), .CLK(net525), .Q(
        \cpuregs[5][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][27]  ( .D(N678), .CLK(net515), .Q(
        \cpuregs[3][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][27]  ( .D(N678), .CLK(net505), .Q(
        \cpuregs[1][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][26]  ( .D(N677), .CLK(net655), .Q(
        \cpuregs[31][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][26]  ( .D(N677), .CLK(net645), .Q(
        \cpuregs[29][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][26]  ( .D(N677), .CLK(net635), .Q(
        \cpuregs[27][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][26]  ( .D(N677), .CLK(net625), .Q(
        \cpuregs[25][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][26]  ( .D(N677), .CLK(net615), .Q(
        \cpuregs[23][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][26]  ( .D(N677), .CLK(net605), .Q(
        \cpuregs[21][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][26]  ( .D(N677), .CLK(net595), .Q(
        \cpuregs[19][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][26]  ( .D(N677), .CLK(net585), .Q(
        \cpuregs[17][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][26]  ( .D(N677), .CLK(net575), .Q(
        \cpuregs[15][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][26]  ( .D(N677), .CLK(net565), .Q(
        \cpuregs[13][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][26]  ( .D(N677), .CLK(net555), .Q(
        \cpuregs[11][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][26]  ( .D(N677), .CLK(net545), .Q(
        \cpuregs[9][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][26]  ( .D(N677), .CLK(net535), .Q(
        \cpuregs[7][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][26]  ( .D(N677), .CLK(net525), .Q(
        \cpuregs[5][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][26]  ( .D(N677), .CLK(net515), .Q(
        \cpuregs[3][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][26]  ( .D(N677), .CLK(net505), .Q(
        \cpuregs[1][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][25]  ( .D(N676), .CLK(net655), .Q(
        \cpuregs[31][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][25]  ( .D(N676), .CLK(net645), .Q(
        \cpuregs[29][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][25]  ( .D(N676), .CLK(net635), .Q(
        \cpuregs[27][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][25]  ( .D(N676), .CLK(net625), .Q(
        \cpuregs[25][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][25]  ( .D(N676), .CLK(net615), .Q(
        \cpuregs[23][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][25]  ( .D(N676), .CLK(net605), .Q(
        \cpuregs[21][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][25]  ( .D(N676), .CLK(net595), .Q(
        \cpuregs[19][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][25]  ( .D(N676), .CLK(net585), .Q(
        \cpuregs[17][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][25]  ( .D(N676), .CLK(net575), .Q(
        \cpuregs[15][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][25]  ( .D(N676), .CLK(net565), .Q(
        \cpuregs[13][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][25]  ( .D(N676), .CLK(net555), .Q(
        \cpuregs[11][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][25]  ( .D(N676), .CLK(net545), .Q(
        \cpuregs[9][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][25]  ( .D(N676), .CLK(net535), .Q(
        \cpuregs[7][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][25]  ( .D(N676), .CLK(net525), .Q(
        \cpuregs[5][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][25]  ( .D(N676), .CLK(net515), .Q(
        \cpuregs[3][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][25]  ( .D(N676), .CLK(net505), .Q(
        \cpuregs[1][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][24]  ( .D(N675), .CLK(net655), .Q(
        \cpuregs[31][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][24]  ( .D(N675), .CLK(net645), .Q(
        \cpuregs[29][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][24]  ( .D(N675), .CLK(net635), .Q(
        \cpuregs[27][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][24]  ( .D(N675), .CLK(net625), .Q(
        \cpuregs[25][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][24]  ( .D(N675), .CLK(net615), .Q(
        \cpuregs[23][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][24]  ( .D(N675), .CLK(net605), .Q(
        \cpuregs[21][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][24]  ( .D(N675), .CLK(net595), .Q(
        \cpuregs[19][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][24]  ( .D(N675), .CLK(net585), .Q(
        \cpuregs[17][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][24]  ( .D(N675), .CLK(net575), .Q(
        \cpuregs[15][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][24]  ( .D(N675), .CLK(net565), .Q(
        \cpuregs[13][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][24]  ( .D(N675), .CLK(net555), .Q(
        \cpuregs[11][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][24]  ( .D(N675), .CLK(net545), .Q(
        \cpuregs[9][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][24]  ( .D(N675), .CLK(net535), .Q(
        \cpuregs[7][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][24]  ( .D(N675), .CLK(net525), .Q(
        \cpuregs[5][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][24]  ( .D(N675), .CLK(net515), .Q(
        \cpuregs[3][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][24]  ( .D(N675), .CLK(net505), .Q(
        \cpuregs[1][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][23]  ( .D(N674), .CLK(net655), .Q(
        \cpuregs[31][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][23]  ( .D(N674), .CLK(net645), .Q(
        \cpuregs[29][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][23]  ( .D(N674), .CLK(net635), .Q(
        \cpuregs[27][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][23]  ( .D(N674), .CLK(net625), .Q(
        \cpuregs[25][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][23]  ( .D(N674), .CLK(net615), .Q(
        \cpuregs[23][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][23]  ( .D(N674), .CLK(net605), .Q(
        \cpuregs[21][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][23]  ( .D(N674), .CLK(net595), .Q(
        \cpuregs[19][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][23]  ( .D(N674), .CLK(net585), .Q(
        \cpuregs[17][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][23]  ( .D(N674), .CLK(net575), .Q(
        \cpuregs[15][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][23]  ( .D(N674), .CLK(net565), .Q(
        \cpuregs[13][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][23]  ( .D(N674), .CLK(net555), .Q(
        \cpuregs[11][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][23]  ( .D(N674), .CLK(net545), .Q(
        \cpuregs[9][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][23]  ( .D(N674), .CLK(net535), .Q(
        \cpuregs[7][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][23]  ( .D(N674), .CLK(net525), .Q(
        \cpuregs[5][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][23]  ( .D(N674), .CLK(net515), .Q(
        \cpuregs[3][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][23]  ( .D(N674), .CLK(net505), .Q(
        \cpuregs[1][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][22]  ( .D(N673), .CLK(net655), .Q(
        \cpuregs[31][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][22]  ( .D(N673), .CLK(net645), .Q(
        \cpuregs[29][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][22]  ( .D(N673), .CLK(net635), .Q(
        \cpuregs[27][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][22]  ( .D(N673), .CLK(net625), .Q(
        \cpuregs[25][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][22]  ( .D(N673), .CLK(net615), .Q(
        \cpuregs[23][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][22]  ( .D(N673), .CLK(net605), .Q(
        \cpuregs[21][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][22]  ( .D(N673), .CLK(net595), .Q(
        \cpuregs[19][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][22]  ( .D(N673), .CLK(net585), .Q(
        \cpuregs[17][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][22]  ( .D(N673), .CLK(net575), .Q(
        \cpuregs[15][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][22]  ( .D(N673), .CLK(net565), .Q(
        \cpuregs[13][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][22]  ( .D(N673), .CLK(net555), .Q(
        \cpuregs[11][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][22]  ( .D(N673), .CLK(net545), .Q(
        \cpuregs[9][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][22]  ( .D(N673), .CLK(net535), .Q(
        \cpuregs[7][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][22]  ( .D(N673), .CLK(net525), .Q(
        \cpuregs[5][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][22]  ( .D(N673), .CLK(net515), .Q(
        \cpuregs[3][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][22]  ( .D(N673), .CLK(net505), .Q(
        \cpuregs[1][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][21]  ( .D(N672), .CLK(net655), .Q(
        \cpuregs[31][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][21]  ( .D(N672), .CLK(net645), .Q(
        \cpuregs[29][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][21]  ( .D(N672), .CLK(net635), .Q(
        \cpuregs[27][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][21]  ( .D(N672), .CLK(net625), .Q(
        \cpuregs[25][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][21]  ( .D(N672), .CLK(net615), .Q(
        \cpuregs[23][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][21]  ( .D(N672), .CLK(net605), .Q(
        \cpuregs[21][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][21]  ( .D(N672), .CLK(net595), .Q(
        \cpuregs[19][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][21]  ( .D(N672), .CLK(net585), .Q(
        \cpuregs[17][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][21]  ( .D(N672), .CLK(net575), .Q(
        \cpuregs[15][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][21]  ( .D(N672), .CLK(net565), .Q(
        \cpuregs[13][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][21]  ( .D(N672), .CLK(net555), .Q(
        \cpuregs[11][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][21]  ( .D(N672), .CLK(net545), .Q(
        \cpuregs[9][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][21]  ( .D(N672), .CLK(net535), .Q(
        \cpuregs[7][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][21]  ( .D(N672), .CLK(net525), .Q(
        \cpuregs[5][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][21]  ( .D(N672), .CLK(net515), .Q(
        \cpuregs[3][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][21]  ( .D(N672), .CLK(net505), .Q(
        \cpuregs[1][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][20]  ( .D(N671), .CLK(net655), .Q(
        \cpuregs[31][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][20]  ( .D(N671), .CLK(net645), .Q(
        \cpuregs[29][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][20]  ( .D(N671), .CLK(net635), .Q(
        \cpuregs[27][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][20]  ( .D(N671), .CLK(net625), .Q(
        \cpuregs[25][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][20]  ( .D(N671), .CLK(net615), .Q(
        \cpuregs[23][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][20]  ( .D(N671), .CLK(net605), .Q(
        \cpuregs[21][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][20]  ( .D(N671), .CLK(net595), .Q(
        \cpuregs[19][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][20]  ( .D(N671), .CLK(net585), .Q(
        \cpuregs[17][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][20]  ( .D(N671), .CLK(net575), .Q(
        \cpuregs[15][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][20]  ( .D(N671), .CLK(net565), .Q(
        \cpuregs[13][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][20]  ( .D(N671), .CLK(net555), .Q(
        \cpuregs[11][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][20]  ( .D(N671), .CLK(net545), .Q(
        \cpuregs[9][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][20]  ( .D(N671), .CLK(net535), .Q(
        \cpuregs[7][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][20]  ( .D(N671), .CLK(net525), .Q(
        \cpuregs[5][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][20]  ( .D(N671), .CLK(net515), .Q(
        \cpuregs[3][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][20]  ( .D(N671), .CLK(net505), .Q(
        \cpuregs[1][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][19]  ( .D(N670), .CLK(net655), .Q(
        \cpuregs[31][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][19]  ( .D(N670), .CLK(net645), .Q(
        \cpuregs[29][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][19]  ( .D(N670), .CLK(net635), .Q(
        \cpuregs[27][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][19]  ( .D(N670), .CLK(net625), .Q(
        \cpuregs[25][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][19]  ( .D(N670), .CLK(net615), .Q(
        \cpuregs[23][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][19]  ( .D(N670), .CLK(net605), .Q(
        \cpuregs[21][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][19]  ( .D(N670), .CLK(net595), .Q(
        \cpuregs[19][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][19]  ( .D(N670), .CLK(net585), .Q(
        \cpuregs[17][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][19]  ( .D(N670), .CLK(net575), .Q(
        \cpuregs[15][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][19]  ( .D(N670), .CLK(net565), .Q(
        \cpuregs[13][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][19]  ( .D(N670), .CLK(net555), .Q(
        \cpuregs[11][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][19]  ( .D(N670), .CLK(net545), .Q(
        \cpuregs[9][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][19]  ( .D(N670), .CLK(net535), .Q(
        \cpuregs[7][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][19]  ( .D(N670), .CLK(net525), .Q(
        \cpuregs[5][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][19]  ( .D(N670), .CLK(net515), .Q(
        \cpuregs[3][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][19]  ( .D(N670), .CLK(net505), .Q(
        \cpuregs[1][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][18]  ( .D(N669), .CLK(net655), .Q(
        \cpuregs[31][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][18]  ( .D(N669), .CLK(net645), .Q(
        \cpuregs[29][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][18]  ( .D(N669), .CLK(net635), .Q(
        \cpuregs[27][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][18]  ( .D(N669), .CLK(net625), .Q(
        \cpuregs[25][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][18]  ( .D(N669), .CLK(net615), .Q(
        \cpuregs[23][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][18]  ( .D(N669), .CLK(net605), .Q(
        \cpuregs[21][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][18]  ( .D(N669), .CLK(net595), .Q(
        \cpuregs[19][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][18]  ( .D(N669), .CLK(net585), .Q(
        \cpuregs[17][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][18]  ( .D(N669), .CLK(net575), .Q(
        \cpuregs[15][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][18]  ( .D(N669), .CLK(net565), .Q(
        \cpuregs[13][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][18]  ( .D(N669), .CLK(net555), .Q(
        \cpuregs[11][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][18]  ( .D(N669), .CLK(net545), .Q(
        \cpuregs[9][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][18]  ( .D(N669), .CLK(net535), .Q(
        \cpuregs[7][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][18]  ( .D(N669), .CLK(net525), .Q(
        \cpuregs[5][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][18]  ( .D(N669), .CLK(net515), .Q(
        \cpuregs[3][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][18]  ( .D(N669), .CLK(net505), .Q(
        \cpuregs[1][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][17]  ( .D(N668), .CLK(net655), .Q(
        \cpuregs[31][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][17]  ( .D(N668), .CLK(net645), .Q(
        \cpuregs[29][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][17]  ( .D(N668), .CLK(net635), .Q(
        \cpuregs[27][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][17]  ( .D(N668), .CLK(net625), .Q(
        \cpuregs[25][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][17]  ( .D(N668), .CLK(net615), .Q(
        \cpuregs[23][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][17]  ( .D(N668), .CLK(net605), .Q(
        \cpuregs[21][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][17]  ( .D(N668), .CLK(net595), .Q(
        \cpuregs[19][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][17]  ( .D(N668), .CLK(net585), .Q(
        \cpuregs[17][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][17]  ( .D(N668), .CLK(net575), .Q(
        \cpuregs[15][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][17]  ( .D(N668), .CLK(net565), .Q(
        \cpuregs[13][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][17]  ( .D(N668), .CLK(net555), .Q(
        \cpuregs[11][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][17]  ( .D(N668), .CLK(net545), .Q(
        \cpuregs[9][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][17]  ( .D(N668), .CLK(net535), .Q(
        \cpuregs[7][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][17]  ( .D(N668), .CLK(net525), .Q(
        \cpuregs[5][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][17]  ( .D(N668), .CLK(net515), .Q(
        \cpuregs[3][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][17]  ( .D(N668), .CLK(net505), .Q(
        \cpuregs[1][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][16]  ( .D(N667), .CLK(net655), .Q(
        \cpuregs[31][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][16]  ( .D(N667), .CLK(net645), .Q(
        \cpuregs[29][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][16]  ( .D(N667), .CLK(net635), .Q(
        \cpuregs[27][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][16]  ( .D(N667), .CLK(net625), .Q(
        \cpuregs[25][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][16]  ( .D(N667), .CLK(net615), .Q(
        \cpuregs[23][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][16]  ( .D(N667), .CLK(net605), .Q(
        \cpuregs[21][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][16]  ( .D(N667), .CLK(net595), .Q(
        \cpuregs[19][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][16]  ( .D(N667), .CLK(net585), .Q(
        \cpuregs[17][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][16]  ( .D(N667), .CLK(net575), .Q(
        \cpuregs[15][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][16]  ( .D(N667), .CLK(net565), .Q(
        \cpuregs[13][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][16]  ( .D(N667), .CLK(net555), .Q(
        \cpuregs[11][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][16]  ( .D(N667), .CLK(net545), .Q(
        \cpuregs[9][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][16]  ( .D(N667), .CLK(net535), .Q(
        \cpuregs[7][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][16]  ( .D(N667), .CLK(net525), .Q(
        \cpuregs[5][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][16]  ( .D(N667), .CLK(net515), .Q(
        \cpuregs[3][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][16]  ( .D(N667), .CLK(net505), .Q(
        \cpuregs[1][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][15]  ( .D(N666), .CLK(net655), .Q(
        \cpuregs[31][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][15]  ( .D(N666), .CLK(net645), .Q(
        \cpuregs[29][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][15]  ( .D(N666), .CLK(net635), .Q(
        \cpuregs[27][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][15]  ( .D(N666), .CLK(net625), .Q(
        \cpuregs[25][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][15]  ( .D(N666), .CLK(net615), .Q(
        \cpuregs[23][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][15]  ( .D(N666), .CLK(net605), .Q(
        \cpuregs[21][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][15]  ( .D(N666), .CLK(net595), .Q(
        \cpuregs[19][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][15]  ( .D(N666), .CLK(net585), .Q(
        \cpuregs[17][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][15]  ( .D(N666), .CLK(net575), .Q(
        \cpuregs[15][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][15]  ( .D(N666), .CLK(net565), .Q(
        \cpuregs[13][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][15]  ( .D(N666), .CLK(net555), .Q(
        \cpuregs[11][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][15]  ( .D(N666), .CLK(net545), .Q(
        \cpuregs[9][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][15]  ( .D(N666), .CLK(net535), .Q(
        \cpuregs[7][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][15]  ( .D(N666), .CLK(net525), .Q(
        \cpuregs[5][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][15]  ( .D(N666), .CLK(net515), .Q(
        \cpuregs[3][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][15]  ( .D(N666), .CLK(net505), .Q(
        \cpuregs[1][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][14]  ( .D(N665), .CLK(net655), .Q(
        \cpuregs[31][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][14]  ( .D(N665), .CLK(net645), .Q(
        \cpuregs[29][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][14]  ( .D(N665), .CLK(net635), .Q(
        \cpuregs[27][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][14]  ( .D(N665), .CLK(net625), .Q(
        \cpuregs[25][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][14]  ( .D(N665), .CLK(net615), .Q(
        \cpuregs[23][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][14]  ( .D(N665), .CLK(net605), .Q(
        \cpuregs[21][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][14]  ( .D(N665), .CLK(net595), .Q(
        \cpuregs[19][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][14]  ( .D(N665), .CLK(net585), .Q(
        \cpuregs[17][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][14]  ( .D(N665), .CLK(net575), .Q(
        \cpuregs[15][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][14]  ( .D(N665), .CLK(net565), .Q(
        \cpuregs[13][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][14]  ( .D(N665), .CLK(net555), .Q(
        \cpuregs[11][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][14]  ( .D(N665), .CLK(net545), .Q(
        \cpuregs[9][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][14]  ( .D(N665), .CLK(net535), .Q(
        \cpuregs[7][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][14]  ( .D(N665), .CLK(net525), .Q(
        \cpuregs[5][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][14]  ( .D(N665), .CLK(net515), .Q(
        \cpuregs[3][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][14]  ( .D(N665), .CLK(net505), .Q(
        \cpuregs[1][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][13]  ( .D(N664), .CLK(net655), .Q(
        \cpuregs[31][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][13]  ( .D(N664), .CLK(net645), .Q(
        \cpuregs[29][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][13]  ( .D(N664), .CLK(net635), .Q(
        \cpuregs[27][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][13]  ( .D(N664), .CLK(net625), .Q(
        \cpuregs[25][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][13]  ( .D(N664), .CLK(net615), .Q(
        \cpuregs[23][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][13]  ( .D(N664), .CLK(net605), .Q(
        \cpuregs[21][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][13]  ( .D(N664), .CLK(net595), .Q(
        \cpuregs[19][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][13]  ( .D(N664), .CLK(net585), .Q(
        \cpuregs[17][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][13]  ( .D(N664), .CLK(net575), .Q(
        \cpuregs[15][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][13]  ( .D(N664), .CLK(net565), .Q(
        \cpuregs[13][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][13]  ( .D(N664), .CLK(net555), .Q(
        \cpuregs[11][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][13]  ( .D(N664), .CLK(net545), .Q(
        \cpuregs[9][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][13]  ( .D(N664), .CLK(net535), .Q(
        \cpuregs[7][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][13]  ( .D(N664), .CLK(net525), .Q(
        \cpuregs[5][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][13]  ( .D(N664), .CLK(net515), .Q(
        \cpuregs[3][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][13]  ( .D(N664), .CLK(net505), .Q(
        \cpuregs[1][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][12]  ( .D(N663), .CLK(net655), .Q(
        \cpuregs[31][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][12]  ( .D(N663), .CLK(net645), .Q(
        \cpuregs[29][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][12]  ( .D(N663), .CLK(net635), .Q(
        \cpuregs[27][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][12]  ( .D(N663), .CLK(net625), .Q(
        \cpuregs[25][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][12]  ( .D(N663), .CLK(net615), .Q(
        \cpuregs[23][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][12]  ( .D(N663), .CLK(net605), .Q(
        \cpuregs[21][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][12]  ( .D(N663), .CLK(net595), .Q(
        \cpuregs[19][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][12]  ( .D(N663), .CLK(net585), .Q(
        \cpuregs[17][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][12]  ( .D(N663), .CLK(net575), .Q(
        \cpuregs[15][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][12]  ( .D(N663), .CLK(net565), .Q(
        \cpuregs[13][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][12]  ( .D(N663), .CLK(net555), .Q(
        \cpuregs[11][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][12]  ( .D(N663), .CLK(net545), .Q(
        \cpuregs[9][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][12]  ( .D(N663), .CLK(net535), .Q(
        \cpuregs[7][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][12]  ( .D(N663), .CLK(net525), .Q(
        \cpuregs[5][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][12]  ( .D(N663), .CLK(net515), .Q(
        \cpuregs[3][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][12]  ( .D(N663), .CLK(net505), .Q(
        \cpuregs[1][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][11]  ( .D(N662), .CLK(net655), .Q(
        \cpuregs[31][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][11]  ( .D(N662), .CLK(net645), .Q(
        \cpuregs[29][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][11]  ( .D(N662), .CLK(net635), .Q(
        \cpuregs[27][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][11]  ( .D(N662), .CLK(net625), .Q(
        \cpuregs[25][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][11]  ( .D(N662), .CLK(net615), .Q(
        \cpuregs[23][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][11]  ( .D(N662), .CLK(net605), .Q(
        \cpuregs[21][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][11]  ( .D(N662), .CLK(net595), .Q(
        \cpuregs[19][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][11]  ( .D(N662), .CLK(net585), .Q(
        \cpuregs[17][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][11]  ( .D(N662), .CLK(net575), .Q(
        \cpuregs[15][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][11]  ( .D(N662), .CLK(net565), .Q(
        \cpuregs[13][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][11]  ( .D(N662), .CLK(net555), .Q(
        \cpuregs[11][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][11]  ( .D(N662), .CLK(net545), .Q(
        \cpuregs[9][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][11]  ( .D(N662), .CLK(net535), .Q(
        \cpuregs[7][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][11]  ( .D(N662), .CLK(net525), .Q(
        \cpuregs[5][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][11]  ( .D(N662), .CLK(net515), .Q(
        \cpuregs[3][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][11]  ( .D(N662), .CLK(net505), .Q(
        \cpuregs[1][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][10]  ( .D(N661), .CLK(net655), .Q(
        \cpuregs[31][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][10]  ( .D(N661), .CLK(net645), .Q(
        \cpuregs[29][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][10]  ( .D(N661), .CLK(net635), .Q(
        \cpuregs[27][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][10]  ( .D(N661), .CLK(net625), .Q(
        \cpuregs[25][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][10]  ( .D(N661), .CLK(net615), .Q(
        \cpuregs[23][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][10]  ( .D(N661), .CLK(net605), .Q(
        \cpuregs[21][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][10]  ( .D(N661), .CLK(net595), .Q(
        \cpuregs[19][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][10]  ( .D(N661), .CLK(net585), .Q(
        \cpuregs[17][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][10]  ( .D(N661), .CLK(net575), .Q(
        \cpuregs[15][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][10]  ( .D(N661), .CLK(net565), .Q(
        \cpuregs[13][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][10]  ( .D(N661), .CLK(net555), .Q(
        \cpuregs[11][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][10]  ( .D(N661), .CLK(net545), .Q(
        \cpuregs[9][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][10]  ( .D(N661), .CLK(net535), .Q(
        \cpuregs[7][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][10]  ( .D(N661), .CLK(net525), .Q(
        \cpuregs[5][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][10]  ( .D(N661), .CLK(net515), .Q(
        \cpuregs[3][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][10]  ( .D(N661), .CLK(net505), .Q(
        \cpuregs[1][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][9]  ( .D(N660), .CLK(net655), .Q(
        \cpuregs[31][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][9]  ( .D(N660), .CLK(net645), .Q(
        \cpuregs[29][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][9]  ( .D(N660), .CLK(net635), .Q(
        \cpuregs[27][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][9]  ( .D(N660), .CLK(net625), .Q(
        \cpuregs[25][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][9]  ( .D(N660), .CLK(net615), .Q(
        \cpuregs[23][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][9]  ( .D(N660), .CLK(net605), .Q(
        \cpuregs[21][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][9]  ( .D(N660), .CLK(net595), .Q(
        \cpuregs[19][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][9]  ( .D(N660), .CLK(net585), .Q(
        \cpuregs[17][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][9]  ( .D(N660), .CLK(net575), .Q(
        \cpuregs[15][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][9]  ( .D(N660), .CLK(net565), .Q(
        \cpuregs[13][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][9]  ( .D(N660), .CLK(net555), .Q(
        \cpuregs[11][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][9]  ( .D(N660), .CLK(net545), .Q(
        \cpuregs[9][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][9]  ( .D(N660), .CLK(net535), .Q(
        \cpuregs[7][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][9]  ( .D(N660), .CLK(net525), .Q(
        \cpuregs[5][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][9]  ( .D(N660), .CLK(net515), .Q(
        \cpuregs[3][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][9]  ( .D(N660), .CLK(net505), .Q(
        \cpuregs[1][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][8]  ( .D(N659), .CLK(net655), .Q(
        \cpuregs[31][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][8]  ( .D(N659), .CLK(net645), .Q(
        \cpuregs[29][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][8]  ( .D(N659), .CLK(net635), .Q(
        \cpuregs[27][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][8]  ( .D(N659), .CLK(net625), .Q(
        \cpuregs[25][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][8]  ( .D(N659), .CLK(net615), .Q(
        \cpuregs[23][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][8]  ( .D(N659), .CLK(net605), .Q(
        \cpuregs[21][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][8]  ( .D(N659), .CLK(net595), .Q(
        \cpuregs[19][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][8]  ( .D(N659), .CLK(net585), .Q(
        \cpuregs[17][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][8]  ( .D(N659), .CLK(net575), .Q(
        \cpuregs[15][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][8]  ( .D(N659), .CLK(net565), .Q(
        \cpuregs[13][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][8]  ( .D(N659), .CLK(net555), .Q(
        \cpuregs[11][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][8]  ( .D(N659), .CLK(net545), .Q(
        \cpuregs[9][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][8]  ( .D(N659), .CLK(net535), .Q(
        \cpuregs[7][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][8]  ( .D(N659), .CLK(net525), .Q(
        \cpuregs[5][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][8]  ( .D(N659), .CLK(net515), .Q(
        \cpuregs[3][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][8]  ( .D(N659), .CLK(net505), .Q(
        \cpuregs[1][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][7]  ( .D(N658), .CLK(net655), .Q(
        \cpuregs[31][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][7]  ( .D(N658), .CLK(net645), .Q(
        \cpuregs[29][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][7]  ( .D(N658), .CLK(net635), .Q(
        \cpuregs[27][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][7]  ( .D(N658), .CLK(net625), .Q(
        \cpuregs[25][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][7]  ( .D(N658), .CLK(net615), .Q(
        \cpuregs[23][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][7]  ( .D(N658), .CLK(net605), .Q(
        \cpuregs[21][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][7]  ( .D(N658), .CLK(net595), .Q(
        \cpuregs[19][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][7]  ( .D(N658), .CLK(net585), .Q(
        \cpuregs[17][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][7]  ( .D(N658), .CLK(net575), .Q(
        \cpuregs[15][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][7]  ( .D(N658), .CLK(net565), .Q(
        \cpuregs[13][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][7]  ( .D(N658), .CLK(net555), .Q(
        \cpuregs[11][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][7]  ( .D(N658), .CLK(net545), .Q(
        \cpuregs[9][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][7]  ( .D(N658), .CLK(net535), .Q(
        \cpuregs[7][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][7]  ( .D(N658), .CLK(net525), .Q(
        \cpuregs[5][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][7]  ( .D(N658), .CLK(net515), .Q(
        \cpuregs[3][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][7]  ( .D(N658), .CLK(net505), .Q(
        \cpuregs[1][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][6]  ( .D(N657), .CLK(net655), .Q(
        \cpuregs[31][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][6]  ( .D(N657), .CLK(net645), .Q(
        \cpuregs[29][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][6]  ( .D(N657), .CLK(net635), .Q(
        \cpuregs[27][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][6]  ( .D(N657), .CLK(net625), .Q(
        \cpuregs[25][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][6]  ( .D(N657), .CLK(net615), .Q(
        \cpuregs[23][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][6]  ( .D(N657), .CLK(net605), .Q(
        \cpuregs[21][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][6]  ( .D(N657), .CLK(net595), .Q(
        \cpuregs[19][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][6]  ( .D(N657), .CLK(net585), .Q(
        \cpuregs[17][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][6]  ( .D(N657), .CLK(net575), .Q(
        \cpuregs[15][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][6]  ( .D(N657), .CLK(net565), .Q(
        \cpuregs[13][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][6]  ( .D(N657), .CLK(net555), .Q(
        \cpuregs[11][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][6]  ( .D(N657), .CLK(net545), .Q(
        \cpuregs[9][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][6]  ( .D(N657), .CLK(net535), .Q(
        \cpuregs[7][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][6]  ( .D(N657), .CLK(net525), .Q(
        \cpuregs[5][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][6]  ( .D(N657), .CLK(net515), .Q(
        \cpuregs[3][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][6]  ( .D(N657), .CLK(net505), .Q(
        \cpuregs[1][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][5]  ( .D(N656), .CLK(net655), .Q(
        \cpuregs[31][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][5]  ( .D(N656), .CLK(net645), .Q(
        \cpuregs[29][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][5]  ( .D(N656), .CLK(net635), .Q(
        \cpuregs[27][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][5]  ( .D(N656), .CLK(net625), .Q(
        \cpuregs[25][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][5]  ( .D(N656), .CLK(net615), .Q(
        \cpuregs[23][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][5]  ( .D(N656), .CLK(net605), .Q(
        \cpuregs[21][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][5]  ( .D(N656), .CLK(net595), .Q(
        \cpuregs[19][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][5]  ( .D(N656), .CLK(net585), .Q(
        \cpuregs[17][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][5]  ( .D(N656), .CLK(net575), .Q(
        \cpuregs[15][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][5]  ( .D(N656), .CLK(net565), .Q(
        \cpuregs[13][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][5]  ( .D(N656), .CLK(net555), .Q(
        \cpuregs[11][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][5]  ( .D(N656), .CLK(net545), .Q(
        \cpuregs[9][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][5]  ( .D(N656), .CLK(net535), .Q(
        \cpuregs[7][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][5]  ( .D(N656), .CLK(net525), .Q(
        \cpuregs[5][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][5]  ( .D(N656), .CLK(net515), .Q(
        \cpuregs[3][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][5]  ( .D(N656), .CLK(net505), .Q(
        \cpuregs[1][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][4]  ( .D(N655), .CLK(net655), .Q(
        \cpuregs[31][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][4]  ( .D(N655), .CLK(net645), .Q(
        \cpuregs[29][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][4]  ( .D(N655), .CLK(net635), .Q(
        \cpuregs[27][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][4]  ( .D(N655), .CLK(net625), .Q(
        \cpuregs[25][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][4]  ( .D(N655), .CLK(net615), .Q(
        \cpuregs[23][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][4]  ( .D(N655), .CLK(net605), .Q(
        \cpuregs[21][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][4]  ( .D(N655), .CLK(net595), .Q(
        \cpuregs[19][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][4]  ( .D(N655), .CLK(net585), .Q(
        \cpuregs[17][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][4]  ( .D(N655), .CLK(net575), .Q(
        \cpuregs[15][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][4]  ( .D(N655), .CLK(net565), .Q(
        \cpuregs[13][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][4]  ( .D(N655), .CLK(net555), .Q(
        \cpuregs[11][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][4]  ( .D(N655), .CLK(net545), .Q(
        \cpuregs[9][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][4]  ( .D(N655), .CLK(net535), .Q(
        \cpuregs[7][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][4]  ( .D(N655), .CLK(net525), .Q(
        \cpuregs[5][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][4]  ( .D(N655), .CLK(net515), .Q(
        \cpuregs[3][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][4]  ( .D(N655), .CLK(net505), .Q(
        \cpuregs[1][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][3]  ( .D(N654), .CLK(net655), .Q(
        \cpuregs[31][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][3]  ( .D(N654), .CLK(net645), .Q(
        \cpuregs[29][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][3]  ( .D(N654), .CLK(net635), .Q(
        \cpuregs[27][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][3]  ( .D(N654), .CLK(net625), .Q(
        \cpuregs[25][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][3]  ( .D(N654), .CLK(net615), .Q(
        \cpuregs[23][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][3]  ( .D(N654), .CLK(net605), .Q(
        \cpuregs[21][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][3]  ( .D(N654), .CLK(net595), .Q(
        \cpuregs[19][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][3]  ( .D(N654), .CLK(net585), .Q(
        \cpuregs[17][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][3]  ( .D(N654), .CLK(net575), .Q(
        \cpuregs[15][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][3]  ( .D(N654), .CLK(net565), .Q(
        \cpuregs[13][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][3]  ( .D(N654), .CLK(net555), .Q(
        \cpuregs[11][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][3]  ( .D(N654), .CLK(net545), .Q(
        \cpuregs[9][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][3]  ( .D(N654), .CLK(net535), .Q(
        \cpuregs[7][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][3]  ( .D(N654), .CLK(net525), .Q(
        \cpuregs[5][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][3]  ( .D(N654), .CLK(net515), .Q(
        \cpuregs[3][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][3]  ( .D(N654), .CLK(net505), .Q(
        \cpuregs[1][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][2]  ( .D(N653), .CLK(net655), .Q(
        \cpuregs[31][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][2]  ( .D(N653), .CLK(net645), .Q(
        \cpuregs[29][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][2]  ( .D(N653), .CLK(net635), .Q(
        \cpuregs[27][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][2]  ( .D(N653), .CLK(net625), .Q(
        \cpuregs[25][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][2]  ( .D(N653), .CLK(net615), .Q(
        \cpuregs[23][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][2]  ( .D(N653), .CLK(net605), .Q(
        \cpuregs[21][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][2]  ( .D(N653), .CLK(net595), .Q(
        \cpuregs[19][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][2]  ( .D(N653), .CLK(net585), .Q(
        \cpuregs[17][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][2]  ( .D(N653), .CLK(net575), .Q(
        \cpuregs[15][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][2]  ( .D(N653), .CLK(net565), .Q(
        \cpuregs[13][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][2]  ( .D(N653), .CLK(net555), .Q(
        \cpuregs[11][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][2]  ( .D(N653), .CLK(net545), .Q(
        \cpuregs[9][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][2]  ( .D(N653), .CLK(net535), .Q(
        \cpuregs[7][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][2]  ( .D(N653), .CLK(net525), .Q(
        \cpuregs[5][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][2]  ( .D(N653), .CLK(net515), .Q(
        \cpuregs[3][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][2]  ( .D(N653), .CLK(net505), .Q(
        \cpuregs[1][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][1]  ( .D(N652), .CLK(net655), .Q(
        \cpuregs[31][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][1]  ( .D(N652), .CLK(net645), .Q(
        \cpuregs[29][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][1]  ( .D(N652), .CLK(net635), .Q(
        \cpuregs[27][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][1]  ( .D(N652), .CLK(net625), .Q(
        \cpuregs[25][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][1]  ( .D(N652), .CLK(net615), .Q(
        \cpuregs[23][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][1]  ( .D(N652), .CLK(net605), .Q(
        \cpuregs[21][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][1]  ( .D(N652), .CLK(net595), .Q(
        \cpuregs[19][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][1]  ( .D(N652), .CLK(net585), .Q(
        \cpuregs[17][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][1]  ( .D(N652), .CLK(net575), .Q(
        \cpuregs[15][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][1]  ( .D(N652), .CLK(net565), .Q(
        \cpuregs[13][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][1]  ( .D(N652), .CLK(net555), .Q(
        \cpuregs[11][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][1]  ( .D(N652), .CLK(net545), .Q(
        \cpuregs[9][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][1]  ( .D(N652), .CLK(net535), .Q(
        \cpuregs[7][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][1]  ( .D(N652), .CLK(net525), .Q(
        \cpuregs[5][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][1]  ( .D(N652), .CLK(net515), .Q(
        \cpuregs[3][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][1]  ( .D(N652), .CLK(net505), .Q(
        \cpuregs[1][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[1][0]  ( .D(n3572), .CLK(net505), .Q(
        \cpuregs[1][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[3][0]  ( .D(n3572), .CLK(net515), .Q(
        \cpuregs[3][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[5][0]  ( .D(n3572), .CLK(net525), .Q(
        \cpuregs[5][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[7][0]  ( .D(n3572), .CLK(net535), .Q(
        \cpuregs[7][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[9][0]  ( .D(n3572), .CLK(net545), .Q(
        \cpuregs[9][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[11][0]  ( .D(n3572), .CLK(net555), .Q(
        \cpuregs[11][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[13][0]  ( .D(n3572), .CLK(net565), .Q(
        \cpuregs[13][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[15][0]  ( .D(n3572), .CLK(net575), .Q(
        \cpuregs[15][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[17][0]  ( .D(n3572), .CLK(net585), .Q(
        \cpuregs[17][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[19][0]  ( .D(n3572), .CLK(net595), .Q(
        \cpuregs[19][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[21][0]  ( .D(n3572), .CLK(net605), .Q(
        \cpuregs[21][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[23][0]  ( .D(n3572), .CLK(net615), .Q(
        \cpuregs[23][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[25][0]  ( .D(n3572), .CLK(net625), .Q(
        \cpuregs[25][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[27][0]  ( .D(n3572), .CLK(net635), .Q(
        \cpuregs[27][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[29][0]  ( .D(n3572), .CLK(net645), .Q(
        \cpuregs[29][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[31][0]  ( .D(n3572), .CLK(net655), .Q(
        \cpuregs[31][0] ) );
  sky130_fd_sc_hd__dfxtp_1 instr_sh_reg ( .D(N274), .CLK(net495), .Q(instr_sh)
         );
  sky130_fd_sc_hd__dfxtp_1 instr_slt_reg ( .D(N367), .CLK(net500), .Q(
        instr_slt) );
  sky130_fd_sc_hd__dfxtp_1 instr_sltu_reg ( .D(N368), .CLK(net500), .Q(
        instr_sltu) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[1]  ( .D(N1879), .CLK(n1052), .Q(
        reg_out[1]) );
  sky130_fd_sc_hd__dfxtp_1 instr_sltiu_reg ( .D(N360), .CLK(net500), .Q(
        instr_sltiu) );
  sky130_fd_sc_hd__dfxtp_1 instr_lui_reg ( .D(n1041), .CLK(net490), .Q(
        instr_lui) );
  sky130_fd_sc_hd__dfxtp_1 instr_sra_reg ( .D(N371), .CLK(net500), .Q(
        instr_sra) );
  sky130_fd_sc_hd__dfxtp_1 instr_jalr_reg ( .D(N259), .CLK(net490), .Q(
        instr_jalr) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[0]  ( .D(mem_rdata[0]), .CLK(
        net469), .Q(mem_rdata_q[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[1]  ( .D(mem_rdata[1]), .CLK(
        net469), .Q(mem_rdata_q[1]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[19]  ( .D(mem_rdata[19]), .CLK(
        net469), .Q(mem_rdata_q[19]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[18]  ( .D(mem_rdata[18]), .CLK(
        net469), .Q(mem_rdata_q[18]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[17]  ( .D(mem_rdata[17]), .CLK(
        net469), .Q(mem_rdata_q[17]) );
  sky130_fd_sc_hd__dfxtp_1 instr_sub_reg ( .D(N365), .CLK(net500), .Q(
        instr_sub) );
  sky130_fd_sc_hd__dfxtp_1 \reg_sh_reg[4]  ( .D(N1877), .CLK(n1052), .Q(
        reg_sh[4]) );
  sky130_fd_sc_hd__dfxtp_1 is_lui_auipc_jal_jalr_addi_add_sub_reg ( .D(N345), 
        .CLK(n1046), .Q(is_lui_auipc_jal_jalr_addi_add_sub) );
  sky130_fd_sc_hd__dfxtp_1 instr_bge_reg ( .D(N355), .CLK(net500), .Q(
        instr_bge) );
  sky130_fd_sc_hd__dfxtp_1 is_alu_reg_reg_reg ( .D(n1035), .CLK(net490), .Q(
        is_alu_reg_reg) );
  sky130_fd_sc_hd__dfxtp_1 \mem_state_reg[1]  ( .D(n1030), .CLK(n1046), .Q(
        mem_state[1]) );
  sky130_fd_sc_hd__dfxtp_1 instr_bgeu_reg ( .D(N357), .CLK(net500), .Q(
        instr_bgeu) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[2]  ( .D(mem_rdata[2]), .CLK(
        net469), .Q(mem_rdata_q[2]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[3]  ( .D(mem_rdata[3]), .CLK(
        net469), .Q(mem_rdata_q[3]) );
  sky130_fd_sc_hd__dfxtp_1 instr_lh_reg ( .D(N269), .CLK(net495), .Q(instr_lh)
         );
  sky130_fd_sc_hd__dfxtp_1 \reg_sh_reg[2]  ( .D(N1875), .CLK(n1046), .Q(
        reg_sh[2]) );
  sky130_fd_sc_hd__dfxtp_1 instr_rdcycle_reg ( .D(N295), .CLK(net495), .Q(
        instr_rdcycle) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][31]  ( .D(\cpuregs[0][31] ), .CLK(
        n1052), .Q(\cpuregs[0][31] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][30]  ( .D(\cpuregs[0][30] ), .CLK(
        n1052), .Q(\cpuregs[0][30] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][29]  ( .D(\cpuregs[0][29] ), .CLK(
        n1052), .Q(\cpuregs[0][29] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][28]  ( .D(\cpuregs[0][28] ), .CLK(
        n1052), .Q(\cpuregs[0][28] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][27]  ( .D(\cpuregs[0][27] ), .CLK(
        n1052), .Q(\cpuregs[0][27] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][26]  ( .D(\cpuregs[0][26] ), .CLK(
        n1052), .Q(\cpuregs[0][26] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][25]  ( .D(\cpuregs[0][25] ), .CLK(
        n1052), .Q(\cpuregs[0][25] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][24]  ( .D(\cpuregs[0][24] ), .CLK(
        n1052), .Q(\cpuregs[0][24] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][23]  ( .D(\cpuregs[0][23] ), .CLK(
        n1052), .Q(\cpuregs[0][23] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][22]  ( .D(\cpuregs[0][22] ), .CLK(
        n1052), .Q(\cpuregs[0][22] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][21]  ( .D(\cpuregs[0][21] ), .CLK(
        n1051), .Q(\cpuregs[0][21] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][20]  ( .D(\cpuregs[0][20] ), .CLK(
        n1051), .Q(\cpuregs[0][20] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][19]  ( .D(\cpuregs[0][19] ), .CLK(
        n1051), .Q(\cpuregs[0][19] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][18]  ( .D(\cpuregs[0][18] ), .CLK(
        n1051), .Q(\cpuregs[0][18] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][17]  ( .D(\cpuregs[0][17] ), .CLK(
        n1051), .Q(\cpuregs[0][17] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][16]  ( .D(\cpuregs[0][16] ), .CLK(
        n1051), .Q(\cpuregs[0][16] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][15]  ( .D(\cpuregs[0][15] ), .CLK(
        n1051), .Q(\cpuregs[0][15] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][14]  ( .D(\cpuregs[0][14] ), .CLK(
        n1051), .Q(\cpuregs[0][14] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][13]  ( .D(\cpuregs[0][13] ), .CLK(
        n1051), .Q(\cpuregs[0][13] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][12]  ( .D(\cpuregs[0][12] ), .CLK(
        n1051), .Q(\cpuregs[0][12] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][11]  ( .D(\cpuregs[0][11] ), .CLK(
        n1051), .Q(\cpuregs[0][11] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][10]  ( .D(\cpuregs[0][10] ), .CLK(
        n1051), .Q(\cpuregs[0][10] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][9]  ( .D(\cpuregs[0][9] ), .CLK(
        n1051), .Q(\cpuregs[0][9] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][8]  ( .D(\cpuregs[0][8] ), .CLK(
        n1051), .Q(\cpuregs[0][8] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][7]  ( .D(\cpuregs[0][7] ), .CLK(
        n1051), .Q(\cpuregs[0][7] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][6]  ( .D(\cpuregs[0][6] ), .CLK(
        n1051), .Q(\cpuregs[0][6] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][5]  ( .D(\cpuregs[0][5] ), .CLK(
        n1051), .Q(\cpuregs[0][5] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][4]  ( .D(\cpuregs[0][4] ), .CLK(
        n1051), .Q(\cpuregs[0][4] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][3]  ( .D(\cpuregs[0][3] ), .CLK(
        n1051), .Q(\cpuregs[0][3] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][2]  ( .D(\cpuregs[0][2] ), .CLK(
        n1051), .Q(\cpuregs[0][2] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][1]  ( .D(\cpuregs[0][1] ), .CLK(
        n1051), .Q(\cpuregs[0][1] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpuregs_reg[0][0]  ( .D(\cpuregs[0][0] ), .CLK(
        n1051), .Q(\cpuregs[0][0] ) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[7]  ( .D(N2115), .CLK(net685), .Q(
        cpu_state[7]) );
  sky130_fd_sc_hd__dfxtp_1 instr_xor_reg ( .D(N369), .CLK(net500), .Q(
        instr_xor) );
  sky130_fd_sc_hd__dfxtp_1 instr_xori_reg ( .D(N361), .CLK(net500), .Q(
        instr_xori) );
  sky130_fd_sc_hd__dfxtp_1 instr_rdinstr_reg ( .D(N297), .CLK(net495), .Q(
        instr_rdinstr) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[63]  ( .D(N946), .CLK(n1046), .Q(
        count_cycle[63]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[63]  ( .D(N2044), .CLK(net670), 
        .Q(count_instr[63]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[7]  ( .D(mem_rdata[7]), .CLK(
        net469), .Q(mem_rdata_q[7]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[15]  ( .D(mem_rdata[15]), .CLK(
        net469), .Q(mem_rdata_q[15]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[16]  ( .D(mem_rdata[16]), .CLK(
        net469), .Q(mem_rdata_q[16]) );
  sky130_fd_sc_hd__dfxtp_1 instr_bne_reg ( .D(N353), .CLK(net500), .Q(
        instr_bne) );
  sky130_fd_sc_hd__dfxtp_1 instr_beq_reg ( .D(N352), .CLK(net500), .Q(
        instr_beq) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[24]  ( .D(mem_rdata[24]), .CLK(
        net469), .Q(mem_rdata_q[24]) );
  sky130_fd_sc_hd__dfxtp_1 latched_stalu_reg ( .D(n1024), .CLK(net700), .Q(
        latched_stalu) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[31]  ( .D(N1909), .CLK(n1048), .Q(
        reg_out[31]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[2]  ( .D(N1880), .CLK(n1052), .Q(
        reg_out[2]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[4]  ( .D(N1882), .CLK(n1052), .Q(
        reg_out[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[5]  ( .D(N1883), .CLK(n1047), .Q(
        reg_out[5]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[6]  ( .D(N1884), .CLK(n1047), .Q(
        reg_out[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[7]  ( .D(N1885), .CLK(n1047), .Q(
        reg_out[7]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[8]  ( .D(N1886), .CLK(n1047), .Q(
        reg_out[8]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[9]  ( .D(N1887), .CLK(n1047), .Q(
        reg_out[9]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[10]  ( .D(N1888), .CLK(n1047), .Q(
        reg_out[10]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[11]  ( .D(N1889), .CLK(n1047), .Q(
        reg_out[11]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[12]  ( .D(N1890), .CLK(n1047), .Q(
        reg_out[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[13]  ( .D(N1891), .CLK(n1047), .Q(
        reg_out[13]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[14]  ( .D(N1892), .CLK(n1047), .Q(
        reg_out[14]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[15]  ( .D(N1893), .CLK(n1047), .Q(
        reg_out[15]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[16]  ( .D(N1894), .CLK(n1047), .Q(
        reg_out[16]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[17]  ( .D(N1895), .CLK(n1048), .Q(
        reg_out[17]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[18]  ( .D(N1896), .CLK(n1048), .Q(
        reg_out[18]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[19]  ( .D(N1897), .CLK(n1048), .Q(
        reg_out[19]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[20]  ( .D(N1898), .CLK(n1048), .Q(
        reg_out[20]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[21]  ( .D(N1899), .CLK(n1048), .Q(
        reg_out[21]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[22]  ( .D(N1900), .CLK(n1048), .Q(
        reg_out[22]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[23]  ( .D(N1901), .CLK(n1048), .Q(
        reg_out[23]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[24]  ( .D(N1902), .CLK(n1048), .Q(
        reg_out[24]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[25]  ( .D(N1903), .CLK(n1048), .Q(
        reg_out[25]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[26]  ( .D(N1904), .CLK(n1048), .Q(
        reg_out[26]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[27]  ( .D(N1905), .CLK(n1052), .Q(
        reg_out[27]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[28]  ( .D(N1906), .CLK(n1052), .Q(
        reg_out[28]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[29]  ( .D(N1907), .CLK(n1052), .Q(
        reg_out[29]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[30]  ( .D(N1908), .CLK(n1048), .Q(
        reg_out[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_out_reg[3]  ( .D(N1881), .CLK(n1052), .Q(
        reg_out[3]) );
  sky130_fd_sc_hd__dfxtp_1 mem_do_rdata_reg ( .D(n1021), .CLK(net700), .Q(
        mem_do_rdata) );
  sky130_fd_sc_hd__dfxtp_1 is_lui_auipc_jal_reg ( .D(N252), .CLK(n1046), .Q(
        is_lui_auipc_jal) );
  sky130_fd_sc_hd__dfxtp_1 is_slli_srli_srai_reg ( .D(N300), .CLK(net495), .Q(
        is_slli_srli_srai) );
  sky130_fd_sc_hd__dfxtp_1 is_alu_reg_imm_reg ( .D(n1036), .CLK(net490), .Q(
        is_alu_reg_imm) );
  sky130_fd_sc_hd__dfxtp_1 mem_do_prefetch_reg ( .D(n1022), .CLK(net700), .Q(
        mem_do_prefetch) );
  sky130_fd_sc_hd__dfxtp_1 \latched_rd_reg[3]  ( .D(N1795), .CLK(net690), .Q(
        latched_rd[3]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wordsize_reg[1]  ( .D(n1026), .CLK(net700), 
        .Q(mem_wordsize[1]) );
  sky130_fd_sc_hd__dfxtp_1 is_sb_sh_sw_reg ( .D(n1037), .CLK(net490), .Q(
        is_sb_sh_sw) );
  sky130_fd_sc_hd__dfxtp_1 \latched_rd_reg[4]  ( .D(N1796), .CLK(net690), .Q(
        latched_rd[4]) );
  sky130_fd_sc_hd__dfxtp_1 is_lb_lh_lw_lbu_lhu_reg ( .D(n1038), .CLK(net490), 
        .Q(is_lb_lh_lw_lbu_lhu) );
  sky130_fd_sc_hd__dfxtp_1 instr_sb_reg ( .D(N273), .CLK(net495), .Q(instr_sb)
         );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[22]  ( .D(mem_rdata[22]), .CLK(
        net469), .Q(mem_rdata_q[22]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[23]  ( .D(mem_rdata[23]), .CLK(
        net469), .Q(mem_rdata_q[23]) );
  sky130_fd_sc_hd__dfxtp_1 is_compare_reg ( .D(N350), .CLK(n1046), .Q(
        is_compare) );
  sky130_fd_sc_hd__dfxtp_1 \reg_sh_reg[3]  ( .D(N1876), .CLK(n1047), .Q(
        reg_sh[3]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[29]  ( .D(mem_rdata[29]), .CLK(
        net469), .Q(mem_rdata_q[29]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[25]  ( .D(mem_rdata[25]), .CLK(
        net469), .Q(mem_rdata_q[25]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[28]  ( .D(mem_rdata[28]), .CLK(
        net469), .Q(mem_rdata_q[28]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[26]  ( .D(mem_rdata[26]), .CLK(
        net469), .Q(mem_rdata_q[26]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_state_reg[0]  ( .D(n1028), .CLK(n1046), .Q(
        mem_state[0]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[4]  ( .D(
        mem_rdata_latched_noshuffle[24]), .CLK(net490), .Q(decoded_imm_j[4])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[3]  ( .D(
        mem_rdata_latched_noshuffle[23]), .CLK(net490), .Q(decoded_imm_j[3])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[2]  ( .D(
        mem_rdata_latched_noshuffle[22]), .CLK(net490), .Q(decoded_imm_j[2])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[19]  ( .D(
        mem_rdata_latched_noshuffle[19]), .CLK(net490), .Q(decoded_imm_j[19])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[18]  ( .D(
        mem_rdata_latched_noshuffle[18]), .CLK(net490), .Q(decoded_imm_j[18])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[17]  ( .D(
        mem_rdata_latched_noshuffle[17]), .CLK(net490), .Q(decoded_imm_j[17])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[16]  ( .D(
        mem_rdata_latched_noshuffle[16]), .CLK(net490), .Q(decoded_imm_j[16])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[20]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[20])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[21]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[21])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[22]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[22])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[23]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[23])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[24]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[24])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[25]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[25])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[26]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[26])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[27]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[27])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[28]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[28])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[29]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[29])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[30]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[30])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[31]  ( .D(
        mem_rdata_latched_noshuffle[31]), .CLK(net490), .Q(decoded_imm_j[31])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[11]  ( .D(
        mem_rdata_latched_noshuffle[20]), .CLK(net490), .Q(decoded_imm_j[11])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[15]  ( .D(
        mem_rdata_latched_noshuffle[15]), .CLK(net490), .Q(decoded_imm_j[15])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[14]  ( .D(
        mem_rdata_latched_noshuffle[14]), .CLK(net490), .Q(decoded_imm_j[14])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[13]  ( .D(
        mem_rdata_latched_noshuffle[13]), .CLK(net490), .Q(decoded_imm_j[13])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[12]  ( .D(
        mem_rdata_latched_noshuffle[12]), .CLK(net490), .Q(decoded_imm_j[12])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[9]  ( .D(
        mem_rdata_latched_noshuffle[29]), .CLK(net490), .Q(decoded_imm_j[9])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[8]  ( .D(
        mem_rdata_latched_noshuffle[28]), .CLK(net490), .Q(decoded_imm_j[8])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[10]  ( .D(
        mem_rdata_latched_noshuffle[30]), .CLK(net490), .Q(decoded_imm_j[10])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[7]  ( .D(
        mem_rdata_latched_noshuffle[27]), .CLK(net490), .Q(decoded_imm_j[7])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[6]  ( .D(
        mem_rdata_latched_noshuffle[26]), .CLK(net490), .Q(decoded_imm_j[6])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[5]  ( .D(
        mem_rdata_latched_noshuffle[25]), .CLK(net490), .Q(decoded_imm_j[5])
         );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_j_reg[1]  ( .D(
        mem_rdata_latched_noshuffle[21]), .CLK(net490), .Q(decoded_imm_j[1])
         );
  sky130_fd_sc_hd__dfxtp_1 \reg_sh_reg[0]  ( .D(N1873), .CLK(n1046), .Q(N1563)
         );
  sky130_fd_sc_hd__dfxtp_1 latched_store_reg ( .D(n1025), .CLK(net700), .Q(
        latched_store) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs1_reg[3]  ( .D(
        mem_rdata_latched_noshuffle[18]), .CLK(net490), .Q(N85) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[14]  ( .D(mem_rdata[14]), .CLK(
        net469), .Q(mem_rdata_q[14]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[12]  ( .D(mem_rdata[12]), .CLK(
        net469), .Q(mem_rdata_q[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[1]  ( .D(n3569), .CLK(net665), .Q(
        reg_pc[1]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[20]  ( .D(mem_rdata[20]), .CLK(
        net469), .Q(mem_rdata_q[20]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[21]  ( .D(mem_rdata[21]), .CLK(
        net469), .Q(mem_rdata_q[21]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs1_reg[2]  ( .D(
        mem_rdata_latched_noshuffle[17]), .CLK(net490), .Q(N84) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[31]  ( .D(n3539), .CLK(net665), .Q(
        reg_pc[31]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[47]  ( .D(N2028), .CLK(net670), 
        .Q(count_instr[47]) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[5]  ( .D(N2113), .CLK(net685), .Q(
        cpu_state[5]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[1]  ( .D(N1982), .CLK(net670), .Q(
        count_instr[1]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[2]  ( .D(N1983), .CLK(net670), .Q(
        count_instr[2]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[3]  ( .D(N1984), .CLK(net670), .Q(
        count_instr[3]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[4]  ( .D(N1985), .CLK(net670), .Q(
        count_instr[4]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[5]  ( .D(N1986), .CLK(net670), .Q(
        count_instr[5]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[6]  ( .D(N1987), .CLK(net670), .Q(
        count_instr[6]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[7]  ( .D(N1988), .CLK(net670), .Q(
        count_instr[7]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[8]  ( .D(N1989), .CLK(net670), .Q(
        count_instr[8]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[9]  ( .D(N1990), .CLK(net670), .Q(
        count_instr[9]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[10]  ( .D(N1991), .CLK(net670), 
        .Q(count_instr[10]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[11]  ( .D(N1992), .CLK(net670), 
        .Q(count_instr[11]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[12]  ( .D(N1993), .CLK(net670), 
        .Q(count_instr[12]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[13]  ( .D(N1994), .CLK(net670), 
        .Q(count_instr[13]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[14]  ( .D(N1995), .CLK(net670), 
        .Q(count_instr[14]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[16]  ( .D(N899), .CLK(n1050), .Q(
        count_cycle[16]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[17]  ( .D(N900), .CLK(n1050), .Q(
        count_cycle[17]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[18]  ( .D(N901), .CLK(n1050), .Q(
        count_cycle[18]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[19]  ( .D(N902), .CLK(n1050), .Q(
        count_cycle[19]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[20]  ( .D(N903), .CLK(n1050), .Q(
        count_cycle[20]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[21]  ( .D(N904), .CLK(n1050), .Q(
        count_cycle[21]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[22]  ( .D(N905), .CLK(n1050), .Q(
        count_cycle[22]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[23]  ( .D(N906), .CLK(n1050), .Q(
        count_cycle[23]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[24]  ( .D(N907), .CLK(n1050), .Q(
        count_cycle[24]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[25]  ( .D(N908), .CLK(n1050), .Q(
        count_cycle[25]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[26]  ( .D(N909), .CLK(n1050), .Q(
        count_cycle[26]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[27]  ( .D(N910), .CLK(n1050), .Q(
        count_cycle[27]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[28]  ( .D(N911), .CLK(n1050), .Q(
        count_cycle[28]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[29]  ( .D(N912), .CLK(n1050), .Q(
        count_cycle[29]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[30]  ( .D(N913), .CLK(n1050), .Q(
        count_cycle[30]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[31]  ( .D(N914), .CLK(n1050), .Q(
        count_cycle[31]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[1]  ( .D(N884), .CLK(n1051), .Q(
        count_cycle[1]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[2]  ( .D(N885), .CLK(n1051), .Q(
        count_cycle[2]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[3]  ( .D(N886), .CLK(n1051), .Q(
        count_cycle[3]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[4]  ( .D(N887), .CLK(n1051), .Q(
        count_cycle[4]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[5]  ( .D(N888), .CLK(n1051), .Q(
        count_cycle[5]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[6]  ( .D(N889), .CLK(n1050), .Q(
        count_cycle[6]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[7]  ( .D(N890), .CLK(n1050), .Q(
        count_cycle[7]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[8]  ( .D(N891), .CLK(n1050), .Q(
        count_cycle[8]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[9]  ( .D(N892), .CLK(n1050), .Q(
        count_cycle[9]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[10]  ( .D(N893), .CLK(n1050), .Q(
        count_cycle[10]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[11]  ( .D(N894), .CLK(n1050), .Q(
        count_cycle[11]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[12]  ( .D(N895), .CLK(n1050), .Q(
        count_cycle[12]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[13]  ( .D(N896), .CLK(n1050), .Q(
        count_cycle[13]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[14]  ( .D(N897), .CLK(n1050), .Q(
        count_cycle[14]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[47]  ( .D(N930), .CLK(n1049), .Q(
        count_cycle[47]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[48]  ( .D(N931), .CLK(n1049), .Q(
        count_cycle[48]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[49]  ( .D(N932), .CLK(n1049), .Q(
        count_cycle[49]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[50]  ( .D(N933), .CLK(n1049), .Q(
        count_cycle[50]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[51]  ( .D(N934), .CLK(n1049), .Q(
        count_cycle[51]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[52]  ( .D(N935), .CLK(n1049), .Q(
        count_cycle[52]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[53]  ( .D(N936), .CLK(n1049), .Q(
        count_cycle[53]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[54]  ( .D(N937), .CLK(n1049), .Q(
        count_cycle[54]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[55]  ( .D(N938), .CLK(n1049), .Q(
        count_cycle[55]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[56]  ( .D(N939), .CLK(n1049), .Q(
        count_cycle[56]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[57]  ( .D(N940), .CLK(n1049), .Q(
        count_cycle[57]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[58]  ( .D(N941), .CLK(n1049), .Q(
        count_cycle[58]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[59]  ( .D(N942), .CLK(n1048), .Q(
        count_cycle[59]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[60]  ( .D(N943), .CLK(n1048), .Q(
        count_cycle[60]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[61]  ( .D(N944), .CLK(n1048), .Q(
        count_cycle[61]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[62]  ( .D(N945), .CLK(n1050), .Q(
        count_cycle[62]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[16]  ( .D(N1997), .CLK(net670), 
        .Q(count_instr[16]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[17]  ( .D(N1998), .CLK(net670), 
        .Q(count_instr[17]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[18]  ( .D(N1999), .CLK(net670), 
        .Q(count_instr[18]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[19]  ( .D(N2000), .CLK(net670), 
        .Q(count_instr[19]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[20]  ( .D(N2001), .CLK(net670), 
        .Q(count_instr[20]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[21]  ( .D(N2002), .CLK(net670), 
        .Q(count_instr[21]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[22]  ( .D(N2003), .CLK(net670), 
        .Q(count_instr[22]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[23]  ( .D(N2004), .CLK(net670), 
        .Q(count_instr[23]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[24]  ( .D(N2005), .CLK(net670), 
        .Q(count_instr[24]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[25]  ( .D(N2006), .CLK(net670), 
        .Q(count_instr[25]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[26]  ( .D(N2007), .CLK(net670), 
        .Q(count_instr[26]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[27]  ( .D(N2008), .CLK(net670), 
        .Q(count_instr[27]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[28]  ( .D(N2009), .CLK(net670), 
        .Q(count_instr[28]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[29]  ( .D(N2010), .CLK(net670), 
        .Q(count_instr[29]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[30]  ( .D(N2011), .CLK(net670), 
        .Q(count_instr[30]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[31]  ( .D(N2012), .CLK(net670), 
        .Q(count_instr[31]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[15]  ( .D(N898), .CLK(n1050), .Q(
        count_cycle[15]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[32]  ( .D(N2013), .CLK(net670), 
        .Q(count_instr[32]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[33]  ( .D(N2014), .CLK(net670), 
        .Q(count_instr[33]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[34]  ( .D(N2015), .CLK(net670), 
        .Q(count_instr[34]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[35]  ( .D(N2016), .CLK(net670), 
        .Q(count_instr[35]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[36]  ( .D(N2017), .CLK(net670), 
        .Q(count_instr[36]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[37]  ( .D(N2018), .CLK(net670), 
        .Q(count_instr[37]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[38]  ( .D(N2019), .CLK(net670), 
        .Q(count_instr[38]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[39]  ( .D(N2020), .CLK(net670), 
        .Q(count_instr[39]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[40]  ( .D(N2021), .CLK(net670), 
        .Q(count_instr[40]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[41]  ( .D(N2022), .CLK(net670), 
        .Q(count_instr[41]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[42]  ( .D(N2023), .CLK(net670), 
        .Q(count_instr[42]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[43]  ( .D(N2024), .CLK(net670), 
        .Q(count_instr[43]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[44]  ( .D(N2025), .CLK(net670), 
        .Q(count_instr[44]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[45]  ( .D(N2026), .CLK(net670), 
        .Q(count_instr[45]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[46]  ( .D(N2027), .CLK(net670), 
        .Q(count_instr[46]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[32]  ( .D(N915), .CLK(n1049), .Q(
        count_cycle[32]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[33]  ( .D(N916), .CLK(n1049), .Q(
        count_cycle[33]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[34]  ( .D(N917), .CLK(n1049), .Q(
        count_cycle[34]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[35]  ( .D(N918), .CLK(n1049), .Q(
        count_cycle[35]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[36]  ( .D(N919), .CLK(n1049), .Q(
        count_cycle[36]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[37]  ( .D(N920), .CLK(n1049), .Q(
        count_cycle[37]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[38]  ( .D(N921), .CLK(n1049), .Q(
        count_cycle[38]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[39]  ( .D(N922), .CLK(n1049), .Q(
        count_cycle[39]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[40]  ( .D(N923), .CLK(n1049), .Q(
        count_cycle[40]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[41]  ( .D(N924), .CLK(n1049), .Q(
        count_cycle[41]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[42]  ( .D(N925), .CLK(n1049), .Q(
        count_cycle[42]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[43]  ( .D(N926), .CLK(n1049), .Q(
        count_cycle[43]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[44]  ( .D(N927), .CLK(n1049), .Q(
        count_cycle[44]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[45]  ( .D(N928), .CLK(n1049), .Q(
        count_cycle[45]) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[46]  ( .D(N929), .CLK(n1049), .Q(
        count_cycle[46]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[15]  ( .D(N1996), .CLK(net670), 
        .Q(count_instr[15]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[48]  ( .D(N2029), .CLK(net670), 
        .Q(count_instr[48]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[49]  ( .D(N2030), .CLK(net670), 
        .Q(count_instr[49]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[50]  ( .D(N2031), .CLK(net670), 
        .Q(count_instr[50]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[51]  ( .D(N2032), .CLK(net670), 
        .Q(count_instr[51]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[52]  ( .D(N2033), .CLK(net670), 
        .Q(count_instr[52]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[53]  ( .D(N2034), .CLK(net670), 
        .Q(count_instr[53]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[54]  ( .D(N2035), .CLK(net670), 
        .Q(count_instr[54]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[55]  ( .D(N2036), .CLK(net670), 
        .Q(count_instr[55]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[56]  ( .D(N2037), .CLK(net670), 
        .Q(count_instr[56]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[57]  ( .D(N2038), .CLK(net670), 
        .Q(count_instr[57]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[58]  ( .D(N2039), .CLK(net670), 
        .Q(count_instr[58]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[59]  ( .D(N2040), .CLK(net670), 
        .Q(count_instr[59]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[60]  ( .D(N2041), .CLK(net670), 
        .Q(count_instr[60]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[61]  ( .D(N2042), .CLK(net670), 
        .Q(count_instr[61]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[62]  ( .D(N2043), .CLK(net670), 
        .Q(count_instr[62]) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[1]  ( .D(N2110), .CLK(net685), .Q(
        cpu_state[1]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[31]  ( .D(mem_rdata[31]), .CLK(
        net469), .Q(mem_rdata_q[31]) );
  sky130_fd_sc_hd__dfxtp_1 mem_do_rinst_reg ( .D(n1031), .CLK(net700), .Q(
        mem_do_rinst) );
  sky130_fd_sc_hd__dfxtp_1 is_beq_bne_blt_bge_bltu_bgeu_reg ( .D(n1027), .CLK(
        net700), .Q(is_beq_bne_blt_bge_bltu_bgeu) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs1_reg[0]  ( .D(
        mem_rdata_latched_noshuffle[15]), .CLK(net490), .Q(N82) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs1_reg[1]  ( .D(
        mem_rdata_latched_noshuffle[16]), .CLK(net490), .Q(N83) );
  sky130_fd_sc_hd__dfxtp_1 \latched_rd_reg[1]  ( .D(N1793), .CLK(net690), .Q(
        latched_rd[1]) );
  sky130_fd_sc_hd__dfxtp_1 \latched_rd_reg[0]  ( .D(N1792), .CLK(net690), .Q(
        latched_rd[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[13]  ( .D(mem_rdata[13]), .CLK(
        net469), .Q(mem_rdata_q[13]) );
  sky130_fd_sc_hd__dfxtp_1 \latched_rd_reg[2]  ( .D(N1794), .CLK(net690), .Q(
        latched_rd[2]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs2_reg[3]  ( .D(
        mem_rdata_latched_noshuffle[23]), .CLK(net490), .Q(N90) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[0]  ( .D(n3570), .CLK(net665), .Q(
        reg_pc[0]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs2_reg[2]  ( .D(
        mem_rdata_latched_noshuffle[22]), .CLK(net490), .Q(N89) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[4]  ( .D(n3566), .CLK(net665), .Q(
        reg_pc[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[30]  ( .D(n3540), .CLK(net665), .Q(
        reg_pc[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[3]  ( .D(n3567), .CLK(net665), .Q(
        reg_pc[3]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[5]  ( .D(n3565), .CLK(net665), .Q(
        reg_pc[5]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[6]  ( .D(n3564), .CLK(net665), .Q(
        reg_pc[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[8]  ( .D(n3562), .CLK(net665), .Q(
        reg_pc[8]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[9]  ( .D(n3561), .CLK(net665), .Q(
        reg_pc[9]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[10]  ( .D(n3560), .CLK(net665), .Q(
        reg_pc[10]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[11]  ( .D(n3559), .CLK(net665), .Q(
        reg_pc[11]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[12]  ( .D(n3558), .CLK(net665), .Q(
        reg_pc[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[13]  ( .D(n3557), .CLK(net665), .Q(
        reg_pc[13]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[14]  ( .D(n3556), .CLK(net665), .Q(
        reg_pc[14]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[15]  ( .D(n3555), .CLK(net665), .Q(
        reg_pc[15]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[16]  ( .D(n3554), .CLK(net665), .Q(
        reg_pc[16]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[17]  ( .D(n3553), .CLK(net665), .Q(
        reg_pc[17]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[18]  ( .D(n3552), .CLK(net665), .Q(
        reg_pc[18]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[19]  ( .D(n3551), .CLK(net665), .Q(
        reg_pc[19]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[20]  ( .D(n3550), .CLK(net665), .Q(
        reg_pc[20]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[21]  ( .D(n3549), .CLK(net665), .Q(
        reg_pc[21]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[22]  ( .D(n3548), .CLK(net665), .Q(
        reg_pc[22]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[23]  ( .D(n3547), .CLK(net665), .Q(
        reg_pc[23]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[24]  ( .D(n3546), .CLK(net665), .Q(
        reg_pc[24]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[25]  ( .D(n3545), .CLK(net665), .Q(
        reg_pc[25]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[26]  ( .D(n3544), .CLK(net665), .Q(
        reg_pc[26]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[27]  ( .D(n3543), .CLK(net665), .Q(
        reg_pc[27]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[28]  ( .D(n3542), .CLK(net665), .Q(
        reg_pc[28]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[29]  ( .D(n3541), .CLK(net665), .Q(
        reg_pc[29]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[7]  ( .D(n3563), .CLK(net665), .Q(
        reg_pc[7]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs2_reg[1]  ( .D(
        mem_rdata_latched_noshuffle[21]), .CLK(net490), .Q(N88) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs2_reg[0]  ( .D(
        mem_rdata_latched_noshuffle[20]), .CLK(net490), .Q(N87) );
  sky130_fd_sc_hd__dfxtp_1 \count_cycle_reg[0]  ( .D(N883), .CLK(n1048), .Q(
        count_cycle[0]) );
  sky130_fd_sc_hd__dfxtp_1 \count_instr_reg[0]  ( .D(N1981), .CLK(net670), .Q(
        count_instr[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[27]  ( .D(mem_rdata[27]), .CLK(
        net469), .Q(mem_rdata_q[27]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[31]  ( .D(N342), .CLK(net495), .Q(
        decoded_imm[31]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[30]  ( .D(N341), .CLK(net495), .Q(
        decoded_imm[30]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[29]  ( .D(N340), .CLK(net495), .Q(
        decoded_imm[29]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[28]  ( .D(N339), .CLK(net495), .Q(
        decoded_imm[28]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[27]  ( .D(N338), .CLK(net495), .Q(
        decoded_imm[27]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[26]  ( .D(N337), .CLK(net495), .Q(
        decoded_imm[26]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[25]  ( .D(N336), .CLK(net495), .Q(
        decoded_imm[25]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[24]  ( .D(N335), .CLK(net495), .Q(
        decoded_imm[24]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[23]  ( .D(N334), .CLK(net495), .Q(
        decoded_imm[23]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[22]  ( .D(N333), .CLK(net495), .Q(
        decoded_imm[22]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[21]  ( .D(N332), .CLK(net495), .Q(
        decoded_imm[21]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[20]  ( .D(N331), .CLK(net495), .Q(
        decoded_imm[20]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[19]  ( .D(N330), .CLK(net495), .Q(
        decoded_imm[19]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[18]  ( .D(N329), .CLK(net495), .Q(
        decoded_imm[18]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[17]  ( .D(N328), .CLK(net495), .Q(
        decoded_imm[17]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[16]  ( .D(N327), .CLK(net495), .Q(
        decoded_imm[16]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[15]  ( .D(N326), .CLK(net495), .Q(
        decoded_imm[15]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[14]  ( .D(N325), .CLK(net495), .Q(
        decoded_imm[14]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[13]  ( .D(N324), .CLK(net495), .Q(
        decoded_imm[13]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[12]  ( .D(N323), .CLK(net495), .Q(
        decoded_imm[12]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[10]  ( .D(N321), .CLK(net495), .Q(
        decoded_imm[10]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[9]  ( .D(N320), .CLK(net495), .Q(
        decoded_imm[9]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[8]  ( .D(N319), .CLK(net495), .Q(
        decoded_imm[8]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[7]  ( .D(N318), .CLK(net495), .Q(
        decoded_imm[7]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[6]  ( .D(N317), .CLK(net495), .Q(
        decoded_imm[6]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[5]  ( .D(N316), .CLK(net495), .Q(
        decoded_imm[5]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[4]  ( .D(N315), .CLK(net495), .Q(
        decoded_imm[4]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[3]  ( .D(N314), .CLK(net495), .Q(
        decoded_imm[3]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[2]  ( .D(N313), .CLK(net495), .Q(
        decoded_imm[2]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[1]  ( .D(N312), .CLK(net495), .Q(
        decoded_imm[1]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[11]  ( .D(N322), .CLK(net495), .Q(
        decoded_imm[11]) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_imm_reg[0]  ( .D(N311), .CLK(net495), .Q(
        decoded_imm[0]) );
  sky130_fd_sc_hd__dfxtp_1 mem_do_wdata_reg ( .D(n1034), .CLK(net700), .Q(
        mem_do_wdata) );
  sky130_fd_sc_hd__dfxtp_1 \mem_rdata_q_reg[30]  ( .D(mem_rdata[30]), .CLK(
        net469), .Q(mem_rdata_q[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_pc_reg[2]  ( .D(n3568), .CLK(net665), .Q(
        reg_pc[2]) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[6]  ( .D(N2114), .CLK(net685), .Q(
        cpu_state[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[0]  ( .D(N1841), .CLK(net660), .Q(
        pcpi_rs2[0]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[27]  ( .D(N1868), .CLK(net660), .Q(
        pcpi_rs2[27]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[26]  ( .D(N1867), .CLK(net660), .Q(
        pcpi_rs2[26]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[25]  ( .D(N1866), .CLK(net660), .Q(
        pcpi_rs2[25]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[24]  ( .D(N1865), .CLK(net660), .Q(
        pcpi_rs2[24]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[23]  ( .D(N1864), .CLK(net660), .Q(
        pcpi_rs2[23]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[22]  ( .D(N1863), .CLK(net660), .Q(
        pcpi_rs2[22]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[21]  ( .D(N1862), .CLK(net660), .Q(
        pcpi_rs2[21]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[20]  ( .D(N1861), .CLK(net660), .Q(
        pcpi_rs2[20]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[19]  ( .D(N1860), .CLK(net660), .Q(
        pcpi_rs2[19]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[18]  ( .D(N1859), .CLK(net660), .Q(
        pcpi_rs2[18]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[17]  ( .D(N1858), .CLK(net660), .Q(
        pcpi_rs2[17]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[16]  ( .D(N1857), .CLK(net660), .Q(
        pcpi_rs2[16]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[30]  ( .D(N1871), .CLK(net660), .Q(
        pcpi_rs2[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[29]  ( .D(N1870), .CLK(net660), .Q(
        pcpi_rs2[29]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[31]  ( .D(N1872), .CLK(net660), .Q(
        pcpi_rs2[31]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[7]  ( .D(N1848), .CLK(net660), .Q(
        pcpi_rs2[7]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[6]  ( .D(N1847), .CLK(net660), .Q(
        pcpi_rs2[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[5]  ( .D(N1846), .CLK(net660), .Q(
        pcpi_rs2[5]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[4]  ( .D(N1845), .CLK(net660), .Q(
        pcpi_rs2[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[3]  ( .D(N1844), .CLK(net660), .Q(
        pcpi_rs2[3]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[2]  ( .D(N1843), .CLK(net660), .Q(
        pcpi_rs2[2]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[28]  ( .D(N1869), .CLK(net660), .Q(
        pcpi_rs2[28]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[15]  ( .D(N1856), .CLK(net660), .Q(
        pcpi_rs2[15]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[14]  ( .D(N1855), .CLK(net660), .Q(
        pcpi_rs2[14]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[13]  ( .D(N1854), .CLK(net660), .Q(
        pcpi_rs2[13]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[12]  ( .D(N1853), .CLK(net660), .Q(
        pcpi_rs2[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[10]  ( .D(N1851), .CLK(net660), .Q(
        pcpi_rs2[10]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[9]  ( .D(N1850), .CLK(net660), .Q(
        pcpi_rs2[9]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[8]  ( .D(N1849), .CLK(net660), .Q(
        pcpi_rs2[8]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[11]  ( .D(N1852), .CLK(net660), .Q(
        pcpi_rs2[11]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op2_reg[1]  ( .D(N1842), .CLK(net660), .Q(
        pcpi_rs2[1]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[28]  ( .D(N1836), .CLK(net695), .Q(
        pcpi_rs1[28]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[30]  ( .D(N1838), .CLK(net695), .Q(
        pcpi_rs1[30]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[29]  ( .D(N1837), .CLK(net695), .Q(
        pcpi_rs1[29]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[25]  ( .D(N1833), .CLK(net695), .Q(
        pcpi_rs1[25]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[26]  ( .D(N1834), .CLK(net695), .Q(
        pcpi_rs1[26]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[24]  ( .D(N1832), .CLK(net695), .Q(
        pcpi_rs1[24]) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[0]  ( .D(N2109), .CLK(net685), .Q(
        cpu_state[0]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[23]  ( .D(N1831), .CLK(net695), .Q(
        pcpi_rs1[23]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[21]  ( .D(N1829), .CLK(net695), .Q(
        pcpi_rs1[21]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[19]  ( .D(N1827), .CLK(net695), .Q(
        pcpi_rs1[19]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[17]  ( .D(N1825), .CLK(net695), .Q(
        pcpi_rs1[17]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[15]  ( .D(N1823), .CLK(net695), .Q(
        pcpi_rs1[15]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[27]  ( .D(N1835), .CLK(net695), .Q(
        pcpi_rs1[27]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[22]  ( .D(N1830), .CLK(net695), .Q(
        pcpi_rs1[22]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[20]  ( .D(N1828), .CLK(net695), .Q(
        pcpi_rs1[20]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[18]  ( .D(N1826), .CLK(net695), .Q(
        pcpi_rs1[18]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[16]  ( .D(N1824), .CLK(net695), .Q(
        pcpi_rs1[16]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[31]  ( .D(n1032), .CLK(net695), .Q(
        pcpi_rs1[31]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[13]  ( .D(N1821), .CLK(net695), .Q(
        pcpi_rs1[13]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[11]  ( .D(N1819), .CLK(net695), .Q(
        pcpi_rs1[11]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[9]  ( .D(N1817), .CLK(net695), .Q(
        pcpi_rs1[9]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[14]  ( .D(N1822), .CLK(net695), .Q(
        pcpi_rs1[14]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[12]  ( .D(N1820), .CLK(net695), .Q(
        pcpi_rs1[12]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[10]  ( .D(N1818), .CLK(net695), .Q(
        pcpi_rs1[10]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[8]  ( .D(N1816), .CLK(net695), .Q(
        pcpi_rs1[8]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[5]  ( .D(N1813), .CLK(net695), .Q(
        pcpi_rs1[5]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[7]  ( .D(N1815), .CLK(net695), .Q(
        pcpi_rs1[7]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[6]  ( .D(N1814), .CLK(net695), .Q(
        pcpi_rs1[6]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[2]  ( .D(N1810), .CLK(net695), .Q(
        pcpi_rs1[2]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[3]  ( .D(N1811), .CLK(net695), .Q(
        pcpi_rs1[3]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[4]  ( .D(N1812), .CLK(net695), .Q(
        pcpi_rs1[4]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[1]  ( .D(N1809), .CLK(net695), .Q(
        pcpi_rs1[1]) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[2]  ( .D(N2111), .CLK(net685), .Q(
        cpu_state[2]) );
  sky130_fd_sc_hd__dfxtp_1 \reg_op1_reg[0]  ( .D(N1808), .CLK(net695), .Q(
        pcpi_rs1[0]) );
  sky130_fd_sc_hd__dfxtp_1 decoder_trigger_reg ( .D(N2074), .CLK(n1046), .Q(
        decoder_trigger) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs1_reg[4]  ( .D(
        mem_rdata_latched_noshuffle[19]), .CLK(net490), .Q(N86) );
  sky130_fd_sc_hd__dfxtp_1 \decoded_rs2_reg[4]  ( .D(
        mem_rdata_latched_noshuffle[24]), .CLK(net490), .Q(N91) );
  sky130_fd_sc_hd__dfxtp_1 latched_branch_reg ( .D(n1023), .CLK(net700), .Q(
        latched_branch) );
  sky130_fd_sc_hd__dfxtp_1 instr_jal_reg ( .D(n1039), .CLK(net490), .Q(
        instr_jal) );
  sky130_fd_sc_hd__dfxtp_1 \cpu_state_reg[3]  ( .D(N2112), .CLK(net685), .Q(
        cpu_state[3]) );
  sky130_fd_sc_hd__dfxtp_1 mem_instr_reg ( .D(n3537), .CLK(net480), .Q(
        mem_instr) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wstrb_reg[3]  ( .D(N242), .CLK(net480), .Q(
        mem_wstrb[3]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wstrb_reg[2]  ( .D(N241), .CLK(net480), .Q(
        mem_wstrb[2]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wstrb_reg[1]  ( .D(N240), .CLK(net480), .Q(
        mem_wstrb[1]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wstrb_reg[0]  ( .D(N239), .CLK(net480), .Q(
        mem_wstrb[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[30]  ( .D(mem_la_addr[30]), .CLK(
        net480), .Q(mem_addr[30]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[3]  ( .D(mem_la_addr[3]), .CLK(net480), .Q(mem_addr[3]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[5]  ( .D(mem_la_addr[5]), .CLK(net480), .Q(mem_addr[5]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[6]  ( .D(mem_la_addr[6]), .CLK(net480), .Q(mem_addr[6]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[8]  ( .D(mem_la_addr[8]), .CLK(net480), .Q(mem_addr[8]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[9]  ( .D(mem_la_addr[9]), .CLK(net480), .Q(mem_addr[9]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[10]  ( .D(mem_la_addr[10]), .CLK(
        net480), .Q(mem_addr[10]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[11]  ( .D(mem_la_addr[11]), .CLK(
        net480), .Q(mem_addr[11]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[12]  ( .D(mem_la_addr[12]), .CLK(
        net480), .Q(mem_addr[12]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[13]  ( .D(mem_la_addr[13]), .CLK(
        net480), .Q(mem_addr[13]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[14]  ( .D(mem_la_addr[14]), .CLK(
        net480), .Q(mem_addr[14]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[15]  ( .D(mem_la_addr[15]), .CLK(
        net480), .Q(mem_addr[15]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[16]  ( .D(mem_la_addr[16]), .CLK(
        net480), .Q(mem_addr[16]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[17]  ( .D(mem_la_addr[17]), .CLK(
        net480), .Q(mem_addr[17]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[18]  ( .D(mem_la_addr[18]), .CLK(
        net480), .Q(mem_addr[18]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[19]  ( .D(mem_la_addr[19]), .CLK(
        net480), .Q(mem_addr[19]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[20]  ( .D(mem_la_addr[20]), .CLK(
        net480), .Q(mem_addr[20]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[21]  ( .D(mem_la_addr[21]), .CLK(
        net480), .Q(mem_addr[21]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[22]  ( .D(mem_la_addr[22]), .CLK(
        net480), .Q(mem_addr[22]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[23]  ( .D(mem_la_addr[23]), .CLK(
        net480), .Q(mem_addr[23]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[24]  ( .D(mem_la_addr[24]), .CLK(
        net480), .Q(mem_addr[24]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[25]  ( .D(mem_la_addr[25]), .CLK(
        net480), .Q(mem_addr[25]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[26]  ( .D(mem_la_addr[26]), .CLK(
        net480), .Q(mem_addr[26]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[27]  ( .D(mem_la_addr[27]), .CLK(
        net480), .Q(mem_addr[27]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[28]  ( .D(mem_la_addr[28]), .CLK(
        net480), .Q(mem_addr[28]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[29]  ( .D(mem_la_addr[29]), .CLK(
        net480), .Q(mem_addr[29]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[7]  ( .D(mem_la_addr[7]), .CLK(net480), .Q(mem_addr[7]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[31]  ( .D(mem_la_addr[31]), .CLK(
        net480), .Q(mem_addr[31]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[4]  ( .D(mem_la_addr[4]), .CLK(net480), .Q(mem_addr[4]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_addr_reg[2]  ( .D(mem_la_addr[2]), .CLK(net480), .Q(mem_addr[2]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[0]  ( .D(mem_la_wdata[0]), .CLK(
        net485), .Q(mem_wdata[0]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[31]  ( .D(mem_la_wdata[31]), .CLK(
        net485), .Q(mem_wdata[31]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[30]  ( .D(mem_la_wdata[30]), .CLK(
        net485), .Q(mem_wdata[30]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[29]  ( .D(mem_la_wdata[29]), .CLK(
        net485), .Q(mem_wdata[29]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[28]  ( .D(mem_la_wdata[28]), .CLK(
        net485), .Q(mem_wdata[28]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[27]  ( .D(mem_la_wdata[27]), .CLK(
        net485), .Q(mem_wdata[27]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[26]  ( .D(mem_la_wdata[26]), .CLK(
        net485), .Q(mem_wdata[26]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[25]  ( .D(mem_la_wdata[25]), .CLK(
        net485), .Q(mem_wdata[25]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[24]  ( .D(mem_la_wdata[24]), .CLK(
        net485), .Q(mem_wdata[24]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[23]  ( .D(mem_la_wdata[23]), .CLK(
        net485), .Q(mem_wdata[23]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[22]  ( .D(mem_la_wdata[22]), .CLK(
        net485), .Q(mem_wdata[22]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[21]  ( .D(mem_la_wdata[21]), .CLK(
        net485), .Q(mem_wdata[21]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[20]  ( .D(mem_la_wdata[20]), .CLK(
        net485), .Q(mem_wdata[20]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[19]  ( .D(mem_la_wdata[19]), .CLK(
        net485), .Q(mem_wdata[19]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[18]  ( .D(mem_la_wdata[18]), .CLK(
        net485), .Q(mem_wdata[18]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[17]  ( .D(mem_la_wdata[17]), .CLK(
        net485), .Q(mem_wdata[17]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[16]  ( .D(mem_la_wdata[16]), .CLK(
        net485), .Q(mem_wdata[16]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[7]  ( .D(mem_la_wdata[7]), .CLK(
        net485), .Q(mem_wdata[7]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[6]  ( .D(mem_la_wdata[6]), .CLK(
        net485), .Q(mem_wdata[6]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[5]  ( .D(mem_la_wdata[5]), .CLK(
        net485), .Q(mem_wdata[5]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[4]  ( .D(mem_la_wdata[4]), .CLK(
        net485), .Q(mem_wdata[4]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[3]  ( .D(mem_la_wdata[3]), .CLK(
        net485), .Q(mem_wdata[3]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[2]  ( .D(mem_la_wdata[2]), .CLK(
        net485), .Q(mem_wdata[2]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[1]  ( .D(mem_la_wdata[1]), .CLK(
        net485), .Q(mem_wdata[1]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[15]  ( .D(mem_la_wdata[15]), .CLK(
        net485), .Q(mem_wdata[15]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[14]  ( .D(mem_la_wdata[14]), .CLK(
        net485), .Q(mem_wdata[14]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[13]  ( .D(mem_la_wdata[13]), .CLK(
        net485), .Q(mem_wdata[13]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[12]  ( .D(mem_la_wdata[12]), .CLK(
        net485), .Q(mem_wdata[12]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[11]  ( .D(mem_la_wdata[11]), .CLK(
        net485), .Q(mem_wdata[11]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[10]  ( .D(mem_la_wdata[10]), .CLK(
        net485), .Q(mem_wdata[10]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[9]  ( .D(mem_la_wdata[9]), .CLK(
        net485), .Q(mem_wdata[9]) );
  sky130_fd_sc_hd__dfxtp_1 \mem_wdata_reg[8]  ( .D(mem_la_wdata[8]), .CLK(
        net485), .Q(mem_wdata[8]) );
  sky130_fd_sc_hd__and2_2 U1761 ( .A(n1064), .B(n1072), .X(n1764) );
  sky130_fd_sc_hd__and2_2 U1762 ( .A(n1064), .B(n1074), .X(n1766) );
  sky130_fd_sc_hd__and2_2 U1763 ( .A(n1065), .B(n1072), .X(n1768) );
  sky130_fd_sc_hd__and2_2 U1764 ( .A(n1065), .B(n1074), .X(n1770) );
  sky130_fd_sc_hd__and2_2 U1765 ( .A(n1070), .B(n1072), .X(n1776) );
  sky130_fd_sc_hd__and2_2 U1766 ( .A(n1074), .B(n1070), .X(n1778) );
  sky130_fd_sc_hd__and2_2 U1767 ( .A(n1075), .B(n1072), .X(n1780) );
  sky130_fd_sc_hd__and2_2 U1768 ( .A(n1075), .B(n1074), .X(n1782) );
  sky130_fd_sc_hd__and2_2 U1769 ( .A(n1796), .B(n1804), .X(n2496) );
  sky130_fd_sc_hd__and2_2 U1770 ( .A(n1796), .B(n1806), .X(n2498) );
  sky130_fd_sc_hd__and2_2 U1771 ( .A(n1797), .B(n1804), .X(n2500) );
  sky130_fd_sc_hd__and2_2 U1772 ( .A(n1797), .B(n1806), .X(n2502) );
  sky130_fd_sc_hd__and2_2 U1773 ( .A(n1802), .B(n1804), .X(n2508) );
  sky130_fd_sc_hd__and2_2 U1774 ( .A(n1806), .B(n1802), .X(n2510) );
  sky130_fd_sc_hd__and2_2 U1775 ( .A(n1807), .B(n1804), .X(n2512) );
  sky130_fd_sc_hd__and2_2 U1776 ( .A(n1807), .B(n1806), .X(n2514) );
  sky130_fd_sc_hd__and2_2 U1777 ( .A(n1064), .B(n1071), .X(n1765) );
  sky130_fd_sc_hd__and2_2 U1778 ( .A(n1064), .B(n1073), .X(n1767) );
  sky130_fd_sc_hd__and2_2 U1779 ( .A(n1065), .B(n1071), .X(n1769) );
  sky130_fd_sc_hd__and2_2 U1780 ( .A(n1065), .B(n1073), .X(n1771) );
  sky130_fd_sc_hd__and2_2 U1781 ( .A(n1071), .B(n1070), .X(n1777) );
  sky130_fd_sc_hd__and2_2 U1782 ( .A(n1073), .B(n1070), .X(n1779) );
  sky130_fd_sc_hd__and2_2 U1783 ( .A(n1075), .B(n1071), .X(n1781) );
  sky130_fd_sc_hd__and2_2 U1784 ( .A(n1075), .B(n1073), .X(n1783) );
  sky130_fd_sc_hd__and2_2 U1785 ( .A(n1796), .B(n1803), .X(n2497) );
  sky130_fd_sc_hd__and2_2 U1786 ( .A(n1796), .B(n1805), .X(n2499) );
  sky130_fd_sc_hd__and2_2 U1787 ( .A(n1797), .B(n1803), .X(n2501) );
  sky130_fd_sc_hd__and2_2 U1788 ( .A(n1797), .B(n1805), .X(n2503) );
  sky130_fd_sc_hd__and2_2 U1789 ( .A(n1803), .B(n1802), .X(n2509) );
  sky130_fd_sc_hd__and2_2 U1790 ( .A(n1805), .B(n1802), .X(n2511) );
  sky130_fd_sc_hd__and2_2 U1791 ( .A(n1807), .B(n1803), .X(n2513) );
  sky130_fd_sc_hd__and2_2 U1792 ( .A(n1807), .B(n1805), .X(n2515) );
  sky130_fd_sc_hd__o21ai_1 U1793 ( .A1(instr_ori), .A2(instr_or), .B1(n2829), 
        .Y(n2827) );
  sky130_fd_sc_hd__nor3_2 U1794 ( .A(n2640), .B(instr_lui), .C(n3125), .Y(
        n2610) );
  sky130_fd_sc_hd__nor3_2 U1795 ( .A(n3150), .B(n3201), .C(n3357), .Y(n2617)
         );
  sky130_fd_sc_hd__nor3_2 U1796 ( .A(n3068), .B(n1063), .C(n3137), .Y(n2683)
         );
  sky130_fd_sc_hd__nor3b_2 U1797 ( .C_N(n3138), .A(n2640), .B(instr_rdinstr), 
        .Y(n3252) );
  sky130_fd_sc_hd__nor3b_2 U1798 ( .C_N(instr_rdcycleh), .A(n2640), .B(
        instr_rdcycle), .Y(n3253) );
  sky130_fd_sc_hd__inv_2 U1799 ( .A(cpu_state[5]), .Y(n2640) );
  sky130_fd_sc_hd__nor4_4 U1800 ( .A(instr_xor), .B(instr_xori), .C(is_compare), .D(is_lui_auipc_jal_jalr_addi_add_sub), .Y(n2829) );
  sky130_fd_sc_hd__inv_2 U1801 ( .A(n1062), .Y(n1053) );
  sky130_fd_sc_hd__inv_2 U1802 ( .A(n1062), .Y(n1055) );
  sky130_fd_sc_hd__inv_2 U1803 ( .A(n1062), .Y(n1054) );
  sky130_fd_sc_hd__inv_2 U1804 ( .A(n1062), .Y(n1061) );
  sky130_fd_sc_hd__inv_2 U1805 ( .A(n1063), .Y(n1060) );
  sky130_fd_sc_hd__inv_2 U1806 ( .A(n1062), .Y(n1056) );
  sky130_fd_sc_hd__inv_2 U1807 ( .A(n1062), .Y(n1057) );
  sky130_fd_sc_hd__inv_2 U1808 ( .A(n1063), .Y(n1059) );
  sky130_fd_sc_hd__inv_2 U1809 ( .A(n1062), .Y(n1058) );
  sky130_fd_sc_hd__inv_2 U1810 ( .A(N91), .Y(n2527) );
  sky130_fd_sc_hd__inv_2 U1811 ( .A(N86), .Y(n1795) );
  sky130_fd_sc_hd__buf_1 U1812 ( .A(clk), .X(n1047) );
  sky130_fd_sc_hd__buf_1 U1813 ( .A(clk), .X(n1049) );
  sky130_fd_sc_hd__buf_1 U1814 ( .A(clk), .X(n1050) );
  sky130_fd_sc_hd__buf_1 U1815 ( .A(clk), .X(n1048) );
  sky130_fd_sc_hd__buf_1 U1816 ( .A(clk), .X(n1051) );
  sky130_fd_sc_hd__buf_1 U1817 ( .A(clk), .X(n1046) );
  sky130_fd_sc_hd__buf_1 U1818 ( .A(clk), .X(n1052) );
  sky130_fd_sc_hd__buf_1 U1819 ( .A(clk), .X(n1043) );
  sky130_fd_sc_hd__buf_1 U1820 ( .A(clk), .X(n1044) );
  sky130_fd_sc_hd__buf_1 U1821 ( .A(clk), .X(n1045) );
  sky130_fd_sc_hd__inv_2 U1822 ( .A(N31), .Y(n1063) );
  sky130_fd_sc_hd__inv_2 U1823 ( .A(N31), .Y(n1062) );
  sky130_fd_sc_hd__inv_2 U1824 ( .A(N87), .Y(n2524) );
  sky130_fd_sc_hd__inv_2 U1825 ( .A(N88), .Y(n2525) );
  sky130_fd_sc_hd__inv_2 U1826 ( .A(N83), .Y(n1793) );
  sky130_fd_sc_hd__inv_2 U1827 ( .A(N82), .Y(n1792) );
  sky130_fd_sc_hd__inv_2 U1828 ( .A(N89), .Y(n2526) );
  sky130_fd_sc_hd__inv_2 U1829 ( .A(N84), .Y(n1794) );
  sky130_fd_sc_hd__conb_1 U1830 ( .LO(n12), .HI(n1042) );
  sky130_fd_sc_hd__nor2_1 U1831 ( .A(n1794), .B(N85), .Y(n1064) );
  sky130_fd_sc_hd__nor2_1 U1832 ( .A(n1793), .B(N82), .Y(n1071) );
  sky130_fd_sc_hd__nor2_1 U1833 ( .A(n1793), .B(n1792), .Y(n1072) );
  sky130_fd_sc_hd__a22oi_1 U1834 ( .A1(\cpuregs[6][0] ), .A2(n1765), .B1(
        \cpuregs[7][0] ), .B2(n1764), .Y(n1069) );
  sky130_fd_sc_hd__nor2_1 U1835 ( .A(N82), .B(N83), .Y(n1073) );
  sky130_fd_sc_hd__nor2_1 U1836 ( .A(n1792), .B(N83), .Y(n1074) );
  sky130_fd_sc_hd__a22oi_1 U1837 ( .A1(\cpuregs[4][0] ), .A2(n1767), .B1(
        \cpuregs[5][0] ), .B2(n1766), .Y(n1068) );
  sky130_fd_sc_hd__nor2_1 U1838 ( .A(N84), .B(N85), .Y(n1065) );
  sky130_fd_sc_hd__a22oi_1 U1839 ( .A1(\cpuregs[2][0] ), .A2(n1769), .B1(
        \cpuregs[3][0] ), .B2(n1768), .Y(n1067) );
  sky130_fd_sc_hd__a22oi_1 U1840 ( .A1(\cpuregs[0][0] ), .A2(n1771), .B1(
        \cpuregs[1][0] ), .B2(n1770), .Y(n1066) );
  sky130_fd_sc_hd__nand4_1 U1841 ( .A(n1069), .B(n1068), .C(n1067), .D(n1066), 
        .Y(n1081) );
  sky130_fd_sc_hd__and2_0 U1842 ( .A(N85), .B(N84), .X(n1070) );
  sky130_fd_sc_hd__a22oi_1 U1843 ( .A1(\cpuregs[14][0] ), .A2(n1777), .B1(
        \cpuregs[15][0] ), .B2(n1776), .Y(n1079) );
  sky130_fd_sc_hd__a22oi_1 U1844 ( .A1(\cpuregs[12][0] ), .A2(n1779), .B1(
        \cpuregs[13][0] ), .B2(n1778), .Y(n1078) );
  sky130_fd_sc_hd__and2_0 U1845 ( .A(N85), .B(n1794), .X(n1075) );
  sky130_fd_sc_hd__a22oi_1 U1846 ( .A1(\cpuregs[10][0] ), .A2(n1781), .B1(
        \cpuregs[11][0] ), .B2(n1780), .Y(n1077) );
  sky130_fd_sc_hd__a22oi_1 U1847 ( .A1(\cpuregs[8][0] ), .A2(n1783), .B1(
        \cpuregs[9][0] ), .B2(n1782), .Y(n1076) );
  sky130_fd_sc_hd__nand4_1 U1848 ( .A(n1079), .B(n1078), .C(n1077), .D(n1076), 
        .Y(n1080) );
  sky130_fd_sc_hd__o21ai_0 U1849 ( .A1(n1081), .A2(n1080), .B1(n1795), .Y(
        n1093) );
  sky130_fd_sc_hd__a22oi_1 U1850 ( .A1(\cpuregs[22][0] ), .A2(n1765), .B1(
        \cpuregs[23][0] ), .B2(n1764), .Y(n1085) );
  sky130_fd_sc_hd__a22oi_1 U1851 ( .A1(\cpuregs[20][0] ), .A2(n1767), .B1(
        \cpuregs[21][0] ), .B2(n1766), .Y(n1084) );
  sky130_fd_sc_hd__a22oi_1 U1852 ( .A1(\cpuregs[18][0] ), .A2(n1769), .B1(
        \cpuregs[19][0] ), .B2(n1768), .Y(n1083) );
  sky130_fd_sc_hd__a22oi_1 U1853 ( .A1(\cpuregs[16][0] ), .A2(n1771), .B1(
        \cpuregs[17][0] ), .B2(n1770), .Y(n1082) );
  sky130_fd_sc_hd__nand4_1 U1854 ( .A(n1085), .B(n1084), .C(n1083), .D(n1082), 
        .Y(n1091) );
  sky130_fd_sc_hd__a22oi_1 U1855 ( .A1(\cpuregs[30][0] ), .A2(n1777), .B1(
        \cpuregs[31][0] ), .B2(n1776), .Y(n1089) );
  sky130_fd_sc_hd__a22oi_1 U1856 ( .A1(\cpuregs[28][0] ), .A2(n1779), .B1(
        \cpuregs[29][0] ), .B2(n1778), .Y(n1088) );
  sky130_fd_sc_hd__a22oi_1 U1857 ( .A1(\cpuregs[26][0] ), .A2(n1781), .B1(
        \cpuregs[27][0] ), .B2(n1780), .Y(n1087) );
  sky130_fd_sc_hd__a22oi_1 U1858 ( .A1(\cpuregs[24][0] ), .A2(n1783), .B1(
        \cpuregs[25][0] ), .B2(n1782), .Y(n1086) );
  sky130_fd_sc_hd__nand4_1 U1859 ( .A(n1089), .B(n1088), .C(n1087), .D(n1086), 
        .Y(n1090) );
  sky130_fd_sc_hd__o21ai_0 U1860 ( .A1(n1091), .A2(n1090), .B1(N86), .Y(n1092)
         );
  sky130_fd_sc_hd__nand2_1 U1861 ( .A(n1093), .B(n1092), .Y(N783) );
  sky130_fd_sc_hd__a22oi_1 U1862 ( .A1(\cpuregs[6][1] ), .A2(n1765), .B1(
        \cpuregs[7][1] ), .B2(n1764), .Y(n1097) );
  sky130_fd_sc_hd__a22oi_1 U1863 ( .A1(\cpuregs[4][1] ), .A2(n1767), .B1(
        \cpuregs[5][1] ), .B2(n1766), .Y(n1096) );
  sky130_fd_sc_hd__a22oi_1 U1864 ( .A1(\cpuregs[2][1] ), .A2(n1769), .B1(
        \cpuregs[3][1] ), .B2(n1768), .Y(n1095) );
  sky130_fd_sc_hd__a22oi_1 U1865 ( .A1(\cpuregs[0][1] ), .A2(n1771), .B1(
        \cpuregs[1][1] ), .B2(n1770), .Y(n1094) );
  sky130_fd_sc_hd__nand4_1 U1866 ( .A(n1097), .B(n1096), .C(n1095), .D(n1094), 
        .Y(n1103) );
  sky130_fd_sc_hd__a22oi_1 U1867 ( .A1(\cpuregs[14][1] ), .A2(n1777), .B1(
        \cpuregs[15][1] ), .B2(n1776), .Y(n1101) );
  sky130_fd_sc_hd__a22oi_1 U1868 ( .A1(\cpuregs[12][1] ), .A2(n1779), .B1(
        \cpuregs[13][1] ), .B2(n1778), .Y(n1100) );
  sky130_fd_sc_hd__a22oi_1 U1869 ( .A1(\cpuregs[10][1] ), .A2(n1781), .B1(
        \cpuregs[11][1] ), .B2(n1780), .Y(n1099) );
  sky130_fd_sc_hd__a22oi_1 U1870 ( .A1(\cpuregs[8][1] ), .A2(n1783), .B1(
        \cpuregs[9][1] ), .B2(n1782), .Y(n1098) );
  sky130_fd_sc_hd__nand4_1 U1871 ( .A(n1101), .B(n1100), .C(n1099), .D(n1098), 
        .Y(n1102) );
  sky130_fd_sc_hd__o21ai_0 U1872 ( .A1(n1103), .A2(n1102), .B1(n1795), .Y(
        n1115) );
  sky130_fd_sc_hd__a22oi_1 U1873 ( .A1(\cpuregs[22][1] ), .A2(n1765), .B1(
        \cpuregs[23][1] ), .B2(n1764), .Y(n1107) );
  sky130_fd_sc_hd__a22oi_1 U1874 ( .A1(\cpuregs[20][1] ), .A2(n1767), .B1(
        \cpuregs[21][1] ), .B2(n1766), .Y(n1106) );
  sky130_fd_sc_hd__a22oi_1 U1875 ( .A1(\cpuregs[18][1] ), .A2(n1769), .B1(
        \cpuregs[19][1] ), .B2(n1768), .Y(n1105) );
  sky130_fd_sc_hd__a22oi_1 U1876 ( .A1(\cpuregs[16][1] ), .A2(n1771), .B1(
        \cpuregs[17][1] ), .B2(n1770), .Y(n1104) );
  sky130_fd_sc_hd__nand4_1 U1877 ( .A(n1107), .B(n1106), .C(n1105), .D(n1104), 
        .Y(n1113) );
  sky130_fd_sc_hd__a22oi_1 U1878 ( .A1(\cpuregs[30][1] ), .A2(n1777), .B1(
        \cpuregs[31][1] ), .B2(n1776), .Y(n1111) );
  sky130_fd_sc_hd__a22oi_1 U1879 ( .A1(\cpuregs[28][1] ), .A2(n1779), .B1(
        \cpuregs[29][1] ), .B2(n1778), .Y(n1110) );
  sky130_fd_sc_hd__a22oi_1 U1880 ( .A1(\cpuregs[26][1] ), .A2(n1781), .B1(
        \cpuregs[27][1] ), .B2(n1780), .Y(n1109) );
  sky130_fd_sc_hd__a22oi_1 U1881 ( .A1(\cpuregs[24][1] ), .A2(n1783), .B1(
        \cpuregs[25][1] ), .B2(n1782), .Y(n1108) );
  sky130_fd_sc_hd__nand4_1 U1882 ( .A(n1111), .B(n1110), .C(n1109), .D(n1108), 
        .Y(n1112) );
  sky130_fd_sc_hd__o21ai_0 U1883 ( .A1(n1113), .A2(n1112), .B1(N86), .Y(n1114)
         );
  sky130_fd_sc_hd__nand2_1 U1884 ( .A(n1115), .B(n1114), .Y(N782) );
  sky130_fd_sc_hd__a22oi_1 U1885 ( .A1(\cpuregs[6][2] ), .A2(n1765), .B1(
        \cpuregs[7][2] ), .B2(n1764), .Y(n1119) );
  sky130_fd_sc_hd__a22oi_1 U1886 ( .A1(\cpuregs[4][2] ), .A2(n1767), .B1(
        \cpuregs[5][2] ), .B2(n1766), .Y(n1118) );
  sky130_fd_sc_hd__a22oi_1 U1887 ( .A1(\cpuregs[2][2] ), .A2(n1769), .B1(
        \cpuregs[3][2] ), .B2(n1768), .Y(n1117) );
  sky130_fd_sc_hd__a22oi_1 U1888 ( .A1(\cpuregs[0][2] ), .A2(n1771), .B1(
        \cpuregs[1][2] ), .B2(n1770), .Y(n1116) );
  sky130_fd_sc_hd__nand4_1 U1889 ( .A(n1119), .B(n1118), .C(n1117), .D(n1116), 
        .Y(n1125) );
  sky130_fd_sc_hd__a22oi_1 U1890 ( .A1(\cpuregs[14][2] ), .A2(n1777), .B1(
        \cpuregs[15][2] ), .B2(n1776), .Y(n1123) );
  sky130_fd_sc_hd__a22oi_1 U1891 ( .A1(\cpuregs[12][2] ), .A2(n1779), .B1(
        \cpuregs[13][2] ), .B2(n1778), .Y(n1122) );
  sky130_fd_sc_hd__a22oi_1 U1892 ( .A1(\cpuregs[10][2] ), .A2(n1781), .B1(
        \cpuregs[11][2] ), .B2(n1780), .Y(n1121) );
  sky130_fd_sc_hd__a22oi_1 U1893 ( .A1(\cpuregs[8][2] ), .A2(n1783), .B1(
        \cpuregs[9][2] ), .B2(n1782), .Y(n1120) );
  sky130_fd_sc_hd__nand4_1 U1894 ( .A(n1123), .B(n1122), .C(n1121), .D(n1120), 
        .Y(n1124) );
  sky130_fd_sc_hd__o21ai_0 U1895 ( .A1(n1125), .A2(n1124), .B1(n1795), .Y(
        n1137) );
  sky130_fd_sc_hd__a22oi_1 U1896 ( .A1(\cpuregs[22][2] ), .A2(n1765), .B1(
        \cpuregs[23][2] ), .B2(n1764), .Y(n1129) );
  sky130_fd_sc_hd__a22oi_1 U1897 ( .A1(\cpuregs[20][2] ), .A2(n1767), .B1(
        \cpuregs[21][2] ), .B2(n1766), .Y(n1128) );
  sky130_fd_sc_hd__a22oi_1 U1898 ( .A1(\cpuregs[18][2] ), .A2(n1769), .B1(
        \cpuregs[19][2] ), .B2(n1768), .Y(n1127) );
  sky130_fd_sc_hd__a22oi_1 U1899 ( .A1(\cpuregs[16][2] ), .A2(n1771), .B1(
        \cpuregs[17][2] ), .B2(n1770), .Y(n1126) );
  sky130_fd_sc_hd__nand4_1 U1900 ( .A(n1129), .B(n1128), .C(n1127), .D(n1126), 
        .Y(n1135) );
  sky130_fd_sc_hd__a22oi_1 U1901 ( .A1(\cpuregs[30][2] ), .A2(n1777), .B1(
        \cpuregs[31][2] ), .B2(n1776), .Y(n1133) );
  sky130_fd_sc_hd__a22oi_1 U1902 ( .A1(\cpuregs[28][2] ), .A2(n1779), .B1(
        \cpuregs[29][2] ), .B2(n1778), .Y(n1132) );
  sky130_fd_sc_hd__a22oi_1 U1903 ( .A1(\cpuregs[26][2] ), .A2(n1781), .B1(
        \cpuregs[27][2] ), .B2(n1780), .Y(n1131) );
  sky130_fd_sc_hd__a22oi_1 U1904 ( .A1(\cpuregs[24][2] ), .A2(n1783), .B1(
        \cpuregs[25][2] ), .B2(n1782), .Y(n1130) );
  sky130_fd_sc_hd__nand4_1 U1905 ( .A(n1133), .B(n1132), .C(n1131), .D(n1130), 
        .Y(n1134) );
  sky130_fd_sc_hd__o21ai_0 U1906 ( .A1(n1135), .A2(n1134), .B1(N86), .Y(n1136)
         );
  sky130_fd_sc_hd__nand2_1 U1907 ( .A(n1137), .B(n1136), .Y(N781) );
  sky130_fd_sc_hd__a22oi_1 U1908 ( .A1(\cpuregs[6][3] ), .A2(n1765), .B1(
        \cpuregs[7][3] ), .B2(n1764), .Y(n1141) );
  sky130_fd_sc_hd__a22oi_1 U1909 ( .A1(\cpuregs[4][3] ), .A2(n1767), .B1(
        \cpuregs[5][3] ), .B2(n1766), .Y(n1140) );
  sky130_fd_sc_hd__a22oi_1 U1910 ( .A1(\cpuregs[2][3] ), .A2(n1769), .B1(
        \cpuregs[3][3] ), .B2(n1768), .Y(n1139) );
  sky130_fd_sc_hd__a22oi_1 U1911 ( .A1(\cpuregs[0][3] ), .A2(n1771), .B1(
        \cpuregs[1][3] ), .B2(n1770), .Y(n1138) );
  sky130_fd_sc_hd__nand4_1 U1912 ( .A(n1141), .B(n1140), .C(n1139), .D(n1138), 
        .Y(n1147) );
  sky130_fd_sc_hd__a22oi_1 U1913 ( .A1(\cpuregs[14][3] ), .A2(n1777), .B1(
        \cpuregs[15][3] ), .B2(n1776), .Y(n1145) );
  sky130_fd_sc_hd__a22oi_1 U1914 ( .A1(\cpuregs[12][3] ), .A2(n1779), .B1(
        \cpuregs[13][3] ), .B2(n1778), .Y(n1144) );
  sky130_fd_sc_hd__a22oi_1 U1915 ( .A1(\cpuregs[10][3] ), .A2(n1781), .B1(
        \cpuregs[11][3] ), .B2(n1780), .Y(n1143) );
  sky130_fd_sc_hd__a22oi_1 U1916 ( .A1(\cpuregs[8][3] ), .A2(n1783), .B1(
        \cpuregs[9][3] ), .B2(n1782), .Y(n1142) );
  sky130_fd_sc_hd__nand4_1 U1917 ( .A(n1145), .B(n1144), .C(n1143), .D(n1142), 
        .Y(n1146) );
  sky130_fd_sc_hd__o21ai_0 U1918 ( .A1(n1147), .A2(n1146), .B1(n1795), .Y(
        n1159) );
  sky130_fd_sc_hd__a22oi_1 U1919 ( .A1(\cpuregs[22][3] ), .A2(n1765), .B1(
        \cpuregs[23][3] ), .B2(n1764), .Y(n1151) );
  sky130_fd_sc_hd__a22oi_1 U1920 ( .A1(\cpuregs[20][3] ), .A2(n1767), .B1(
        \cpuregs[21][3] ), .B2(n1766), .Y(n1150) );
  sky130_fd_sc_hd__a22oi_1 U1921 ( .A1(\cpuregs[18][3] ), .A2(n1769), .B1(
        \cpuregs[19][3] ), .B2(n1768), .Y(n1149) );
  sky130_fd_sc_hd__a22oi_1 U1922 ( .A1(\cpuregs[16][3] ), .A2(n1771), .B1(
        \cpuregs[17][3] ), .B2(n1770), .Y(n1148) );
  sky130_fd_sc_hd__nand4_1 U1923 ( .A(n1151), .B(n1150), .C(n1149), .D(n1148), 
        .Y(n1157) );
  sky130_fd_sc_hd__a22oi_1 U1924 ( .A1(\cpuregs[30][3] ), .A2(n1777), .B1(
        \cpuregs[31][3] ), .B2(n1776), .Y(n1155) );
  sky130_fd_sc_hd__a22oi_1 U1925 ( .A1(\cpuregs[28][3] ), .A2(n1779), .B1(
        \cpuregs[29][3] ), .B2(n1778), .Y(n1154) );
  sky130_fd_sc_hd__a22oi_1 U1926 ( .A1(\cpuregs[26][3] ), .A2(n1781), .B1(
        \cpuregs[27][3] ), .B2(n1780), .Y(n1153) );
  sky130_fd_sc_hd__a22oi_1 U1927 ( .A1(\cpuregs[24][3] ), .A2(n1783), .B1(
        \cpuregs[25][3] ), .B2(n1782), .Y(n1152) );
  sky130_fd_sc_hd__nand4_1 U1928 ( .A(n1155), .B(n1154), .C(n1153), .D(n1152), 
        .Y(n1156) );
  sky130_fd_sc_hd__o21ai_0 U1929 ( .A1(n1157), .A2(n1156), .B1(N86), .Y(n1158)
         );
  sky130_fd_sc_hd__nand2_1 U1930 ( .A(n1159), .B(n1158), .Y(N780) );
  sky130_fd_sc_hd__a22oi_1 U1931 ( .A1(\cpuregs[6][4] ), .A2(n1765), .B1(
        \cpuregs[7][4] ), .B2(n1764), .Y(n1163) );
  sky130_fd_sc_hd__a22oi_1 U1932 ( .A1(\cpuregs[4][4] ), .A2(n1767), .B1(
        \cpuregs[5][4] ), .B2(n1766), .Y(n1162) );
  sky130_fd_sc_hd__a22oi_1 U1933 ( .A1(\cpuregs[2][4] ), .A2(n1769), .B1(
        \cpuregs[3][4] ), .B2(n1768), .Y(n1161) );
  sky130_fd_sc_hd__a22oi_1 U1934 ( .A1(\cpuregs[0][4] ), .A2(n1771), .B1(
        \cpuregs[1][4] ), .B2(n1770), .Y(n1160) );
  sky130_fd_sc_hd__nand4_1 U1935 ( .A(n1163), .B(n1162), .C(n1161), .D(n1160), 
        .Y(n1169) );
  sky130_fd_sc_hd__a22oi_1 U1936 ( .A1(\cpuregs[14][4] ), .A2(n1777), .B1(
        \cpuregs[15][4] ), .B2(n1776), .Y(n1167) );
  sky130_fd_sc_hd__a22oi_1 U1937 ( .A1(\cpuregs[12][4] ), .A2(n1779), .B1(
        \cpuregs[13][4] ), .B2(n1778), .Y(n1166) );
  sky130_fd_sc_hd__a22oi_1 U1938 ( .A1(\cpuregs[10][4] ), .A2(n1781), .B1(
        \cpuregs[11][4] ), .B2(n1780), .Y(n1165) );
  sky130_fd_sc_hd__a22oi_1 U1939 ( .A1(\cpuregs[8][4] ), .A2(n1783), .B1(
        \cpuregs[9][4] ), .B2(n1782), .Y(n1164) );
  sky130_fd_sc_hd__nand4_1 U1940 ( .A(n1167), .B(n1166), .C(n1165), .D(n1164), 
        .Y(n1168) );
  sky130_fd_sc_hd__o21ai_0 U1941 ( .A1(n1169), .A2(n1168), .B1(n1795), .Y(
        n1181) );
  sky130_fd_sc_hd__a22oi_1 U1942 ( .A1(\cpuregs[22][4] ), .A2(n1765), .B1(
        \cpuregs[23][4] ), .B2(n1764), .Y(n1173) );
  sky130_fd_sc_hd__a22oi_1 U1943 ( .A1(\cpuregs[20][4] ), .A2(n1767), .B1(
        \cpuregs[21][4] ), .B2(n1766), .Y(n1172) );
  sky130_fd_sc_hd__a22oi_1 U1944 ( .A1(\cpuregs[18][4] ), .A2(n1769), .B1(
        \cpuregs[19][4] ), .B2(n1768), .Y(n1171) );
  sky130_fd_sc_hd__a22oi_1 U1945 ( .A1(\cpuregs[16][4] ), .A2(n1771), .B1(
        \cpuregs[17][4] ), .B2(n1770), .Y(n1170) );
  sky130_fd_sc_hd__nand4_1 U1946 ( .A(n1173), .B(n1172), .C(n1171), .D(n1170), 
        .Y(n1179) );
  sky130_fd_sc_hd__a22oi_1 U1947 ( .A1(\cpuregs[30][4] ), .A2(n1777), .B1(
        \cpuregs[31][4] ), .B2(n1776), .Y(n1177) );
  sky130_fd_sc_hd__a22oi_1 U1948 ( .A1(\cpuregs[28][4] ), .A2(n1779), .B1(
        \cpuregs[29][4] ), .B2(n1778), .Y(n1176) );
  sky130_fd_sc_hd__a22oi_1 U1949 ( .A1(\cpuregs[26][4] ), .A2(n1781), .B1(
        \cpuregs[27][4] ), .B2(n1780), .Y(n1175) );
  sky130_fd_sc_hd__a22oi_1 U1950 ( .A1(\cpuregs[24][4] ), .A2(n1783), .B1(
        \cpuregs[25][4] ), .B2(n1782), .Y(n1174) );
  sky130_fd_sc_hd__nand4_1 U1951 ( .A(n1177), .B(n1176), .C(n1175), .D(n1174), 
        .Y(n1178) );
  sky130_fd_sc_hd__o21ai_0 U1952 ( .A1(n1179), .A2(n1178), .B1(N86), .Y(n1180)
         );
  sky130_fd_sc_hd__nand2_1 U1953 ( .A(n1181), .B(n1180), .Y(N779) );
  sky130_fd_sc_hd__a22oi_1 U1954 ( .A1(\cpuregs[6][5] ), .A2(n1765), .B1(
        \cpuregs[7][5] ), .B2(n1764), .Y(n1185) );
  sky130_fd_sc_hd__a22oi_1 U1955 ( .A1(\cpuregs[4][5] ), .A2(n1767), .B1(
        \cpuregs[5][5] ), .B2(n1766), .Y(n1184) );
  sky130_fd_sc_hd__a22oi_1 U1956 ( .A1(\cpuregs[2][5] ), .A2(n1769), .B1(
        \cpuregs[3][5] ), .B2(n1768), .Y(n1183) );
  sky130_fd_sc_hd__a22oi_1 U1957 ( .A1(\cpuregs[0][5] ), .A2(n1771), .B1(
        \cpuregs[1][5] ), .B2(n1770), .Y(n1182) );
  sky130_fd_sc_hd__nand4_1 U1958 ( .A(n1185), .B(n1184), .C(n1183), .D(n1182), 
        .Y(n1191) );
  sky130_fd_sc_hd__a22oi_1 U1959 ( .A1(\cpuregs[14][5] ), .A2(n1777), .B1(
        \cpuregs[15][5] ), .B2(n1776), .Y(n1189) );
  sky130_fd_sc_hd__a22oi_1 U1960 ( .A1(\cpuregs[12][5] ), .A2(n1779), .B1(
        \cpuregs[13][5] ), .B2(n1778), .Y(n1188) );
  sky130_fd_sc_hd__a22oi_1 U1961 ( .A1(\cpuregs[10][5] ), .A2(n1781), .B1(
        \cpuregs[11][5] ), .B2(n1780), .Y(n1187) );
  sky130_fd_sc_hd__a22oi_1 U1962 ( .A1(\cpuregs[8][5] ), .A2(n1783), .B1(
        \cpuregs[9][5] ), .B2(n1782), .Y(n1186) );
  sky130_fd_sc_hd__nand4_1 U1963 ( .A(n1189), .B(n1188), .C(n1187), .D(n1186), 
        .Y(n1190) );
  sky130_fd_sc_hd__o21ai_0 U1964 ( .A1(n1191), .A2(n1190), .B1(n1795), .Y(
        n1203) );
  sky130_fd_sc_hd__a22oi_1 U1965 ( .A1(\cpuregs[22][5] ), .A2(n1765), .B1(
        \cpuregs[23][5] ), .B2(n1764), .Y(n1195) );
  sky130_fd_sc_hd__a22oi_1 U1966 ( .A1(\cpuregs[20][5] ), .A2(n1767), .B1(
        \cpuregs[21][5] ), .B2(n1766), .Y(n1194) );
  sky130_fd_sc_hd__a22oi_1 U1967 ( .A1(\cpuregs[18][5] ), .A2(n1769), .B1(
        \cpuregs[19][5] ), .B2(n1768), .Y(n1193) );
  sky130_fd_sc_hd__a22oi_1 U1968 ( .A1(\cpuregs[16][5] ), .A2(n1771), .B1(
        \cpuregs[17][5] ), .B2(n1770), .Y(n1192) );
  sky130_fd_sc_hd__nand4_1 U1969 ( .A(n1195), .B(n1194), .C(n1193), .D(n1192), 
        .Y(n1201) );
  sky130_fd_sc_hd__a22oi_1 U1970 ( .A1(\cpuregs[30][5] ), .A2(n1777), .B1(
        \cpuregs[31][5] ), .B2(n1776), .Y(n1199) );
  sky130_fd_sc_hd__a22oi_1 U1971 ( .A1(\cpuregs[28][5] ), .A2(n1779), .B1(
        \cpuregs[29][5] ), .B2(n1778), .Y(n1198) );
  sky130_fd_sc_hd__a22oi_1 U1972 ( .A1(\cpuregs[26][5] ), .A2(n1781), .B1(
        \cpuregs[27][5] ), .B2(n1780), .Y(n1197) );
  sky130_fd_sc_hd__a22oi_1 U1973 ( .A1(\cpuregs[24][5] ), .A2(n1783), .B1(
        \cpuregs[25][5] ), .B2(n1782), .Y(n1196) );
  sky130_fd_sc_hd__nand4_1 U1974 ( .A(n1199), .B(n1198), .C(n1197), .D(n1196), 
        .Y(n1200) );
  sky130_fd_sc_hd__o21ai_0 U1975 ( .A1(n1201), .A2(n1200), .B1(N86), .Y(n1202)
         );
  sky130_fd_sc_hd__nand2_1 U1976 ( .A(n1203), .B(n1202), .Y(N778) );
  sky130_fd_sc_hd__a22oi_1 U1977 ( .A1(\cpuregs[6][6] ), .A2(n1765), .B1(
        \cpuregs[7][6] ), .B2(n1764), .Y(n1207) );
  sky130_fd_sc_hd__a22oi_1 U1978 ( .A1(\cpuregs[4][6] ), .A2(n1767), .B1(
        \cpuregs[5][6] ), .B2(n1766), .Y(n1206) );
  sky130_fd_sc_hd__a22oi_1 U1979 ( .A1(\cpuregs[2][6] ), .A2(n1769), .B1(
        \cpuregs[3][6] ), .B2(n1768), .Y(n1205) );
  sky130_fd_sc_hd__a22oi_1 U1980 ( .A1(\cpuregs[0][6] ), .A2(n1771), .B1(
        \cpuregs[1][6] ), .B2(n1770), .Y(n1204) );
  sky130_fd_sc_hd__nand4_1 U1981 ( .A(n1207), .B(n1206), .C(n1205), .D(n1204), 
        .Y(n1213) );
  sky130_fd_sc_hd__a22oi_1 U1982 ( .A1(\cpuregs[14][6] ), .A2(n1777), .B1(
        \cpuregs[15][6] ), .B2(n1776), .Y(n1211) );
  sky130_fd_sc_hd__a22oi_1 U1983 ( .A1(\cpuregs[12][6] ), .A2(n1779), .B1(
        \cpuregs[13][6] ), .B2(n1778), .Y(n1210) );
  sky130_fd_sc_hd__a22oi_1 U1984 ( .A1(\cpuregs[10][6] ), .A2(n1781), .B1(
        \cpuregs[11][6] ), .B2(n1780), .Y(n1209) );
  sky130_fd_sc_hd__a22oi_1 U1985 ( .A1(\cpuregs[8][6] ), .A2(n1783), .B1(
        \cpuregs[9][6] ), .B2(n1782), .Y(n1208) );
  sky130_fd_sc_hd__nand4_1 U1986 ( .A(n1211), .B(n1210), .C(n1209), .D(n1208), 
        .Y(n1212) );
  sky130_fd_sc_hd__o21ai_0 U1987 ( .A1(n1213), .A2(n1212), .B1(n1795), .Y(
        n1225) );
  sky130_fd_sc_hd__a22oi_1 U1988 ( .A1(\cpuregs[22][6] ), .A2(n1765), .B1(
        \cpuregs[23][6] ), .B2(n1764), .Y(n1217) );
  sky130_fd_sc_hd__a22oi_1 U1989 ( .A1(\cpuregs[20][6] ), .A2(n1767), .B1(
        \cpuregs[21][6] ), .B2(n1766), .Y(n1216) );
  sky130_fd_sc_hd__a22oi_1 U1990 ( .A1(\cpuregs[18][6] ), .A2(n1769), .B1(
        \cpuregs[19][6] ), .B2(n1768), .Y(n1215) );
  sky130_fd_sc_hd__a22oi_1 U1991 ( .A1(\cpuregs[16][6] ), .A2(n1771), .B1(
        \cpuregs[17][6] ), .B2(n1770), .Y(n1214) );
  sky130_fd_sc_hd__nand4_1 U1992 ( .A(n1217), .B(n1216), .C(n1215), .D(n1214), 
        .Y(n1223) );
  sky130_fd_sc_hd__a22oi_1 U1993 ( .A1(\cpuregs[30][6] ), .A2(n1777), .B1(
        \cpuregs[31][6] ), .B2(n1776), .Y(n1221) );
  sky130_fd_sc_hd__a22oi_1 U1994 ( .A1(\cpuregs[28][6] ), .A2(n1779), .B1(
        \cpuregs[29][6] ), .B2(n1778), .Y(n1220) );
  sky130_fd_sc_hd__a22oi_1 U1995 ( .A1(\cpuregs[26][6] ), .A2(n1781), .B1(
        \cpuregs[27][6] ), .B2(n1780), .Y(n1219) );
  sky130_fd_sc_hd__a22oi_1 U1996 ( .A1(\cpuregs[24][6] ), .A2(n1783), .B1(
        \cpuregs[25][6] ), .B2(n1782), .Y(n1218) );
  sky130_fd_sc_hd__nand4_1 U1997 ( .A(n1221), .B(n1220), .C(n1219), .D(n1218), 
        .Y(n1222) );
  sky130_fd_sc_hd__o21ai_0 U1998 ( .A1(n1223), .A2(n1222), .B1(N86), .Y(n1224)
         );
  sky130_fd_sc_hd__nand2_1 U1999 ( .A(n1225), .B(n1224), .Y(N777) );
  sky130_fd_sc_hd__a22oi_1 U2000 ( .A1(\cpuregs[6][7] ), .A2(n1765), .B1(
        \cpuregs[7][7] ), .B2(n1764), .Y(n1229) );
  sky130_fd_sc_hd__a22oi_1 U2001 ( .A1(\cpuregs[4][7] ), .A2(n1767), .B1(
        \cpuregs[5][7] ), .B2(n1766), .Y(n1228) );
  sky130_fd_sc_hd__a22oi_1 U2002 ( .A1(\cpuregs[2][7] ), .A2(n1769), .B1(
        \cpuregs[3][7] ), .B2(n1768), .Y(n1227) );
  sky130_fd_sc_hd__a22oi_1 U2003 ( .A1(\cpuregs[0][7] ), .A2(n1771), .B1(
        \cpuregs[1][7] ), .B2(n1770), .Y(n1226) );
  sky130_fd_sc_hd__nand4_1 U2004 ( .A(n1229), .B(n1228), .C(n1227), .D(n1226), 
        .Y(n1235) );
  sky130_fd_sc_hd__a22oi_1 U2005 ( .A1(\cpuregs[14][7] ), .A2(n1777), .B1(
        \cpuregs[15][7] ), .B2(n1776), .Y(n1233) );
  sky130_fd_sc_hd__a22oi_1 U2006 ( .A1(\cpuregs[12][7] ), .A2(n1779), .B1(
        \cpuregs[13][7] ), .B2(n1778), .Y(n1232) );
  sky130_fd_sc_hd__a22oi_1 U2007 ( .A1(\cpuregs[10][7] ), .A2(n1781), .B1(
        \cpuregs[11][7] ), .B2(n1780), .Y(n1231) );
  sky130_fd_sc_hd__a22oi_1 U2008 ( .A1(\cpuregs[8][7] ), .A2(n1783), .B1(
        \cpuregs[9][7] ), .B2(n1782), .Y(n1230) );
  sky130_fd_sc_hd__nand4_1 U2009 ( .A(n1233), .B(n1232), .C(n1231), .D(n1230), 
        .Y(n1234) );
  sky130_fd_sc_hd__o21ai_0 U2010 ( .A1(n1235), .A2(n1234), .B1(n1795), .Y(
        n1247) );
  sky130_fd_sc_hd__a22oi_1 U2011 ( .A1(\cpuregs[22][7] ), .A2(n1765), .B1(
        \cpuregs[23][7] ), .B2(n1764), .Y(n1239) );
  sky130_fd_sc_hd__a22oi_1 U2012 ( .A1(\cpuregs[20][7] ), .A2(n1767), .B1(
        \cpuregs[21][7] ), .B2(n1766), .Y(n1238) );
  sky130_fd_sc_hd__a22oi_1 U2013 ( .A1(\cpuregs[18][7] ), .A2(n1769), .B1(
        \cpuregs[19][7] ), .B2(n1768), .Y(n1237) );
  sky130_fd_sc_hd__a22oi_1 U2014 ( .A1(\cpuregs[16][7] ), .A2(n1771), .B1(
        \cpuregs[17][7] ), .B2(n1770), .Y(n1236) );
  sky130_fd_sc_hd__nand4_1 U2015 ( .A(n1239), .B(n1238), .C(n1237), .D(n1236), 
        .Y(n1245) );
  sky130_fd_sc_hd__a22oi_1 U2016 ( .A1(\cpuregs[30][7] ), .A2(n1777), .B1(
        \cpuregs[31][7] ), .B2(n1776), .Y(n1243) );
  sky130_fd_sc_hd__a22oi_1 U2017 ( .A1(\cpuregs[28][7] ), .A2(n1779), .B1(
        \cpuregs[29][7] ), .B2(n1778), .Y(n1242) );
  sky130_fd_sc_hd__a22oi_1 U2018 ( .A1(\cpuregs[26][7] ), .A2(n1781), .B1(
        \cpuregs[27][7] ), .B2(n1780), .Y(n1241) );
  sky130_fd_sc_hd__a22oi_1 U2019 ( .A1(\cpuregs[24][7] ), .A2(n1783), .B1(
        \cpuregs[25][7] ), .B2(n1782), .Y(n1240) );
  sky130_fd_sc_hd__nand4_1 U2020 ( .A(n1243), .B(n1242), .C(n1241), .D(n1240), 
        .Y(n1244) );
  sky130_fd_sc_hd__o21ai_0 U2021 ( .A1(n1245), .A2(n1244), .B1(N86), .Y(n1246)
         );
  sky130_fd_sc_hd__nand2_1 U2022 ( .A(n1247), .B(n1246), .Y(N776) );
  sky130_fd_sc_hd__a22oi_1 U2023 ( .A1(\cpuregs[6][8] ), .A2(n1765), .B1(
        \cpuregs[7][8] ), .B2(n1764), .Y(n1251) );
  sky130_fd_sc_hd__a22oi_1 U2024 ( .A1(\cpuregs[4][8] ), .A2(n1767), .B1(
        \cpuregs[5][8] ), .B2(n1766), .Y(n1250) );
  sky130_fd_sc_hd__a22oi_1 U2025 ( .A1(\cpuregs[2][8] ), .A2(n1769), .B1(
        \cpuregs[3][8] ), .B2(n1768), .Y(n1249) );
  sky130_fd_sc_hd__a22oi_1 U2026 ( .A1(\cpuregs[0][8] ), .A2(n1771), .B1(
        \cpuregs[1][8] ), .B2(n1770), .Y(n1248) );
  sky130_fd_sc_hd__nand4_1 U2027 ( .A(n1251), .B(n1250), .C(n1249), .D(n1248), 
        .Y(n1257) );
  sky130_fd_sc_hd__a22oi_1 U2028 ( .A1(\cpuregs[14][8] ), .A2(n1777), .B1(
        \cpuregs[15][8] ), .B2(n1776), .Y(n1255) );
  sky130_fd_sc_hd__a22oi_1 U2029 ( .A1(\cpuregs[12][8] ), .A2(n1779), .B1(
        \cpuregs[13][8] ), .B2(n1778), .Y(n1254) );
  sky130_fd_sc_hd__a22oi_1 U2030 ( .A1(\cpuregs[10][8] ), .A2(n1781), .B1(
        \cpuregs[11][8] ), .B2(n1780), .Y(n1253) );
  sky130_fd_sc_hd__a22oi_1 U2031 ( .A1(\cpuregs[8][8] ), .A2(n1783), .B1(
        \cpuregs[9][8] ), .B2(n1782), .Y(n1252) );
  sky130_fd_sc_hd__nand4_1 U2032 ( .A(n1255), .B(n1254), .C(n1253), .D(n1252), 
        .Y(n1256) );
  sky130_fd_sc_hd__o21ai_0 U2033 ( .A1(n1257), .A2(n1256), .B1(n1795), .Y(
        n1269) );
  sky130_fd_sc_hd__a22oi_1 U2034 ( .A1(\cpuregs[22][8] ), .A2(n1765), .B1(
        \cpuregs[23][8] ), .B2(n1764), .Y(n1261) );
  sky130_fd_sc_hd__a22oi_1 U2035 ( .A1(\cpuregs[20][8] ), .A2(n1767), .B1(
        \cpuregs[21][8] ), .B2(n1766), .Y(n1260) );
  sky130_fd_sc_hd__a22oi_1 U2036 ( .A1(\cpuregs[18][8] ), .A2(n1769), .B1(
        \cpuregs[19][8] ), .B2(n1768), .Y(n1259) );
  sky130_fd_sc_hd__a22oi_1 U2037 ( .A1(\cpuregs[16][8] ), .A2(n1771), .B1(
        \cpuregs[17][8] ), .B2(n1770), .Y(n1258) );
  sky130_fd_sc_hd__nand4_1 U2038 ( .A(n1261), .B(n1260), .C(n1259), .D(n1258), 
        .Y(n1267) );
  sky130_fd_sc_hd__a22oi_1 U2039 ( .A1(\cpuregs[30][8] ), .A2(n1777), .B1(
        \cpuregs[31][8] ), .B2(n1776), .Y(n1265) );
  sky130_fd_sc_hd__a22oi_1 U2040 ( .A1(\cpuregs[28][8] ), .A2(n1779), .B1(
        \cpuregs[29][8] ), .B2(n1778), .Y(n1264) );
  sky130_fd_sc_hd__a22oi_1 U2041 ( .A1(\cpuregs[26][8] ), .A2(n1781), .B1(
        \cpuregs[27][8] ), .B2(n1780), .Y(n1263) );
  sky130_fd_sc_hd__a22oi_1 U2042 ( .A1(\cpuregs[24][8] ), .A2(n1783), .B1(
        \cpuregs[25][8] ), .B2(n1782), .Y(n1262) );
  sky130_fd_sc_hd__nand4_1 U2043 ( .A(n1265), .B(n1264), .C(n1263), .D(n1262), 
        .Y(n1266) );
  sky130_fd_sc_hd__o21ai_0 U2044 ( .A1(n1267), .A2(n1266), .B1(N86), .Y(n1268)
         );
  sky130_fd_sc_hd__nand2_1 U2045 ( .A(n1269), .B(n1268), .Y(N775) );
  sky130_fd_sc_hd__a22oi_1 U2046 ( .A1(\cpuregs[6][9] ), .A2(n1765), .B1(
        \cpuregs[7][9] ), .B2(n1764), .Y(n1273) );
  sky130_fd_sc_hd__a22oi_1 U2047 ( .A1(\cpuregs[4][9] ), .A2(n1767), .B1(
        \cpuregs[5][9] ), .B2(n1766), .Y(n1272) );
  sky130_fd_sc_hd__a22oi_1 U2048 ( .A1(\cpuregs[2][9] ), .A2(n1769), .B1(
        \cpuregs[3][9] ), .B2(n1768), .Y(n1271) );
  sky130_fd_sc_hd__a22oi_1 U2049 ( .A1(\cpuregs[0][9] ), .A2(n1771), .B1(
        \cpuregs[1][9] ), .B2(n1770), .Y(n1270) );
  sky130_fd_sc_hd__nand4_1 U2050 ( .A(n1273), .B(n1272), .C(n1271), .D(n1270), 
        .Y(n1279) );
  sky130_fd_sc_hd__a22oi_1 U2051 ( .A1(\cpuregs[14][9] ), .A2(n1777), .B1(
        \cpuregs[15][9] ), .B2(n1776), .Y(n1277) );
  sky130_fd_sc_hd__a22oi_1 U2052 ( .A1(\cpuregs[12][9] ), .A2(n1779), .B1(
        \cpuregs[13][9] ), .B2(n1778), .Y(n1276) );
  sky130_fd_sc_hd__a22oi_1 U2053 ( .A1(\cpuregs[10][9] ), .A2(n1781), .B1(
        \cpuregs[11][9] ), .B2(n1780), .Y(n1275) );
  sky130_fd_sc_hd__a22oi_1 U2054 ( .A1(\cpuregs[8][9] ), .A2(n1783), .B1(
        \cpuregs[9][9] ), .B2(n1782), .Y(n1274) );
  sky130_fd_sc_hd__nand4_1 U2055 ( .A(n1277), .B(n1276), .C(n1275), .D(n1274), 
        .Y(n1278) );
  sky130_fd_sc_hd__o21ai_0 U2056 ( .A1(n1279), .A2(n1278), .B1(n1795), .Y(
        n1291) );
  sky130_fd_sc_hd__a22oi_1 U2057 ( .A1(\cpuregs[22][9] ), .A2(n1765), .B1(
        \cpuregs[23][9] ), .B2(n1764), .Y(n1283) );
  sky130_fd_sc_hd__a22oi_1 U2058 ( .A1(\cpuregs[20][9] ), .A2(n1767), .B1(
        \cpuregs[21][9] ), .B2(n1766), .Y(n1282) );
  sky130_fd_sc_hd__a22oi_1 U2059 ( .A1(\cpuregs[18][9] ), .A2(n1769), .B1(
        \cpuregs[19][9] ), .B2(n1768), .Y(n1281) );
  sky130_fd_sc_hd__a22oi_1 U2060 ( .A1(\cpuregs[16][9] ), .A2(n1771), .B1(
        \cpuregs[17][9] ), .B2(n1770), .Y(n1280) );
  sky130_fd_sc_hd__nand4_1 U2061 ( .A(n1283), .B(n1282), .C(n1281), .D(n1280), 
        .Y(n1289) );
  sky130_fd_sc_hd__a22oi_1 U2062 ( .A1(\cpuregs[30][9] ), .A2(n1777), .B1(
        \cpuregs[31][9] ), .B2(n1776), .Y(n1287) );
  sky130_fd_sc_hd__a22oi_1 U2063 ( .A1(\cpuregs[28][9] ), .A2(n1779), .B1(
        \cpuregs[29][9] ), .B2(n1778), .Y(n1286) );
  sky130_fd_sc_hd__a22oi_1 U2064 ( .A1(\cpuregs[26][9] ), .A2(n1781), .B1(
        \cpuregs[27][9] ), .B2(n1780), .Y(n1285) );
  sky130_fd_sc_hd__a22oi_1 U2065 ( .A1(\cpuregs[24][9] ), .A2(n1783), .B1(
        \cpuregs[25][9] ), .B2(n1782), .Y(n1284) );
  sky130_fd_sc_hd__nand4_1 U2066 ( .A(n1287), .B(n1286), .C(n1285), .D(n1284), 
        .Y(n1288) );
  sky130_fd_sc_hd__o21ai_0 U2067 ( .A1(n1289), .A2(n1288), .B1(N86), .Y(n1290)
         );
  sky130_fd_sc_hd__nand2_1 U2068 ( .A(n1291), .B(n1290), .Y(N774) );
  sky130_fd_sc_hd__a22oi_1 U2069 ( .A1(\cpuregs[6][10] ), .A2(n1765), .B1(
        \cpuregs[7][10] ), .B2(n1764), .Y(n1295) );
  sky130_fd_sc_hd__a22oi_1 U2070 ( .A1(\cpuregs[4][10] ), .A2(n1767), .B1(
        \cpuregs[5][10] ), .B2(n1766), .Y(n1294) );
  sky130_fd_sc_hd__a22oi_1 U2071 ( .A1(\cpuregs[2][10] ), .A2(n1769), .B1(
        \cpuregs[3][10] ), .B2(n1768), .Y(n1293) );
  sky130_fd_sc_hd__a22oi_1 U2072 ( .A1(\cpuregs[0][10] ), .A2(n1771), .B1(
        \cpuregs[1][10] ), .B2(n1770), .Y(n1292) );
  sky130_fd_sc_hd__nand4_1 U2073 ( .A(n1295), .B(n1294), .C(n1293), .D(n1292), 
        .Y(n1301) );
  sky130_fd_sc_hd__a22oi_1 U2074 ( .A1(\cpuregs[14][10] ), .A2(n1777), .B1(
        \cpuregs[15][10] ), .B2(n1776), .Y(n1299) );
  sky130_fd_sc_hd__a22oi_1 U2075 ( .A1(\cpuregs[12][10] ), .A2(n1779), .B1(
        \cpuregs[13][10] ), .B2(n1778), .Y(n1298) );
  sky130_fd_sc_hd__a22oi_1 U2076 ( .A1(\cpuregs[10][10] ), .A2(n1781), .B1(
        \cpuregs[11][10] ), .B2(n1780), .Y(n1297) );
  sky130_fd_sc_hd__a22oi_1 U2077 ( .A1(\cpuregs[8][10] ), .A2(n1783), .B1(
        \cpuregs[9][10] ), .B2(n1782), .Y(n1296) );
  sky130_fd_sc_hd__nand4_1 U2078 ( .A(n1299), .B(n1298), .C(n1297), .D(n1296), 
        .Y(n1300) );
  sky130_fd_sc_hd__o21ai_0 U2079 ( .A1(n1301), .A2(n1300), .B1(n1795), .Y(
        n1313) );
  sky130_fd_sc_hd__a22oi_1 U2080 ( .A1(\cpuregs[22][10] ), .A2(n1765), .B1(
        \cpuregs[23][10] ), .B2(n1764), .Y(n1305) );
  sky130_fd_sc_hd__a22oi_1 U2081 ( .A1(\cpuregs[20][10] ), .A2(n1767), .B1(
        \cpuregs[21][10] ), .B2(n1766), .Y(n1304) );
  sky130_fd_sc_hd__a22oi_1 U2082 ( .A1(\cpuregs[18][10] ), .A2(n1769), .B1(
        \cpuregs[19][10] ), .B2(n1768), .Y(n1303) );
  sky130_fd_sc_hd__a22oi_1 U2083 ( .A1(\cpuregs[16][10] ), .A2(n1771), .B1(
        \cpuregs[17][10] ), .B2(n1770), .Y(n1302) );
  sky130_fd_sc_hd__nand4_1 U2084 ( .A(n1305), .B(n1304), .C(n1303), .D(n1302), 
        .Y(n1311) );
  sky130_fd_sc_hd__a22oi_1 U2085 ( .A1(\cpuregs[30][10] ), .A2(n1777), .B1(
        \cpuregs[31][10] ), .B2(n1776), .Y(n1309) );
  sky130_fd_sc_hd__a22oi_1 U2086 ( .A1(\cpuregs[28][10] ), .A2(n1779), .B1(
        \cpuregs[29][10] ), .B2(n1778), .Y(n1308) );
  sky130_fd_sc_hd__a22oi_1 U2087 ( .A1(\cpuregs[26][10] ), .A2(n1781), .B1(
        \cpuregs[27][10] ), .B2(n1780), .Y(n1307) );
  sky130_fd_sc_hd__a22oi_1 U2088 ( .A1(\cpuregs[24][10] ), .A2(n1783), .B1(
        \cpuregs[25][10] ), .B2(n1782), .Y(n1306) );
  sky130_fd_sc_hd__nand4_1 U2089 ( .A(n1309), .B(n1308), .C(n1307), .D(n1306), 
        .Y(n1310) );
  sky130_fd_sc_hd__o21ai_0 U2090 ( .A1(n1311), .A2(n1310), .B1(N86), .Y(n1312)
         );
  sky130_fd_sc_hd__nand2_1 U2091 ( .A(n1313), .B(n1312), .Y(N773) );
  sky130_fd_sc_hd__a22oi_1 U2092 ( .A1(\cpuregs[6][11] ), .A2(n1765), .B1(
        \cpuregs[7][11] ), .B2(n1764), .Y(n1317) );
  sky130_fd_sc_hd__a22oi_1 U2093 ( .A1(\cpuregs[4][11] ), .A2(n1767), .B1(
        \cpuregs[5][11] ), .B2(n1766), .Y(n1316) );
  sky130_fd_sc_hd__a22oi_1 U2094 ( .A1(\cpuregs[2][11] ), .A2(n1769), .B1(
        \cpuregs[3][11] ), .B2(n1768), .Y(n1315) );
  sky130_fd_sc_hd__a22oi_1 U2095 ( .A1(\cpuregs[0][11] ), .A2(n1771), .B1(
        \cpuregs[1][11] ), .B2(n1770), .Y(n1314) );
  sky130_fd_sc_hd__nand4_1 U2096 ( .A(n1317), .B(n1316), .C(n1315), .D(n1314), 
        .Y(n1323) );
  sky130_fd_sc_hd__a22oi_1 U2097 ( .A1(\cpuregs[14][11] ), .A2(n1777), .B1(
        \cpuregs[15][11] ), .B2(n1776), .Y(n1321) );
  sky130_fd_sc_hd__a22oi_1 U2098 ( .A1(\cpuregs[12][11] ), .A2(n1779), .B1(
        \cpuregs[13][11] ), .B2(n1778), .Y(n1320) );
  sky130_fd_sc_hd__a22oi_1 U2099 ( .A1(\cpuregs[10][11] ), .A2(n1781), .B1(
        \cpuregs[11][11] ), .B2(n1780), .Y(n1319) );
  sky130_fd_sc_hd__a22oi_1 U2100 ( .A1(\cpuregs[8][11] ), .A2(n1783), .B1(
        \cpuregs[9][11] ), .B2(n1782), .Y(n1318) );
  sky130_fd_sc_hd__nand4_1 U2101 ( .A(n1321), .B(n1320), .C(n1319), .D(n1318), 
        .Y(n1322) );
  sky130_fd_sc_hd__o21ai_0 U2102 ( .A1(n1323), .A2(n1322), .B1(n1795), .Y(
        n1335) );
  sky130_fd_sc_hd__a22oi_1 U2103 ( .A1(\cpuregs[22][11] ), .A2(n1765), .B1(
        \cpuregs[23][11] ), .B2(n1764), .Y(n1327) );
  sky130_fd_sc_hd__a22oi_1 U2104 ( .A1(\cpuregs[20][11] ), .A2(n1767), .B1(
        \cpuregs[21][11] ), .B2(n1766), .Y(n1326) );
  sky130_fd_sc_hd__a22oi_1 U2105 ( .A1(\cpuregs[18][11] ), .A2(n1769), .B1(
        \cpuregs[19][11] ), .B2(n1768), .Y(n1325) );
  sky130_fd_sc_hd__a22oi_1 U2106 ( .A1(\cpuregs[16][11] ), .A2(n1771), .B1(
        \cpuregs[17][11] ), .B2(n1770), .Y(n1324) );
  sky130_fd_sc_hd__nand4_1 U2107 ( .A(n1327), .B(n1326), .C(n1325), .D(n1324), 
        .Y(n1333) );
  sky130_fd_sc_hd__a22oi_1 U2108 ( .A1(\cpuregs[30][11] ), .A2(n1777), .B1(
        \cpuregs[31][11] ), .B2(n1776), .Y(n1331) );
  sky130_fd_sc_hd__a22oi_1 U2109 ( .A1(\cpuregs[28][11] ), .A2(n1779), .B1(
        \cpuregs[29][11] ), .B2(n1778), .Y(n1330) );
  sky130_fd_sc_hd__a22oi_1 U2110 ( .A1(\cpuregs[26][11] ), .A2(n1781), .B1(
        \cpuregs[27][11] ), .B2(n1780), .Y(n1329) );
  sky130_fd_sc_hd__a22oi_1 U2111 ( .A1(\cpuregs[24][11] ), .A2(n1783), .B1(
        \cpuregs[25][11] ), .B2(n1782), .Y(n1328) );
  sky130_fd_sc_hd__nand4_1 U2112 ( .A(n1331), .B(n1330), .C(n1329), .D(n1328), 
        .Y(n1332) );
  sky130_fd_sc_hd__o21ai_0 U2113 ( .A1(n1333), .A2(n1332), .B1(N86), .Y(n1334)
         );
  sky130_fd_sc_hd__nand2_1 U2114 ( .A(n1335), .B(n1334), .Y(N772) );
  sky130_fd_sc_hd__a22oi_1 U2115 ( .A1(\cpuregs[6][12] ), .A2(n1765), .B1(
        \cpuregs[7][12] ), .B2(n1764), .Y(n1339) );
  sky130_fd_sc_hd__a22oi_1 U2116 ( .A1(\cpuregs[4][12] ), .A2(n1767), .B1(
        \cpuregs[5][12] ), .B2(n1766), .Y(n1338) );
  sky130_fd_sc_hd__a22oi_1 U2117 ( .A1(\cpuregs[2][12] ), .A2(n1769), .B1(
        \cpuregs[3][12] ), .B2(n1768), .Y(n1337) );
  sky130_fd_sc_hd__a22oi_1 U2118 ( .A1(\cpuregs[0][12] ), .A2(n1771), .B1(
        \cpuregs[1][12] ), .B2(n1770), .Y(n1336) );
  sky130_fd_sc_hd__nand4_1 U2119 ( .A(n1339), .B(n1338), .C(n1337), .D(n1336), 
        .Y(n1345) );
  sky130_fd_sc_hd__a22oi_1 U2120 ( .A1(\cpuregs[14][12] ), .A2(n1777), .B1(
        \cpuregs[15][12] ), .B2(n1776), .Y(n1343) );
  sky130_fd_sc_hd__a22oi_1 U2121 ( .A1(\cpuregs[12][12] ), .A2(n1779), .B1(
        \cpuregs[13][12] ), .B2(n1778), .Y(n1342) );
  sky130_fd_sc_hd__a22oi_1 U2122 ( .A1(\cpuregs[10][12] ), .A2(n1781), .B1(
        \cpuregs[11][12] ), .B2(n1780), .Y(n1341) );
  sky130_fd_sc_hd__a22oi_1 U2123 ( .A1(\cpuregs[8][12] ), .A2(n1783), .B1(
        \cpuregs[9][12] ), .B2(n1782), .Y(n1340) );
  sky130_fd_sc_hd__nand4_1 U2124 ( .A(n1343), .B(n1342), .C(n1341), .D(n1340), 
        .Y(n1344) );
  sky130_fd_sc_hd__o21ai_0 U2125 ( .A1(n1345), .A2(n1344), .B1(n1795), .Y(
        n1357) );
  sky130_fd_sc_hd__a22oi_1 U2126 ( .A1(\cpuregs[22][12] ), .A2(n1765), .B1(
        \cpuregs[23][12] ), .B2(n1764), .Y(n1349) );
  sky130_fd_sc_hd__a22oi_1 U2127 ( .A1(\cpuregs[20][12] ), .A2(n1767), .B1(
        \cpuregs[21][12] ), .B2(n1766), .Y(n1348) );
  sky130_fd_sc_hd__a22oi_1 U2128 ( .A1(\cpuregs[18][12] ), .A2(n1769), .B1(
        \cpuregs[19][12] ), .B2(n1768), .Y(n1347) );
  sky130_fd_sc_hd__a22oi_1 U2129 ( .A1(\cpuregs[16][12] ), .A2(n1771), .B1(
        \cpuregs[17][12] ), .B2(n1770), .Y(n1346) );
  sky130_fd_sc_hd__nand4_1 U2130 ( .A(n1349), .B(n1348), .C(n1347), .D(n1346), 
        .Y(n1355) );
  sky130_fd_sc_hd__a22oi_1 U2131 ( .A1(\cpuregs[30][12] ), .A2(n1777), .B1(
        \cpuregs[31][12] ), .B2(n1776), .Y(n1353) );
  sky130_fd_sc_hd__a22oi_1 U2132 ( .A1(\cpuregs[28][12] ), .A2(n1779), .B1(
        \cpuregs[29][12] ), .B2(n1778), .Y(n1352) );
  sky130_fd_sc_hd__a22oi_1 U2133 ( .A1(\cpuregs[26][12] ), .A2(n1781), .B1(
        \cpuregs[27][12] ), .B2(n1780), .Y(n1351) );
  sky130_fd_sc_hd__a22oi_1 U2134 ( .A1(\cpuregs[24][12] ), .A2(n1783), .B1(
        \cpuregs[25][12] ), .B2(n1782), .Y(n1350) );
  sky130_fd_sc_hd__nand4_1 U2135 ( .A(n1353), .B(n1352), .C(n1351), .D(n1350), 
        .Y(n1354) );
  sky130_fd_sc_hd__o21ai_0 U2136 ( .A1(n1355), .A2(n1354), .B1(N86), .Y(n1356)
         );
  sky130_fd_sc_hd__nand2_1 U2137 ( .A(n1357), .B(n1356), .Y(N771) );
  sky130_fd_sc_hd__a22oi_1 U2138 ( .A1(\cpuregs[6][13] ), .A2(n1765), .B1(
        \cpuregs[7][13] ), .B2(n1764), .Y(n1361) );
  sky130_fd_sc_hd__a22oi_1 U2139 ( .A1(\cpuregs[4][13] ), .A2(n1767), .B1(
        \cpuregs[5][13] ), .B2(n1766), .Y(n1360) );
  sky130_fd_sc_hd__a22oi_1 U2140 ( .A1(\cpuregs[2][13] ), .A2(n1769), .B1(
        \cpuregs[3][13] ), .B2(n1768), .Y(n1359) );
  sky130_fd_sc_hd__a22oi_1 U2141 ( .A1(\cpuregs[0][13] ), .A2(n1771), .B1(
        \cpuregs[1][13] ), .B2(n1770), .Y(n1358) );
  sky130_fd_sc_hd__nand4_1 U2142 ( .A(n1361), .B(n1360), .C(n1359), .D(n1358), 
        .Y(n1367) );
  sky130_fd_sc_hd__a22oi_1 U2143 ( .A1(\cpuregs[14][13] ), .A2(n1777), .B1(
        \cpuregs[15][13] ), .B2(n1776), .Y(n1365) );
  sky130_fd_sc_hd__a22oi_1 U2144 ( .A1(\cpuregs[12][13] ), .A2(n1779), .B1(
        \cpuregs[13][13] ), .B2(n1778), .Y(n1364) );
  sky130_fd_sc_hd__a22oi_1 U2145 ( .A1(\cpuregs[10][13] ), .A2(n1781), .B1(
        \cpuregs[11][13] ), .B2(n1780), .Y(n1363) );
  sky130_fd_sc_hd__a22oi_1 U2146 ( .A1(\cpuregs[8][13] ), .A2(n1783), .B1(
        \cpuregs[9][13] ), .B2(n1782), .Y(n1362) );
  sky130_fd_sc_hd__nand4_1 U2147 ( .A(n1365), .B(n1364), .C(n1363), .D(n1362), 
        .Y(n1366) );
  sky130_fd_sc_hd__o21ai_0 U2148 ( .A1(n1367), .A2(n1366), .B1(n1795), .Y(
        n1379) );
  sky130_fd_sc_hd__a22oi_1 U2149 ( .A1(\cpuregs[22][13] ), .A2(n1765), .B1(
        \cpuregs[23][13] ), .B2(n1764), .Y(n1371) );
  sky130_fd_sc_hd__a22oi_1 U2150 ( .A1(\cpuregs[20][13] ), .A2(n1767), .B1(
        \cpuregs[21][13] ), .B2(n1766), .Y(n1370) );
  sky130_fd_sc_hd__a22oi_1 U2151 ( .A1(\cpuregs[18][13] ), .A2(n1769), .B1(
        \cpuregs[19][13] ), .B2(n1768), .Y(n1369) );
  sky130_fd_sc_hd__a22oi_1 U2152 ( .A1(\cpuregs[16][13] ), .A2(n1771), .B1(
        \cpuregs[17][13] ), .B2(n1770), .Y(n1368) );
  sky130_fd_sc_hd__nand4_1 U2153 ( .A(n1371), .B(n1370), .C(n1369), .D(n1368), 
        .Y(n1377) );
  sky130_fd_sc_hd__a22oi_1 U2154 ( .A1(\cpuregs[30][13] ), .A2(n1777), .B1(
        \cpuregs[31][13] ), .B2(n1776), .Y(n1375) );
  sky130_fd_sc_hd__a22oi_1 U2155 ( .A1(\cpuregs[28][13] ), .A2(n1779), .B1(
        \cpuregs[29][13] ), .B2(n1778), .Y(n1374) );
  sky130_fd_sc_hd__a22oi_1 U2156 ( .A1(\cpuregs[26][13] ), .A2(n1781), .B1(
        \cpuregs[27][13] ), .B2(n1780), .Y(n1373) );
  sky130_fd_sc_hd__a22oi_1 U2157 ( .A1(\cpuregs[24][13] ), .A2(n1783), .B1(
        \cpuregs[25][13] ), .B2(n1782), .Y(n1372) );
  sky130_fd_sc_hd__nand4_1 U2158 ( .A(n1375), .B(n1374), .C(n1373), .D(n1372), 
        .Y(n1376) );
  sky130_fd_sc_hd__o21ai_0 U2159 ( .A1(n1377), .A2(n1376), .B1(N86), .Y(n1378)
         );
  sky130_fd_sc_hd__nand2_1 U2160 ( .A(n1379), .B(n1378), .Y(N770) );
  sky130_fd_sc_hd__a22oi_1 U2161 ( .A1(\cpuregs[6][14] ), .A2(n1765), .B1(
        \cpuregs[7][14] ), .B2(n1764), .Y(n1383) );
  sky130_fd_sc_hd__a22oi_1 U2162 ( .A1(\cpuregs[4][14] ), .A2(n1767), .B1(
        \cpuregs[5][14] ), .B2(n1766), .Y(n1382) );
  sky130_fd_sc_hd__a22oi_1 U2163 ( .A1(\cpuregs[2][14] ), .A2(n1769), .B1(
        \cpuregs[3][14] ), .B2(n1768), .Y(n1381) );
  sky130_fd_sc_hd__a22oi_1 U2164 ( .A1(\cpuregs[0][14] ), .A2(n1771), .B1(
        \cpuregs[1][14] ), .B2(n1770), .Y(n1380) );
  sky130_fd_sc_hd__nand4_1 U2165 ( .A(n1383), .B(n1382), .C(n1381), .D(n1380), 
        .Y(n1389) );
  sky130_fd_sc_hd__a22oi_1 U2166 ( .A1(\cpuregs[14][14] ), .A2(n1777), .B1(
        \cpuregs[15][14] ), .B2(n1776), .Y(n1387) );
  sky130_fd_sc_hd__a22oi_1 U2167 ( .A1(\cpuregs[12][14] ), .A2(n1779), .B1(
        \cpuregs[13][14] ), .B2(n1778), .Y(n1386) );
  sky130_fd_sc_hd__a22oi_1 U2168 ( .A1(\cpuregs[10][14] ), .A2(n1781), .B1(
        \cpuregs[11][14] ), .B2(n1780), .Y(n1385) );
  sky130_fd_sc_hd__a22oi_1 U2169 ( .A1(\cpuregs[8][14] ), .A2(n1783), .B1(
        \cpuregs[9][14] ), .B2(n1782), .Y(n1384) );
  sky130_fd_sc_hd__nand4_1 U2170 ( .A(n1387), .B(n1386), .C(n1385), .D(n1384), 
        .Y(n1388) );
  sky130_fd_sc_hd__o21ai_0 U2171 ( .A1(n1389), .A2(n1388), .B1(n1795), .Y(
        n1401) );
  sky130_fd_sc_hd__a22oi_1 U2172 ( .A1(\cpuregs[22][14] ), .A2(n1765), .B1(
        \cpuregs[23][14] ), .B2(n1764), .Y(n1393) );
  sky130_fd_sc_hd__a22oi_1 U2173 ( .A1(\cpuregs[20][14] ), .A2(n1767), .B1(
        \cpuregs[21][14] ), .B2(n1766), .Y(n1392) );
  sky130_fd_sc_hd__a22oi_1 U2174 ( .A1(\cpuregs[18][14] ), .A2(n1769), .B1(
        \cpuregs[19][14] ), .B2(n1768), .Y(n1391) );
  sky130_fd_sc_hd__a22oi_1 U2175 ( .A1(\cpuregs[16][14] ), .A2(n1771), .B1(
        \cpuregs[17][14] ), .B2(n1770), .Y(n1390) );
  sky130_fd_sc_hd__nand4_1 U2176 ( .A(n1393), .B(n1392), .C(n1391), .D(n1390), 
        .Y(n1399) );
  sky130_fd_sc_hd__a22oi_1 U2177 ( .A1(\cpuregs[30][14] ), .A2(n1777), .B1(
        \cpuregs[31][14] ), .B2(n1776), .Y(n1397) );
  sky130_fd_sc_hd__a22oi_1 U2178 ( .A1(\cpuregs[28][14] ), .A2(n1779), .B1(
        \cpuregs[29][14] ), .B2(n1778), .Y(n1396) );
  sky130_fd_sc_hd__a22oi_1 U2179 ( .A1(\cpuregs[26][14] ), .A2(n1781), .B1(
        \cpuregs[27][14] ), .B2(n1780), .Y(n1395) );
  sky130_fd_sc_hd__a22oi_1 U2180 ( .A1(\cpuregs[24][14] ), .A2(n1783), .B1(
        \cpuregs[25][14] ), .B2(n1782), .Y(n1394) );
  sky130_fd_sc_hd__nand4_1 U2181 ( .A(n1397), .B(n1396), .C(n1395), .D(n1394), 
        .Y(n1398) );
  sky130_fd_sc_hd__o21ai_0 U2182 ( .A1(n1399), .A2(n1398), .B1(N86), .Y(n1400)
         );
  sky130_fd_sc_hd__nand2_1 U2183 ( .A(n1401), .B(n1400), .Y(N769) );
  sky130_fd_sc_hd__a22oi_1 U2184 ( .A1(\cpuregs[6][15] ), .A2(n1765), .B1(
        \cpuregs[7][15] ), .B2(n1764), .Y(n1405) );
  sky130_fd_sc_hd__a22oi_1 U2185 ( .A1(\cpuregs[4][15] ), .A2(n1767), .B1(
        \cpuregs[5][15] ), .B2(n1766), .Y(n1404) );
  sky130_fd_sc_hd__a22oi_1 U2186 ( .A1(\cpuregs[2][15] ), .A2(n1769), .B1(
        \cpuregs[3][15] ), .B2(n1768), .Y(n1403) );
  sky130_fd_sc_hd__a22oi_1 U2187 ( .A1(\cpuregs[0][15] ), .A2(n1771), .B1(
        \cpuregs[1][15] ), .B2(n1770), .Y(n1402) );
  sky130_fd_sc_hd__nand4_1 U2188 ( .A(n1405), .B(n1404), .C(n1403), .D(n1402), 
        .Y(n1411) );
  sky130_fd_sc_hd__a22oi_1 U2189 ( .A1(\cpuregs[14][15] ), .A2(n1777), .B1(
        \cpuregs[15][15] ), .B2(n1776), .Y(n1409) );
  sky130_fd_sc_hd__a22oi_1 U2190 ( .A1(\cpuregs[12][15] ), .A2(n1779), .B1(
        \cpuregs[13][15] ), .B2(n1778), .Y(n1408) );
  sky130_fd_sc_hd__a22oi_1 U2191 ( .A1(\cpuregs[10][15] ), .A2(n1781), .B1(
        \cpuregs[11][15] ), .B2(n1780), .Y(n1407) );
  sky130_fd_sc_hd__a22oi_1 U2192 ( .A1(\cpuregs[8][15] ), .A2(n1783), .B1(
        \cpuregs[9][15] ), .B2(n1782), .Y(n1406) );
  sky130_fd_sc_hd__nand4_1 U2193 ( .A(n1409), .B(n1408), .C(n1407), .D(n1406), 
        .Y(n1410) );
  sky130_fd_sc_hd__o21ai_0 U2194 ( .A1(n1411), .A2(n1410), .B1(n1795), .Y(
        n1423) );
  sky130_fd_sc_hd__a22oi_1 U2195 ( .A1(\cpuregs[22][15] ), .A2(n1765), .B1(
        \cpuregs[23][15] ), .B2(n1764), .Y(n1415) );
  sky130_fd_sc_hd__a22oi_1 U2196 ( .A1(\cpuregs[20][15] ), .A2(n1767), .B1(
        \cpuregs[21][15] ), .B2(n1766), .Y(n1414) );
  sky130_fd_sc_hd__a22oi_1 U2197 ( .A1(\cpuregs[18][15] ), .A2(n1769), .B1(
        \cpuregs[19][15] ), .B2(n1768), .Y(n1413) );
  sky130_fd_sc_hd__a22oi_1 U2198 ( .A1(\cpuregs[16][15] ), .A2(n1771), .B1(
        \cpuregs[17][15] ), .B2(n1770), .Y(n1412) );
  sky130_fd_sc_hd__nand4_1 U2199 ( .A(n1415), .B(n1414), .C(n1413), .D(n1412), 
        .Y(n1421) );
  sky130_fd_sc_hd__a22oi_1 U2200 ( .A1(\cpuregs[30][15] ), .A2(n1777), .B1(
        \cpuregs[31][15] ), .B2(n1776), .Y(n1419) );
  sky130_fd_sc_hd__a22oi_1 U2201 ( .A1(\cpuregs[28][15] ), .A2(n1779), .B1(
        \cpuregs[29][15] ), .B2(n1778), .Y(n1418) );
  sky130_fd_sc_hd__a22oi_1 U2202 ( .A1(\cpuregs[26][15] ), .A2(n1781), .B1(
        \cpuregs[27][15] ), .B2(n1780), .Y(n1417) );
  sky130_fd_sc_hd__a22oi_1 U2203 ( .A1(\cpuregs[24][15] ), .A2(n1783), .B1(
        \cpuregs[25][15] ), .B2(n1782), .Y(n1416) );
  sky130_fd_sc_hd__nand4_1 U2204 ( .A(n1419), .B(n1418), .C(n1417), .D(n1416), 
        .Y(n1420) );
  sky130_fd_sc_hd__o21ai_0 U2205 ( .A1(n1421), .A2(n1420), .B1(N86), .Y(n1422)
         );
  sky130_fd_sc_hd__nand2_1 U2206 ( .A(n1423), .B(n1422), .Y(N768) );
  sky130_fd_sc_hd__a22oi_1 U2207 ( .A1(\cpuregs[6][16] ), .A2(n1765), .B1(
        \cpuregs[7][16] ), .B2(n1764), .Y(n1427) );
  sky130_fd_sc_hd__a22oi_1 U2208 ( .A1(\cpuregs[4][16] ), .A2(n1767), .B1(
        \cpuregs[5][16] ), .B2(n1766), .Y(n1426) );
  sky130_fd_sc_hd__a22oi_1 U2209 ( .A1(\cpuregs[2][16] ), .A2(n1769), .B1(
        \cpuregs[3][16] ), .B2(n1768), .Y(n1425) );
  sky130_fd_sc_hd__a22oi_1 U2210 ( .A1(\cpuregs[0][16] ), .A2(n1771), .B1(
        \cpuregs[1][16] ), .B2(n1770), .Y(n1424) );
  sky130_fd_sc_hd__nand4_1 U2211 ( .A(n1427), .B(n1426), .C(n1425), .D(n1424), 
        .Y(n1433) );
  sky130_fd_sc_hd__a22oi_1 U2212 ( .A1(\cpuregs[14][16] ), .A2(n1777), .B1(
        \cpuregs[15][16] ), .B2(n1776), .Y(n1431) );
  sky130_fd_sc_hd__a22oi_1 U2213 ( .A1(\cpuregs[12][16] ), .A2(n1779), .B1(
        \cpuregs[13][16] ), .B2(n1778), .Y(n1430) );
  sky130_fd_sc_hd__a22oi_1 U2214 ( .A1(\cpuregs[10][16] ), .A2(n1781), .B1(
        \cpuregs[11][16] ), .B2(n1780), .Y(n1429) );
  sky130_fd_sc_hd__a22oi_1 U2215 ( .A1(\cpuregs[8][16] ), .A2(n1783), .B1(
        \cpuregs[9][16] ), .B2(n1782), .Y(n1428) );
  sky130_fd_sc_hd__nand4_1 U2216 ( .A(n1431), .B(n1430), .C(n1429), .D(n1428), 
        .Y(n1432) );
  sky130_fd_sc_hd__o21ai_0 U2217 ( .A1(n1433), .A2(n1432), .B1(n1795), .Y(
        n1445) );
  sky130_fd_sc_hd__a22oi_1 U2218 ( .A1(\cpuregs[22][16] ), .A2(n1765), .B1(
        \cpuregs[23][16] ), .B2(n1764), .Y(n1437) );
  sky130_fd_sc_hd__a22oi_1 U2219 ( .A1(\cpuregs[20][16] ), .A2(n1767), .B1(
        \cpuregs[21][16] ), .B2(n1766), .Y(n1436) );
  sky130_fd_sc_hd__a22oi_1 U2220 ( .A1(\cpuregs[18][16] ), .A2(n1769), .B1(
        \cpuregs[19][16] ), .B2(n1768), .Y(n1435) );
  sky130_fd_sc_hd__a22oi_1 U2221 ( .A1(\cpuregs[16][16] ), .A2(n1771), .B1(
        \cpuregs[17][16] ), .B2(n1770), .Y(n1434) );
  sky130_fd_sc_hd__nand4_1 U2222 ( .A(n1437), .B(n1436), .C(n1435), .D(n1434), 
        .Y(n1443) );
  sky130_fd_sc_hd__a22oi_1 U2223 ( .A1(\cpuregs[30][16] ), .A2(n1777), .B1(
        \cpuregs[31][16] ), .B2(n1776), .Y(n1441) );
  sky130_fd_sc_hd__a22oi_1 U2224 ( .A1(\cpuregs[28][16] ), .A2(n1779), .B1(
        \cpuregs[29][16] ), .B2(n1778), .Y(n1440) );
  sky130_fd_sc_hd__a22oi_1 U2225 ( .A1(\cpuregs[26][16] ), .A2(n1781), .B1(
        \cpuregs[27][16] ), .B2(n1780), .Y(n1439) );
  sky130_fd_sc_hd__a22oi_1 U2226 ( .A1(\cpuregs[24][16] ), .A2(n1783), .B1(
        \cpuregs[25][16] ), .B2(n1782), .Y(n1438) );
  sky130_fd_sc_hd__nand4_1 U2227 ( .A(n1441), .B(n1440), .C(n1439), .D(n1438), 
        .Y(n1442) );
  sky130_fd_sc_hd__o21ai_0 U2228 ( .A1(n1443), .A2(n1442), .B1(N86), .Y(n1444)
         );
  sky130_fd_sc_hd__nand2_1 U2229 ( .A(n1445), .B(n1444), .Y(N767) );
  sky130_fd_sc_hd__a22oi_1 U2230 ( .A1(\cpuregs[6][17] ), .A2(n1765), .B1(
        \cpuregs[7][17] ), .B2(n1764), .Y(n1449) );
  sky130_fd_sc_hd__a22oi_1 U2231 ( .A1(\cpuregs[4][17] ), .A2(n1767), .B1(
        \cpuregs[5][17] ), .B2(n1766), .Y(n1448) );
  sky130_fd_sc_hd__a22oi_1 U2232 ( .A1(\cpuregs[2][17] ), .A2(n1769), .B1(
        \cpuregs[3][17] ), .B2(n1768), .Y(n1447) );
  sky130_fd_sc_hd__a22oi_1 U2233 ( .A1(\cpuregs[0][17] ), .A2(n1771), .B1(
        \cpuregs[1][17] ), .B2(n1770), .Y(n1446) );
  sky130_fd_sc_hd__nand4_1 U2234 ( .A(n1449), .B(n1448), .C(n1447), .D(n1446), 
        .Y(n1455) );
  sky130_fd_sc_hd__a22oi_1 U2235 ( .A1(\cpuregs[14][17] ), .A2(n1777), .B1(
        \cpuregs[15][17] ), .B2(n1776), .Y(n1453) );
  sky130_fd_sc_hd__a22oi_1 U2236 ( .A1(\cpuregs[12][17] ), .A2(n1779), .B1(
        \cpuregs[13][17] ), .B2(n1778), .Y(n1452) );
  sky130_fd_sc_hd__a22oi_1 U2237 ( .A1(\cpuregs[10][17] ), .A2(n1781), .B1(
        \cpuregs[11][17] ), .B2(n1780), .Y(n1451) );
  sky130_fd_sc_hd__a22oi_1 U2238 ( .A1(\cpuregs[8][17] ), .A2(n1783), .B1(
        \cpuregs[9][17] ), .B2(n1782), .Y(n1450) );
  sky130_fd_sc_hd__nand4_1 U2239 ( .A(n1453), .B(n1452), .C(n1451), .D(n1450), 
        .Y(n1454) );
  sky130_fd_sc_hd__o21ai_0 U2240 ( .A1(n1455), .A2(n1454), .B1(n1795), .Y(
        n1467) );
  sky130_fd_sc_hd__a22oi_1 U2241 ( .A1(\cpuregs[22][17] ), .A2(n1765), .B1(
        \cpuregs[23][17] ), .B2(n1764), .Y(n1459) );
  sky130_fd_sc_hd__a22oi_1 U2242 ( .A1(\cpuregs[20][17] ), .A2(n1767), .B1(
        \cpuregs[21][17] ), .B2(n1766), .Y(n1458) );
  sky130_fd_sc_hd__a22oi_1 U2243 ( .A1(\cpuregs[18][17] ), .A2(n1769), .B1(
        \cpuregs[19][17] ), .B2(n1768), .Y(n1457) );
  sky130_fd_sc_hd__a22oi_1 U2244 ( .A1(\cpuregs[16][17] ), .A2(n1771), .B1(
        \cpuregs[17][17] ), .B2(n1770), .Y(n1456) );
  sky130_fd_sc_hd__nand4_1 U2245 ( .A(n1459), .B(n1458), .C(n1457), .D(n1456), 
        .Y(n1465) );
  sky130_fd_sc_hd__a22oi_1 U2246 ( .A1(\cpuregs[30][17] ), .A2(n1777), .B1(
        \cpuregs[31][17] ), .B2(n1776), .Y(n1463) );
  sky130_fd_sc_hd__a22oi_1 U2247 ( .A1(\cpuregs[28][17] ), .A2(n1779), .B1(
        \cpuregs[29][17] ), .B2(n1778), .Y(n1462) );
  sky130_fd_sc_hd__a22oi_1 U2248 ( .A1(\cpuregs[26][17] ), .A2(n1781), .B1(
        \cpuregs[27][17] ), .B2(n1780), .Y(n1461) );
  sky130_fd_sc_hd__a22oi_1 U2249 ( .A1(\cpuregs[24][17] ), .A2(n1783), .B1(
        \cpuregs[25][17] ), .B2(n1782), .Y(n1460) );
  sky130_fd_sc_hd__nand4_1 U2250 ( .A(n1463), .B(n1462), .C(n1461), .D(n1460), 
        .Y(n1464) );
  sky130_fd_sc_hd__o21ai_0 U2251 ( .A1(n1465), .A2(n1464), .B1(N86), .Y(n1466)
         );
  sky130_fd_sc_hd__nand2_1 U2252 ( .A(n1467), .B(n1466), .Y(N766) );
  sky130_fd_sc_hd__a22oi_1 U2253 ( .A1(\cpuregs[6][18] ), .A2(n1765), .B1(
        \cpuregs[7][18] ), .B2(n1764), .Y(n1471) );
  sky130_fd_sc_hd__a22oi_1 U2254 ( .A1(\cpuregs[4][18] ), .A2(n1767), .B1(
        \cpuregs[5][18] ), .B2(n1766), .Y(n1470) );
  sky130_fd_sc_hd__a22oi_1 U2255 ( .A1(\cpuregs[2][18] ), .A2(n1769), .B1(
        \cpuregs[3][18] ), .B2(n1768), .Y(n1469) );
  sky130_fd_sc_hd__a22oi_1 U2256 ( .A1(\cpuregs[0][18] ), .A2(n1771), .B1(
        \cpuregs[1][18] ), .B2(n1770), .Y(n1468) );
  sky130_fd_sc_hd__nand4_1 U2257 ( .A(n1471), .B(n1470), .C(n1469), .D(n1468), 
        .Y(n1477) );
  sky130_fd_sc_hd__a22oi_1 U2258 ( .A1(\cpuregs[14][18] ), .A2(n1777), .B1(
        \cpuregs[15][18] ), .B2(n1776), .Y(n1475) );
  sky130_fd_sc_hd__a22oi_1 U2259 ( .A1(\cpuregs[12][18] ), .A2(n1779), .B1(
        \cpuregs[13][18] ), .B2(n1778), .Y(n1474) );
  sky130_fd_sc_hd__a22oi_1 U2260 ( .A1(\cpuregs[10][18] ), .A2(n1781), .B1(
        \cpuregs[11][18] ), .B2(n1780), .Y(n1473) );
  sky130_fd_sc_hd__a22oi_1 U2261 ( .A1(\cpuregs[8][18] ), .A2(n1783), .B1(
        \cpuregs[9][18] ), .B2(n1782), .Y(n1472) );
  sky130_fd_sc_hd__nand4_1 U2262 ( .A(n1475), .B(n1474), .C(n1473), .D(n1472), 
        .Y(n1476) );
  sky130_fd_sc_hd__o21ai_0 U2263 ( .A1(n1477), .A2(n1476), .B1(n1795), .Y(
        n1489) );
  sky130_fd_sc_hd__a22oi_1 U2264 ( .A1(\cpuregs[22][18] ), .A2(n1765), .B1(
        \cpuregs[23][18] ), .B2(n1764), .Y(n1481) );
  sky130_fd_sc_hd__a22oi_1 U2265 ( .A1(\cpuregs[20][18] ), .A2(n1767), .B1(
        \cpuregs[21][18] ), .B2(n1766), .Y(n1480) );
  sky130_fd_sc_hd__a22oi_1 U2266 ( .A1(\cpuregs[18][18] ), .A2(n1769), .B1(
        \cpuregs[19][18] ), .B2(n1768), .Y(n1479) );
  sky130_fd_sc_hd__a22oi_1 U2267 ( .A1(\cpuregs[16][18] ), .A2(n1771), .B1(
        \cpuregs[17][18] ), .B2(n1770), .Y(n1478) );
  sky130_fd_sc_hd__nand4_1 U2268 ( .A(n1481), .B(n1480), .C(n1479), .D(n1478), 
        .Y(n1487) );
  sky130_fd_sc_hd__a22oi_1 U2269 ( .A1(\cpuregs[30][18] ), .A2(n1777), .B1(
        \cpuregs[31][18] ), .B2(n1776), .Y(n1485) );
  sky130_fd_sc_hd__a22oi_1 U2270 ( .A1(\cpuregs[28][18] ), .A2(n1779), .B1(
        \cpuregs[29][18] ), .B2(n1778), .Y(n1484) );
  sky130_fd_sc_hd__a22oi_1 U2271 ( .A1(\cpuregs[26][18] ), .A2(n1781), .B1(
        \cpuregs[27][18] ), .B2(n1780), .Y(n1483) );
  sky130_fd_sc_hd__a22oi_1 U2272 ( .A1(\cpuregs[24][18] ), .A2(n1783), .B1(
        \cpuregs[25][18] ), .B2(n1782), .Y(n1482) );
  sky130_fd_sc_hd__nand4_1 U2273 ( .A(n1485), .B(n1484), .C(n1483), .D(n1482), 
        .Y(n1486) );
  sky130_fd_sc_hd__o21ai_0 U2274 ( .A1(n1487), .A2(n1486), .B1(N86), .Y(n1488)
         );
  sky130_fd_sc_hd__nand2_1 U2275 ( .A(n1489), .B(n1488), .Y(N765) );
  sky130_fd_sc_hd__a22oi_1 U2276 ( .A1(\cpuregs[6][19] ), .A2(n1765), .B1(
        \cpuregs[7][19] ), .B2(n1764), .Y(n1493) );
  sky130_fd_sc_hd__a22oi_1 U2277 ( .A1(\cpuregs[4][19] ), .A2(n1767), .B1(
        \cpuregs[5][19] ), .B2(n1766), .Y(n1492) );
  sky130_fd_sc_hd__a22oi_1 U2278 ( .A1(\cpuregs[2][19] ), .A2(n1769), .B1(
        \cpuregs[3][19] ), .B2(n1768), .Y(n1491) );
  sky130_fd_sc_hd__a22oi_1 U2279 ( .A1(\cpuregs[0][19] ), .A2(n1771), .B1(
        \cpuregs[1][19] ), .B2(n1770), .Y(n1490) );
  sky130_fd_sc_hd__nand4_1 U2280 ( .A(n1493), .B(n1492), .C(n1491), .D(n1490), 
        .Y(n1499) );
  sky130_fd_sc_hd__a22oi_1 U2281 ( .A1(\cpuregs[14][19] ), .A2(n1777), .B1(
        \cpuregs[15][19] ), .B2(n1776), .Y(n1497) );
  sky130_fd_sc_hd__a22oi_1 U2282 ( .A1(\cpuregs[12][19] ), .A2(n1779), .B1(
        \cpuregs[13][19] ), .B2(n1778), .Y(n1496) );
  sky130_fd_sc_hd__a22oi_1 U2283 ( .A1(\cpuregs[10][19] ), .A2(n1781), .B1(
        \cpuregs[11][19] ), .B2(n1780), .Y(n1495) );
  sky130_fd_sc_hd__a22oi_1 U2284 ( .A1(\cpuregs[8][19] ), .A2(n1783), .B1(
        \cpuregs[9][19] ), .B2(n1782), .Y(n1494) );
  sky130_fd_sc_hd__nand4_1 U2285 ( .A(n1497), .B(n1496), .C(n1495), .D(n1494), 
        .Y(n1498) );
  sky130_fd_sc_hd__o21ai_0 U2286 ( .A1(n1499), .A2(n1498), .B1(n1795), .Y(
        n1511) );
  sky130_fd_sc_hd__a22oi_1 U2287 ( .A1(\cpuregs[22][19] ), .A2(n1765), .B1(
        \cpuregs[23][19] ), .B2(n1764), .Y(n1503) );
  sky130_fd_sc_hd__a22oi_1 U2288 ( .A1(\cpuregs[20][19] ), .A2(n1767), .B1(
        \cpuregs[21][19] ), .B2(n1766), .Y(n1502) );
  sky130_fd_sc_hd__a22oi_1 U2289 ( .A1(\cpuregs[18][19] ), .A2(n1769), .B1(
        \cpuregs[19][19] ), .B2(n1768), .Y(n1501) );
  sky130_fd_sc_hd__a22oi_1 U2290 ( .A1(\cpuregs[16][19] ), .A2(n1771), .B1(
        \cpuregs[17][19] ), .B2(n1770), .Y(n1500) );
  sky130_fd_sc_hd__nand4_1 U2291 ( .A(n1503), .B(n1502), .C(n1501), .D(n1500), 
        .Y(n1509) );
  sky130_fd_sc_hd__a22oi_1 U2292 ( .A1(\cpuregs[30][19] ), .A2(n1777), .B1(
        \cpuregs[31][19] ), .B2(n1776), .Y(n1507) );
  sky130_fd_sc_hd__a22oi_1 U2293 ( .A1(\cpuregs[28][19] ), .A2(n1779), .B1(
        \cpuregs[29][19] ), .B2(n1778), .Y(n1506) );
  sky130_fd_sc_hd__a22oi_1 U2294 ( .A1(\cpuregs[26][19] ), .A2(n1781), .B1(
        \cpuregs[27][19] ), .B2(n1780), .Y(n1505) );
  sky130_fd_sc_hd__a22oi_1 U2295 ( .A1(\cpuregs[24][19] ), .A2(n1783), .B1(
        \cpuregs[25][19] ), .B2(n1782), .Y(n1504) );
  sky130_fd_sc_hd__nand4_1 U2296 ( .A(n1507), .B(n1506), .C(n1505), .D(n1504), 
        .Y(n1508) );
  sky130_fd_sc_hd__o21ai_0 U2297 ( .A1(n1509), .A2(n1508), .B1(N86), .Y(n1510)
         );
  sky130_fd_sc_hd__nand2_1 U2298 ( .A(n1511), .B(n1510), .Y(N764) );
  sky130_fd_sc_hd__a22oi_1 U2299 ( .A1(\cpuregs[6][20] ), .A2(n1765), .B1(
        \cpuregs[7][20] ), .B2(n1764), .Y(n1515) );
  sky130_fd_sc_hd__a22oi_1 U2300 ( .A1(\cpuregs[4][20] ), .A2(n1767), .B1(
        \cpuregs[5][20] ), .B2(n1766), .Y(n1514) );
  sky130_fd_sc_hd__a22oi_1 U2301 ( .A1(\cpuregs[2][20] ), .A2(n1769), .B1(
        \cpuregs[3][20] ), .B2(n1768), .Y(n1513) );
  sky130_fd_sc_hd__a22oi_1 U2302 ( .A1(\cpuregs[0][20] ), .A2(n1771), .B1(
        \cpuregs[1][20] ), .B2(n1770), .Y(n1512) );
  sky130_fd_sc_hd__nand4_1 U2303 ( .A(n1515), .B(n1514), .C(n1513), .D(n1512), 
        .Y(n1521) );
  sky130_fd_sc_hd__a22oi_1 U2304 ( .A1(\cpuregs[14][20] ), .A2(n1777), .B1(
        \cpuregs[15][20] ), .B2(n1776), .Y(n1519) );
  sky130_fd_sc_hd__a22oi_1 U2305 ( .A1(\cpuregs[12][20] ), .A2(n1779), .B1(
        \cpuregs[13][20] ), .B2(n1778), .Y(n1518) );
  sky130_fd_sc_hd__a22oi_1 U2306 ( .A1(\cpuregs[10][20] ), .A2(n1781), .B1(
        \cpuregs[11][20] ), .B2(n1780), .Y(n1517) );
  sky130_fd_sc_hd__a22oi_1 U2307 ( .A1(\cpuregs[8][20] ), .A2(n1783), .B1(
        \cpuregs[9][20] ), .B2(n1782), .Y(n1516) );
  sky130_fd_sc_hd__nand4_1 U2308 ( .A(n1519), .B(n1518), .C(n1517), .D(n1516), 
        .Y(n1520) );
  sky130_fd_sc_hd__o21ai_0 U2309 ( .A1(n1521), .A2(n1520), .B1(n1795), .Y(
        n1533) );
  sky130_fd_sc_hd__a22oi_1 U2310 ( .A1(\cpuregs[22][20] ), .A2(n1765), .B1(
        \cpuregs[23][20] ), .B2(n1764), .Y(n1525) );
  sky130_fd_sc_hd__a22oi_1 U2311 ( .A1(\cpuregs[20][20] ), .A2(n1767), .B1(
        \cpuregs[21][20] ), .B2(n1766), .Y(n1524) );
  sky130_fd_sc_hd__a22oi_1 U2312 ( .A1(\cpuregs[18][20] ), .A2(n1769), .B1(
        \cpuregs[19][20] ), .B2(n1768), .Y(n1523) );
  sky130_fd_sc_hd__a22oi_1 U2313 ( .A1(\cpuregs[16][20] ), .A2(n1771), .B1(
        \cpuregs[17][20] ), .B2(n1770), .Y(n1522) );
  sky130_fd_sc_hd__nand4_1 U2314 ( .A(n1525), .B(n1524), .C(n1523), .D(n1522), 
        .Y(n1531) );
  sky130_fd_sc_hd__a22oi_1 U2315 ( .A1(\cpuregs[30][20] ), .A2(n1777), .B1(
        \cpuregs[31][20] ), .B2(n1776), .Y(n1529) );
  sky130_fd_sc_hd__a22oi_1 U2316 ( .A1(\cpuregs[28][20] ), .A2(n1779), .B1(
        \cpuregs[29][20] ), .B2(n1778), .Y(n1528) );
  sky130_fd_sc_hd__a22oi_1 U2317 ( .A1(\cpuregs[26][20] ), .A2(n1781), .B1(
        \cpuregs[27][20] ), .B2(n1780), .Y(n1527) );
  sky130_fd_sc_hd__a22oi_1 U2318 ( .A1(\cpuregs[24][20] ), .A2(n1783), .B1(
        \cpuregs[25][20] ), .B2(n1782), .Y(n1526) );
  sky130_fd_sc_hd__nand4_1 U2319 ( .A(n1529), .B(n1528), .C(n1527), .D(n1526), 
        .Y(n1530) );
  sky130_fd_sc_hd__o21ai_0 U2320 ( .A1(n1531), .A2(n1530), .B1(N86), .Y(n1532)
         );
  sky130_fd_sc_hd__nand2_1 U2321 ( .A(n1533), .B(n1532), .Y(N763) );
  sky130_fd_sc_hd__a22oi_1 U2322 ( .A1(\cpuregs[6][21] ), .A2(n1765), .B1(
        \cpuregs[7][21] ), .B2(n1764), .Y(n1537) );
  sky130_fd_sc_hd__a22oi_1 U2323 ( .A1(\cpuregs[4][21] ), .A2(n1767), .B1(
        \cpuregs[5][21] ), .B2(n1766), .Y(n1536) );
  sky130_fd_sc_hd__a22oi_1 U2324 ( .A1(\cpuregs[2][21] ), .A2(n1769), .B1(
        \cpuregs[3][21] ), .B2(n1768), .Y(n1535) );
  sky130_fd_sc_hd__a22oi_1 U2325 ( .A1(\cpuregs[0][21] ), .A2(n1771), .B1(
        \cpuregs[1][21] ), .B2(n1770), .Y(n1534) );
  sky130_fd_sc_hd__nand4_1 U2326 ( .A(n1537), .B(n1536), .C(n1535), .D(n1534), 
        .Y(n1543) );
  sky130_fd_sc_hd__a22oi_1 U2327 ( .A1(\cpuregs[14][21] ), .A2(n1777), .B1(
        \cpuregs[15][21] ), .B2(n1776), .Y(n1541) );
  sky130_fd_sc_hd__a22oi_1 U2328 ( .A1(\cpuregs[12][21] ), .A2(n1779), .B1(
        \cpuregs[13][21] ), .B2(n1778), .Y(n1540) );
  sky130_fd_sc_hd__a22oi_1 U2329 ( .A1(\cpuregs[10][21] ), .A2(n1781), .B1(
        \cpuregs[11][21] ), .B2(n1780), .Y(n1539) );
  sky130_fd_sc_hd__a22oi_1 U2330 ( .A1(\cpuregs[8][21] ), .A2(n1783), .B1(
        \cpuregs[9][21] ), .B2(n1782), .Y(n1538) );
  sky130_fd_sc_hd__nand4_1 U2331 ( .A(n1541), .B(n1540), .C(n1539), .D(n1538), 
        .Y(n1542) );
  sky130_fd_sc_hd__o21ai_0 U2332 ( .A1(n1543), .A2(n1542), .B1(n1795), .Y(
        n1555) );
  sky130_fd_sc_hd__a22oi_1 U2333 ( .A1(\cpuregs[22][21] ), .A2(n1765), .B1(
        \cpuregs[23][21] ), .B2(n1764), .Y(n1547) );
  sky130_fd_sc_hd__a22oi_1 U2334 ( .A1(\cpuregs[20][21] ), .A2(n1767), .B1(
        \cpuregs[21][21] ), .B2(n1766), .Y(n1546) );
  sky130_fd_sc_hd__a22oi_1 U2335 ( .A1(\cpuregs[18][21] ), .A2(n1769), .B1(
        \cpuregs[19][21] ), .B2(n1768), .Y(n1545) );
  sky130_fd_sc_hd__a22oi_1 U2336 ( .A1(\cpuregs[16][21] ), .A2(n1771), .B1(
        \cpuregs[17][21] ), .B2(n1770), .Y(n1544) );
  sky130_fd_sc_hd__nand4_1 U2337 ( .A(n1547), .B(n1546), .C(n1545), .D(n1544), 
        .Y(n1553) );
  sky130_fd_sc_hd__a22oi_1 U2338 ( .A1(\cpuregs[30][21] ), .A2(n1777), .B1(
        \cpuregs[31][21] ), .B2(n1776), .Y(n1551) );
  sky130_fd_sc_hd__a22oi_1 U2339 ( .A1(\cpuregs[28][21] ), .A2(n1779), .B1(
        \cpuregs[29][21] ), .B2(n1778), .Y(n1550) );
  sky130_fd_sc_hd__a22oi_1 U2340 ( .A1(\cpuregs[26][21] ), .A2(n1781), .B1(
        \cpuregs[27][21] ), .B2(n1780), .Y(n1549) );
  sky130_fd_sc_hd__a22oi_1 U2341 ( .A1(\cpuregs[24][21] ), .A2(n1783), .B1(
        \cpuregs[25][21] ), .B2(n1782), .Y(n1548) );
  sky130_fd_sc_hd__nand4_1 U2342 ( .A(n1551), .B(n1550), .C(n1549), .D(n1548), 
        .Y(n1552) );
  sky130_fd_sc_hd__o21ai_0 U2343 ( .A1(n1553), .A2(n1552), .B1(N86), .Y(n1554)
         );
  sky130_fd_sc_hd__nand2_1 U2344 ( .A(n1555), .B(n1554), .Y(N762) );
  sky130_fd_sc_hd__a22oi_1 U2345 ( .A1(\cpuregs[6][22] ), .A2(n1765), .B1(
        \cpuregs[7][22] ), .B2(n1764), .Y(n1559) );
  sky130_fd_sc_hd__a22oi_1 U2346 ( .A1(\cpuregs[4][22] ), .A2(n1767), .B1(
        \cpuregs[5][22] ), .B2(n1766), .Y(n1558) );
  sky130_fd_sc_hd__a22oi_1 U2347 ( .A1(\cpuregs[2][22] ), .A2(n1769), .B1(
        \cpuregs[3][22] ), .B2(n1768), .Y(n1557) );
  sky130_fd_sc_hd__a22oi_1 U2348 ( .A1(\cpuregs[0][22] ), .A2(n1771), .B1(
        \cpuregs[1][22] ), .B2(n1770), .Y(n1556) );
  sky130_fd_sc_hd__nand4_1 U2349 ( .A(n1559), .B(n1558), .C(n1557), .D(n1556), 
        .Y(n1565) );
  sky130_fd_sc_hd__a22oi_1 U2350 ( .A1(\cpuregs[14][22] ), .A2(n1777), .B1(
        \cpuregs[15][22] ), .B2(n1776), .Y(n1563) );
  sky130_fd_sc_hd__a22oi_1 U2351 ( .A1(\cpuregs[12][22] ), .A2(n1779), .B1(
        \cpuregs[13][22] ), .B2(n1778), .Y(n1562) );
  sky130_fd_sc_hd__a22oi_1 U2352 ( .A1(\cpuregs[10][22] ), .A2(n1781), .B1(
        \cpuregs[11][22] ), .B2(n1780), .Y(n1561) );
  sky130_fd_sc_hd__a22oi_1 U2353 ( .A1(\cpuregs[8][22] ), .A2(n1783), .B1(
        \cpuregs[9][22] ), .B2(n1782), .Y(n1560) );
  sky130_fd_sc_hd__nand4_1 U2354 ( .A(n1563), .B(n1562), .C(n1561), .D(n1560), 
        .Y(n1564) );
  sky130_fd_sc_hd__o21ai_0 U2355 ( .A1(n1565), .A2(n1564), .B1(n1795), .Y(
        n1577) );
  sky130_fd_sc_hd__a22oi_1 U2356 ( .A1(\cpuregs[22][22] ), .A2(n1765), .B1(
        \cpuregs[23][22] ), .B2(n1764), .Y(n1569) );
  sky130_fd_sc_hd__a22oi_1 U2357 ( .A1(\cpuregs[20][22] ), .A2(n1767), .B1(
        \cpuregs[21][22] ), .B2(n1766), .Y(n1568) );
  sky130_fd_sc_hd__a22oi_1 U2358 ( .A1(\cpuregs[18][22] ), .A2(n1769), .B1(
        \cpuregs[19][22] ), .B2(n1768), .Y(n1567) );
  sky130_fd_sc_hd__a22oi_1 U2359 ( .A1(\cpuregs[16][22] ), .A2(n1771), .B1(
        \cpuregs[17][22] ), .B2(n1770), .Y(n1566) );
  sky130_fd_sc_hd__nand4_1 U2360 ( .A(n1569), .B(n1568), .C(n1567), .D(n1566), 
        .Y(n1575) );
  sky130_fd_sc_hd__a22oi_1 U2361 ( .A1(\cpuregs[30][22] ), .A2(n1777), .B1(
        \cpuregs[31][22] ), .B2(n1776), .Y(n1573) );
  sky130_fd_sc_hd__a22oi_1 U2362 ( .A1(\cpuregs[28][22] ), .A2(n1779), .B1(
        \cpuregs[29][22] ), .B2(n1778), .Y(n1572) );
  sky130_fd_sc_hd__a22oi_1 U2363 ( .A1(\cpuregs[26][22] ), .A2(n1781), .B1(
        \cpuregs[27][22] ), .B2(n1780), .Y(n1571) );
  sky130_fd_sc_hd__a22oi_1 U2364 ( .A1(\cpuregs[24][22] ), .A2(n1783), .B1(
        \cpuregs[25][22] ), .B2(n1782), .Y(n1570) );
  sky130_fd_sc_hd__nand4_1 U2365 ( .A(n1573), .B(n1572), .C(n1571), .D(n1570), 
        .Y(n1574) );
  sky130_fd_sc_hd__o21ai_0 U2366 ( .A1(n1575), .A2(n1574), .B1(N86), .Y(n1576)
         );
  sky130_fd_sc_hd__nand2_1 U2367 ( .A(n1577), .B(n1576), .Y(N761) );
  sky130_fd_sc_hd__a22oi_1 U2368 ( .A1(\cpuregs[6][23] ), .A2(n1765), .B1(
        \cpuregs[7][23] ), .B2(n1764), .Y(n1581) );
  sky130_fd_sc_hd__a22oi_1 U2369 ( .A1(\cpuregs[4][23] ), .A2(n1767), .B1(
        \cpuregs[5][23] ), .B2(n1766), .Y(n1580) );
  sky130_fd_sc_hd__a22oi_1 U2370 ( .A1(\cpuregs[2][23] ), .A2(n1769), .B1(
        \cpuregs[3][23] ), .B2(n1768), .Y(n1579) );
  sky130_fd_sc_hd__a22oi_1 U2371 ( .A1(\cpuregs[0][23] ), .A2(n1771), .B1(
        \cpuregs[1][23] ), .B2(n1770), .Y(n1578) );
  sky130_fd_sc_hd__nand4_1 U2372 ( .A(n1581), .B(n1580), .C(n1579), .D(n1578), 
        .Y(n1587) );
  sky130_fd_sc_hd__a22oi_1 U2373 ( .A1(\cpuregs[14][23] ), .A2(n1777), .B1(
        \cpuregs[15][23] ), .B2(n1776), .Y(n1585) );
  sky130_fd_sc_hd__a22oi_1 U2374 ( .A1(\cpuregs[12][23] ), .A2(n1779), .B1(
        \cpuregs[13][23] ), .B2(n1778), .Y(n1584) );
  sky130_fd_sc_hd__a22oi_1 U2375 ( .A1(\cpuregs[10][23] ), .A2(n1781), .B1(
        \cpuregs[11][23] ), .B2(n1780), .Y(n1583) );
  sky130_fd_sc_hd__a22oi_1 U2376 ( .A1(\cpuregs[8][23] ), .A2(n1783), .B1(
        \cpuregs[9][23] ), .B2(n1782), .Y(n1582) );
  sky130_fd_sc_hd__nand4_1 U2377 ( .A(n1585), .B(n1584), .C(n1583), .D(n1582), 
        .Y(n1586) );
  sky130_fd_sc_hd__o21ai_0 U2378 ( .A1(n1587), .A2(n1586), .B1(n1795), .Y(
        n1599) );
  sky130_fd_sc_hd__a22oi_1 U2379 ( .A1(\cpuregs[22][23] ), .A2(n1765), .B1(
        \cpuregs[23][23] ), .B2(n1764), .Y(n1591) );
  sky130_fd_sc_hd__a22oi_1 U2380 ( .A1(\cpuregs[20][23] ), .A2(n1767), .B1(
        \cpuregs[21][23] ), .B2(n1766), .Y(n1590) );
  sky130_fd_sc_hd__a22oi_1 U2381 ( .A1(\cpuregs[18][23] ), .A2(n1769), .B1(
        \cpuregs[19][23] ), .B2(n1768), .Y(n1589) );
  sky130_fd_sc_hd__a22oi_1 U2382 ( .A1(\cpuregs[16][23] ), .A2(n1771), .B1(
        \cpuregs[17][23] ), .B2(n1770), .Y(n1588) );
  sky130_fd_sc_hd__nand4_1 U2383 ( .A(n1591), .B(n1590), .C(n1589), .D(n1588), 
        .Y(n1597) );
  sky130_fd_sc_hd__a22oi_1 U2384 ( .A1(\cpuregs[30][23] ), .A2(n1777), .B1(
        \cpuregs[31][23] ), .B2(n1776), .Y(n1595) );
  sky130_fd_sc_hd__a22oi_1 U2385 ( .A1(\cpuregs[28][23] ), .A2(n1779), .B1(
        \cpuregs[29][23] ), .B2(n1778), .Y(n1594) );
  sky130_fd_sc_hd__a22oi_1 U2386 ( .A1(\cpuregs[26][23] ), .A2(n1781), .B1(
        \cpuregs[27][23] ), .B2(n1780), .Y(n1593) );
  sky130_fd_sc_hd__a22oi_1 U2387 ( .A1(\cpuregs[24][23] ), .A2(n1783), .B1(
        \cpuregs[25][23] ), .B2(n1782), .Y(n1592) );
  sky130_fd_sc_hd__nand4_1 U2388 ( .A(n1595), .B(n1594), .C(n1593), .D(n1592), 
        .Y(n1596) );
  sky130_fd_sc_hd__o21ai_0 U2389 ( .A1(n1597), .A2(n1596), .B1(N86), .Y(n1598)
         );
  sky130_fd_sc_hd__nand2_1 U2390 ( .A(n1599), .B(n1598), .Y(N760) );
  sky130_fd_sc_hd__a22oi_1 U2391 ( .A1(\cpuregs[6][24] ), .A2(n1765), .B1(
        \cpuregs[7][24] ), .B2(n1764), .Y(n1603) );
  sky130_fd_sc_hd__a22oi_1 U2392 ( .A1(\cpuregs[4][24] ), .A2(n1767), .B1(
        \cpuregs[5][24] ), .B2(n1766), .Y(n1602) );
  sky130_fd_sc_hd__a22oi_1 U2393 ( .A1(\cpuregs[2][24] ), .A2(n1769), .B1(
        \cpuregs[3][24] ), .B2(n1768), .Y(n1601) );
  sky130_fd_sc_hd__a22oi_1 U2394 ( .A1(\cpuregs[0][24] ), .A2(n1771), .B1(
        \cpuregs[1][24] ), .B2(n1770), .Y(n1600) );
  sky130_fd_sc_hd__nand4_1 U2395 ( .A(n1603), .B(n1602), .C(n1601), .D(n1600), 
        .Y(n1609) );
  sky130_fd_sc_hd__a22oi_1 U2396 ( .A1(\cpuregs[14][24] ), .A2(n1777), .B1(
        \cpuregs[15][24] ), .B2(n1776), .Y(n1607) );
  sky130_fd_sc_hd__a22oi_1 U2397 ( .A1(\cpuregs[12][24] ), .A2(n1779), .B1(
        \cpuregs[13][24] ), .B2(n1778), .Y(n1606) );
  sky130_fd_sc_hd__a22oi_1 U2398 ( .A1(\cpuregs[10][24] ), .A2(n1781), .B1(
        \cpuregs[11][24] ), .B2(n1780), .Y(n1605) );
  sky130_fd_sc_hd__a22oi_1 U2399 ( .A1(\cpuregs[8][24] ), .A2(n1783), .B1(
        \cpuregs[9][24] ), .B2(n1782), .Y(n1604) );
  sky130_fd_sc_hd__nand4_1 U2400 ( .A(n1607), .B(n1606), .C(n1605), .D(n1604), 
        .Y(n1608) );
  sky130_fd_sc_hd__o21ai_0 U2401 ( .A1(n1609), .A2(n1608), .B1(n1795), .Y(
        n1621) );
  sky130_fd_sc_hd__a22oi_1 U2402 ( .A1(\cpuregs[22][24] ), .A2(n1765), .B1(
        \cpuregs[23][24] ), .B2(n1764), .Y(n1613) );
  sky130_fd_sc_hd__a22oi_1 U2403 ( .A1(\cpuregs[20][24] ), .A2(n1767), .B1(
        \cpuregs[21][24] ), .B2(n1766), .Y(n1612) );
  sky130_fd_sc_hd__a22oi_1 U2404 ( .A1(\cpuregs[18][24] ), .A2(n1769), .B1(
        \cpuregs[19][24] ), .B2(n1768), .Y(n1611) );
  sky130_fd_sc_hd__a22oi_1 U2405 ( .A1(\cpuregs[16][24] ), .A2(n1771), .B1(
        \cpuregs[17][24] ), .B2(n1770), .Y(n1610) );
  sky130_fd_sc_hd__nand4_1 U2406 ( .A(n1613), .B(n1612), .C(n1611), .D(n1610), 
        .Y(n1619) );
  sky130_fd_sc_hd__a22oi_1 U2407 ( .A1(\cpuregs[30][24] ), .A2(n1777), .B1(
        \cpuregs[31][24] ), .B2(n1776), .Y(n1617) );
  sky130_fd_sc_hd__a22oi_1 U2408 ( .A1(\cpuregs[28][24] ), .A2(n1779), .B1(
        \cpuregs[29][24] ), .B2(n1778), .Y(n1616) );
  sky130_fd_sc_hd__a22oi_1 U2409 ( .A1(\cpuregs[26][24] ), .A2(n1781), .B1(
        \cpuregs[27][24] ), .B2(n1780), .Y(n1615) );
  sky130_fd_sc_hd__a22oi_1 U2410 ( .A1(\cpuregs[24][24] ), .A2(n1783), .B1(
        \cpuregs[25][24] ), .B2(n1782), .Y(n1614) );
  sky130_fd_sc_hd__nand4_1 U2411 ( .A(n1617), .B(n1616), .C(n1615), .D(n1614), 
        .Y(n1618) );
  sky130_fd_sc_hd__o21ai_0 U2412 ( .A1(n1619), .A2(n1618), .B1(N86), .Y(n1620)
         );
  sky130_fd_sc_hd__nand2_1 U2413 ( .A(n1621), .B(n1620), .Y(N759) );
  sky130_fd_sc_hd__a22oi_1 U2414 ( .A1(\cpuregs[6][25] ), .A2(n1765), .B1(
        \cpuregs[7][25] ), .B2(n1764), .Y(n1625) );
  sky130_fd_sc_hd__a22oi_1 U2415 ( .A1(\cpuregs[4][25] ), .A2(n1767), .B1(
        \cpuregs[5][25] ), .B2(n1766), .Y(n1624) );
  sky130_fd_sc_hd__a22oi_1 U2416 ( .A1(\cpuregs[2][25] ), .A2(n1769), .B1(
        \cpuregs[3][25] ), .B2(n1768), .Y(n1623) );
  sky130_fd_sc_hd__a22oi_1 U2417 ( .A1(\cpuregs[0][25] ), .A2(n1771), .B1(
        \cpuregs[1][25] ), .B2(n1770), .Y(n1622) );
  sky130_fd_sc_hd__nand4_1 U2418 ( .A(n1625), .B(n1624), .C(n1623), .D(n1622), 
        .Y(n1631) );
  sky130_fd_sc_hd__a22oi_1 U2419 ( .A1(\cpuregs[14][25] ), .A2(n1777), .B1(
        \cpuregs[15][25] ), .B2(n1776), .Y(n1629) );
  sky130_fd_sc_hd__a22oi_1 U2420 ( .A1(\cpuregs[12][25] ), .A2(n1779), .B1(
        \cpuregs[13][25] ), .B2(n1778), .Y(n1628) );
  sky130_fd_sc_hd__a22oi_1 U2421 ( .A1(\cpuregs[10][25] ), .A2(n1781), .B1(
        \cpuregs[11][25] ), .B2(n1780), .Y(n1627) );
  sky130_fd_sc_hd__a22oi_1 U2422 ( .A1(\cpuregs[8][25] ), .A2(n1783), .B1(
        \cpuregs[9][25] ), .B2(n1782), .Y(n1626) );
  sky130_fd_sc_hd__nand4_1 U2423 ( .A(n1629), .B(n1628), .C(n1627), .D(n1626), 
        .Y(n1630) );
  sky130_fd_sc_hd__o21ai_0 U2424 ( .A1(n1631), .A2(n1630), .B1(n1795), .Y(
        n1643) );
  sky130_fd_sc_hd__a22oi_1 U2425 ( .A1(\cpuregs[22][25] ), .A2(n1765), .B1(
        \cpuregs[23][25] ), .B2(n1764), .Y(n1635) );
  sky130_fd_sc_hd__a22oi_1 U2426 ( .A1(\cpuregs[20][25] ), .A2(n1767), .B1(
        \cpuregs[21][25] ), .B2(n1766), .Y(n1634) );
  sky130_fd_sc_hd__a22oi_1 U2427 ( .A1(\cpuregs[18][25] ), .A2(n1769), .B1(
        \cpuregs[19][25] ), .B2(n1768), .Y(n1633) );
  sky130_fd_sc_hd__a22oi_1 U2428 ( .A1(\cpuregs[16][25] ), .A2(n1771), .B1(
        \cpuregs[17][25] ), .B2(n1770), .Y(n1632) );
  sky130_fd_sc_hd__nand4_1 U2429 ( .A(n1635), .B(n1634), .C(n1633), .D(n1632), 
        .Y(n1641) );
  sky130_fd_sc_hd__a22oi_1 U2430 ( .A1(\cpuregs[30][25] ), .A2(n1777), .B1(
        \cpuregs[31][25] ), .B2(n1776), .Y(n1639) );
  sky130_fd_sc_hd__a22oi_1 U2431 ( .A1(\cpuregs[28][25] ), .A2(n1779), .B1(
        \cpuregs[29][25] ), .B2(n1778), .Y(n1638) );
  sky130_fd_sc_hd__a22oi_1 U2432 ( .A1(\cpuregs[26][25] ), .A2(n1781), .B1(
        \cpuregs[27][25] ), .B2(n1780), .Y(n1637) );
  sky130_fd_sc_hd__a22oi_1 U2433 ( .A1(\cpuregs[24][25] ), .A2(n1783), .B1(
        \cpuregs[25][25] ), .B2(n1782), .Y(n1636) );
  sky130_fd_sc_hd__nand4_1 U2434 ( .A(n1639), .B(n1638), .C(n1637), .D(n1636), 
        .Y(n1640) );
  sky130_fd_sc_hd__o21ai_0 U2435 ( .A1(n1641), .A2(n1640), .B1(N86), .Y(n1642)
         );
  sky130_fd_sc_hd__nand2_1 U2436 ( .A(n1643), .B(n1642), .Y(N758) );
  sky130_fd_sc_hd__a22oi_1 U2437 ( .A1(\cpuregs[6][26] ), .A2(n1765), .B1(
        \cpuregs[7][26] ), .B2(n1764), .Y(n1647) );
  sky130_fd_sc_hd__a22oi_1 U2438 ( .A1(\cpuregs[4][26] ), .A2(n1767), .B1(
        \cpuregs[5][26] ), .B2(n1766), .Y(n1646) );
  sky130_fd_sc_hd__a22oi_1 U2439 ( .A1(\cpuregs[2][26] ), .A2(n1769), .B1(
        \cpuregs[3][26] ), .B2(n1768), .Y(n1645) );
  sky130_fd_sc_hd__a22oi_1 U2440 ( .A1(\cpuregs[0][26] ), .A2(n1771), .B1(
        \cpuregs[1][26] ), .B2(n1770), .Y(n1644) );
  sky130_fd_sc_hd__nand4_1 U2441 ( .A(n1647), .B(n1646), .C(n1645), .D(n1644), 
        .Y(n1653) );
  sky130_fd_sc_hd__a22oi_1 U2442 ( .A1(\cpuregs[14][26] ), .A2(n1777), .B1(
        \cpuregs[15][26] ), .B2(n1776), .Y(n1651) );
  sky130_fd_sc_hd__a22oi_1 U2443 ( .A1(\cpuregs[12][26] ), .A2(n1779), .B1(
        \cpuregs[13][26] ), .B2(n1778), .Y(n1650) );
  sky130_fd_sc_hd__a22oi_1 U2444 ( .A1(\cpuregs[10][26] ), .A2(n1781), .B1(
        \cpuregs[11][26] ), .B2(n1780), .Y(n1649) );
  sky130_fd_sc_hd__a22oi_1 U2445 ( .A1(\cpuregs[8][26] ), .A2(n1783), .B1(
        \cpuregs[9][26] ), .B2(n1782), .Y(n1648) );
  sky130_fd_sc_hd__nand4_1 U2446 ( .A(n1651), .B(n1650), .C(n1649), .D(n1648), 
        .Y(n1652) );
  sky130_fd_sc_hd__o21ai_0 U2447 ( .A1(n1653), .A2(n1652), .B1(n1795), .Y(
        n1665) );
  sky130_fd_sc_hd__a22oi_1 U2448 ( .A1(\cpuregs[22][26] ), .A2(n1765), .B1(
        \cpuregs[23][26] ), .B2(n1764), .Y(n1657) );
  sky130_fd_sc_hd__a22oi_1 U2449 ( .A1(\cpuregs[20][26] ), .A2(n1767), .B1(
        \cpuregs[21][26] ), .B2(n1766), .Y(n1656) );
  sky130_fd_sc_hd__a22oi_1 U2450 ( .A1(\cpuregs[18][26] ), .A2(n1769), .B1(
        \cpuregs[19][26] ), .B2(n1768), .Y(n1655) );
  sky130_fd_sc_hd__a22oi_1 U2451 ( .A1(\cpuregs[16][26] ), .A2(n1771), .B1(
        \cpuregs[17][26] ), .B2(n1770), .Y(n1654) );
  sky130_fd_sc_hd__nand4_1 U2452 ( .A(n1657), .B(n1656), .C(n1655), .D(n1654), 
        .Y(n1663) );
  sky130_fd_sc_hd__a22oi_1 U2453 ( .A1(\cpuregs[30][26] ), .A2(n1777), .B1(
        \cpuregs[31][26] ), .B2(n1776), .Y(n1661) );
  sky130_fd_sc_hd__a22oi_1 U2454 ( .A1(\cpuregs[28][26] ), .A2(n1779), .B1(
        \cpuregs[29][26] ), .B2(n1778), .Y(n1660) );
  sky130_fd_sc_hd__a22oi_1 U2455 ( .A1(\cpuregs[26][26] ), .A2(n1781), .B1(
        \cpuregs[27][26] ), .B2(n1780), .Y(n1659) );
  sky130_fd_sc_hd__a22oi_1 U2456 ( .A1(\cpuregs[24][26] ), .A2(n1783), .B1(
        \cpuregs[25][26] ), .B2(n1782), .Y(n1658) );
  sky130_fd_sc_hd__nand4_1 U2457 ( .A(n1661), .B(n1660), .C(n1659), .D(n1658), 
        .Y(n1662) );
  sky130_fd_sc_hd__o21ai_0 U2458 ( .A1(n1663), .A2(n1662), .B1(N86), .Y(n1664)
         );
  sky130_fd_sc_hd__nand2_1 U2459 ( .A(n1665), .B(n1664), .Y(N757) );
  sky130_fd_sc_hd__a22oi_1 U2460 ( .A1(\cpuregs[6][27] ), .A2(n1765), .B1(
        \cpuregs[7][27] ), .B2(n1764), .Y(n1669) );
  sky130_fd_sc_hd__a22oi_1 U2461 ( .A1(\cpuregs[4][27] ), .A2(n1767), .B1(
        \cpuregs[5][27] ), .B2(n1766), .Y(n1668) );
  sky130_fd_sc_hd__a22oi_1 U2462 ( .A1(\cpuregs[2][27] ), .A2(n1769), .B1(
        \cpuregs[3][27] ), .B2(n1768), .Y(n1667) );
  sky130_fd_sc_hd__a22oi_1 U2463 ( .A1(\cpuregs[0][27] ), .A2(n1771), .B1(
        \cpuregs[1][27] ), .B2(n1770), .Y(n1666) );
  sky130_fd_sc_hd__nand4_1 U2464 ( .A(n1669), .B(n1668), .C(n1667), .D(n1666), 
        .Y(n1675) );
  sky130_fd_sc_hd__a22oi_1 U2465 ( .A1(\cpuregs[14][27] ), .A2(n1777), .B1(
        \cpuregs[15][27] ), .B2(n1776), .Y(n1673) );
  sky130_fd_sc_hd__a22oi_1 U2466 ( .A1(\cpuregs[12][27] ), .A2(n1779), .B1(
        \cpuregs[13][27] ), .B2(n1778), .Y(n1672) );
  sky130_fd_sc_hd__a22oi_1 U2467 ( .A1(\cpuregs[10][27] ), .A2(n1781), .B1(
        \cpuregs[11][27] ), .B2(n1780), .Y(n1671) );
  sky130_fd_sc_hd__a22oi_1 U2468 ( .A1(\cpuregs[8][27] ), .A2(n1783), .B1(
        \cpuregs[9][27] ), .B2(n1782), .Y(n1670) );
  sky130_fd_sc_hd__nand4_1 U2469 ( .A(n1673), .B(n1672), .C(n1671), .D(n1670), 
        .Y(n1674) );
  sky130_fd_sc_hd__o21ai_0 U2470 ( .A1(n1675), .A2(n1674), .B1(n1795), .Y(
        n1687) );
  sky130_fd_sc_hd__a22oi_1 U2471 ( .A1(\cpuregs[22][27] ), .A2(n1765), .B1(
        \cpuregs[23][27] ), .B2(n1764), .Y(n1679) );
  sky130_fd_sc_hd__a22oi_1 U2472 ( .A1(\cpuregs[20][27] ), .A2(n1767), .B1(
        \cpuregs[21][27] ), .B2(n1766), .Y(n1678) );
  sky130_fd_sc_hd__a22oi_1 U2473 ( .A1(\cpuregs[18][27] ), .A2(n1769), .B1(
        \cpuregs[19][27] ), .B2(n1768), .Y(n1677) );
  sky130_fd_sc_hd__a22oi_1 U2474 ( .A1(\cpuregs[16][27] ), .A2(n1771), .B1(
        \cpuregs[17][27] ), .B2(n1770), .Y(n1676) );
  sky130_fd_sc_hd__nand4_1 U2475 ( .A(n1679), .B(n1678), .C(n1677), .D(n1676), 
        .Y(n1685) );
  sky130_fd_sc_hd__a22oi_1 U2476 ( .A1(\cpuregs[30][27] ), .A2(n1777), .B1(
        \cpuregs[31][27] ), .B2(n1776), .Y(n1683) );
  sky130_fd_sc_hd__a22oi_1 U2477 ( .A1(\cpuregs[28][27] ), .A2(n1779), .B1(
        \cpuregs[29][27] ), .B2(n1778), .Y(n1682) );
  sky130_fd_sc_hd__a22oi_1 U2478 ( .A1(\cpuregs[26][27] ), .A2(n1781), .B1(
        \cpuregs[27][27] ), .B2(n1780), .Y(n1681) );
  sky130_fd_sc_hd__a22oi_1 U2479 ( .A1(\cpuregs[24][27] ), .A2(n1783), .B1(
        \cpuregs[25][27] ), .B2(n1782), .Y(n1680) );
  sky130_fd_sc_hd__nand4_1 U2480 ( .A(n1683), .B(n1682), .C(n1681), .D(n1680), 
        .Y(n1684) );
  sky130_fd_sc_hd__o21ai_0 U2481 ( .A1(n1685), .A2(n1684), .B1(N86), .Y(n1686)
         );
  sky130_fd_sc_hd__nand2_1 U2482 ( .A(n1687), .B(n1686), .Y(N756) );
  sky130_fd_sc_hd__a22oi_1 U2483 ( .A1(\cpuregs[6][28] ), .A2(n1765), .B1(
        \cpuregs[7][28] ), .B2(n1764), .Y(n1691) );
  sky130_fd_sc_hd__a22oi_1 U2484 ( .A1(\cpuregs[4][28] ), .A2(n1767), .B1(
        \cpuregs[5][28] ), .B2(n1766), .Y(n1690) );
  sky130_fd_sc_hd__a22oi_1 U2485 ( .A1(\cpuregs[2][28] ), .A2(n1769), .B1(
        \cpuregs[3][28] ), .B2(n1768), .Y(n1689) );
  sky130_fd_sc_hd__a22oi_1 U2486 ( .A1(\cpuregs[0][28] ), .A2(n1771), .B1(
        \cpuregs[1][28] ), .B2(n1770), .Y(n1688) );
  sky130_fd_sc_hd__nand4_1 U2487 ( .A(n1691), .B(n1690), .C(n1689), .D(n1688), 
        .Y(n1697) );
  sky130_fd_sc_hd__a22oi_1 U2488 ( .A1(\cpuregs[14][28] ), .A2(n1777), .B1(
        \cpuregs[15][28] ), .B2(n1776), .Y(n1695) );
  sky130_fd_sc_hd__a22oi_1 U2489 ( .A1(\cpuregs[12][28] ), .A2(n1779), .B1(
        \cpuregs[13][28] ), .B2(n1778), .Y(n1694) );
  sky130_fd_sc_hd__a22oi_1 U2490 ( .A1(\cpuregs[10][28] ), .A2(n1781), .B1(
        \cpuregs[11][28] ), .B2(n1780), .Y(n1693) );
  sky130_fd_sc_hd__a22oi_1 U2491 ( .A1(\cpuregs[8][28] ), .A2(n1783), .B1(
        \cpuregs[9][28] ), .B2(n1782), .Y(n1692) );
  sky130_fd_sc_hd__nand4_1 U2492 ( .A(n1695), .B(n1694), .C(n1693), .D(n1692), 
        .Y(n1696) );
  sky130_fd_sc_hd__o21ai_0 U2493 ( .A1(n1697), .A2(n1696), .B1(n1795), .Y(
        n1709) );
  sky130_fd_sc_hd__a22oi_1 U2494 ( .A1(\cpuregs[22][28] ), .A2(n1765), .B1(
        \cpuregs[23][28] ), .B2(n1764), .Y(n1701) );
  sky130_fd_sc_hd__a22oi_1 U2495 ( .A1(\cpuregs[20][28] ), .A2(n1767), .B1(
        \cpuregs[21][28] ), .B2(n1766), .Y(n1700) );
  sky130_fd_sc_hd__a22oi_1 U2496 ( .A1(\cpuregs[18][28] ), .A2(n1769), .B1(
        \cpuregs[19][28] ), .B2(n1768), .Y(n1699) );
  sky130_fd_sc_hd__a22oi_1 U2497 ( .A1(\cpuregs[16][28] ), .A2(n1771), .B1(
        \cpuregs[17][28] ), .B2(n1770), .Y(n1698) );
  sky130_fd_sc_hd__nand4_1 U2498 ( .A(n1701), .B(n1700), .C(n1699), .D(n1698), 
        .Y(n1707) );
  sky130_fd_sc_hd__a22oi_1 U2499 ( .A1(\cpuregs[30][28] ), .A2(n1777), .B1(
        \cpuregs[31][28] ), .B2(n1776), .Y(n1705) );
  sky130_fd_sc_hd__a22oi_1 U2500 ( .A1(\cpuregs[28][28] ), .A2(n1779), .B1(
        \cpuregs[29][28] ), .B2(n1778), .Y(n1704) );
  sky130_fd_sc_hd__a22oi_1 U2501 ( .A1(\cpuregs[26][28] ), .A2(n1781), .B1(
        \cpuregs[27][28] ), .B2(n1780), .Y(n1703) );
  sky130_fd_sc_hd__a22oi_1 U2502 ( .A1(\cpuregs[24][28] ), .A2(n1783), .B1(
        \cpuregs[25][28] ), .B2(n1782), .Y(n1702) );
  sky130_fd_sc_hd__nand4_1 U2503 ( .A(n1705), .B(n1704), .C(n1703), .D(n1702), 
        .Y(n1706) );
  sky130_fd_sc_hd__o21ai_0 U2504 ( .A1(n1707), .A2(n1706), .B1(N86), .Y(n1708)
         );
  sky130_fd_sc_hd__nand2_1 U2505 ( .A(n1709), .B(n1708), .Y(N755) );
  sky130_fd_sc_hd__a22oi_1 U2506 ( .A1(\cpuregs[6][29] ), .A2(n1765), .B1(
        \cpuregs[7][29] ), .B2(n1764), .Y(n1713) );
  sky130_fd_sc_hd__a22oi_1 U2507 ( .A1(\cpuregs[4][29] ), .A2(n1767), .B1(
        \cpuregs[5][29] ), .B2(n1766), .Y(n1712) );
  sky130_fd_sc_hd__a22oi_1 U2508 ( .A1(\cpuregs[2][29] ), .A2(n1769), .B1(
        \cpuregs[3][29] ), .B2(n1768), .Y(n1711) );
  sky130_fd_sc_hd__a22oi_1 U2509 ( .A1(\cpuregs[0][29] ), .A2(n1771), .B1(
        \cpuregs[1][29] ), .B2(n1770), .Y(n1710) );
  sky130_fd_sc_hd__nand4_1 U2510 ( .A(n1713), .B(n1712), .C(n1711), .D(n1710), 
        .Y(n1719) );
  sky130_fd_sc_hd__a22oi_1 U2511 ( .A1(\cpuregs[14][29] ), .A2(n1777), .B1(
        \cpuregs[15][29] ), .B2(n1776), .Y(n1717) );
  sky130_fd_sc_hd__a22oi_1 U2512 ( .A1(\cpuregs[12][29] ), .A2(n1779), .B1(
        \cpuregs[13][29] ), .B2(n1778), .Y(n1716) );
  sky130_fd_sc_hd__a22oi_1 U2513 ( .A1(\cpuregs[10][29] ), .A2(n1781), .B1(
        \cpuregs[11][29] ), .B2(n1780), .Y(n1715) );
  sky130_fd_sc_hd__a22oi_1 U2514 ( .A1(\cpuregs[8][29] ), .A2(n1783), .B1(
        \cpuregs[9][29] ), .B2(n1782), .Y(n1714) );
  sky130_fd_sc_hd__nand4_1 U2515 ( .A(n1717), .B(n1716), .C(n1715), .D(n1714), 
        .Y(n1718) );
  sky130_fd_sc_hd__o21ai_0 U2516 ( .A1(n1719), .A2(n1718), .B1(n1795), .Y(
        n1731) );
  sky130_fd_sc_hd__a22oi_1 U2517 ( .A1(\cpuregs[22][29] ), .A2(n1765), .B1(
        \cpuregs[23][29] ), .B2(n1764), .Y(n1723) );
  sky130_fd_sc_hd__a22oi_1 U2518 ( .A1(\cpuregs[20][29] ), .A2(n1767), .B1(
        \cpuregs[21][29] ), .B2(n1766), .Y(n1722) );
  sky130_fd_sc_hd__a22oi_1 U2519 ( .A1(\cpuregs[18][29] ), .A2(n1769), .B1(
        \cpuregs[19][29] ), .B2(n1768), .Y(n1721) );
  sky130_fd_sc_hd__a22oi_1 U2520 ( .A1(\cpuregs[16][29] ), .A2(n1771), .B1(
        \cpuregs[17][29] ), .B2(n1770), .Y(n1720) );
  sky130_fd_sc_hd__nand4_1 U2521 ( .A(n1723), .B(n1722), .C(n1721), .D(n1720), 
        .Y(n1729) );
  sky130_fd_sc_hd__a22oi_1 U2522 ( .A1(\cpuregs[30][29] ), .A2(n1777), .B1(
        \cpuregs[31][29] ), .B2(n1776), .Y(n1727) );
  sky130_fd_sc_hd__a22oi_1 U2523 ( .A1(\cpuregs[28][29] ), .A2(n1779), .B1(
        \cpuregs[29][29] ), .B2(n1778), .Y(n1726) );
  sky130_fd_sc_hd__a22oi_1 U2524 ( .A1(\cpuregs[26][29] ), .A2(n1781), .B1(
        \cpuregs[27][29] ), .B2(n1780), .Y(n1725) );
  sky130_fd_sc_hd__a22oi_1 U2525 ( .A1(\cpuregs[24][29] ), .A2(n1783), .B1(
        \cpuregs[25][29] ), .B2(n1782), .Y(n1724) );
  sky130_fd_sc_hd__nand4_1 U2526 ( .A(n1727), .B(n1726), .C(n1725), .D(n1724), 
        .Y(n1728) );
  sky130_fd_sc_hd__o21ai_0 U2527 ( .A1(n1729), .A2(n1728), .B1(N86), .Y(n1730)
         );
  sky130_fd_sc_hd__nand2_1 U2528 ( .A(n1731), .B(n1730), .Y(N754) );
  sky130_fd_sc_hd__a22oi_1 U2529 ( .A1(\cpuregs[6][30] ), .A2(n1765), .B1(
        \cpuregs[7][30] ), .B2(n1764), .Y(n1735) );
  sky130_fd_sc_hd__a22oi_1 U2530 ( .A1(\cpuregs[4][30] ), .A2(n1767), .B1(
        \cpuregs[5][30] ), .B2(n1766), .Y(n1734) );
  sky130_fd_sc_hd__a22oi_1 U2531 ( .A1(\cpuregs[2][30] ), .A2(n1769), .B1(
        \cpuregs[3][30] ), .B2(n1768), .Y(n1733) );
  sky130_fd_sc_hd__a22oi_1 U2532 ( .A1(\cpuregs[0][30] ), .A2(n1771), .B1(
        \cpuregs[1][30] ), .B2(n1770), .Y(n1732) );
  sky130_fd_sc_hd__nand4_1 U2533 ( .A(n1735), .B(n1734), .C(n1733), .D(n1732), 
        .Y(n1741) );
  sky130_fd_sc_hd__a22oi_1 U2534 ( .A1(\cpuregs[14][30] ), .A2(n1777), .B1(
        \cpuregs[15][30] ), .B2(n1776), .Y(n1739) );
  sky130_fd_sc_hd__a22oi_1 U2535 ( .A1(\cpuregs[12][30] ), .A2(n1779), .B1(
        \cpuregs[13][30] ), .B2(n1778), .Y(n1738) );
  sky130_fd_sc_hd__a22oi_1 U2536 ( .A1(\cpuregs[10][30] ), .A2(n1781), .B1(
        \cpuregs[11][30] ), .B2(n1780), .Y(n1737) );
  sky130_fd_sc_hd__a22oi_1 U2537 ( .A1(\cpuregs[8][30] ), .A2(n1783), .B1(
        \cpuregs[9][30] ), .B2(n1782), .Y(n1736) );
  sky130_fd_sc_hd__nand4_1 U2538 ( .A(n1739), .B(n1738), .C(n1737), .D(n1736), 
        .Y(n1740) );
  sky130_fd_sc_hd__o21ai_0 U2539 ( .A1(n1741), .A2(n1740), .B1(n1795), .Y(
        n1753) );
  sky130_fd_sc_hd__a22oi_1 U2540 ( .A1(\cpuregs[22][30] ), .A2(n1765), .B1(
        \cpuregs[23][30] ), .B2(n1764), .Y(n1745) );
  sky130_fd_sc_hd__a22oi_1 U2541 ( .A1(\cpuregs[20][30] ), .A2(n1767), .B1(
        \cpuregs[21][30] ), .B2(n1766), .Y(n1744) );
  sky130_fd_sc_hd__a22oi_1 U2542 ( .A1(\cpuregs[18][30] ), .A2(n1769), .B1(
        \cpuregs[19][30] ), .B2(n1768), .Y(n1743) );
  sky130_fd_sc_hd__a22oi_1 U2543 ( .A1(\cpuregs[16][30] ), .A2(n1771), .B1(
        \cpuregs[17][30] ), .B2(n1770), .Y(n1742) );
  sky130_fd_sc_hd__nand4_1 U2544 ( .A(n1745), .B(n1744), .C(n1743), .D(n1742), 
        .Y(n1751) );
  sky130_fd_sc_hd__a22oi_1 U2545 ( .A1(\cpuregs[30][30] ), .A2(n1777), .B1(
        \cpuregs[31][30] ), .B2(n1776), .Y(n1749) );
  sky130_fd_sc_hd__a22oi_1 U2546 ( .A1(\cpuregs[28][30] ), .A2(n1779), .B1(
        \cpuregs[29][30] ), .B2(n1778), .Y(n1748) );
  sky130_fd_sc_hd__a22oi_1 U2547 ( .A1(\cpuregs[26][30] ), .A2(n1781), .B1(
        \cpuregs[27][30] ), .B2(n1780), .Y(n1747) );
  sky130_fd_sc_hd__a22oi_1 U2548 ( .A1(\cpuregs[24][30] ), .A2(n1783), .B1(
        \cpuregs[25][30] ), .B2(n1782), .Y(n1746) );
  sky130_fd_sc_hd__nand4_1 U2549 ( .A(n1749), .B(n1748), .C(n1747), .D(n1746), 
        .Y(n1750) );
  sky130_fd_sc_hd__o21ai_0 U2550 ( .A1(n1751), .A2(n1750), .B1(N86), .Y(n1752)
         );
  sky130_fd_sc_hd__nand2_1 U2551 ( .A(n1753), .B(n1752), .Y(N753) );
  sky130_fd_sc_hd__a22oi_1 U2552 ( .A1(\cpuregs[6][31] ), .A2(n1765), .B1(
        \cpuregs[7][31] ), .B2(n1764), .Y(n1757) );
  sky130_fd_sc_hd__a22oi_1 U2553 ( .A1(\cpuregs[4][31] ), .A2(n1767), .B1(
        \cpuregs[5][31] ), .B2(n1766), .Y(n1756) );
  sky130_fd_sc_hd__a22oi_1 U2554 ( .A1(\cpuregs[2][31] ), .A2(n1769), .B1(
        \cpuregs[3][31] ), .B2(n1768), .Y(n1755) );
  sky130_fd_sc_hd__a22oi_1 U2555 ( .A1(\cpuregs[0][31] ), .A2(n1771), .B1(
        \cpuregs[1][31] ), .B2(n1770), .Y(n1754) );
  sky130_fd_sc_hd__nand4_1 U2556 ( .A(n1757), .B(n1756), .C(n1755), .D(n1754), 
        .Y(n1763) );
  sky130_fd_sc_hd__a22oi_1 U2557 ( .A1(\cpuregs[14][31] ), .A2(n1777), .B1(
        \cpuregs[15][31] ), .B2(n1776), .Y(n1761) );
  sky130_fd_sc_hd__a22oi_1 U2558 ( .A1(\cpuregs[12][31] ), .A2(n1779), .B1(
        \cpuregs[13][31] ), .B2(n1778), .Y(n1760) );
  sky130_fd_sc_hd__a22oi_1 U2559 ( .A1(\cpuregs[10][31] ), .A2(n1781), .B1(
        \cpuregs[11][31] ), .B2(n1780), .Y(n1759) );
  sky130_fd_sc_hd__a22oi_1 U2560 ( .A1(\cpuregs[8][31] ), .A2(n1783), .B1(
        \cpuregs[9][31] ), .B2(n1782), .Y(n1758) );
  sky130_fd_sc_hd__nand4_1 U2561 ( .A(n1761), .B(n1760), .C(n1759), .D(n1758), 
        .Y(n1762) );
  sky130_fd_sc_hd__o21ai_0 U2562 ( .A1(n1763), .A2(n1762), .B1(n1795), .Y(
        n1791) );
  sky130_fd_sc_hd__a22oi_1 U2563 ( .A1(\cpuregs[22][31] ), .A2(n1765), .B1(
        \cpuregs[23][31] ), .B2(n1764), .Y(n1775) );
  sky130_fd_sc_hd__a22oi_1 U2564 ( .A1(\cpuregs[20][31] ), .A2(n1767), .B1(
        \cpuregs[21][31] ), .B2(n1766), .Y(n1774) );
  sky130_fd_sc_hd__a22oi_1 U2565 ( .A1(\cpuregs[18][31] ), .A2(n1769), .B1(
        \cpuregs[19][31] ), .B2(n1768), .Y(n1773) );
  sky130_fd_sc_hd__a22oi_1 U2566 ( .A1(\cpuregs[16][31] ), .A2(n1771), .B1(
        \cpuregs[17][31] ), .B2(n1770), .Y(n1772) );
  sky130_fd_sc_hd__nand4_1 U2567 ( .A(n1775), .B(n1774), .C(n1773), .D(n1772), 
        .Y(n1789) );
  sky130_fd_sc_hd__a22oi_1 U2568 ( .A1(\cpuregs[30][31] ), .A2(n1777), .B1(
        \cpuregs[31][31] ), .B2(n1776), .Y(n1787) );
  sky130_fd_sc_hd__a22oi_1 U2569 ( .A1(\cpuregs[28][31] ), .A2(n1779), .B1(
        \cpuregs[29][31] ), .B2(n1778), .Y(n1786) );
  sky130_fd_sc_hd__a22oi_1 U2570 ( .A1(\cpuregs[26][31] ), .A2(n1781), .B1(
        \cpuregs[27][31] ), .B2(n1780), .Y(n1785) );
  sky130_fd_sc_hd__a22oi_1 U2571 ( .A1(\cpuregs[24][31] ), .A2(n1783), .B1(
        \cpuregs[25][31] ), .B2(n1782), .Y(n1784) );
  sky130_fd_sc_hd__nand4_1 U2572 ( .A(n1787), .B(n1786), .C(n1785), .D(n1784), 
        .Y(n1788) );
  sky130_fd_sc_hd__o21ai_0 U2573 ( .A1(n1789), .A2(n1788), .B1(N86), .Y(n1790)
         );
  sky130_fd_sc_hd__nand2_1 U2574 ( .A(n1791), .B(n1790), .Y(N752) );
  sky130_fd_sc_hd__nor2_1 U2575 ( .A(n2526), .B(N90), .Y(n1796) );
  sky130_fd_sc_hd__nor2_1 U2576 ( .A(n2525), .B(N87), .Y(n1803) );
  sky130_fd_sc_hd__nor2_1 U2577 ( .A(n2525), .B(n2524), .Y(n1804) );
  sky130_fd_sc_hd__a22oi_1 U2578 ( .A1(\cpuregs[6][0] ), .A2(n2497), .B1(
        \cpuregs[7][0] ), .B2(n2496), .Y(n1801) );
  sky130_fd_sc_hd__nor2_1 U2579 ( .A(N87), .B(N88), .Y(n1805) );
  sky130_fd_sc_hd__nor2_1 U2580 ( .A(n2524), .B(N88), .Y(n1806) );
  sky130_fd_sc_hd__a22oi_1 U2581 ( .A1(\cpuregs[4][0] ), .A2(n2499), .B1(
        \cpuregs[5][0] ), .B2(n2498), .Y(n1800) );
  sky130_fd_sc_hd__nor2_1 U2582 ( .A(N89), .B(N90), .Y(n1797) );
  sky130_fd_sc_hd__a22oi_1 U2583 ( .A1(\cpuregs[2][0] ), .A2(n2501), .B1(
        \cpuregs[3][0] ), .B2(n2500), .Y(n1799) );
  sky130_fd_sc_hd__a22oi_1 U2584 ( .A1(\cpuregs[0][0] ), .A2(n2503), .B1(
        \cpuregs[1][0] ), .B2(n2502), .Y(n1798) );
  sky130_fd_sc_hd__nand4_1 U2585 ( .A(n1801), .B(n1800), .C(n1799), .D(n1798), 
        .Y(n1813) );
  sky130_fd_sc_hd__and2_0 U2586 ( .A(N90), .B(N89), .X(n1802) );
  sky130_fd_sc_hd__a22oi_1 U2587 ( .A1(\cpuregs[14][0] ), .A2(n2509), .B1(
        \cpuregs[15][0] ), .B2(n2508), .Y(n1811) );
  sky130_fd_sc_hd__a22oi_1 U2588 ( .A1(\cpuregs[12][0] ), .A2(n2511), .B1(
        \cpuregs[13][0] ), .B2(n2510), .Y(n1810) );
  sky130_fd_sc_hd__and2_0 U2589 ( .A(N90), .B(n2526), .X(n1807) );
  sky130_fd_sc_hd__a22oi_1 U2590 ( .A1(\cpuregs[10][0] ), .A2(n2513), .B1(
        \cpuregs[11][0] ), .B2(n2512), .Y(n1809) );
  sky130_fd_sc_hd__a22oi_1 U2591 ( .A1(\cpuregs[8][0] ), .A2(n2515), .B1(
        \cpuregs[9][0] ), .B2(n2514), .Y(n1808) );
  sky130_fd_sc_hd__nand4_1 U2592 ( .A(n1811), .B(n1810), .C(n1809), .D(n1808), 
        .Y(n1812) );
  sky130_fd_sc_hd__o21ai_0 U2593 ( .A1(n1813), .A2(n1812), .B1(n2527), .Y(
        n1825) );
  sky130_fd_sc_hd__a22oi_1 U2594 ( .A1(\cpuregs[22][0] ), .A2(n2497), .B1(
        \cpuregs[23][0] ), .B2(n2496), .Y(n1817) );
  sky130_fd_sc_hd__a22oi_1 U2595 ( .A1(\cpuregs[20][0] ), .A2(n2499), .B1(
        \cpuregs[21][0] ), .B2(n2498), .Y(n1816) );
  sky130_fd_sc_hd__a22oi_1 U2596 ( .A1(\cpuregs[18][0] ), .A2(n2501), .B1(
        \cpuregs[19][0] ), .B2(n2500), .Y(n1815) );
  sky130_fd_sc_hd__a22oi_1 U2597 ( .A1(\cpuregs[16][0] ), .A2(n2503), .B1(
        \cpuregs[17][0] ), .B2(n2502), .Y(n1814) );
  sky130_fd_sc_hd__nand4_1 U2598 ( .A(n1817), .B(n1816), .C(n1815), .D(n1814), 
        .Y(n1823) );
  sky130_fd_sc_hd__a22oi_1 U2599 ( .A1(\cpuregs[30][0] ), .A2(n2509), .B1(
        \cpuregs[31][0] ), .B2(n2508), .Y(n1821) );
  sky130_fd_sc_hd__a22oi_1 U2600 ( .A1(\cpuregs[28][0] ), .A2(n2511), .B1(
        \cpuregs[29][0] ), .B2(n2510), .Y(n1820) );
  sky130_fd_sc_hd__a22oi_1 U2601 ( .A1(\cpuregs[26][0] ), .A2(n2513), .B1(
        \cpuregs[27][0] ), .B2(n2512), .Y(n1819) );
  sky130_fd_sc_hd__a22oi_1 U2602 ( .A1(\cpuregs[24][0] ), .A2(n2515), .B1(
        \cpuregs[25][0] ), .B2(n2514), .Y(n1818) );
  sky130_fd_sc_hd__nand4_1 U2603 ( .A(n1821), .B(n1820), .C(n1819), .D(n1818), 
        .Y(n1822) );
  sky130_fd_sc_hd__o21ai_0 U2604 ( .A1(n1823), .A2(n1822), .B1(N91), .Y(n1824)
         );
  sky130_fd_sc_hd__nand2_1 U2605 ( .A(n1825), .B(n1824), .Y(N817) );
  sky130_fd_sc_hd__a22oi_1 U2606 ( .A1(\cpuregs[6][1] ), .A2(n2497), .B1(
        \cpuregs[7][1] ), .B2(n2496), .Y(n1829) );
  sky130_fd_sc_hd__a22oi_1 U2607 ( .A1(\cpuregs[4][1] ), .A2(n2499), .B1(
        \cpuregs[5][1] ), .B2(n2498), .Y(n1828) );
  sky130_fd_sc_hd__a22oi_1 U2608 ( .A1(\cpuregs[2][1] ), .A2(n2501), .B1(
        \cpuregs[3][1] ), .B2(n2500), .Y(n1827) );
  sky130_fd_sc_hd__a22oi_1 U2609 ( .A1(\cpuregs[0][1] ), .A2(n2503), .B1(
        \cpuregs[1][1] ), .B2(n2502), .Y(n1826) );
  sky130_fd_sc_hd__nand4_1 U2610 ( .A(n1829), .B(n1828), .C(n1827), .D(n1826), 
        .Y(n1835) );
  sky130_fd_sc_hd__a22oi_1 U2611 ( .A1(\cpuregs[14][1] ), .A2(n2509), .B1(
        \cpuregs[15][1] ), .B2(n2508), .Y(n1833) );
  sky130_fd_sc_hd__a22oi_1 U2612 ( .A1(\cpuregs[12][1] ), .A2(n2511), .B1(
        \cpuregs[13][1] ), .B2(n2510), .Y(n1832) );
  sky130_fd_sc_hd__a22oi_1 U2613 ( .A1(\cpuregs[10][1] ), .A2(n2513), .B1(
        \cpuregs[11][1] ), .B2(n2512), .Y(n1831) );
  sky130_fd_sc_hd__a22oi_1 U2614 ( .A1(\cpuregs[8][1] ), .A2(n2515), .B1(
        \cpuregs[9][1] ), .B2(n2514), .Y(n1830) );
  sky130_fd_sc_hd__nand4_1 U2615 ( .A(n1833), .B(n1832), .C(n1831), .D(n1830), 
        .Y(n1834) );
  sky130_fd_sc_hd__o21ai_0 U2616 ( .A1(n1835), .A2(n1834), .B1(n2527), .Y(
        n1847) );
  sky130_fd_sc_hd__a22oi_1 U2617 ( .A1(\cpuregs[22][1] ), .A2(n2497), .B1(
        \cpuregs[23][1] ), .B2(n2496), .Y(n1839) );
  sky130_fd_sc_hd__a22oi_1 U2618 ( .A1(\cpuregs[20][1] ), .A2(n2499), .B1(
        \cpuregs[21][1] ), .B2(n2498), .Y(n1838) );
  sky130_fd_sc_hd__a22oi_1 U2619 ( .A1(\cpuregs[18][1] ), .A2(n2501), .B1(
        \cpuregs[19][1] ), .B2(n2500), .Y(n1837) );
  sky130_fd_sc_hd__a22oi_1 U2620 ( .A1(\cpuregs[16][1] ), .A2(n2503), .B1(
        \cpuregs[17][1] ), .B2(n2502), .Y(n1836) );
  sky130_fd_sc_hd__nand4_1 U2621 ( .A(n1839), .B(n1838), .C(n1837), .D(n1836), 
        .Y(n1845) );
  sky130_fd_sc_hd__a22oi_1 U2622 ( .A1(\cpuregs[30][1] ), .A2(n2509), .B1(
        \cpuregs[31][1] ), .B2(n2508), .Y(n1843) );
  sky130_fd_sc_hd__a22oi_1 U2623 ( .A1(\cpuregs[28][1] ), .A2(n2511), .B1(
        \cpuregs[29][1] ), .B2(n2510), .Y(n1842) );
  sky130_fd_sc_hd__a22oi_1 U2624 ( .A1(\cpuregs[26][1] ), .A2(n2513), .B1(
        \cpuregs[27][1] ), .B2(n2512), .Y(n1841) );
  sky130_fd_sc_hd__a22oi_1 U2625 ( .A1(\cpuregs[24][1] ), .A2(n2515), .B1(
        \cpuregs[25][1] ), .B2(n2514), .Y(n1840) );
  sky130_fd_sc_hd__nand4_1 U2626 ( .A(n1843), .B(n1842), .C(n1841), .D(n1840), 
        .Y(n1844) );
  sky130_fd_sc_hd__o21ai_0 U2627 ( .A1(n1845), .A2(n1844), .B1(N91), .Y(n1846)
         );
  sky130_fd_sc_hd__nand2_1 U2628 ( .A(n1847), .B(n1846), .Y(N816) );
  sky130_fd_sc_hd__a22oi_1 U2629 ( .A1(\cpuregs[6][2] ), .A2(n2497), .B1(
        \cpuregs[7][2] ), .B2(n2496), .Y(n1851) );
  sky130_fd_sc_hd__a22oi_1 U2630 ( .A1(\cpuregs[4][2] ), .A2(n2499), .B1(
        \cpuregs[5][2] ), .B2(n2498), .Y(n1850) );
  sky130_fd_sc_hd__a22oi_1 U2631 ( .A1(\cpuregs[2][2] ), .A2(n2501), .B1(
        \cpuregs[3][2] ), .B2(n2500), .Y(n1849) );
  sky130_fd_sc_hd__a22oi_1 U2632 ( .A1(\cpuregs[0][2] ), .A2(n2503), .B1(
        \cpuregs[1][2] ), .B2(n2502), .Y(n1848) );
  sky130_fd_sc_hd__nand4_1 U2633 ( .A(n1851), .B(n1850), .C(n1849), .D(n1848), 
        .Y(n1857) );
  sky130_fd_sc_hd__a22oi_1 U2634 ( .A1(\cpuregs[14][2] ), .A2(n2509), .B1(
        \cpuregs[15][2] ), .B2(n2508), .Y(n1855) );
  sky130_fd_sc_hd__a22oi_1 U2635 ( .A1(\cpuregs[12][2] ), .A2(n2511), .B1(
        \cpuregs[13][2] ), .B2(n2510), .Y(n1854) );
  sky130_fd_sc_hd__a22oi_1 U2636 ( .A1(\cpuregs[10][2] ), .A2(n2513), .B1(
        \cpuregs[11][2] ), .B2(n2512), .Y(n1853) );
  sky130_fd_sc_hd__a22oi_1 U2637 ( .A1(\cpuregs[8][2] ), .A2(n2515), .B1(
        \cpuregs[9][2] ), .B2(n2514), .Y(n1852) );
  sky130_fd_sc_hd__nand4_1 U2638 ( .A(n1855), .B(n1854), .C(n1853), .D(n1852), 
        .Y(n1856) );
  sky130_fd_sc_hd__o21ai_0 U2639 ( .A1(n1857), .A2(n1856), .B1(n2527), .Y(
        n1869) );
  sky130_fd_sc_hd__a22oi_1 U2640 ( .A1(\cpuregs[22][2] ), .A2(n2497), .B1(
        \cpuregs[23][2] ), .B2(n2496), .Y(n1861) );
  sky130_fd_sc_hd__a22oi_1 U2641 ( .A1(\cpuregs[20][2] ), .A2(n2499), .B1(
        \cpuregs[21][2] ), .B2(n2498), .Y(n1860) );
  sky130_fd_sc_hd__a22oi_1 U2642 ( .A1(\cpuregs[18][2] ), .A2(n2501), .B1(
        \cpuregs[19][2] ), .B2(n2500), .Y(n1859) );
  sky130_fd_sc_hd__a22oi_1 U2643 ( .A1(\cpuregs[16][2] ), .A2(n2503), .B1(
        \cpuregs[17][2] ), .B2(n2502), .Y(n1858) );
  sky130_fd_sc_hd__nand4_1 U2644 ( .A(n1861), .B(n1860), .C(n1859), .D(n1858), 
        .Y(n1867) );
  sky130_fd_sc_hd__a22oi_1 U2645 ( .A1(\cpuregs[30][2] ), .A2(n2509), .B1(
        \cpuregs[31][2] ), .B2(n2508), .Y(n1865) );
  sky130_fd_sc_hd__a22oi_1 U2646 ( .A1(\cpuregs[28][2] ), .A2(n2511), .B1(
        \cpuregs[29][2] ), .B2(n2510), .Y(n1864) );
  sky130_fd_sc_hd__a22oi_1 U2647 ( .A1(\cpuregs[26][2] ), .A2(n2513), .B1(
        \cpuregs[27][2] ), .B2(n2512), .Y(n1863) );
  sky130_fd_sc_hd__a22oi_1 U2648 ( .A1(\cpuregs[24][2] ), .A2(n2515), .B1(
        \cpuregs[25][2] ), .B2(n2514), .Y(n1862) );
  sky130_fd_sc_hd__nand4_1 U2649 ( .A(n1865), .B(n1864), .C(n1863), .D(n1862), 
        .Y(n1866) );
  sky130_fd_sc_hd__o21ai_0 U2650 ( .A1(n1867), .A2(n1866), .B1(N91), .Y(n1868)
         );
  sky130_fd_sc_hd__nand2_1 U2651 ( .A(n1869), .B(n1868), .Y(N815) );
  sky130_fd_sc_hd__a22oi_1 U2652 ( .A1(\cpuregs[6][3] ), .A2(n2497), .B1(
        \cpuregs[7][3] ), .B2(n2496), .Y(n1873) );
  sky130_fd_sc_hd__a22oi_1 U2653 ( .A1(\cpuregs[4][3] ), .A2(n2499), .B1(
        \cpuregs[5][3] ), .B2(n2498), .Y(n1872) );
  sky130_fd_sc_hd__a22oi_1 U2654 ( .A1(\cpuregs[2][3] ), .A2(n2501), .B1(
        \cpuregs[3][3] ), .B2(n2500), .Y(n1871) );
  sky130_fd_sc_hd__a22oi_1 U2655 ( .A1(\cpuregs[0][3] ), .A2(n2503), .B1(
        \cpuregs[1][3] ), .B2(n2502), .Y(n1870) );
  sky130_fd_sc_hd__nand4_1 U2656 ( .A(n1873), .B(n1872), .C(n1871), .D(n1870), 
        .Y(n1879) );
  sky130_fd_sc_hd__a22oi_1 U2657 ( .A1(\cpuregs[14][3] ), .A2(n2509), .B1(
        \cpuregs[15][3] ), .B2(n2508), .Y(n1877) );
  sky130_fd_sc_hd__a22oi_1 U2658 ( .A1(\cpuregs[12][3] ), .A2(n2511), .B1(
        \cpuregs[13][3] ), .B2(n2510), .Y(n1876) );
  sky130_fd_sc_hd__a22oi_1 U2659 ( .A1(\cpuregs[10][3] ), .A2(n2513), .B1(
        \cpuregs[11][3] ), .B2(n2512), .Y(n1875) );
  sky130_fd_sc_hd__a22oi_1 U2660 ( .A1(\cpuregs[8][3] ), .A2(n2515), .B1(
        \cpuregs[9][3] ), .B2(n2514), .Y(n1874) );
  sky130_fd_sc_hd__nand4_1 U2661 ( .A(n1877), .B(n1876), .C(n1875), .D(n1874), 
        .Y(n1878) );
  sky130_fd_sc_hd__o21ai_0 U2662 ( .A1(n1879), .A2(n1878), .B1(n2527), .Y(
        n1891) );
  sky130_fd_sc_hd__a22oi_1 U2663 ( .A1(\cpuregs[22][3] ), .A2(n2497), .B1(
        \cpuregs[23][3] ), .B2(n2496), .Y(n1883) );
  sky130_fd_sc_hd__a22oi_1 U2664 ( .A1(\cpuregs[20][3] ), .A2(n2499), .B1(
        \cpuregs[21][3] ), .B2(n2498), .Y(n1882) );
  sky130_fd_sc_hd__a22oi_1 U2665 ( .A1(\cpuregs[18][3] ), .A2(n2501), .B1(
        \cpuregs[19][3] ), .B2(n2500), .Y(n1881) );
  sky130_fd_sc_hd__a22oi_1 U2666 ( .A1(\cpuregs[16][3] ), .A2(n2503), .B1(
        \cpuregs[17][3] ), .B2(n2502), .Y(n1880) );
  sky130_fd_sc_hd__nand4_1 U2667 ( .A(n1883), .B(n1882), .C(n1881), .D(n1880), 
        .Y(n1889) );
  sky130_fd_sc_hd__a22oi_1 U2668 ( .A1(\cpuregs[30][3] ), .A2(n2509), .B1(
        \cpuregs[31][3] ), .B2(n2508), .Y(n1887) );
  sky130_fd_sc_hd__a22oi_1 U2669 ( .A1(\cpuregs[28][3] ), .A2(n2511), .B1(
        \cpuregs[29][3] ), .B2(n2510), .Y(n1886) );
  sky130_fd_sc_hd__a22oi_1 U2670 ( .A1(\cpuregs[26][3] ), .A2(n2513), .B1(
        \cpuregs[27][3] ), .B2(n2512), .Y(n1885) );
  sky130_fd_sc_hd__a22oi_1 U2671 ( .A1(\cpuregs[24][3] ), .A2(n2515), .B1(
        \cpuregs[25][3] ), .B2(n2514), .Y(n1884) );
  sky130_fd_sc_hd__nand4_1 U2672 ( .A(n1887), .B(n1886), .C(n1885), .D(n1884), 
        .Y(n1888) );
  sky130_fd_sc_hd__o21ai_0 U2673 ( .A1(n1889), .A2(n1888), .B1(N91), .Y(n1890)
         );
  sky130_fd_sc_hd__nand2_1 U2674 ( .A(n1891), .B(n1890), .Y(N814) );
  sky130_fd_sc_hd__a22oi_1 U2675 ( .A1(\cpuregs[6][4] ), .A2(n2497), .B1(
        \cpuregs[7][4] ), .B2(n2496), .Y(n1895) );
  sky130_fd_sc_hd__a22oi_1 U2676 ( .A1(\cpuregs[4][4] ), .A2(n2499), .B1(
        \cpuregs[5][4] ), .B2(n2498), .Y(n1894) );
  sky130_fd_sc_hd__a22oi_1 U2677 ( .A1(\cpuregs[2][4] ), .A2(n2501), .B1(
        \cpuregs[3][4] ), .B2(n2500), .Y(n1893) );
  sky130_fd_sc_hd__a22oi_1 U2678 ( .A1(\cpuregs[0][4] ), .A2(n2503), .B1(
        \cpuregs[1][4] ), .B2(n2502), .Y(n1892) );
  sky130_fd_sc_hd__nand4_1 U2679 ( .A(n1895), .B(n1894), .C(n1893), .D(n1892), 
        .Y(n1901) );
  sky130_fd_sc_hd__a22oi_1 U2680 ( .A1(\cpuregs[14][4] ), .A2(n2509), .B1(
        \cpuregs[15][4] ), .B2(n2508), .Y(n1899) );
  sky130_fd_sc_hd__a22oi_1 U2681 ( .A1(\cpuregs[12][4] ), .A2(n2511), .B1(
        \cpuregs[13][4] ), .B2(n2510), .Y(n1898) );
  sky130_fd_sc_hd__a22oi_1 U2682 ( .A1(\cpuregs[10][4] ), .A2(n2513), .B1(
        \cpuregs[11][4] ), .B2(n2512), .Y(n1897) );
  sky130_fd_sc_hd__a22oi_1 U2683 ( .A1(\cpuregs[8][4] ), .A2(n2515), .B1(
        \cpuregs[9][4] ), .B2(n2514), .Y(n1896) );
  sky130_fd_sc_hd__nand4_1 U2684 ( .A(n1899), .B(n1898), .C(n1897), .D(n1896), 
        .Y(n1900) );
  sky130_fd_sc_hd__o21ai_0 U2685 ( .A1(n1901), .A2(n1900), .B1(n2527), .Y(
        n1913) );
  sky130_fd_sc_hd__a22oi_1 U2686 ( .A1(\cpuregs[22][4] ), .A2(n2497), .B1(
        \cpuregs[23][4] ), .B2(n2496), .Y(n1905) );
  sky130_fd_sc_hd__a22oi_1 U2687 ( .A1(\cpuregs[20][4] ), .A2(n2499), .B1(
        \cpuregs[21][4] ), .B2(n2498), .Y(n1904) );
  sky130_fd_sc_hd__a22oi_1 U2688 ( .A1(\cpuregs[18][4] ), .A2(n2501), .B1(
        \cpuregs[19][4] ), .B2(n2500), .Y(n1903) );
  sky130_fd_sc_hd__a22oi_1 U2689 ( .A1(\cpuregs[16][4] ), .A2(n2503), .B1(
        \cpuregs[17][4] ), .B2(n2502), .Y(n1902) );
  sky130_fd_sc_hd__nand4_1 U2690 ( .A(n1905), .B(n1904), .C(n1903), .D(n1902), 
        .Y(n1911) );
  sky130_fd_sc_hd__a22oi_1 U2691 ( .A1(\cpuregs[30][4] ), .A2(n2509), .B1(
        \cpuregs[31][4] ), .B2(n2508), .Y(n1909) );
  sky130_fd_sc_hd__a22oi_1 U2692 ( .A1(\cpuregs[28][4] ), .A2(n2511), .B1(
        \cpuregs[29][4] ), .B2(n2510), .Y(n1908) );
  sky130_fd_sc_hd__a22oi_1 U2693 ( .A1(\cpuregs[26][4] ), .A2(n2513), .B1(
        \cpuregs[27][4] ), .B2(n2512), .Y(n1907) );
  sky130_fd_sc_hd__a22oi_1 U2694 ( .A1(\cpuregs[24][4] ), .A2(n2515), .B1(
        \cpuregs[25][4] ), .B2(n2514), .Y(n1906) );
  sky130_fd_sc_hd__nand4_1 U2695 ( .A(n1909), .B(n1908), .C(n1907), .D(n1906), 
        .Y(n1910) );
  sky130_fd_sc_hd__o21ai_0 U2696 ( .A1(n1911), .A2(n1910), .B1(N91), .Y(n1912)
         );
  sky130_fd_sc_hd__nand2_1 U2697 ( .A(n1913), .B(n1912), .Y(N813) );
  sky130_fd_sc_hd__a22oi_1 U2698 ( .A1(\cpuregs[6][5] ), .A2(n2497), .B1(
        \cpuregs[7][5] ), .B2(n2496), .Y(n1917) );
  sky130_fd_sc_hd__a22oi_1 U2699 ( .A1(\cpuregs[4][5] ), .A2(n2499), .B1(
        \cpuregs[5][5] ), .B2(n2498), .Y(n1916) );
  sky130_fd_sc_hd__a22oi_1 U2700 ( .A1(\cpuregs[2][5] ), .A2(n2501), .B1(
        \cpuregs[3][5] ), .B2(n2500), .Y(n1915) );
  sky130_fd_sc_hd__a22oi_1 U2701 ( .A1(\cpuregs[0][5] ), .A2(n2503), .B1(
        \cpuregs[1][5] ), .B2(n2502), .Y(n1914) );
  sky130_fd_sc_hd__nand4_1 U2702 ( .A(n1917), .B(n1916), .C(n1915), .D(n1914), 
        .Y(n1923) );
  sky130_fd_sc_hd__a22oi_1 U2703 ( .A1(\cpuregs[14][5] ), .A2(n2509), .B1(
        \cpuregs[15][5] ), .B2(n2508), .Y(n1921) );
  sky130_fd_sc_hd__a22oi_1 U2704 ( .A1(\cpuregs[12][5] ), .A2(n2511), .B1(
        \cpuregs[13][5] ), .B2(n2510), .Y(n1920) );
  sky130_fd_sc_hd__a22oi_1 U2705 ( .A1(\cpuregs[10][5] ), .A2(n2513), .B1(
        \cpuregs[11][5] ), .B2(n2512), .Y(n1919) );
  sky130_fd_sc_hd__a22oi_1 U2706 ( .A1(\cpuregs[8][5] ), .A2(n2515), .B1(
        \cpuregs[9][5] ), .B2(n2514), .Y(n1918) );
  sky130_fd_sc_hd__nand4_1 U2707 ( .A(n1921), .B(n1920), .C(n1919), .D(n1918), 
        .Y(n1922) );
  sky130_fd_sc_hd__o21ai_0 U2708 ( .A1(n1923), .A2(n1922), .B1(n2527), .Y(
        n1935) );
  sky130_fd_sc_hd__a22oi_1 U2709 ( .A1(\cpuregs[22][5] ), .A2(n2497), .B1(
        \cpuregs[23][5] ), .B2(n2496), .Y(n1927) );
  sky130_fd_sc_hd__a22oi_1 U2710 ( .A1(\cpuregs[20][5] ), .A2(n2499), .B1(
        \cpuregs[21][5] ), .B2(n2498), .Y(n1926) );
  sky130_fd_sc_hd__a22oi_1 U2711 ( .A1(\cpuregs[18][5] ), .A2(n2501), .B1(
        \cpuregs[19][5] ), .B2(n2500), .Y(n1925) );
  sky130_fd_sc_hd__a22oi_1 U2712 ( .A1(\cpuregs[16][5] ), .A2(n2503), .B1(
        \cpuregs[17][5] ), .B2(n2502), .Y(n1924) );
  sky130_fd_sc_hd__nand4_1 U2713 ( .A(n1927), .B(n1926), .C(n1925), .D(n1924), 
        .Y(n1933) );
  sky130_fd_sc_hd__a22oi_1 U2714 ( .A1(\cpuregs[30][5] ), .A2(n2509), .B1(
        \cpuregs[31][5] ), .B2(n2508), .Y(n1931) );
  sky130_fd_sc_hd__a22oi_1 U2715 ( .A1(\cpuregs[28][5] ), .A2(n2511), .B1(
        \cpuregs[29][5] ), .B2(n2510), .Y(n1930) );
  sky130_fd_sc_hd__a22oi_1 U2716 ( .A1(\cpuregs[26][5] ), .A2(n2513), .B1(
        \cpuregs[27][5] ), .B2(n2512), .Y(n1929) );
  sky130_fd_sc_hd__a22oi_1 U2717 ( .A1(\cpuregs[24][5] ), .A2(n2515), .B1(
        \cpuregs[25][5] ), .B2(n2514), .Y(n1928) );
  sky130_fd_sc_hd__nand4_1 U2718 ( .A(n1931), .B(n1930), .C(n1929), .D(n1928), 
        .Y(n1932) );
  sky130_fd_sc_hd__o21ai_0 U2719 ( .A1(n1933), .A2(n1932), .B1(N91), .Y(n1934)
         );
  sky130_fd_sc_hd__nand2_1 U2720 ( .A(n1935), .B(n1934), .Y(N812) );
  sky130_fd_sc_hd__a22oi_1 U2721 ( .A1(\cpuregs[6][6] ), .A2(n2497), .B1(
        \cpuregs[7][6] ), .B2(n2496), .Y(n1939) );
  sky130_fd_sc_hd__a22oi_1 U2722 ( .A1(\cpuregs[4][6] ), .A2(n2499), .B1(
        \cpuregs[5][6] ), .B2(n2498), .Y(n1938) );
  sky130_fd_sc_hd__a22oi_1 U2723 ( .A1(\cpuregs[2][6] ), .A2(n2501), .B1(
        \cpuregs[3][6] ), .B2(n2500), .Y(n1937) );
  sky130_fd_sc_hd__a22oi_1 U2724 ( .A1(\cpuregs[0][6] ), .A2(n2503), .B1(
        \cpuregs[1][6] ), .B2(n2502), .Y(n1936) );
  sky130_fd_sc_hd__nand4_1 U2725 ( .A(n1939), .B(n1938), .C(n1937), .D(n1936), 
        .Y(n1945) );
  sky130_fd_sc_hd__a22oi_1 U2726 ( .A1(\cpuregs[14][6] ), .A2(n2509), .B1(
        \cpuregs[15][6] ), .B2(n2508), .Y(n1943) );
  sky130_fd_sc_hd__a22oi_1 U2727 ( .A1(\cpuregs[12][6] ), .A2(n2511), .B1(
        \cpuregs[13][6] ), .B2(n2510), .Y(n1942) );
  sky130_fd_sc_hd__a22oi_1 U2728 ( .A1(\cpuregs[10][6] ), .A2(n2513), .B1(
        \cpuregs[11][6] ), .B2(n2512), .Y(n1941) );
  sky130_fd_sc_hd__a22oi_1 U2729 ( .A1(\cpuregs[8][6] ), .A2(n2515), .B1(
        \cpuregs[9][6] ), .B2(n2514), .Y(n1940) );
  sky130_fd_sc_hd__nand4_1 U2730 ( .A(n1943), .B(n1942), .C(n1941), .D(n1940), 
        .Y(n1944) );
  sky130_fd_sc_hd__o21ai_0 U2731 ( .A1(n1945), .A2(n1944), .B1(n2527), .Y(
        n1957) );
  sky130_fd_sc_hd__a22oi_1 U2732 ( .A1(\cpuregs[22][6] ), .A2(n2497), .B1(
        \cpuregs[23][6] ), .B2(n2496), .Y(n1949) );
  sky130_fd_sc_hd__a22oi_1 U2733 ( .A1(\cpuregs[20][6] ), .A2(n2499), .B1(
        \cpuregs[21][6] ), .B2(n2498), .Y(n1948) );
  sky130_fd_sc_hd__a22oi_1 U2734 ( .A1(\cpuregs[18][6] ), .A2(n2501), .B1(
        \cpuregs[19][6] ), .B2(n2500), .Y(n1947) );
  sky130_fd_sc_hd__a22oi_1 U2735 ( .A1(\cpuregs[16][6] ), .A2(n2503), .B1(
        \cpuregs[17][6] ), .B2(n2502), .Y(n1946) );
  sky130_fd_sc_hd__nand4_1 U2736 ( .A(n1949), .B(n1948), .C(n1947), .D(n1946), 
        .Y(n1955) );
  sky130_fd_sc_hd__a22oi_1 U2737 ( .A1(\cpuregs[30][6] ), .A2(n2509), .B1(
        \cpuregs[31][6] ), .B2(n2508), .Y(n1953) );
  sky130_fd_sc_hd__a22oi_1 U2738 ( .A1(\cpuregs[28][6] ), .A2(n2511), .B1(
        \cpuregs[29][6] ), .B2(n2510), .Y(n1952) );
  sky130_fd_sc_hd__a22oi_1 U2739 ( .A1(\cpuregs[26][6] ), .A2(n2513), .B1(
        \cpuregs[27][6] ), .B2(n2512), .Y(n1951) );
  sky130_fd_sc_hd__a22oi_1 U2740 ( .A1(\cpuregs[24][6] ), .A2(n2515), .B1(
        \cpuregs[25][6] ), .B2(n2514), .Y(n1950) );
  sky130_fd_sc_hd__nand4_1 U2741 ( .A(n1953), .B(n1952), .C(n1951), .D(n1950), 
        .Y(n1954) );
  sky130_fd_sc_hd__o21ai_0 U2742 ( .A1(n1955), .A2(n1954), .B1(N91), .Y(n1956)
         );
  sky130_fd_sc_hd__nand2_1 U2743 ( .A(n1957), .B(n1956), .Y(N811) );
  sky130_fd_sc_hd__a22oi_1 U2744 ( .A1(\cpuregs[6][7] ), .A2(n2497), .B1(
        \cpuregs[7][7] ), .B2(n2496), .Y(n1961) );
  sky130_fd_sc_hd__a22oi_1 U2745 ( .A1(\cpuregs[4][7] ), .A2(n2499), .B1(
        \cpuregs[5][7] ), .B2(n2498), .Y(n1960) );
  sky130_fd_sc_hd__a22oi_1 U2746 ( .A1(\cpuregs[2][7] ), .A2(n2501), .B1(
        \cpuregs[3][7] ), .B2(n2500), .Y(n1959) );
  sky130_fd_sc_hd__a22oi_1 U2747 ( .A1(\cpuregs[0][7] ), .A2(n2503), .B1(
        \cpuregs[1][7] ), .B2(n2502), .Y(n1958) );
  sky130_fd_sc_hd__nand4_1 U2748 ( .A(n1961), .B(n1960), .C(n1959), .D(n1958), 
        .Y(n1967) );
  sky130_fd_sc_hd__a22oi_1 U2749 ( .A1(\cpuregs[14][7] ), .A2(n2509), .B1(
        \cpuregs[15][7] ), .B2(n2508), .Y(n1965) );
  sky130_fd_sc_hd__a22oi_1 U2750 ( .A1(\cpuregs[12][7] ), .A2(n2511), .B1(
        \cpuregs[13][7] ), .B2(n2510), .Y(n1964) );
  sky130_fd_sc_hd__a22oi_1 U2751 ( .A1(\cpuregs[10][7] ), .A2(n2513), .B1(
        \cpuregs[11][7] ), .B2(n2512), .Y(n1963) );
  sky130_fd_sc_hd__a22oi_1 U2752 ( .A1(\cpuregs[8][7] ), .A2(n2515), .B1(
        \cpuregs[9][7] ), .B2(n2514), .Y(n1962) );
  sky130_fd_sc_hd__nand4_1 U2753 ( .A(n1965), .B(n1964), .C(n1963), .D(n1962), 
        .Y(n1966) );
  sky130_fd_sc_hd__o21ai_0 U2754 ( .A1(n1967), .A2(n1966), .B1(n2527), .Y(
        n1979) );
  sky130_fd_sc_hd__a22oi_1 U2755 ( .A1(\cpuregs[22][7] ), .A2(n2497), .B1(
        \cpuregs[23][7] ), .B2(n2496), .Y(n1971) );
  sky130_fd_sc_hd__a22oi_1 U2756 ( .A1(\cpuregs[20][7] ), .A2(n2499), .B1(
        \cpuregs[21][7] ), .B2(n2498), .Y(n1970) );
  sky130_fd_sc_hd__a22oi_1 U2757 ( .A1(\cpuregs[18][7] ), .A2(n2501), .B1(
        \cpuregs[19][7] ), .B2(n2500), .Y(n1969) );
  sky130_fd_sc_hd__a22oi_1 U2758 ( .A1(\cpuregs[16][7] ), .A2(n2503), .B1(
        \cpuregs[17][7] ), .B2(n2502), .Y(n1968) );
  sky130_fd_sc_hd__nand4_1 U2759 ( .A(n1971), .B(n1970), .C(n1969), .D(n1968), 
        .Y(n1977) );
  sky130_fd_sc_hd__a22oi_1 U2760 ( .A1(\cpuregs[30][7] ), .A2(n2509), .B1(
        \cpuregs[31][7] ), .B2(n2508), .Y(n1975) );
  sky130_fd_sc_hd__a22oi_1 U2761 ( .A1(\cpuregs[28][7] ), .A2(n2511), .B1(
        \cpuregs[29][7] ), .B2(n2510), .Y(n1974) );
  sky130_fd_sc_hd__a22oi_1 U2762 ( .A1(\cpuregs[26][7] ), .A2(n2513), .B1(
        \cpuregs[27][7] ), .B2(n2512), .Y(n1973) );
  sky130_fd_sc_hd__a22oi_1 U2763 ( .A1(\cpuregs[24][7] ), .A2(n2515), .B1(
        \cpuregs[25][7] ), .B2(n2514), .Y(n1972) );
  sky130_fd_sc_hd__nand4_1 U2764 ( .A(n1975), .B(n1974), .C(n1973), .D(n1972), 
        .Y(n1976) );
  sky130_fd_sc_hd__o21ai_0 U2765 ( .A1(n1977), .A2(n1976), .B1(N91), .Y(n1978)
         );
  sky130_fd_sc_hd__nand2_1 U2766 ( .A(n1979), .B(n1978), .Y(N810) );
  sky130_fd_sc_hd__a22oi_1 U2767 ( .A1(\cpuregs[6][8] ), .A2(n2497), .B1(
        \cpuregs[7][8] ), .B2(n2496), .Y(n1983) );
  sky130_fd_sc_hd__a22oi_1 U2768 ( .A1(\cpuregs[4][8] ), .A2(n2499), .B1(
        \cpuregs[5][8] ), .B2(n2498), .Y(n1982) );
  sky130_fd_sc_hd__a22oi_1 U2769 ( .A1(\cpuregs[2][8] ), .A2(n2501), .B1(
        \cpuregs[3][8] ), .B2(n2500), .Y(n1981) );
  sky130_fd_sc_hd__a22oi_1 U2770 ( .A1(\cpuregs[0][8] ), .A2(n2503), .B1(
        \cpuregs[1][8] ), .B2(n2502), .Y(n1980) );
  sky130_fd_sc_hd__nand4_1 U2771 ( .A(n1983), .B(n1982), .C(n1981), .D(n1980), 
        .Y(n1989) );
  sky130_fd_sc_hd__a22oi_1 U2772 ( .A1(\cpuregs[14][8] ), .A2(n2509), .B1(
        \cpuregs[15][8] ), .B2(n2508), .Y(n1987) );
  sky130_fd_sc_hd__a22oi_1 U2773 ( .A1(\cpuregs[12][8] ), .A2(n2511), .B1(
        \cpuregs[13][8] ), .B2(n2510), .Y(n1986) );
  sky130_fd_sc_hd__a22oi_1 U2774 ( .A1(\cpuregs[10][8] ), .A2(n2513), .B1(
        \cpuregs[11][8] ), .B2(n2512), .Y(n1985) );
  sky130_fd_sc_hd__a22oi_1 U2775 ( .A1(\cpuregs[8][8] ), .A2(n2515), .B1(
        \cpuregs[9][8] ), .B2(n2514), .Y(n1984) );
  sky130_fd_sc_hd__nand4_1 U2776 ( .A(n1987), .B(n1986), .C(n1985), .D(n1984), 
        .Y(n1988) );
  sky130_fd_sc_hd__o21ai_0 U2777 ( .A1(n1989), .A2(n1988), .B1(n2527), .Y(
        n2001) );
  sky130_fd_sc_hd__a22oi_1 U2778 ( .A1(\cpuregs[22][8] ), .A2(n2497), .B1(
        \cpuregs[23][8] ), .B2(n2496), .Y(n1993) );
  sky130_fd_sc_hd__a22oi_1 U2779 ( .A1(\cpuregs[20][8] ), .A2(n2499), .B1(
        \cpuregs[21][8] ), .B2(n2498), .Y(n1992) );
  sky130_fd_sc_hd__a22oi_1 U2780 ( .A1(\cpuregs[18][8] ), .A2(n2501), .B1(
        \cpuregs[19][8] ), .B2(n2500), .Y(n1991) );
  sky130_fd_sc_hd__a22oi_1 U2781 ( .A1(\cpuregs[16][8] ), .A2(n2503), .B1(
        \cpuregs[17][8] ), .B2(n2502), .Y(n1990) );
  sky130_fd_sc_hd__nand4_1 U2782 ( .A(n1993), .B(n1992), .C(n1991), .D(n1990), 
        .Y(n1999) );
  sky130_fd_sc_hd__a22oi_1 U2783 ( .A1(\cpuregs[30][8] ), .A2(n2509), .B1(
        \cpuregs[31][8] ), .B2(n2508), .Y(n1997) );
  sky130_fd_sc_hd__a22oi_1 U2784 ( .A1(\cpuregs[28][8] ), .A2(n2511), .B1(
        \cpuregs[29][8] ), .B2(n2510), .Y(n1996) );
  sky130_fd_sc_hd__a22oi_1 U2785 ( .A1(\cpuregs[26][8] ), .A2(n2513), .B1(
        \cpuregs[27][8] ), .B2(n2512), .Y(n1995) );
  sky130_fd_sc_hd__a22oi_1 U2786 ( .A1(\cpuregs[24][8] ), .A2(n2515), .B1(
        \cpuregs[25][8] ), .B2(n2514), .Y(n1994) );
  sky130_fd_sc_hd__nand4_1 U2787 ( .A(n1997), .B(n1996), .C(n1995), .D(n1994), 
        .Y(n1998) );
  sky130_fd_sc_hd__o21ai_0 U2788 ( .A1(n1999), .A2(n1998), .B1(N91), .Y(n2000)
         );
  sky130_fd_sc_hd__nand2_1 U2789 ( .A(n2001), .B(n2000), .Y(N809) );
  sky130_fd_sc_hd__a22oi_1 U2790 ( .A1(\cpuregs[6][9] ), .A2(n2497), .B1(
        \cpuregs[7][9] ), .B2(n2496), .Y(n2005) );
  sky130_fd_sc_hd__a22oi_1 U2791 ( .A1(\cpuregs[4][9] ), .A2(n2499), .B1(
        \cpuregs[5][9] ), .B2(n2498), .Y(n2004) );
  sky130_fd_sc_hd__a22oi_1 U2792 ( .A1(\cpuregs[2][9] ), .A2(n2501), .B1(
        \cpuregs[3][9] ), .B2(n2500), .Y(n2003) );
  sky130_fd_sc_hd__a22oi_1 U2793 ( .A1(\cpuregs[0][9] ), .A2(n2503), .B1(
        \cpuregs[1][9] ), .B2(n2502), .Y(n2002) );
  sky130_fd_sc_hd__nand4_1 U2794 ( .A(n2005), .B(n2004), .C(n2003), .D(n2002), 
        .Y(n2011) );
  sky130_fd_sc_hd__a22oi_1 U2795 ( .A1(\cpuregs[14][9] ), .A2(n2509), .B1(
        \cpuregs[15][9] ), .B2(n2508), .Y(n2009) );
  sky130_fd_sc_hd__a22oi_1 U2796 ( .A1(\cpuregs[12][9] ), .A2(n2511), .B1(
        \cpuregs[13][9] ), .B2(n2510), .Y(n2008) );
  sky130_fd_sc_hd__a22oi_1 U2797 ( .A1(\cpuregs[10][9] ), .A2(n2513), .B1(
        \cpuregs[11][9] ), .B2(n2512), .Y(n2007) );
  sky130_fd_sc_hd__a22oi_1 U2798 ( .A1(\cpuregs[8][9] ), .A2(n2515), .B1(
        \cpuregs[9][9] ), .B2(n2514), .Y(n2006) );
  sky130_fd_sc_hd__nand4_1 U2799 ( .A(n2009), .B(n2008), .C(n2007), .D(n2006), 
        .Y(n2010) );
  sky130_fd_sc_hd__o21ai_0 U2800 ( .A1(n2011), .A2(n2010), .B1(n2527), .Y(
        n2023) );
  sky130_fd_sc_hd__a22oi_1 U2801 ( .A1(\cpuregs[22][9] ), .A2(n2497), .B1(
        \cpuregs[23][9] ), .B2(n2496), .Y(n2015) );
  sky130_fd_sc_hd__a22oi_1 U2802 ( .A1(\cpuregs[20][9] ), .A2(n2499), .B1(
        \cpuregs[21][9] ), .B2(n2498), .Y(n2014) );
  sky130_fd_sc_hd__a22oi_1 U2803 ( .A1(\cpuregs[18][9] ), .A2(n2501), .B1(
        \cpuregs[19][9] ), .B2(n2500), .Y(n2013) );
  sky130_fd_sc_hd__a22oi_1 U2804 ( .A1(\cpuregs[16][9] ), .A2(n2503), .B1(
        \cpuregs[17][9] ), .B2(n2502), .Y(n2012) );
  sky130_fd_sc_hd__nand4_1 U2805 ( .A(n2015), .B(n2014), .C(n2013), .D(n2012), 
        .Y(n2021) );
  sky130_fd_sc_hd__a22oi_1 U2806 ( .A1(\cpuregs[30][9] ), .A2(n2509), .B1(
        \cpuregs[31][9] ), .B2(n2508), .Y(n2019) );
  sky130_fd_sc_hd__a22oi_1 U2807 ( .A1(\cpuregs[28][9] ), .A2(n2511), .B1(
        \cpuregs[29][9] ), .B2(n2510), .Y(n2018) );
  sky130_fd_sc_hd__a22oi_1 U2808 ( .A1(\cpuregs[26][9] ), .A2(n2513), .B1(
        \cpuregs[27][9] ), .B2(n2512), .Y(n2017) );
  sky130_fd_sc_hd__a22oi_1 U2809 ( .A1(\cpuregs[24][9] ), .A2(n2515), .B1(
        \cpuregs[25][9] ), .B2(n2514), .Y(n2016) );
  sky130_fd_sc_hd__nand4_1 U2810 ( .A(n2019), .B(n2018), .C(n2017), .D(n2016), 
        .Y(n2020) );
  sky130_fd_sc_hd__o21ai_0 U2811 ( .A1(n2021), .A2(n2020), .B1(N91), .Y(n2022)
         );
  sky130_fd_sc_hd__nand2_1 U2812 ( .A(n2023), .B(n2022), .Y(N808) );
  sky130_fd_sc_hd__a22oi_1 U2813 ( .A1(\cpuregs[6][10] ), .A2(n2497), .B1(
        \cpuregs[7][10] ), .B2(n2496), .Y(n2027) );
  sky130_fd_sc_hd__a22oi_1 U2814 ( .A1(\cpuregs[4][10] ), .A2(n2499), .B1(
        \cpuregs[5][10] ), .B2(n2498), .Y(n2026) );
  sky130_fd_sc_hd__a22oi_1 U2815 ( .A1(\cpuregs[2][10] ), .A2(n2501), .B1(
        \cpuregs[3][10] ), .B2(n2500), .Y(n2025) );
  sky130_fd_sc_hd__a22oi_1 U2816 ( .A1(\cpuregs[0][10] ), .A2(n2503), .B1(
        \cpuregs[1][10] ), .B2(n2502), .Y(n2024) );
  sky130_fd_sc_hd__nand4_1 U2817 ( .A(n2027), .B(n2026), .C(n2025), .D(n2024), 
        .Y(n2033) );
  sky130_fd_sc_hd__a22oi_1 U2818 ( .A1(\cpuregs[14][10] ), .A2(n2509), .B1(
        \cpuregs[15][10] ), .B2(n2508), .Y(n2031) );
  sky130_fd_sc_hd__a22oi_1 U2819 ( .A1(\cpuregs[12][10] ), .A2(n2511), .B1(
        \cpuregs[13][10] ), .B2(n2510), .Y(n2030) );
  sky130_fd_sc_hd__a22oi_1 U2820 ( .A1(\cpuregs[10][10] ), .A2(n2513), .B1(
        \cpuregs[11][10] ), .B2(n2512), .Y(n2029) );
  sky130_fd_sc_hd__a22oi_1 U2821 ( .A1(\cpuregs[8][10] ), .A2(n2515), .B1(
        \cpuregs[9][10] ), .B2(n2514), .Y(n2028) );
  sky130_fd_sc_hd__nand4_1 U2822 ( .A(n2031), .B(n2030), .C(n2029), .D(n2028), 
        .Y(n2032) );
  sky130_fd_sc_hd__o21ai_0 U2823 ( .A1(n2033), .A2(n2032), .B1(n2527), .Y(
        n2045) );
  sky130_fd_sc_hd__a22oi_1 U2824 ( .A1(\cpuregs[22][10] ), .A2(n2497), .B1(
        \cpuregs[23][10] ), .B2(n2496), .Y(n2037) );
  sky130_fd_sc_hd__a22oi_1 U2825 ( .A1(\cpuregs[20][10] ), .A2(n2499), .B1(
        \cpuregs[21][10] ), .B2(n2498), .Y(n2036) );
  sky130_fd_sc_hd__a22oi_1 U2826 ( .A1(\cpuregs[18][10] ), .A2(n2501), .B1(
        \cpuregs[19][10] ), .B2(n2500), .Y(n2035) );
  sky130_fd_sc_hd__a22oi_1 U2827 ( .A1(\cpuregs[16][10] ), .A2(n2503), .B1(
        \cpuregs[17][10] ), .B2(n2502), .Y(n2034) );
  sky130_fd_sc_hd__nand4_1 U2828 ( .A(n2037), .B(n2036), .C(n2035), .D(n2034), 
        .Y(n2043) );
  sky130_fd_sc_hd__a22oi_1 U2829 ( .A1(\cpuregs[30][10] ), .A2(n2509), .B1(
        \cpuregs[31][10] ), .B2(n2508), .Y(n2041) );
  sky130_fd_sc_hd__a22oi_1 U2830 ( .A1(\cpuregs[28][10] ), .A2(n2511), .B1(
        \cpuregs[29][10] ), .B2(n2510), .Y(n2040) );
  sky130_fd_sc_hd__a22oi_1 U2831 ( .A1(\cpuregs[26][10] ), .A2(n2513), .B1(
        \cpuregs[27][10] ), .B2(n2512), .Y(n2039) );
  sky130_fd_sc_hd__a22oi_1 U2832 ( .A1(\cpuregs[24][10] ), .A2(n2515), .B1(
        \cpuregs[25][10] ), .B2(n2514), .Y(n2038) );
  sky130_fd_sc_hd__nand4_1 U2833 ( .A(n2041), .B(n2040), .C(n2039), .D(n2038), 
        .Y(n2042) );
  sky130_fd_sc_hd__o21ai_0 U2834 ( .A1(n2043), .A2(n2042), .B1(N91), .Y(n2044)
         );
  sky130_fd_sc_hd__nand2_1 U2835 ( .A(n2045), .B(n2044), .Y(N807) );
  sky130_fd_sc_hd__a22oi_1 U2836 ( .A1(\cpuregs[6][11] ), .A2(n2497), .B1(
        \cpuregs[7][11] ), .B2(n2496), .Y(n2049) );
  sky130_fd_sc_hd__a22oi_1 U2837 ( .A1(\cpuregs[4][11] ), .A2(n2499), .B1(
        \cpuregs[5][11] ), .B2(n2498), .Y(n2048) );
  sky130_fd_sc_hd__a22oi_1 U2838 ( .A1(\cpuregs[2][11] ), .A2(n2501), .B1(
        \cpuregs[3][11] ), .B2(n2500), .Y(n2047) );
  sky130_fd_sc_hd__a22oi_1 U2839 ( .A1(\cpuregs[0][11] ), .A2(n2503), .B1(
        \cpuregs[1][11] ), .B2(n2502), .Y(n2046) );
  sky130_fd_sc_hd__nand4_1 U2840 ( .A(n2049), .B(n2048), .C(n2047), .D(n2046), 
        .Y(n2055) );
  sky130_fd_sc_hd__a22oi_1 U2841 ( .A1(\cpuregs[14][11] ), .A2(n2509), .B1(
        \cpuregs[15][11] ), .B2(n2508), .Y(n2053) );
  sky130_fd_sc_hd__a22oi_1 U2842 ( .A1(\cpuregs[12][11] ), .A2(n2511), .B1(
        \cpuregs[13][11] ), .B2(n2510), .Y(n2052) );
  sky130_fd_sc_hd__a22oi_1 U2843 ( .A1(\cpuregs[10][11] ), .A2(n2513), .B1(
        \cpuregs[11][11] ), .B2(n2512), .Y(n2051) );
  sky130_fd_sc_hd__a22oi_1 U2844 ( .A1(\cpuregs[8][11] ), .A2(n2515), .B1(
        \cpuregs[9][11] ), .B2(n2514), .Y(n2050) );
  sky130_fd_sc_hd__nand4_1 U2845 ( .A(n2053), .B(n2052), .C(n2051), .D(n2050), 
        .Y(n2054) );
  sky130_fd_sc_hd__o21ai_0 U2846 ( .A1(n2055), .A2(n2054), .B1(n2527), .Y(
        n2067) );
  sky130_fd_sc_hd__a22oi_1 U2847 ( .A1(\cpuregs[22][11] ), .A2(n2497), .B1(
        \cpuregs[23][11] ), .B2(n2496), .Y(n2059) );
  sky130_fd_sc_hd__a22oi_1 U2848 ( .A1(\cpuregs[20][11] ), .A2(n2499), .B1(
        \cpuregs[21][11] ), .B2(n2498), .Y(n2058) );
  sky130_fd_sc_hd__a22oi_1 U2849 ( .A1(\cpuregs[18][11] ), .A2(n2501), .B1(
        \cpuregs[19][11] ), .B2(n2500), .Y(n2057) );
  sky130_fd_sc_hd__a22oi_1 U2850 ( .A1(\cpuregs[16][11] ), .A2(n2503), .B1(
        \cpuregs[17][11] ), .B2(n2502), .Y(n2056) );
  sky130_fd_sc_hd__nand4_1 U2851 ( .A(n2059), .B(n2058), .C(n2057), .D(n2056), 
        .Y(n2065) );
  sky130_fd_sc_hd__a22oi_1 U2852 ( .A1(\cpuregs[30][11] ), .A2(n2509), .B1(
        \cpuregs[31][11] ), .B2(n2508), .Y(n2063) );
  sky130_fd_sc_hd__a22oi_1 U2853 ( .A1(\cpuregs[28][11] ), .A2(n2511), .B1(
        \cpuregs[29][11] ), .B2(n2510), .Y(n2062) );
  sky130_fd_sc_hd__a22oi_1 U2854 ( .A1(\cpuregs[26][11] ), .A2(n2513), .B1(
        \cpuregs[27][11] ), .B2(n2512), .Y(n2061) );
  sky130_fd_sc_hd__a22oi_1 U2855 ( .A1(\cpuregs[24][11] ), .A2(n2515), .B1(
        \cpuregs[25][11] ), .B2(n2514), .Y(n2060) );
  sky130_fd_sc_hd__nand4_1 U2856 ( .A(n2063), .B(n2062), .C(n2061), .D(n2060), 
        .Y(n2064) );
  sky130_fd_sc_hd__o21ai_0 U2857 ( .A1(n2065), .A2(n2064), .B1(N91), .Y(n2066)
         );
  sky130_fd_sc_hd__nand2_1 U2858 ( .A(n2067), .B(n2066), .Y(N806) );
  sky130_fd_sc_hd__a22oi_1 U2859 ( .A1(\cpuregs[6][12] ), .A2(n2497), .B1(
        \cpuregs[7][12] ), .B2(n2496), .Y(n2071) );
  sky130_fd_sc_hd__a22oi_1 U2860 ( .A1(\cpuregs[4][12] ), .A2(n2499), .B1(
        \cpuregs[5][12] ), .B2(n2498), .Y(n2070) );
  sky130_fd_sc_hd__a22oi_1 U2861 ( .A1(\cpuregs[2][12] ), .A2(n2501), .B1(
        \cpuregs[3][12] ), .B2(n2500), .Y(n2069) );
  sky130_fd_sc_hd__a22oi_1 U2862 ( .A1(\cpuregs[0][12] ), .A2(n2503), .B1(
        \cpuregs[1][12] ), .B2(n2502), .Y(n2068) );
  sky130_fd_sc_hd__nand4_1 U2863 ( .A(n2071), .B(n2070), .C(n2069), .D(n2068), 
        .Y(n2077) );
  sky130_fd_sc_hd__a22oi_1 U2864 ( .A1(\cpuregs[14][12] ), .A2(n2509), .B1(
        \cpuregs[15][12] ), .B2(n2508), .Y(n2075) );
  sky130_fd_sc_hd__a22oi_1 U2865 ( .A1(\cpuregs[12][12] ), .A2(n2511), .B1(
        \cpuregs[13][12] ), .B2(n2510), .Y(n2074) );
  sky130_fd_sc_hd__a22oi_1 U2866 ( .A1(\cpuregs[10][12] ), .A2(n2513), .B1(
        \cpuregs[11][12] ), .B2(n2512), .Y(n2073) );
  sky130_fd_sc_hd__a22oi_1 U2867 ( .A1(\cpuregs[8][12] ), .A2(n2515), .B1(
        \cpuregs[9][12] ), .B2(n2514), .Y(n2072) );
  sky130_fd_sc_hd__nand4_1 U2868 ( .A(n2075), .B(n2074), .C(n2073), .D(n2072), 
        .Y(n2076) );
  sky130_fd_sc_hd__o21ai_0 U2869 ( .A1(n2077), .A2(n2076), .B1(n2527), .Y(
        n2089) );
  sky130_fd_sc_hd__a22oi_1 U2870 ( .A1(\cpuregs[22][12] ), .A2(n2497), .B1(
        \cpuregs[23][12] ), .B2(n2496), .Y(n2081) );
  sky130_fd_sc_hd__a22oi_1 U2871 ( .A1(\cpuregs[20][12] ), .A2(n2499), .B1(
        \cpuregs[21][12] ), .B2(n2498), .Y(n2080) );
  sky130_fd_sc_hd__a22oi_1 U2872 ( .A1(\cpuregs[18][12] ), .A2(n2501), .B1(
        \cpuregs[19][12] ), .B2(n2500), .Y(n2079) );
  sky130_fd_sc_hd__a22oi_1 U2873 ( .A1(\cpuregs[16][12] ), .A2(n2503), .B1(
        \cpuregs[17][12] ), .B2(n2502), .Y(n2078) );
  sky130_fd_sc_hd__nand4_1 U2874 ( .A(n2081), .B(n2080), .C(n2079), .D(n2078), 
        .Y(n2087) );
  sky130_fd_sc_hd__a22oi_1 U2875 ( .A1(\cpuregs[30][12] ), .A2(n2509), .B1(
        \cpuregs[31][12] ), .B2(n2508), .Y(n2085) );
  sky130_fd_sc_hd__a22oi_1 U2876 ( .A1(\cpuregs[28][12] ), .A2(n2511), .B1(
        \cpuregs[29][12] ), .B2(n2510), .Y(n2084) );
  sky130_fd_sc_hd__a22oi_1 U2877 ( .A1(\cpuregs[26][12] ), .A2(n2513), .B1(
        \cpuregs[27][12] ), .B2(n2512), .Y(n2083) );
  sky130_fd_sc_hd__a22oi_1 U2878 ( .A1(\cpuregs[24][12] ), .A2(n2515), .B1(
        \cpuregs[25][12] ), .B2(n2514), .Y(n2082) );
  sky130_fd_sc_hd__nand4_1 U2879 ( .A(n2085), .B(n2084), .C(n2083), .D(n2082), 
        .Y(n2086) );
  sky130_fd_sc_hd__o21ai_0 U2880 ( .A1(n2087), .A2(n2086), .B1(N91), .Y(n2088)
         );
  sky130_fd_sc_hd__nand2_1 U2881 ( .A(n2089), .B(n2088), .Y(N805) );
  sky130_fd_sc_hd__a22oi_1 U2882 ( .A1(\cpuregs[6][13] ), .A2(n2497), .B1(
        \cpuregs[7][13] ), .B2(n2496), .Y(n2093) );
  sky130_fd_sc_hd__a22oi_1 U2883 ( .A1(\cpuregs[4][13] ), .A2(n2499), .B1(
        \cpuregs[5][13] ), .B2(n2498), .Y(n2092) );
  sky130_fd_sc_hd__a22oi_1 U2884 ( .A1(\cpuregs[2][13] ), .A2(n2501), .B1(
        \cpuregs[3][13] ), .B2(n2500), .Y(n2091) );
  sky130_fd_sc_hd__a22oi_1 U2885 ( .A1(\cpuregs[0][13] ), .A2(n2503), .B1(
        \cpuregs[1][13] ), .B2(n2502), .Y(n2090) );
  sky130_fd_sc_hd__nand4_1 U2886 ( .A(n2093), .B(n2092), .C(n2091), .D(n2090), 
        .Y(n2099) );
  sky130_fd_sc_hd__a22oi_1 U2887 ( .A1(\cpuregs[14][13] ), .A2(n2509), .B1(
        \cpuregs[15][13] ), .B2(n2508), .Y(n2097) );
  sky130_fd_sc_hd__a22oi_1 U2888 ( .A1(\cpuregs[12][13] ), .A2(n2511), .B1(
        \cpuregs[13][13] ), .B2(n2510), .Y(n2096) );
  sky130_fd_sc_hd__a22oi_1 U2889 ( .A1(\cpuregs[10][13] ), .A2(n2513), .B1(
        \cpuregs[11][13] ), .B2(n2512), .Y(n2095) );
  sky130_fd_sc_hd__a22oi_1 U2890 ( .A1(\cpuregs[8][13] ), .A2(n2515), .B1(
        \cpuregs[9][13] ), .B2(n2514), .Y(n2094) );
  sky130_fd_sc_hd__nand4_1 U2891 ( .A(n2097), .B(n2096), .C(n2095), .D(n2094), 
        .Y(n2098) );
  sky130_fd_sc_hd__o21ai_0 U2892 ( .A1(n2099), .A2(n2098), .B1(n2527), .Y(
        n2111) );
  sky130_fd_sc_hd__a22oi_1 U2893 ( .A1(\cpuregs[22][13] ), .A2(n2497), .B1(
        \cpuregs[23][13] ), .B2(n2496), .Y(n2103) );
  sky130_fd_sc_hd__a22oi_1 U2894 ( .A1(\cpuregs[20][13] ), .A2(n2499), .B1(
        \cpuregs[21][13] ), .B2(n2498), .Y(n2102) );
  sky130_fd_sc_hd__a22oi_1 U2895 ( .A1(\cpuregs[18][13] ), .A2(n2501), .B1(
        \cpuregs[19][13] ), .B2(n2500), .Y(n2101) );
  sky130_fd_sc_hd__a22oi_1 U2896 ( .A1(\cpuregs[16][13] ), .A2(n2503), .B1(
        \cpuregs[17][13] ), .B2(n2502), .Y(n2100) );
  sky130_fd_sc_hd__nand4_1 U2897 ( .A(n2103), .B(n2102), .C(n2101), .D(n2100), 
        .Y(n2109) );
  sky130_fd_sc_hd__a22oi_1 U2898 ( .A1(\cpuregs[30][13] ), .A2(n2509), .B1(
        \cpuregs[31][13] ), .B2(n2508), .Y(n2107) );
  sky130_fd_sc_hd__a22oi_1 U2899 ( .A1(\cpuregs[28][13] ), .A2(n2511), .B1(
        \cpuregs[29][13] ), .B2(n2510), .Y(n2106) );
  sky130_fd_sc_hd__a22oi_1 U2900 ( .A1(\cpuregs[26][13] ), .A2(n2513), .B1(
        \cpuregs[27][13] ), .B2(n2512), .Y(n2105) );
  sky130_fd_sc_hd__a22oi_1 U2901 ( .A1(\cpuregs[24][13] ), .A2(n2515), .B1(
        \cpuregs[25][13] ), .B2(n2514), .Y(n2104) );
  sky130_fd_sc_hd__nand4_1 U2902 ( .A(n2107), .B(n2106), .C(n2105), .D(n2104), 
        .Y(n2108) );
  sky130_fd_sc_hd__o21ai_0 U2903 ( .A1(n2109), .A2(n2108), .B1(N91), .Y(n2110)
         );
  sky130_fd_sc_hd__nand2_1 U2904 ( .A(n2111), .B(n2110), .Y(N804) );
  sky130_fd_sc_hd__a22oi_1 U2905 ( .A1(\cpuregs[6][14] ), .A2(n2497), .B1(
        \cpuregs[7][14] ), .B2(n2496), .Y(n2115) );
  sky130_fd_sc_hd__a22oi_1 U2906 ( .A1(\cpuregs[4][14] ), .A2(n2499), .B1(
        \cpuregs[5][14] ), .B2(n2498), .Y(n2114) );
  sky130_fd_sc_hd__a22oi_1 U2907 ( .A1(\cpuregs[2][14] ), .A2(n2501), .B1(
        \cpuregs[3][14] ), .B2(n2500), .Y(n2113) );
  sky130_fd_sc_hd__a22oi_1 U2908 ( .A1(\cpuregs[0][14] ), .A2(n2503), .B1(
        \cpuregs[1][14] ), .B2(n2502), .Y(n2112) );
  sky130_fd_sc_hd__nand4_1 U2909 ( .A(n2115), .B(n2114), .C(n2113), .D(n2112), 
        .Y(n2121) );
  sky130_fd_sc_hd__a22oi_1 U2910 ( .A1(\cpuregs[14][14] ), .A2(n2509), .B1(
        \cpuregs[15][14] ), .B2(n2508), .Y(n2119) );
  sky130_fd_sc_hd__a22oi_1 U2911 ( .A1(\cpuregs[12][14] ), .A2(n2511), .B1(
        \cpuregs[13][14] ), .B2(n2510), .Y(n2118) );
  sky130_fd_sc_hd__a22oi_1 U2912 ( .A1(\cpuregs[10][14] ), .A2(n2513), .B1(
        \cpuregs[11][14] ), .B2(n2512), .Y(n2117) );
  sky130_fd_sc_hd__a22oi_1 U2913 ( .A1(\cpuregs[8][14] ), .A2(n2515), .B1(
        \cpuregs[9][14] ), .B2(n2514), .Y(n2116) );
  sky130_fd_sc_hd__nand4_1 U2914 ( .A(n2119), .B(n2118), .C(n2117), .D(n2116), 
        .Y(n2120) );
  sky130_fd_sc_hd__o21ai_0 U2915 ( .A1(n2121), .A2(n2120), .B1(n2527), .Y(
        n2133) );
  sky130_fd_sc_hd__a22oi_1 U2916 ( .A1(\cpuregs[22][14] ), .A2(n2497), .B1(
        \cpuregs[23][14] ), .B2(n2496), .Y(n2125) );
  sky130_fd_sc_hd__a22oi_1 U2917 ( .A1(\cpuregs[20][14] ), .A2(n2499), .B1(
        \cpuregs[21][14] ), .B2(n2498), .Y(n2124) );
  sky130_fd_sc_hd__a22oi_1 U2918 ( .A1(\cpuregs[18][14] ), .A2(n2501), .B1(
        \cpuregs[19][14] ), .B2(n2500), .Y(n2123) );
  sky130_fd_sc_hd__a22oi_1 U2919 ( .A1(\cpuregs[16][14] ), .A2(n2503), .B1(
        \cpuregs[17][14] ), .B2(n2502), .Y(n2122) );
  sky130_fd_sc_hd__nand4_1 U2920 ( .A(n2125), .B(n2124), .C(n2123), .D(n2122), 
        .Y(n2131) );
  sky130_fd_sc_hd__a22oi_1 U2921 ( .A1(\cpuregs[30][14] ), .A2(n2509), .B1(
        \cpuregs[31][14] ), .B2(n2508), .Y(n2129) );
  sky130_fd_sc_hd__a22oi_1 U2922 ( .A1(\cpuregs[28][14] ), .A2(n2511), .B1(
        \cpuregs[29][14] ), .B2(n2510), .Y(n2128) );
  sky130_fd_sc_hd__a22oi_1 U2923 ( .A1(\cpuregs[26][14] ), .A2(n2513), .B1(
        \cpuregs[27][14] ), .B2(n2512), .Y(n2127) );
  sky130_fd_sc_hd__a22oi_1 U2924 ( .A1(\cpuregs[24][14] ), .A2(n2515), .B1(
        \cpuregs[25][14] ), .B2(n2514), .Y(n2126) );
  sky130_fd_sc_hd__nand4_1 U2925 ( .A(n2129), .B(n2128), .C(n2127), .D(n2126), 
        .Y(n2130) );
  sky130_fd_sc_hd__o21ai_0 U2926 ( .A1(n2131), .A2(n2130), .B1(N91), .Y(n2132)
         );
  sky130_fd_sc_hd__nand2_1 U2927 ( .A(n2133), .B(n2132), .Y(N803) );
  sky130_fd_sc_hd__a22oi_1 U2928 ( .A1(\cpuregs[6][15] ), .A2(n2497), .B1(
        \cpuregs[7][15] ), .B2(n2496), .Y(n2137) );
  sky130_fd_sc_hd__a22oi_1 U2929 ( .A1(\cpuregs[4][15] ), .A2(n2499), .B1(
        \cpuregs[5][15] ), .B2(n2498), .Y(n2136) );
  sky130_fd_sc_hd__a22oi_1 U2930 ( .A1(\cpuregs[2][15] ), .A2(n2501), .B1(
        \cpuregs[3][15] ), .B2(n2500), .Y(n2135) );
  sky130_fd_sc_hd__a22oi_1 U2931 ( .A1(\cpuregs[0][15] ), .A2(n2503), .B1(
        \cpuregs[1][15] ), .B2(n2502), .Y(n2134) );
  sky130_fd_sc_hd__nand4_1 U2932 ( .A(n2137), .B(n2136), .C(n2135), .D(n2134), 
        .Y(n2143) );
  sky130_fd_sc_hd__a22oi_1 U2933 ( .A1(\cpuregs[14][15] ), .A2(n2509), .B1(
        \cpuregs[15][15] ), .B2(n2508), .Y(n2141) );
  sky130_fd_sc_hd__a22oi_1 U2934 ( .A1(\cpuregs[12][15] ), .A2(n2511), .B1(
        \cpuregs[13][15] ), .B2(n2510), .Y(n2140) );
  sky130_fd_sc_hd__a22oi_1 U2935 ( .A1(\cpuregs[10][15] ), .A2(n2513), .B1(
        \cpuregs[11][15] ), .B2(n2512), .Y(n2139) );
  sky130_fd_sc_hd__a22oi_1 U2936 ( .A1(\cpuregs[8][15] ), .A2(n2515), .B1(
        \cpuregs[9][15] ), .B2(n2514), .Y(n2138) );
  sky130_fd_sc_hd__nand4_1 U2937 ( .A(n2141), .B(n2140), .C(n2139), .D(n2138), 
        .Y(n2142) );
  sky130_fd_sc_hd__o21ai_0 U2938 ( .A1(n2143), .A2(n2142), .B1(n2527), .Y(
        n2155) );
  sky130_fd_sc_hd__a22oi_1 U2939 ( .A1(\cpuregs[22][15] ), .A2(n2497), .B1(
        \cpuregs[23][15] ), .B2(n2496), .Y(n2147) );
  sky130_fd_sc_hd__a22oi_1 U2940 ( .A1(\cpuregs[20][15] ), .A2(n2499), .B1(
        \cpuregs[21][15] ), .B2(n2498), .Y(n2146) );
  sky130_fd_sc_hd__a22oi_1 U2941 ( .A1(\cpuregs[18][15] ), .A2(n2501), .B1(
        \cpuregs[19][15] ), .B2(n2500), .Y(n2145) );
  sky130_fd_sc_hd__a22oi_1 U2942 ( .A1(\cpuregs[16][15] ), .A2(n2503), .B1(
        \cpuregs[17][15] ), .B2(n2502), .Y(n2144) );
  sky130_fd_sc_hd__nand4_1 U2943 ( .A(n2147), .B(n2146), .C(n2145), .D(n2144), 
        .Y(n2153) );
  sky130_fd_sc_hd__a22oi_1 U2944 ( .A1(\cpuregs[30][15] ), .A2(n2509), .B1(
        \cpuregs[31][15] ), .B2(n2508), .Y(n2151) );
  sky130_fd_sc_hd__a22oi_1 U2945 ( .A1(\cpuregs[28][15] ), .A2(n2511), .B1(
        \cpuregs[29][15] ), .B2(n2510), .Y(n2150) );
  sky130_fd_sc_hd__a22oi_1 U2946 ( .A1(\cpuregs[26][15] ), .A2(n2513), .B1(
        \cpuregs[27][15] ), .B2(n2512), .Y(n2149) );
  sky130_fd_sc_hd__a22oi_1 U2947 ( .A1(\cpuregs[24][15] ), .A2(n2515), .B1(
        \cpuregs[25][15] ), .B2(n2514), .Y(n2148) );
  sky130_fd_sc_hd__nand4_1 U2948 ( .A(n2151), .B(n2150), .C(n2149), .D(n2148), 
        .Y(n2152) );
  sky130_fd_sc_hd__o21ai_0 U2949 ( .A1(n2153), .A2(n2152), .B1(N91), .Y(n2154)
         );
  sky130_fd_sc_hd__nand2_1 U2950 ( .A(n2155), .B(n2154), .Y(N802) );
  sky130_fd_sc_hd__a22oi_1 U2951 ( .A1(\cpuregs[6][16] ), .A2(n2497), .B1(
        \cpuregs[7][16] ), .B2(n2496), .Y(n2159) );
  sky130_fd_sc_hd__a22oi_1 U2952 ( .A1(\cpuregs[4][16] ), .A2(n2499), .B1(
        \cpuregs[5][16] ), .B2(n2498), .Y(n2158) );
  sky130_fd_sc_hd__a22oi_1 U2953 ( .A1(\cpuregs[2][16] ), .A2(n2501), .B1(
        \cpuregs[3][16] ), .B2(n2500), .Y(n2157) );
  sky130_fd_sc_hd__a22oi_1 U2954 ( .A1(\cpuregs[0][16] ), .A2(n2503), .B1(
        \cpuregs[1][16] ), .B2(n2502), .Y(n2156) );
  sky130_fd_sc_hd__nand4_1 U2955 ( .A(n2159), .B(n2158), .C(n2157), .D(n2156), 
        .Y(n2165) );
  sky130_fd_sc_hd__a22oi_1 U2956 ( .A1(\cpuregs[14][16] ), .A2(n2509), .B1(
        \cpuregs[15][16] ), .B2(n2508), .Y(n2163) );
  sky130_fd_sc_hd__a22oi_1 U2957 ( .A1(\cpuregs[12][16] ), .A2(n2511), .B1(
        \cpuregs[13][16] ), .B2(n2510), .Y(n2162) );
  sky130_fd_sc_hd__a22oi_1 U2958 ( .A1(\cpuregs[10][16] ), .A2(n2513), .B1(
        \cpuregs[11][16] ), .B2(n2512), .Y(n2161) );
  sky130_fd_sc_hd__a22oi_1 U2959 ( .A1(\cpuregs[8][16] ), .A2(n2515), .B1(
        \cpuregs[9][16] ), .B2(n2514), .Y(n2160) );
  sky130_fd_sc_hd__nand4_1 U2960 ( .A(n2163), .B(n2162), .C(n2161), .D(n2160), 
        .Y(n2164) );
  sky130_fd_sc_hd__o21ai_0 U2961 ( .A1(n2165), .A2(n2164), .B1(n2527), .Y(
        n2177) );
  sky130_fd_sc_hd__a22oi_1 U2962 ( .A1(\cpuregs[22][16] ), .A2(n2497), .B1(
        \cpuregs[23][16] ), .B2(n2496), .Y(n2169) );
  sky130_fd_sc_hd__a22oi_1 U2963 ( .A1(\cpuregs[20][16] ), .A2(n2499), .B1(
        \cpuregs[21][16] ), .B2(n2498), .Y(n2168) );
  sky130_fd_sc_hd__a22oi_1 U2964 ( .A1(\cpuregs[18][16] ), .A2(n2501), .B1(
        \cpuregs[19][16] ), .B2(n2500), .Y(n2167) );
  sky130_fd_sc_hd__a22oi_1 U2965 ( .A1(\cpuregs[16][16] ), .A2(n2503), .B1(
        \cpuregs[17][16] ), .B2(n2502), .Y(n2166) );
  sky130_fd_sc_hd__nand4_1 U2966 ( .A(n2169), .B(n2168), .C(n2167), .D(n2166), 
        .Y(n2175) );
  sky130_fd_sc_hd__a22oi_1 U2967 ( .A1(\cpuregs[30][16] ), .A2(n2509), .B1(
        \cpuregs[31][16] ), .B2(n2508), .Y(n2173) );
  sky130_fd_sc_hd__a22oi_1 U2968 ( .A1(\cpuregs[28][16] ), .A2(n2511), .B1(
        \cpuregs[29][16] ), .B2(n2510), .Y(n2172) );
  sky130_fd_sc_hd__a22oi_1 U2969 ( .A1(\cpuregs[26][16] ), .A2(n2513), .B1(
        \cpuregs[27][16] ), .B2(n2512), .Y(n2171) );
  sky130_fd_sc_hd__a22oi_1 U2970 ( .A1(\cpuregs[24][16] ), .A2(n2515), .B1(
        \cpuregs[25][16] ), .B2(n2514), .Y(n2170) );
  sky130_fd_sc_hd__nand4_1 U2971 ( .A(n2173), .B(n2172), .C(n2171), .D(n2170), 
        .Y(n2174) );
  sky130_fd_sc_hd__o21ai_0 U2972 ( .A1(n2175), .A2(n2174), .B1(N91), .Y(n2176)
         );
  sky130_fd_sc_hd__nand2_1 U2973 ( .A(n2177), .B(n2176), .Y(N801) );
  sky130_fd_sc_hd__a22oi_1 U2974 ( .A1(\cpuregs[6][17] ), .A2(n2497), .B1(
        \cpuregs[7][17] ), .B2(n2496), .Y(n2181) );
  sky130_fd_sc_hd__a22oi_1 U2975 ( .A1(\cpuregs[4][17] ), .A2(n2499), .B1(
        \cpuregs[5][17] ), .B2(n2498), .Y(n2180) );
  sky130_fd_sc_hd__a22oi_1 U2976 ( .A1(\cpuregs[2][17] ), .A2(n2501), .B1(
        \cpuregs[3][17] ), .B2(n2500), .Y(n2179) );
  sky130_fd_sc_hd__a22oi_1 U2977 ( .A1(\cpuregs[0][17] ), .A2(n2503), .B1(
        \cpuregs[1][17] ), .B2(n2502), .Y(n2178) );
  sky130_fd_sc_hd__nand4_1 U2978 ( .A(n2181), .B(n2180), .C(n2179), .D(n2178), 
        .Y(n2187) );
  sky130_fd_sc_hd__a22oi_1 U2979 ( .A1(\cpuregs[14][17] ), .A2(n2509), .B1(
        \cpuregs[15][17] ), .B2(n2508), .Y(n2185) );
  sky130_fd_sc_hd__a22oi_1 U2980 ( .A1(\cpuregs[12][17] ), .A2(n2511), .B1(
        \cpuregs[13][17] ), .B2(n2510), .Y(n2184) );
  sky130_fd_sc_hd__a22oi_1 U2981 ( .A1(\cpuregs[10][17] ), .A2(n2513), .B1(
        \cpuregs[11][17] ), .B2(n2512), .Y(n2183) );
  sky130_fd_sc_hd__a22oi_1 U2982 ( .A1(\cpuregs[8][17] ), .A2(n2515), .B1(
        \cpuregs[9][17] ), .B2(n2514), .Y(n2182) );
  sky130_fd_sc_hd__nand4_1 U2983 ( .A(n2185), .B(n2184), .C(n2183), .D(n2182), 
        .Y(n2186) );
  sky130_fd_sc_hd__o21ai_0 U2984 ( .A1(n2187), .A2(n2186), .B1(n2527), .Y(
        n2199) );
  sky130_fd_sc_hd__a22oi_1 U2985 ( .A1(\cpuregs[22][17] ), .A2(n2497), .B1(
        \cpuregs[23][17] ), .B2(n2496), .Y(n2191) );
  sky130_fd_sc_hd__a22oi_1 U2986 ( .A1(\cpuregs[20][17] ), .A2(n2499), .B1(
        \cpuregs[21][17] ), .B2(n2498), .Y(n2190) );
  sky130_fd_sc_hd__a22oi_1 U2987 ( .A1(\cpuregs[18][17] ), .A2(n2501), .B1(
        \cpuregs[19][17] ), .B2(n2500), .Y(n2189) );
  sky130_fd_sc_hd__a22oi_1 U2988 ( .A1(\cpuregs[16][17] ), .A2(n2503), .B1(
        \cpuregs[17][17] ), .B2(n2502), .Y(n2188) );
  sky130_fd_sc_hd__nand4_1 U2989 ( .A(n2191), .B(n2190), .C(n2189), .D(n2188), 
        .Y(n2197) );
  sky130_fd_sc_hd__a22oi_1 U2990 ( .A1(\cpuregs[30][17] ), .A2(n2509), .B1(
        \cpuregs[31][17] ), .B2(n2508), .Y(n2195) );
  sky130_fd_sc_hd__a22oi_1 U2991 ( .A1(\cpuregs[28][17] ), .A2(n2511), .B1(
        \cpuregs[29][17] ), .B2(n2510), .Y(n2194) );
  sky130_fd_sc_hd__a22oi_1 U2992 ( .A1(\cpuregs[26][17] ), .A2(n2513), .B1(
        \cpuregs[27][17] ), .B2(n2512), .Y(n2193) );
  sky130_fd_sc_hd__a22oi_1 U2993 ( .A1(\cpuregs[24][17] ), .A2(n2515), .B1(
        \cpuregs[25][17] ), .B2(n2514), .Y(n2192) );
  sky130_fd_sc_hd__nand4_1 U2994 ( .A(n2195), .B(n2194), .C(n2193), .D(n2192), 
        .Y(n2196) );
  sky130_fd_sc_hd__o21ai_0 U2995 ( .A1(n2197), .A2(n2196), .B1(N91), .Y(n2198)
         );
  sky130_fd_sc_hd__nand2_1 U2996 ( .A(n2199), .B(n2198), .Y(N800) );
  sky130_fd_sc_hd__a22oi_1 U2997 ( .A1(\cpuregs[6][18] ), .A2(n2497), .B1(
        \cpuregs[7][18] ), .B2(n2496), .Y(n2203) );
  sky130_fd_sc_hd__a22oi_1 U2998 ( .A1(\cpuregs[4][18] ), .A2(n2499), .B1(
        \cpuregs[5][18] ), .B2(n2498), .Y(n2202) );
  sky130_fd_sc_hd__a22oi_1 U2999 ( .A1(\cpuregs[2][18] ), .A2(n2501), .B1(
        \cpuregs[3][18] ), .B2(n2500), .Y(n2201) );
  sky130_fd_sc_hd__a22oi_1 U3000 ( .A1(\cpuregs[0][18] ), .A2(n2503), .B1(
        \cpuregs[1][18] ), .B2(n2502), .Y(n2200) );
  sky130_fd_sc_hd__nand4_1 U3001 ( .A(n2203), .B(n2202), .C(n2201), .D(n2200), 
        .Y(n2209) );
  sky130_fd_sc_hd__a22oi_1 U3002 ( .A1(\cpuregs[14][18] ), .A2(n2509), .B1(
        \cpuregs[15][18] ), .B2(n2508), .Y(n2207) );
  sky130_fd_sc_hd__a22oi_1 U3003 ( .A1(\cpuregs[12][18] ), .A2(n2511), .B1(
        \cpuregs[13][18] ), .B2(n2510), .Y(n2206) );
  sky130_fd_sc_hd__a22oi_1 U3004 ( .A1(\cpuregs[10][18] ), .A2(n2513), .B1(
        \cpuregs[11][18] ), .B2(n2512), .Y(n2205) );
  sky130_fd_sc_hd__a22oi_1 U3005 ( .A1(\cpuregs[8][18] ), .A2(n2515), .B1(
        \cpuregs[9][18] ), .B2(n2514), .Y(n2204) );
  sky130_fd_sc_hd__nand4_1 U3006 ( .A(n2207), .B(n2206), .C(n2205), .D(n2204), 
        .Y(n2208) );
  sky130_fd_sc_hd__o21ai_0 U3007 ( .A1(n2209), .A2(n2208), .B1(n2527), .Y(
        n2221) );
  sky130_fd_sc_hd__a22oi_1 U3008 ( .A1(\cpuregs[22][18] ), .A2(n2497), .B1(
        \cpuregs[23][18] ), .B2(n2496), .Y(n2213) );
  sky130_fd_sc_hd__a22oi_1 U3009 ( .A1(\cpuregs[20][18] ), .A2(n2499), .B1(
        \cpuregs[21][18] ), .B2(n2498), .Y(n2212) );
  sky130_fd_sc_hd__a22oi_1 U3010 ( .A1(\cpuregs[18][18] ), .A2(n2501), .B1(
        \cpuregs[19][18] ), .B2(n2500), .Y(n2211) );
  sky130_fd_sc_hd__a22oi_1 U3011 ( .A1(\cpuregs[16][18] ), .A2(n2503), .B1(
        \cpuregs[17][18] ), .B2(n2502), .Y(n2210) );
  sky130_fd_sc_hd__nand4_1 U3012 ( .A(n2213), .B(n2212), .C(n2211), .D(n2210), 
        .Y(n2219) );
  sky130_fd_sc_hd__a22oi_1 U3013 ( .A1(\cpuregs[30][18] ), .A2(n2509), .B1(
        \cpuregs[31][18] ), .B2(n2508), .Y(n2217) );
  sky130_fd_sc_hd__a22oi_1 U3014 ( .A1(\cpuregs[28][18] ), .A2(n2511), .B1(
        \cpuregs[29][18] ), .B2(n2510), .Y(n2216) );
  sky130_fd_sc_hd__a22oi_1 U3015 ( .A1(\cpuregs[26][18] ), .A2(n2513), .B1(
        \cpuregs[27][18] ), .B2(n2512), .Y(n2215) );
  sky130_fd_sc_hd__a22oi_1 U3016 ( .A1(\cpuregs[24][18] ), .A2(n2515), .B1(
        \cpuregs[25][18] ), .B2(n2514), .Y(n2214) );
  sky130_fd_sc_hd__nand4_1 U3017 ( .A(n2217), .B(n2216), .C(n2215), .D(n2214), 
        .Y(n2218) );
  sky130_fd_sc_hd__o21ai_0 U3018 ( .A1(n2219), .A2(n2218), .B1(N91), .Y(n2220)
         );
  sky130_fd_sc_hd__nand2_1 U3019 ( .A(n2221), .B(n2220), .Y(N799) );
  sky130_fd_sc_hd__a22oi_1 U3020 ( .A1(\cpuregs[6][19] ), .A2(n2497), .B1(
        \cpuregs[7][19] ), .B2(n2496), .Y(n2225) );
  sky130_fd_sc_hd__a22oi_1 U3021 ( .A1(\cpuregs[4][19] ), .A2(n2499), .B1(
        \cpuregs[5][19] ), .B2(n2498), .Y(n2224) );
  sky130_fd_sc_hd__a22oi_1 U3022 ( .A1(\cpuregs[2][19] ), .A2(n2501), .B1(
        \cpuregs[3][19] ), .B2(n2500), .Y(n2223) );
  sky130_fd_sc_hd__a22oi_1 U3023 ( .A1(\cpuregs[0][19] ), .A2(n2503), .B1(
        \cpuregs[1][19] ), .B2(n2502), .Y(n2222) );
  sky130_fd_sc_hd__nand4_1 U3024 ( .A(n2225), .B(n2224), .C(n2223), .D(n2222), 
        .Y(n2231) );
  sky130_fd_sc_hd__a22oi_1 U3025 ( .A1(\cpuregs[14][19] ), .A2(n2509), .B1(
        \cpuregs[15][19] ), .B2(n2508), .Y(n2229) );
  sky130_fd_sc_hd__a22oi_1 U3026 ( .A1(\cpuregs[12][19] ), .A2(n2511), .B1(
        \cpuregs[13][19] ), .B2(n2510), .Y(n2228) );
  sky130_fd_sc_hd__a22oi_1 U3027 ( .A1(\cpuregs[10][19] ), .A2(n2513), .B1(
        \cpuregs[11][19] ), .B2(n2512), .Y(n2227) );
  sky130_fd_sc_hd__a22oi_1 U3028 ( .A1(\cpuregs[8][19] ), .A2(n2515), .B1(
        \cpuregs[9][19] ), .B2(n2514), .Y(n2226) );
  sky130_fd_sc_hd__nand4_1 U3029 ( .A(n2229), .B(n2228), .C(n2227), .D(n2226), 
        .Y(n2230) );
  sky130_fd_sc_hd__o21ai_0 U3030 ( .A1(n2231), .A2(n2230), .B1(n2527), .Y(
        n2243) );
  sky130_fd_sc_hd__a22oi_1 U3031 ( .A1(\cpuregs[22][19] ), .A2(n2497), .B1(
        \cpuregs[23][19] ), .B2(n2496), .Y(n2235) );
  sky130_fd_sc_hd__a22oi_1 U3032 ( .A1(\cpuregs[20][19] ), .A2(n2499), .B1(
        \cpuregs[21][19] ), .B2(n2498), .Y(n2234) );
  sky130_fd_sc_hd__a22oi_1 U3033 ( .A1(\cpuregs[18][19] ), .A2(n2501), .B1(
        \cpuregs[19][19] ), .B2(n2500), .Y(n2233) );
  sky130_fd_sc_hd__a22oi_1 U3034 ( .A1(\cpuregs[16][19] ), .A2(n2503), .B1(
        \cpuregs[17][19] ), .B2(n2502), .Y(n2232) );
  sky130_fd_sc_hd__nand4_1 U3035 ( .A(n2235), .B(n2234), .C(n2233), .D(n2232), 
        .Y(n2241) );
  sky130_fd_sc_hd__a22oi_1 U3036 ( .A1(\cpuregs[30][19] ), .A2(n2509), .B1(
        \cpuregs[31][19] ), .B2(n2508), .Y(n2239) );
  sky130_fd_sc_hd__a22oi_1 U3037 ( .A1(\cpuregs[28][19] ), .A2(n2511), .B1(
        \cpuregs[29][19] ), .B2(n2510), .Y(n2238) );
  sky130_fd_sc_hd__a22oi_1 U3038 ( .A1(\cpuregs[26][19] ), .A2(n2513), .B1(
        \cpuregs[27][19] ), .B2(n2512), .Y(n2237) );
  sky130_fd_sc_hd__a22oi_1 U3039 ( .A1(\cpuregs[24][19] ), .A2(n2515), .B1(
        \cpuregs[25][19] ), .B2(n2514), .Y(n2236) );
  sky130_fd_sc_hd__nand4_1 U3040 ( .A(n2239), .B(n2238), .C(n2237), .D(n2236), 
        .Y(n2240) );
  sky130_fd_sc_hd__o21ai_0 U3041 ( .A1(n2241), .A2(n2240), .B1(N91), .Y(n2242)
         );
  sky130_fd_sc_hd__nand2_1 U3042 ( .A(n2243), .B(n2242), .Y(N798) );
  sky130_fd_sc_hd__a22oi_1 U3043 ( .A1(\cpuregs[6][20] ), .A2(n2497), .B1(
        \cpuregs[7][20] ), .B2(n2496), .Y(n2247) );
  sky130_fd_sc_hd__a22oi_1 U3044 ( .A1(\cpuregs[4][20] ), .A2(n2499), .B1(
        \cpuregs[5][20] ), .B2(n2498), .Y(n2246) );
  sky130_fd_sc_hd__a22oi_1 U3045 ( .A1(\cpuregs[2][20] ), .A2(n2501), .B1(
        \cpuregs[3][20] ), .B2(n2500), .Y(n2245) );
  sky130_fd_sc_hd__a22oi_1 U3046 ( .A1(\cpuregs[0][20] ), .A2(n2503), .B1(
        \cpuregs[1][20] ), .B2(n2502), .Y(n2244) );
  sky130_fd_sc_hd__nand4_1 U3047 ( .A(n2247), .B(n2246), .C(n2245), .D(n2244), 
        .Y(n2253) );
  sky130_fd_sc_hd__a22oi_1 U3048 ( .A1(\cpuregs[14][20] ), .A2(n2509), .B1(
        \cpuregs[15][20] ), .B2(n2508), .Y(n2251) );
  sky130_fd_sc_hd__a22oi_1 U3049 ( .A1(\cpuregs[12][20] ), .A2(n2511), .B1(
        \cpuregs[13][20] ), .B2(n2510), .Y(n2250) );
  sky130_fd_sc_hd__a22oi_1 U3050 ( .A1(\cpuregs[10][20] ), .A2(n2513), .B1(
        \cpuregs[11][20] ), .B2(n2512), .Y(n2249) );
  sky130_fd_sc_hd__a22oi_1 U3051 ( .A1(\cpuregs[8][20] ), .A2(n2515), .B1(
        \cpuregs[9][20] ), .B2(n2514), .Y(n2248) );
  sky130_fd_sc_hd__nand4_1 U3052 ( .A(n2251), .B(n2250), .C(n2249), .D(n2248), 
        .Y(n2252) );
  sky130_fd_sc_hd__o21ai_0 U3053 ( .A1(n2253), .A2(n2252), .B1(n2527), .Y(
        n2265) );
  sky130_fd_sc_hd__a22oi_1 U3054 ( .A1(\cpuregs[22][20] ), .A2(n2497), .B1(
        \cpuregs[23][20] ), .B2(n2496), .Y(n2257) );
  sky130_fd_sc_hd__a22oi_1 U3055 ( .A1(\cpuregs[20][20] ), .A2(n2499), .B1(
        \cpuregs[21][20] ), .B2(n2498), .Y(n2256) );
  sky130_fd_sc_hd__a22oi_1 U3056 ( .A1(\cpuregs[18][20] ), .A2(n2501), .B1(
        \cpuregs[19][20] ), .B2(n2500), .Y(n2255) );
  sky130_fd_sc_hd__a22oi_1 U3057 ( .A1(\cpuregs[16][20] ), .A2(n2503), .B1(
        \cpuregs[17][20] ), .B2(n2502), .Y(n2254) );
  sky130_fd_sc_hd__nand4_1 U3058 ( .A(n2257), .B(n2256), .C(n2255), .D(n2254), 
        .Y(n2263) );
  sky130_fd_sc_hd__a22oi_1 U3059 ( .A1(\cpuregs[30][20] ), .A2(n2509), .B1(
        \cpuregs[31][20] ), .B2(n2508), .Y(n2261) );
  sky130_fd_sc_hd__a22oi_1 U3060 ( .A1(\cpuregs[28][20] ), .A2(n2511), .B1(
        \cpuregs[29][20] ), .B2(n2510), .Y(n2260) );
  sky130_fd_sc_hd__a22oi_1 U3061 ( .A1(\cpuregs[26][20] ), .A2(n2513), .B1(
        \cpuregs[27][20] ), .B2(n2512), .Y(n2259) );
  sky130_fd_sc_hd__a22oi_1 U3062 ( .A1(\cpuregs[24][20] ), .A2(n2515), .B1(
        \cpuregs[25][20] ), .B2(n2514), .Y(n2258) );
  sky130_fd_sc_hd__nand4_1 U3063 ( .A(n2261), .B(n2260), .C(n2259), .D(n2258), 
        .Y(n2262) );
  sky130_fd_sc_hd__o21ai_0 U3064 ( .A1(n2263), .A2(n2262), .B1(N91), .Y(n2264)
         );
  sky130_fd_sc_hd__nand2_1 U3065 ( .A(n2265), .B(n2264), .Y(N797) );
  sky130_fd_sc_hd__a22oi_1 U3066 ( .A1(\cpuregs[6][21] ), .A2(n2497), .B1(
        \cpuregs[7][21] ), .B2(n2496), .Y(n2269) );
  sky130_fd_sc_hd__a22oi_1 U3067 ( .A1(\cpuregs[4][21] ), .A2(n2499), .B1(
        \cpuregs[5][21] ), .B2(n2498), .Y(n2268) );
  sky130_fd_sc_hd__a22oi_1 U3068 ( .A1(\cpuregs[2][21] ), .A2(n2501), .B1(
        \cpuregs[3][21] ), .B2(n2500), .Y(n2267) );
  sky130_fd_sc_hd__a22oi_1 U3069 ( .A1(\cpuregs[0][21] ), .A2(n2503), .B1(
        \cpuregs[1][21] ), .B2(n2502), .Y(n2266) );
  sky130_fd_sc_hd__nand4_1 U3070 ( .A(n2269), .B(n2268), .C(n2267), .D(n2266), 
        .Y(n2275) );
  sky130_fd_sc_hd__a22oi_1 U3071 ( .A1(\cpuregs[14][21] ), .A2(n2509), .B1(
        \cpuregs[15][21] ), .B2(n2508), .Y(n2273) );
  sky130_fd_sc_hd__a22oi_1 U3072 ( .A1(\cpuregs[12][21] ), .A2(n2511), .B1(
        \cpuregs[13][21] ), .B2(n2510), .Y(n2272) );
  sky130_fd_sc_hd__a22oi_1 U3073 ( .A1(\cpuregs[10][21] ), .A2(n2513), .B1(
        \cpuregs[11][21] ), .B2(n2512), .Y(n2271) );
  sky130_fd_sc_hd__a22oi_1 U3074 ( .A1(\cpuregs[8][21] ), .A2(n2515), .B1(
        \cpuregs[9][21] ), .B2(n2514), .Y(n2270) );
  sky130_fd_sc_hd__nand4_1 U3075 ( .A(n2273), .B(n2272), .C(n2271), .D(n2270), 
        .Y(n2274) );
  sky130_fd_sc_hd__o21ai_0 U3076 ( .A1(n2275), .A2(n2274), .B1(n2527), .Y(
        n2287) );
  sky130_fd_sc_hd__a22oi_1 U3077 ( .A1(\cpuregs[22][21] ), .A2(n2497), .B1(
        \cpuregs[23][21] ), .B2(n2496), .Y(n2279) );
  sky130_fd_sc_hd__a22oi_1 U3078 ( .A1(\cpuregs[20][21] ), .A2(n2499), .B1(
        \cpuregs[21][21] ), .B2(n2498), .Y(n2278) );
  sky130_fd_sc_hd__a22oi_1 U3079 ( .A1(\cpuregs[18][21] ), .A2(n2501), .B1(
        \cpuregs[19][21] ), .B2(n2500), .Y(n2277) );
  sky130_fd_sc_hd__a22oi_1 U3080 ( .A1(\cpuregs[16][21] ), .A2(n2503), .B1(
        \cpuregs[17][21] ), .B2(n2502), .Y(n2276) );
  sky130_fd_sc_hd__nand4_1 U3081 ( .A(n2279), .B(n2278), .C(n2277), .D(n2276), 
        .Y(n2285) );
  sky130_fd_sc_hd__a22oi_1 U3082 ( .A1(\cpuregs[30][21] ), .A2(n2509), .B1(
        \cpuregs[31][21] ), .B2(n2508), .Y(n2283) );
  sky130_fd_sc_hd__a22oi_1 U3083 ( .A1(\cpuregs[28][21] ), .A2(n2511), .B1(
        \cpuregs[29][21] ), .B2(n2510), .Y(n2282) );
  sky130_fd_sc_hd__a22oi_1 U3084 ( .A1(\cpuregs[26][21] ), .A2(n2513), .B1(
        \cpuregs[27][21] ), .B2(n2512), .Y(n2281) );
  sky130_fd_sc_hd__a22oi_1 U3085 ( .A1(\cpuregs[24][21] ), .A2(n2515), .B1(
        \cpuregs[25][21] ), .B2(n2514), .Y(n2280) );
  sky130_fd_sc_hd__nand4_1 U3086 ( .A(n2283), .B(n2282), .C(n2281), .D(n2280), 
        .Y(n2284) );
  sky130_fd_sc_hd__o21ai_0 U3087 ( .A1(n2285), .A2(n2284), .B1(N91), .Y(n2286)
         );
  sky130_fd_sc_hd__nand2_1 U3088 ( .A(n2287), .B(n2286), .Y(N796) );
  sky130_fd_sc_hd__a22oi_1 U3089 ( .A1(\cpuregs[6][22] ), .A2(n2497), .B1(
        \cpuregs[7][22] ), .B2(n2496), .Y(n2291) );
  sky130_fd_sc_hd__a22oi_1 U3090 ( .A1(\cpuregs[4][22] ), .A2(n2499), .B1(
        \cpuregs[5][22] ), .B2(n2498), .Y(n2290) );
  sky130_fd_sc_hd__a22oi_1 U3091 ( .A1(\cpuregs[2][22] ), .A2(n2501), .B1(
        \cpuregs[3][22] ), .B2(n2500), .Y(n2289) );
  sky130_fd_sc_hd__a22oi_1 U3092 ( .A1(\cpuregs[0][22] ), .A2(n2503), .B1(
        \cpuregs[1][22] ), .B2(n2502), .Y(n2288) );
  sky130_fd_sc_hd__nand4_1 U3093 ( .A(n2291), .B(n2290), .C(n2289), .D(n2288), 
        .Y(n2297) );
  sky130_fd_sc_hd__a22oi_1 U3094 ( .A1(\cpuregs[14][22] ), .A2(n2509), .B1(
        \cpuregs[15][22] ), .B2(n2508), .Y(n2295) );
  sky130_fd_sc_hd__a22oi_1 U3095 ( .A1(\cpuregs[12][22] ), .A2(n2511), .B1(
        \cpuregs[13][22] ), .B2(n2510), .Y(n2294) );
  sky130_fd_sc_hd__a22oi_1 U3096 ( .A1(\cpuregs[10][22] ), .A2(n2513), .B1(
        \cpuregs[11][22] ), .B2(n2512), .Y(n2293) );
  sky130_fd_sc_hd__a22oi_1 U3097 ( .A1(\cpuregs[8][22] ), .A2(n2515), .B1(
        \cpuregs[9][22] ), .B2(n2514), .Y(n2292) );
  sky130_fd_sc_hd__nand4_1 U3098 ( .A(n2295), .B(n2294), .C(n2293), .D(n2292), 
        .Y(n2296) );
  sky130_fd_sc_hd__o21ai_0 U3099 ( .A1(n2297), .A2(n2296), .B1(n2527), .Y(
        n2309) );
  sky130_fd_sc_hd__a22oi_1 U3100 ( .A1(\cpuregs[22][22] ), .A2(n2497), .B1(
        \cpuregs[23][22] ), .B2(n2496), .Y(n2301) );
  sky130_fd_sc_hd__a22oi_1 U3101 ( .A1(\cpuregs[20][22] ), .A2(n2499), .B1(
        \cpuregs[21][22] ), .B2(n2498), .Y(n2300) );
  sky130_fd_sc_hd__a22oi_1 U3102 ( .A1(\cpuregs[18][22] ), .A2(n2501), .B1(
        \cpuregs[19][22] ), .B2(n2500), .Y(n2299) );
  sky130_fd_sc_hd__a22oi_1 U3103 ( .A1(\cpuregs[16][22] ), .A2(n2503), .B1(
        \cpuregs[17][22] ), .B2(n2502), .Y(n2298) );
  sky130_fd_sc_hd__nand4_1 U3104 ( .A(n2301), .B(n2300), .C(n2299), .D(n2298), 
        .Y(n2307) );
  sky130_fd_sc_hd__a22oi_1 U3105 ( .A1(\cpuregs[30][22] ), .A2(n2509), .B1(
        \cpuregs[31][22] ), .B2(n2508), .Y(n2305) );
  sky130_fd_sc_hd__a22oi_1 U3106 ( .A1(\cpuregs[28][22] ), .A2(n2511), .B1(
        \cpuregs[29][22] ), .B2(n2510), .Y(n2304) );
  sky130_fd_sc_hd__a22oi_1 U3107 ( .A1(\cpuregs[26][22] ), .A2(n2513), .B1(
        \cpuregs[27][22] ), .B2(n2512), .Y(n2303) );
  sky130_fd_sc_hd__a22oi_1 U3108 ( .A1(\cpuregs[24][22] ), .A2(n2515), .B1(
        \cpuregs[25][22] ), .B2(n2514), .Y(n2302) );
  sky130_fd_sc_hd__nand4_1 U3109 ( .A(n2305), .B(n2304), .C(n2303), .D(n2302), 
        .Y(n2306) );
  sky130_fd_sc_hd__o21ai_0 U3110 ( .A1(n2307), .A2(n2306), .B1(N91), .Y(n2308)
         );
  sky130_fd_sc_hd__nand2_1 U3111 ( .A(n2309), .B(n2308), .Y(N795) );
  sky130_fd_sc_hd__a22oi_1 U3112 ( .A1(\cpuregs[6][23] ), .A2(n2497), .B1(
        \cpuregs[7][23] ), .B2(n2496), .Y(n2313) );
  sky130_fd_sc_hd__a22oi_1 U3113 ( .A1(\cpuregs[4][23] ), .A2(n2499), .B1(
        \cpuregs[5][23] ), .B2(n2498), .Y(n2312) );
  sky130_fd_sc_hd__a22oi_1 U3114 ( .A1(\cpuregs[2][23] ), .A2(n2501), .B1(
        \cpuregs[3][23] ), .B2(n2500), .Y(n2311) );
  sky130_fd_sc_hd__a22oi_1 U3115 ( .A1(\cpuregs[0][23] ), .A2(n2503), .B1(
        \cpuregs[1][23] ), .B2(n2502), .Y(n2310) );
  sky130_fd_sc_hd__nand4_1 U3116 ( .A(n2313), .B(n2312), .C(n2311), .D(n2310), 
        .Y(n2319) );
  sky130_fd_sc_hd__a22oi_1 U3117 ( .A1(\cpuregs[14][23] ), .A2(n2509), .B1(
        \cpuregs[15][23] ), .B2(n2508), .Y(n2317) );
  sky130_fd_sc_hd__a22oi_1 U3118 ( .A1(\cpuregs[12][23] ), .A2(n2511), .B1(
        \cpuregs[13][23] ), .B2(n2510), .Y(n2316) );
  sky130_fd_sc_hd__a22oi_1 U3119 ( .A1(\cpuregs[10][23] ), .A2(n2513), .B1(
        \cpuregs[11][23] ), .B2(n2512), .Y(n2315) );
  sky130_fd_sc_hd__a22oi_1 U3120 ( .A1(\cpuregs[8][23] ), .A2(n2515), .B1(
        \cpuregs[9][23] ), .B2(n2514), .Y(n2314) );
  sky130_fd_sc_hd__nand4_1 U3121 ( .A(n2317), .B(n2316), .C(n2315), .D(n2314), 
        .Y(n2318) );
  sky130_fd_sc_hd__o21ai_0 U3122 ( .A1(n2319), .A2(n2318), .B1(n2527), .Y(
        n2331) );
  sky130_fd_sc_hd__a22oi_1 U3123 ( .A1(\cpuregs[22][23] ), .A2(n2497), .B1(
        \cpuregs[23][23] ), .B2(n2496), .Y(n2323) );
  sky130_fd_sc_hd__a22oi_1 U3124 ( .A1(\cpuregs[20][23] ), .A2(n2499), .B1(
        \cpuregs[21][23] ), .B2(n2498), .Y(n2322) );
  sky130_fd_sc_hd__a22oi_1 U3125 ( .A1(\cpuregs[18][23] ), .A2(n2501), .B1(
        \cpuregs[19][23] ), .B2(n2500), .Y(n2321) );
  sky130_fd_sc_hd__a22oi_1 U3126 ( .A1(\cpuregs[16][23] ), .A2(n2503), .B1(
        \cpuregs[17][23] ), .B2(n2502), .Y(n2320) );
  sky130_fd_sc_hd__nand4_1 U3127 ( .A(n2323), .B(n2322), .C(n2321), .D(n2320), 
        .Y(n2329) );
  sky130_fd_sc_hd__a22oi_1 U3128 ( .A1(\cpuregs[30][23] ), .A2(n2509), .B1(
        \cpuregs[31][23] ), .B2(n2508), .Y(n2327) );
  sky130_fd_sc_hd__a22oi_1 U3129 ( .A1(\cpuregs[28][23] ), .A2(n2511), .B1(
        \cpuregs[29][23] ), .B2(n2510), .Y(n2326) );
  sky130_fd_sc_hd__a22oi_1 U3130 ( .A1(\cpuregs[26][23] ), .A2(n2513), .B1(
        \cpuregs[27][23] ), .B2(n2512), .Y(n2325) );
  sky130_fd_sc_hd__a22oi_1 U3131 ( .A1(\cpuregs[24][23] ), .A2(n2515), .B1(
        \cpuregs[25][23] ), .B2(n2514), .Y(n2324) );
  sky130_fd_sc_hd__nand4_1 U3132 ( .A(n2327), .B(n2326), .C(n2325), .D(n2324), 
        .Y(n2328) );
  sky130_fd_sc_hd__o21ai_0 U3133 ( .A1(n2329), .A2(n2328), .B1(N91), .Y(n2330)
         );
  sky130_fd_sc_hd__nand2_1 U3134 ( .A(n2331), .B(n2330), .Y(N794) );
  sky130_fd_sc_hd__a22oi_1 U3135 ( .A1(\cpuregs[6][24] ), .A2(n2497), .B1(
        \cpuregs[7][24] ), .B2(n2496), .Y(n2335) );
  sky130_fd_sc_hd__a22oi_1 U3136 ( .A1(\cpuregs[4][24] ), .A2(n2499), .B1(
        \cpuregs[5][24] ), .B2(n2498), .Y(n2334) );
  sky130_fd_sc_hd__a22oi_1 U3137 ( .A1(\cpuregs[2][24] ), .A2(n2501), .B1(
        \cpuregs[3][24] ), .B2(n2500), .Y(n2333) );
  sky130_fd_sc_hd__a22oi_1 U3138 ( .A1(\cpuregs[0][24] ), .A2(n2503), .B1(
        \cpuregs[1][24] ), .B2(n2502), .Y(n2332) );
  sky130_fd_sc_hd__nand4_1 U3139 ( .A(n2335), .B(n2334), .C(n2333), .D(n2332), 
        .Y(n2341) );
  sky130_fd_sc_hd__a22oi_1 U3140 ( .A1(\cpuregs[14][24] ), .A2(n2509), .B1(
        \cpuregs[15][24] ), .B2(n2508), .Y(n2339) );
  sky130_fd_sc_hd__a22oi_1 U3141 ( .A1(\cpuregs[12][24] ), .A2(n2511), .B1(
        \cpuregs[13][24] ), .B2(n2510), .Y(n2338) );
  sky130_fd_sc_hd__a22oi_1 U3142 ( .A1(\cpuregs[10][24] ), .A2(n2513), .B1(
        \cpuregs[11][24] ), .B2(n2512), .Y(n2337) );
  sky130_fd_sc_hd__a22oi_1 U3143 ( .A1(\cpuregs[8][24] ), .A2(n2515), .B1(
        \cpuregs[9][24] ), .B2(n2514), .Y(n2336) );
  sky130_fd_sc_hd__nand4_1 U3144 ( .A(n2339), .B(n2338), .C(n2337), .D(n2336), 
        .Y(n2340) );
  sky130_fd_sc_hd__o21ai_0 U3145 ( .A1(n2341), .A2(n2340), .B1(n2527), .Y(
        n2353) );
  sky130_fd_sc_hd__a22oi_1 U3146 ( .A1(\cpuregs[22][24] ), .A2(n2497), .B1(
        \cpuregs[23][24] ), .B2(n2496), .Y(n2345) );
  sky130_fd_sc_hd__a22oi_1 U3147 ( .A1(\cpuregs[20][24] ), .A2(n2499), .B1(
        \cpuregs[21][24] ), .B2(n2498), .Y(n2344) );
  sky130_fd_sc_hd__a22oi_1 U3148 ( .A1(\cpuregs[18][24] ), .A2(n2501), .B1(
        \cpuregs[19][24] ), .B2(n2500), .Y(n2343) );
  sky130_fd_sc_hd__a22oi_1 U3149 ( .A1(\cpuregs[16][24] ), .A2(n2503), .B1(
        \cpuregs[17][24] ), .B2(n2502), .Y(n2342) );
  sky130_fd_sc_hd__nand4_1 U3150 ( .A(n2345), .B(n2344), .C(n2343), .D(n2342), 
        .Y(n2351) );
  sky130_fd_sc_hd__a22oi_1 U3151 ( .A1(\cpuregs[30][24] ), .A2(n2509), .B1(
        \cpuregs[31][24] ), .B2(n2508), .Y(n2349) );
  sky130_fd_sc_hd__a22oi_1 U3152 ( .A1(\cpuregs[28][24] ), .A2(n2511), .B1(
        \cpuregs[29][24] ), .B2(n2510), .Y(n2348) );
  sky130_fd_sc_hd__a22oi_1 U3153 ( .A1(\cpuregs[26][24] ), .A2(n2513), .B1(
        \cpuregs[27][24] ), .B2(n2512), .Y(n2347) );
  sky130_fd_sc_hd__a22oi_1 U3154 ( .A1(\cpuregs[24][24] ), .A2(n2515), .B1(
        \cpuregs[25][24] ), .B2(n2514), .Y(n2346) );
  sky130_fd_sc_hd__nand4_1 U3155 ( .A(n2349), .B(n2348), .C(n2347), .D(n2346), 
        .Y(n2350) );
  sky130_fd_sc_hd__o21ai_0 U3156 ( .A1(n2351), .A2(n2350), .B1(N91), .Y(n2352)
         );
  sky130_fd_sc_hd__nand2_1 U3157 ( .A(n2353), .B(n2352), .Y(N793) );
  sky130_fd_sc_hd__a22oi_1 U3158 ( .A1(\cpuregs[6][25] ), .A2(n2497), .B1(
        \cpuregs[7][25] ), .B2(n2496), .Y(n2357) );
  sky130_fd_sc_hd__a22oi_1 U3159 ( .A1(\cpuregs[4][25] ), .A2(n2499), .B1(
        \cpuregs[5][25] ), .B2(n2498), .Y(n2356) );
  sky130_fd_sc_hd__a22oi_1 U3160 ( .A1(\cpuregs[2][25] ), .A2(n2501), .B1(
        \cpuregs[3][25] ), .B2(n2500), .Y(n2355) );
  sky130_fd_sc_hd__a22oi_1 U3161 ( .A1(\cpuregs[0][25] ), .A2(n2503), .B1(
        \cpuregs[1][25] ), .B2(n2502), .Y(n2354) );
  sky130_fd_sc_hd__nand4_1 U3162 ( .A(n2357), .B(n2356), .C(n2355), .D(n2354), 
        .Y(n2363) );
  sky130_fd_sc_hd__a22oi_1 U3163 ( .A1(\cpuregs[14][25] ), .A2(n2509), .B1(
        \cpuregs[15][25] ), .B2(n2508), .Y(n2361) );
  sky130_fd_sc_hd__a22oi_1 U3164 ( .A1(\cpuregs[12][25] ), .A2(n2511), .B1(
        \cpuregs[13][25] ), .B2(n2510), .Y(n2360) );
  sky130_fd_sc_hd__a22oi_1 U3165 ( .A1(\cpuregs[10][25] ), .A2(n2513), .B1(
        \cpuregs[11][25] ), .B2(n2512), .Y(n2359) );
  sky130_fd_sc_hd__a22oi_1 U3166 ( .A1(\cpuregs[8][25] ), .A2(n2515), .B1(
        \cpuregs[9][25] ), .B2(n2514), .Y(n2358) );
  sky130_fd_sc_hd__nand4_1 U3167 ( .A(n2361), .B(n2360), .C(n2359), .D(n2358), 
        .Y(n2362) );
  sky130_fd_sc_hd__o21ai_0 U3168 ( .A1(n2363), .A2(n2362), .B1(n2527), .Y(
        n2375) );
  sky130_fd_sc_hd__a22oi_1 U3169 ( .A1(\cpuregs[22][25] ), .A2(n2497), .B1(
        \cpuregs[23][25] ), .B2(n2496), .Y(n2367) );
  sky130_fd_sc_hd__a22oi_1 U3170 ( .A1(\cpuregs[20][25] ), .A2(n2499), .B1(
        \cpuregs[21][25] ), .B2(n2498), .Y(n2366) );
  sky130_fd_sc_hd__a22oi_1 U3171 ( .A1(\cpuregs[18][25] ), .A2(n2501), .B1(
        \cpuregs[19][25] ), .B2(n2500), .Y(n2365) );
  sky130_fd_sc_hd__a22oi_1 U3172 ( .A1(\cpuregs[16][25] ), .A2(n2503), .B1(
        \cpuregs[17][25] ), .B2(n2502), .Y(n2364) );
  sky130_fd_sc_hd__nand4_1 U3173 ( .A(n2367), .B(n2366), .C(n2365), .D(n2364), 
        .Y(n2373) );
  sky130_fd_sc_hd__a22oi_1 U3174 ( .A1(\cpuregs[30][25] ), .A2(n2509), .B1(
        \cpuregs[31][25] ), .B2(n2508), .Y(n2371) );
  sky130_fd_sc_hd__a22oi_1 U3175 ( .A1(\cpuregs[28][25] ), .A2(n2511), .B1(
        \cpuregs[29][25] ), .B2(n2510), .Y(n2370) );
  sky130_fd_sc_hd__a22oi_1 U3176 ( .A1(\cpuregs[26][25] ), .A2(n2513), .B1(
        \cpuregs[27][25] ), .B2(n2512), .Y(n2369) );
  sky130_fd_sc_hd__a22oi_1 U3177 ( .A1(\cpuregs[24][25] ), .A2(n2515), .B1(
        \cpuregs[25][25] ), .B2(n2514), .Y(n2368) );
  sky130_fd_sc_hd__nand4_1 U3178 ( .A(n2371), .B(n2370), .C(n2369), .D(n2368), 
        .Y(n2372) );
  sky130_fd_sc_hd__o21ai_0 U3179 ( .A1(n2373), .A2(n2372), .B1(N91), .Y(n2374)
         );
  sky130_fd_sc_hd__nand2_1 U3180 ( .A(n2375), .B(n2374), .Y(N792) );
  sky130_fd_sc_hd__a22oi_1 U3181 ( .A1(\cpuregs[6][26] ), .A2(n2497), .B1(
        \cpuregs[7][26] ), .B2(n2496), .Y(n2379) );
  sky130_fd_sc_hd__a22oi_1 U3182 ( .A1(\cpuregs[4][26] ), .A2(n2499), .B1(
        \cpuregs[5][26] ), .B2(n2498), .Y(n2378) );
  sky130_fd_sc_hd__a22oi_1 U3183 ( .A1(\cpuregs[2][26] ), .A2(n2501), .B1(
        \cpuregs[3][26] ), .B2(n2500), .Y(n2377) );
  sky130_fd_sc_hd__a22oi_1 U3184 ( .A1(\cpuregs[0][26] ), .A2(n2503), .B1(
        \cpuregs[1][26] ), .B2(n2502), .Y(n2376) );
  sky130_fd_sc_hd__nand4_1 U3185 ( .A(n2379), .B(n2378), .C(n2377), .D(n2376), 
        .Y(n2385) );
  sky130_fd_sc_hd__a22oi_1 U3186 ( .A1(\cpuregs[14][26] ), .A2(n2509), .B1(
        \cpuregs[15][26] ), .B2(n2508), .Y(n2383) );
  sky130_fd_sc_hd__a22oi_1 U3187 ( .A1(\cpuregs[12][26] ), .A2(n2511), .B1(
        \cpuregs[13][26] ), .B2(n2510), .Y(n2382) );
  sky130_fd_sc_hd__a22oi_1 U3188 ( .A1(\cpuregs[10][26] ), .A2(n2513), .B1(
        \cpuregs[11][26] ), .B2(n2512), .Y(n2381) );
  sky130_fd_sc_hd__a22oi_1 U3189 ( .A1(\cpuregs[8][26] ), .A2(n2515), .B1(
        \cpuregs[9][26] ), .B2(n2514), .Y(n2380) );
  sky130_fd_sc_hd__nand4_1 U3190 ( .A(n2383), .B(n2382), .C(n2381), .D(n2380), 
        .Y(n2384) );
  sky130_fd_sc_hd__o21ai_0 U3191 ( .A1(n2385), .A2(n2384), .B1(n2527), .Y(
        n2397) );
  sky130_fd_sc_hd__a22oi_1 U3192 ( .A1(\cpuregs[22][26] ), .A2(n2497), .B1(
        \cpuregs[23][26] ), .B2(n2496), .Y(n2389) );
  sky130_fd_sc_hd__a22oi_1 U3193 ( .A1(\cpuregs[20][26] ), .A2(n2499), .B1(
        \cpuregs[21][26] ), .B2(n2498), .Y(n2388) );
  sky130_fd_sc_hd__a22oi_1 U3194 ( .A1(\cpuregs[18][26] ), .A2(n2501), .B1(
        \cpuregs[19][26] ), .B2(n2500), .Y(n2387) );
  sky130_fd_sc_hd__a22oi_1 U3195 ( .A1(\cpuregs[16][26] ), .A2(n2503), .B1(
        \cpuregs[17][26] ), .B2(n2502), .Y(n2386) );
  sky130_fd_sc_hd__nand4_1 U3196 ( .A(n2389), .B(n2388), .C(n2387), .D(n2386), 
        .Y(n2395) );
  sky130_fd_sc_hd__a22oi_1 U3197 ( .A1(\cpuregs[30][26] ), .A2(n2509), .B1(
        \cpuregs[31][26] ), .B2(n2508), .Y(n2393) );
  sky130_fd_sc_hd__a22oi_1 U3198 ( .A1(\cpuregs[28][26] ), .A2(n2511), .B1(
        \cpuregs[29][26] ), .B2(n2510), .Y(n2392) );
  sky130_fd_sc_hd__a22oi_1 U3199 ( .A1(\cpuregs[26][26] ), .A2(n2513), .B1(
        \cpuregs[27][26] ), .B2(n2512), .Y(n2391) );
  sky130_fd_sc_hd__a22oi_1 U3200 ( .A1(\cpuregs[24][26] ), .A2(n2515), .B1(
        \cpuregs[25][26] ), .B2(n2514), .Y(n2390) );
  sky130_fd_sc_hd__nand4_1 U3201 ( .A(n2393), .B(n2392), .C(n2391), .D(n2390), 
        .Y(n2394) );
  sky130_fd_sc_hd__o21ai_0 U3202 ( .A1(n2395), .A2(n2394), .B1(N91), .Y(n2396)
         );
  sky130_fd_sc_hd__nand2_1 U3203 ( .A(n2397), .B(n2396), .Y(N791) );
  sky130_fd_sc_hd__a22oi_1 U3204 ( .A1(\cpuregs[6][27] ), .A2(n2497), .B1(
        \cpuregs[7][27] ), .B2(n2496), .Y(n2401) );
  sky130_fd_sc_hd__a22oi_1 U3205 ( .A1(\cpuregs[4][27] ), .A2(n2499), .B1(
        \cpuregs[5][27] ), .B2(n2498), .Y(n2400) );
  sky130_fd_sc_hd__a22oi_1 U3206 ( .A1(\cpuregs[2][27] ), .A2(n2501), .B1(
        \cpuregs[3][27] ), .B2(n2500), .Y(n2399) );
  sky130_fd_sc_hd__a22oi_1 U3207 ( .A1(\cpuregs[0][27] ), .A2(n2503), .B1(
        \cpuregs[1][27] ), .B2(n2502), .Y(n2398) );
  sky130_fd_sc_hd__nand4_1 U3208 ( .A(n2401), .B(n2400), .C(n2399), .D(n2398), 
        .Y(n2407) );
  sky130_fd_sc_hd__a22oi_1 U3209 ( .A1(\cpuregs[14][27] ), .A2(n2509), .B1(
        \cpuregs[15][27] ), .B2(n2508), .Y(n2405) );
  sky130_fd_sc_hd__a22oi_1 U3210 ( .A1(\cpuregs[12][27] ), .A2(n2511), .B1(
        \cpuregs[13][27] ), .B2(n2510), .Y(n2404) );
  sky130_fd_sc_hd__a22oi_1 U3211 ( .A1(\cpuregs[10][27] ), .A2(n2513), .B1(
        \cpuregs[11][27] ), .B2(n2512), .Y(n2403) );
  sky130_fd_sc_hd__a22oi_1 U3212 ( .A1(\cpuregs[8][27] ), .A2(n2515), .B1(
        \cpuregs[9][27] ), .B2(n2514), .Y(n2402) );
  sky130_fd_sc_hd__nand4_1 U3213 ( .A(n2405), .B(n2404), .C(n2403), .D(n2402), 
        .Y(n2406) );
  sky130_fd_sc_hd__o21ai_0 U3214 ( .A1(n2407), .A2(n2406), .B1(n2527), .Y(
        n2419) );
  sky130_fd_sc_hd__a22oi_1 U3215 ( .A1(\cpuregs[22][27] ), .A2(n2497), .B1(
        \cpuregs[23][27] ), .B2(n2496), .Y(n2411) );
  sky130_fd_sc_hd__a22oi_1 U3216 ( .A1(\cpuregs[20][27] ), .A2(n2499), .B1(
        \cpuregs[21][27] ), .B2(n2498), .Y(n2410) );
  sky130_fd_sc_hd__a22oi_1 U3217 ( .A1(\cpuregs[18][27] ), .A2(n2501), .B1(
        \cpuregs[19][27] ), .B2(n2500), .Y(n2409) );
  sky130_fd_sc_hd__a22oi_1 U3218 ( .A1(\cpuregs[16][27] ), .A2(n2503), .B1(
        \cpuregs[17][27] ), .B2(n2502), .Y(n2408) );
  sky130_fd_sc_hd__nand4_1 U3219 ( .A(n2411), .B(n2410), .C(n2409), .D(n2408), 
        .Y(n2417) );
  sky130_fd_sc_hd__a22oi_1 U3220 ( .A1(\cpuregs[30][27] ), .A2(n2509), .B1(
        \cpuregs[31][27] ), .B2(n2508), .Y(n2415) );
  sky130_fd_sc_hd__a22oi_1 U3221 ( .A1(\cpuregs[28][27] ), .A2(n2511), .B1(
        \cpuregs[29][27] ), .B2(n2510), .Y(n2414) );
  sky130_fd_sc_hd__a22oi_1 U3222 ( .A1(\cpuregs[26][27] ), .A2(n2513), .B1(
        \cpuregs[27][27] ), .B2(n2512), .Y(n2413) );
  sky130_fd_sc_hd__a22oi_1 U3223 ( .A1(\cpuregs[24][27] ), .A2(n2515), .B1(
        \cpuregs[25][27] ), .B2(n2514), .Y(n2412) );
  sky130_fd_sc_hd__nand4_1 U3224 ( .A(n2415), .B(n2414), .C(n2413), .D(n2412), 
        .Y(n2416) );
  sky130_fd_sc_hd__o21ai_0 U3225 ( .A1(n2417), .A2(n2416), .B1(N91), .Y(n2418)
         );
  sky130_fd_sc_hd__nand2_1 U3226 ( .A(n2419), .B(n2418), .Y(N790) );
  sky130_fd_sc_hd__a22oi_1 U3227 ( .A1(\cpuregs[6][28] ), .A2(n2497), .B1(
        \cpuregs[7][28] ), .B2(n2496), .Y(n2423) );
  sky130_fd_sc_hd__a22oi_1 U3228 ( .A1(\cpuregs[4][28] ), .A2(n2499), .B1(
        \cpuregs[5][28] ), .B2(n2498), .Y(n2422) );
  sky130_fd_sc_hd__a22oi_1 U3229 ( .A1(\cpuregs[2][28] ), .A2(n2501), .B1(
        \cpuregs[3][28] ), .B2(n2500), .Y(n2421) );
  sky130_fd_sc_hd__a22oi_1 U3230 ( .A1(\cpuregs[0][28] ), .A2(n2503), .B1(
        \cpuregs[1][28] ), .B2(n2502), .Y(n2420) );
  sky130_fd_sc_hd__nand4_1 U3231 ( .A(n2423), .B(n2422), .C(n2421), .D(n2420), 
        .Y(n2429) );
  sky130_fd_sc_hd__a22oi_1 U3232 ( .A1(\cpuregs[14][28] ), .A2(n2509), .B1(
        \cpuregs[15][28] ), .B2(n2508), .Y(n2427) );
  sky130_fd_sc_hd__a22oi_1 U3233 ( .A1(\cpuregs[12][28] ), .A2(n2511), .B1(
        \cpuregs[13][28] ), .B2(n2510), .Y(n2426) );
  sky130_fd_sc_hd__a22oi_1 U3234 ( .A1(\cpuregs[10][28] ), .A2(n2513), .B1(
        \cpuregs[11][28] ), .B2(n2512), .Y(n2425) );
  sky130_fd_sc_hd__a22oi_1 U3235 ( .A1(\cpuregs[8][28] ), .A2(n2515), .B1(
        \cpuregs[9][28] ), .B2(n2514), .Y(n2424) );
  sky130_fd_sc_hd__nand4_1 U3236 ( .A(n2427), .B(n2426), .C(n2425), .D(n2424), 
        .Y(n2428) );
  sky130_fd_sc_hd__o21ai_0 U3237 ( .A1(n2429), .A2(n2428), .B1(n2527), .Y(
        n2441) );
  sky130_fd_sc_hd__a22oi_1 U3238 ( .A1(\cpuregs[22][28] ), .A2(n2497), .B1(
        \cpuregs[23][28] ), .B2(n2496), .Y(n2433) );
  sky130_fd_sc_hd__a22oi_1 U3239 ( .A1(\cpuregs[20][28] ), .A2(n2499), .B1(
        \cpuregs[21][28] ), .B2(n2498), .Y(n2432) );
  sky130_fd_sc_hd__a22oi_1 U3240 ( .A1(\cpuregs[18][28] ), .A2(n2501), .B1(
        \cpuregs[19][28] ), .B2(n2500), .Y(n2431) );
  sky130_fd_sc_hd__a22oi_1 U3241 ( .A1(\cpuregs[16][28] ), .A2(n2503), .B1(
        \cpuregs[17][28] ), .B2(n2502), .Y(n2430) );
  sky130_fd_sc_hd__nand4_1 U3242 ( .A(n2433), .B(n2432), .C(n2431), .D(n2430), 
        .Y(n2439) );
  sky130_fd_sc_hd__a22oi_1 U3243 ( .A1(\cpuregs[30][28] ), .A2(n2509), .B1(
        \cpuregs[31][28] ), .B2(n2508), .Y(n2437) );
  sky130_fd_sc_hd__a22oi_1 U3244 ( .A1(\cpuregs[28][28] ), .A2(n2511), .B1(
        \cpuregs[29][28] ), .B2(n2510), .Y(n2436) );
  sky130_fd_sc_hd__a22oi_1 U3245 ( .A1(\cpuregs[26][28] ), .A2(n2513), .B1(
        \cpuregs[27][28] ), .B2(n2512), .Y(n2435) );
  sky130_fd_sc_hd__a22oi_1 U3246 ( .A1(\cpuregs[24][28] ), .A2(n2515), .B1(
        \cpuregs[25][28] ), .B2(n2514), .Y(n2434) );
  sky130_fd_sc_hd__nand4_1 U3247 ( .A(n2437), .B(n2436), .C(n2435), .D(n2434), 
        .Y(n2438) );
  sky130_fd_sc_hd__o21ai_0 U3248 ( .A1(n2439), .A2(n2438), .B1(N91), .Y(n2440)
         );
  sky130_fd_sc_hd__nand2_1 U3249 ( .A(n2441), .B(n2440), .Y(N789) );
  sky130_fd_sc_hd__a22oi_1 U3250 ( .A1(\cpuregs[6][29] ), .A2(n2497), .B1(
        \cpuregs[7][29] ), .B2(n2496), .Y(n2445) );
  sky130_fd_sc_hd__a22oi_1 U3251 ( .A1(\cpuregs[4][29] ), .A2(n2499), .B1(
        \cpuregs[5][29] ), .B2(n2498), .Y(n2444) );
  sky130_fd_sc_hd__a22oi_1 U3252 ( .A1(\cpuregs[2][29] ), .A2(n2501), .B1(
        \cpuregs[3][29] ), .B2(n2500), .Y(n2443) );
  sky130_fd_sc_hd__a22oi_1 U3253 ( .A1(\cpuregs[0][29] ), .A2(n2503), .B1(
        \cpuregs[1][29] ), .B2(n2502), .Y(n2442) );
  sky130_fd_sc_hd__nand4_1 U3254 ( .A(n2445), .B(n2444), .C(n2443), .D(n2442), 
        .Y(n2451) );
  sky130_fd_sc_hd__a22oi_1 U3255 ( .A1(\cpuregs[14][29] ), .A2(n2509), .B1(
        \cpuregs[15][29] ), .B2(n2508), .Y(n2449) );
  sky130_fd_sc_hd__a22oi_1 U3256 ( .A1(\cpuregs[12][29] ), .A2(n2511), .B1(
        \cpuregs[13][29] ), .B2(n2510), .Y(n2448) );
  sky130_fd_sc_hd__a22oi_1 U3257 ( .A1(\cpuregs[10][29] ), .A2(n2513), .B1(
        \cpuregs[11][29] ), .B2(n2512), .Y(n2447) );
  sky130_fd_sc_hd__a22oi_1 U3258 ( .A1(\cpuregs[8][29] ), .A2(n2515), .B1(
        \cpuregs[9][29] ), .B2(n2514), .Y(n2446) );
  sky130_fd_sc_hd__nand4_1 U3259 ( .A(n2449), .B(n2448), .C(n2447), .D(n2446), 
        .Y(n2450) );
  sky130_fd_sc_hd__o21ai_0 U3260 ( .A1(n2451), .A2(n2450), .B1(n2527), .Y(
        n2463) );
  sky130_fd_sc_hd__a22oi_1 U3261 ( .A1(\cpuregs[22][29] ), .A2(n2497), .B1(
        \cpuregs[23][29] ), .B2(n2496), .Y(n2455) );
  sky130_fd_sc_hd__a22oi_1 U3262 ( .A1(\cpuregs[20][29] ), .A2(n2499), .B1(
        \cpuregs[21][29] ), .B2(n2498), .Y(n2454) );
  sky130_fd_sc_hd__a22oi_1 U3263 ( .A1(\cpuregs[18][29] ), .A2(n2501), .B1(
        \cpuregs[19][29] ), .B2(n2500), .Y(n2453) );
  sky130_fd_sc_hd__a22oi_1 U3264 ( .A1(\cpuregs[16][29] ), .A2(n2503), .B1(
        \cpuregs[17][29] ), .B2(n2502), .Y(n2452) );
  sky130_fd_sc_hd__nand4_1 U3265 ( .A(n2455), .B(n2454), .C(n2453), .D(n2452), 
        .Y(n2461) );
  sky130_fd_sc_hd__a22oi_1 U3266 ( .A1(\cpuregs[30][29] ), .A2(n2509), .B1(
        \cpuregs[31][29] ), .B2(n2508), .Y(n2459) );
  sky130_fd_sc_hd__a22oi_1 U3267 ( .A1(\cpuregs[28][29] ), .A2(n2511), .B1(
        \cpuregs[29][29] ), .B2(n2510), .Y(n2458) );
  sky130_fd_sc_hd__a22oi_1 U3268 ( .A1(\cpuregs[26][29] ), .A2(n2513), .B1(
        \cpuregs[27][29] ), .B2(n2512), .Y(n2457) );
  sky130_fd_sc_hd__a22oi_1 U3269 ( .A1(\cpuregs[24][29] ), .A2(n2515), .B1(
        \cpuregs[25][29] ), .B2(n2514), .Y(n2456) );
  sky130_fd_sc_hd__nand4_1 U3270 ( .A(n2459), .B(n2458), .C(n2457), .D(n2456), 
        .Y(n2460) );
  sky130_fd_sc_hd__o21ai_0 U3271 ( .A1(n2461), .A2(n2460), .B1(N91), .Y(n2462)
         );
  sky130_fd_sc_hd__nand2_1 U3272 ( .A(n2463), .B(n2462), .Y(N788) );
  sky130_fd_sc_hd__a22oi_1 U3273 ( .A1(\cpuregs[6][30] ), .A2(n2497), .B1(
        \cpuregs[7][30] ), .B2(n2496), .Y(n2467) );
  sky130_fd_sc_hd__a22oi_1 U3274 ( .A1(\cpuregs[4][30] ), .A2(n2499), .B1(
        \cpuregs[5][30] ), .B2(n2498), .Y(n2466) );
  sky130_fd_sc_hd__a22oi_1 U3275 ( .A1(\cpuregs[2][30] ), .A2(n2501), .B1(
        \cpuregs[3][30] ), .B2(n2500), .Y(n2465) );
  sky130_fd_sc_hd__a22oi_1 U3276 ( .A1(\cpuregs[0][30] ), .A2(n2503), .B1(
        \cpuregs[1][30] ), .B2(n2502), .Y(n2464) );
  sky130_fd_sc_hd__nand4_1 U3277 ( .A(n2467), .B(n2466), .C(n2465), .D(n2464), 
        .Y(n2473) );
  sky130_fd_sc_hd__a22oi_1 U3278 ( .A1(\cpuregs[14][30] ), .A2(n2509), .B1(
        \cpuregs[15][30] ), .B2(n2508), .Y(n2471) );
  sky130_fd_sc_hd__a22oi_1 U3279 ( .A1(\cpuregs[12][30] ), .A2(n2511), .B1(
        \cpuregs[13][30] ), .B2(n2510), .Y(n2470) );
  sky130_fd_sc_hd__a22oi_1 U3280 ( .A1(\cpuregs[10][30] ), .A2(n2513), .B1(
        \cpuregs[11][30] ), .B2(n2512), .Y(n2469) );
  sky130_fd_sc_hd__a22oi_1 U3281 ( .A1(\cpuregs[8][30] ), .A2(n2515), .B1(
        \cpuregs[9][30] ), .B2(n2514), .Y(n2468) );
  sky130_fd_sc_hd__nand4_1 U3282 ( .A(n2471), .B(n2470), .C(n2469), .D(n2468), 
        .Y(n2472) );
  sky130_fd_sc_hd__o21ai_0 U3283 ( .A1(n2473), .A2(n2472), .B1(n2527), .Y(
        n2485) );
  sky130_fd_sc_hd__a22oi_1 U3284 ( .A1(\cpuregs[22][30] ), .A2(n2497), .B1(
        \cpuregs[23][30] ), .B2(n2496), .Y(n2477) );
  sky130_fd_sc_hd__a22oi_1 U3285 ( .A1(\cpuregs[20][30] ), .A2(n2499), .B1(
        \cpuregs[21][30] ), .B2(n2498), .Y(n2476) );
  sky130_fd_sc_hd__a22oi_1 U3286 ( .A1(\cpuregs[18][30] ), .A2(n2501), .B1(
        \cpuregs[19][30] ), .B2(n2500), .Y(n2475) );
  sky130_fd_sc_hd__a22oi_1 U3287 ( .A1(\cpuregs[16][30] ), .A2(n2503), .B1(
        \cpuregs[17][30] ), .B2(n2502), .Y(n2474) );
  sky130_fd_sc_hd__nand4_1 U3288 ( .A(n2477), .B(n2476), .C(n2475), .D(n2474), 
        .Y(n2483) );
  sky130_fd_sc_hd__a22oi_1 U3289 ( .A1(\cpuregs[30][30] ), .A2(n2509), .B1(
        \cpuregs[31][30] ), .B2(n2508), .Y(n2481) );
  sky130_fd_sc_hd__a22oi_1 U3290 ( .A1(\cpuregs[28][30] ), .A2(n2511), .B1(
        \cpuregs[29][30] ), .B2(n2510), .Y(n2480) );
  sky130_fd_sc_hd__a22oi_1 U3291 ( .A1(\cpuregs[26][30] ), .A2(n2513), .B1(
        \cpuregs[27][30] ), .B2(n2512), .Y(n2479) );
  sky130_fd_sc_hd__a22oi_1 U3292 ( .A1(\cpuregs[24][30] ), .A2(n2515), .B1(
        \cpuregs[25][30] ), .B2(n2514), .Y(n2478) );
  sky130_fd_sc_hd__nand4_1 U3293 ( .A(n2481), .B(n2480), .C(n2479), .D(n2478), 
        .Y(n2482) );
  sky130_fd_sc_hd__o21ai_0 U3294 ( .A1(n2483), .A2(n2482), .B1(N91), .Y(n2484)
         );
  sky130_fd_sc_hd__nand2_1 U3295 ( .A(n2485), .B(n2484), .Y(N787) );
  sky130_fd_sc_hd__a22oi_1 U3296 ( .A1(\cpuregs[6][31] ), .A2(n2497), .B1(
        \cpuregs[7][31] ), .B2(n2496), .Y(n2489) );
  sky130_fd_sc_hd__a22oi_1 U3297 ( .A1(\cpuregs[4][31] ), .A2(n2499), .B1(
        \cpuregs[5][31] ), .B2(n2498), .Y(n2488) );
  sky130_fd_sc_hd__a22oi_1 U3298 ( .A1(\cpuregs[2][31] ), .A2(n2501), .B1(
        \cpuregs[3][31] ), .B2(n2500), .Y(n2487) );
  sky130_fd_sc_hd__a22oi_1 U3299 ( .A1(\cpuregs[0][31] ), .A2(n2503), .B1(
        \cpuregs[1][31] ), .B2(n2502), .Y(n2486) );
  sky130_fd_sc_hd__nand4_1 U3300 ( .A(n2489), .B(n2488), .C(n2487), .D(n2486), 
        .Y(n2495) );
  sky130_fd_sc_hd__a22oi_1 U3301 ( .A1(\cpuregs[14][31] ), .A2(n2509), .B1(
        \cpuregs[15][31] ), .B2(n2508), .Y(n2493) );
  sky130_fd_sc_hd__a22oi_1 U3302 ( .A1(\cpuregs[12][31] ), .A2(n2511), .B1(
        \cpuregs[13][31] ), .B2(n2510), .Y(n2492) );
  sky130_fd_sc_hd__a22oi_1 U3303 ( .A1(\cpuregs[10][31] ), .A2(n2513), .B1(
        \cpuregs[11][31] ), .B2(n2512), .Y(n2491) );
  sky130_fd_sc_hd__a22oi_1 U3304 ( .A1(\cpuregs[8][31] ), .A2(n2515), .B1(
        \cpuregs[9][31] ), .B2(n2514), .Y(n2490) );
  sky130_fd_sc_hd__nand4_1 U3305 ( .A(n2493), .B(n2492), .C(n2491), .D(n2490), 
        .Y(n2494) );
  sky130_fd_sc_hd__o21ai_0 U3306 ( .A1(n2495), .A2(n2494), .B1(n2527), .Y(
        n2523) );
  sky130_fd_sc_hd__a22oi_1 U3307 ( .A1(\cpuregs[22][31] ), .A2(n2497), .B1(
        \cpuregs[23][31] ), .B2(n2496), .Y(n2507) );
  sky130_fd_sc_hd__a22oi_1 U3308 ( .A1(\cpuregs[20][31] ), .A2(n2499), .B1(
        \cpuregs[21][31] ), .B2(n2498), .Y(n2506) );
  sky130_fd_sc_hd__a22oi_1 U3309 ( .A1(\cpuregs[18][31] ), .A2(n2501), .B1(
        \cpuregs[19][31] ), .B2(n2500), .Y(n2505) );
  sky130_fd_sc_hd__a22oi_1 U3310 ( .A1(\cpuregs[16][31] ), .A2(n2503), .B1(
        \cpuregs[17][31] ), .B2(n2502), .Y(n2504) );
  sky130_fd_sc_hd__nand4_1 U3311 ( .A(n2507), .B(n2506), .C(n2505), .D(n2504), 
        .Y(n2521) );
  sky130_fd_sc_hd__a22oi_1 U3312 ( .A1(\cpuregs[30][31] ), .A2(n2509), .B1(
        \cpuregs[31][31] ), .B2(n2508), .Y(n2519) );
  sky130_fd_sc_hd__a22oi_1 U3313 ( .A1(\cpuregs[28][31] ), .A2(n2511), .B1(
        \cpuregs[29][31] ), .B2(n2510), .Y(n2518) );
  sky130_fd_sc_hd__a22oi_1 U3314 ( .A1(\cpuregs[26][31] ), .A2(n2513), .B1(
        \cpuregs[27][31] ), .B2(n2512), .Y(n2517) );
  sky130_fd_sc_hd__a22oi_1 U3315 ( .A1(\cpuregs[24][31] ), .A2(n2515), .B1(
        \cpuregs[25][31] ), .B2(n2514), .Y(n2516) );
  sky130_fd_sc_hd__nand4_1 U3316 ( .A(n2519), .B(n2518), .C(n2517), .D(n2516), 
        .Y(n2520) );
  sky130_fd_sc_hd__o21ai_0 U3317 ( .A1(n2521), .A2(n2520), .B1(N91), .Y(n2522)
         );
  sky130_fd_sc_hd__nand2_1 U3318 ( .A(n2523), .B(n2522), .Y(N786) );
  sky130_fd_sc_hd__nand4_1 U3319 ( .A(n2528), .B(n2529), .C(n2530), .D(n2531), 
        .Y(net420) );
  sky130_fd_sc_hd__nor3_1 U3320 ( .A(n2532), .B(n2533), .C(n2534), .Y(n2531)
         );
  sky130_fd_sc_hd__mux2i_1 U3321 ( .A0(n2535), .A1(n2536), .S(n2537), .Y(n3536) );
  sky130_fd_sc_hd__nand2_1 U3322 ( .A(instr_lh), .B(n2538), .Y(n2535) );
  sky130_fd_sc_hd__mux2i_1 U3323 ( .A0(n2539), .A1(n2540), .S(n2537), .Y(n3535) );
  sky130_fd_sc_hd__nor2_1 U3324 ( .A(n2541), .B(n3538), .Y(n2537) );
  sky130_fd_sc_hd__nand2_1 U3325 ( .A(is_lbu_lhu_lw), .B(n2538), .Y(n2539) );
  sky130_fd_sc_hd__clkinv_1 U3326 ( .A(n2542), .Y(n2538) );
  sky130_fd_sc_hd__nor2_1 U3327 ( .A(mem_do_wdata), .B(n2543), .Y(n3537) );
  sky130_fd_sc_hd__clkinv_1 U3328 ( .A(n2544), .Y(n3539) );
  sky130_fd_sc_hd__clkinv_1 U3329 ( .A(n2545), .Y(n3540) );
  sky130_fd_sc_hd__clkinv_1 U3330 ( .A(n2546), .Y(n3541) );
  sky130_fd_sc_hd__clkinv_1 U3331 ( .A(n2547), .Y(n3542) );
  sky130_fd_sc_hd__clkinv_1 U3332 ( .A(n2548), .Y(n3543) );
  sky130_fd_sc_hd__clkinv_1 U3333 ( .A(n2549), .Y(n3544) );
  sky130_fd_sc_hd__clkinv_1 U3334 ( .A(n2550), .Y(n3545) );
  sky130_fd_sc_hd__clkinv_1 U3335 ( .A(n2551), .Y(n3546) );
  sky130_fd_sc_hd__clkinv_1 U3336 ( .A(n2552), .Y(n3547) );
  sky130_fd_sc_hd__clkinv_1 U3337 ( .A(n2553), .Y(n3548) );
  sky130_fd_sc_hd__clkinv_1 U3338 ( .A(n2554), .Y(n3549) );
  sky130_fd_sc_hd__clkinv_1 U3339 ( .A(n2555), .Y(n3550) );
  sky130_fd_sc_hd__clkinv_1 U3340 ( .A(n2556), .Y(n3551) );
  sky130_fd_sc_hd__clkinv_1 U3341 ( .A(n2557), .Y(n3552) );
  sky130_fd_sc_hd__clkinv_1 U3342 ( .A(n2558), .Y(n3553) );
  sky130_fd_sc_hd__clkinv_1 U3343 ( .A(n2559), .Y(n3554) );
  sky130_fd_sc_hd__clkinv_1 U3344 ( .A(n2560), .Y(n3555) );
  sky130_fd_sc_hd__clkinv_1 U3345 ( .A(n2561), .Y(n3556) );
  sky130_fd_sc_hd__clkinv_1 U3346 ( .A(n2562), .Y(n3557) );
  sky130_fd_sc_hd__clkinv_1 U3347 ( .A(n2563), .Y(n3558) );
  sky130_fd_sc_hd__clkinv_1 U3348 ( .A(n2564), .Y(n3559) );
  sky130_fd_sc_hd__clkinv_1 U3349 ( .A(n2565), .Y(n3560) );
  sky130_fd_sc_hd__clkinv_1 U3350 ( .A(n2566), .Y(n3561) );
  sky130_fd_sc_hd__clkinv_1 U3351 ( .A(n2567), .Y(n3562) );
  sky130_fd_sc_hd__clkinv_1 U3352 ( .A(n2568), .Y(n3563) );
  sky130_fd_sc_hd__clkinv_1 U3353 ( .A(n2569), .Y(n3564) );
  sky130_fd_sc_hd__clkinv_1 U3354 ( .A(n2570), .Y(n3565) );
  sky130_fd_sc_hd__clkinv_1 U3355 ( .A(n2571), .Y(n3566) );
  sky130_fd_sc_hd__clkinv_1 U3356 ( .A(n2572), .Y(n3567) );
  sky130_fd_sc_hd__clkinv_1 U3357 ( .A(n2573), .Y(n3568) );
  sky130_fd_sc_hd__clkinv_1 U3358 ( .A(n2574), .Y(n3569) );
  sky130_fd_sc_hd__clkinv_1 U3359 ( .A(n2575), .Y(n3570) );
  sky130_fd_sc_hd__clkinv_1 U3360 ( .A(n2576), .Y(n3572) );
  sky130_fd_sc_hd__a222oi_1 U3361 ( .A1(N584), .A2(latched_branch), .B1(
        alu_out_q[0]), .B2(n2577), .C1(reg_out[0]), .C2(n2578), .Y(n2576) );
  sky130_fd_sc_hd__nor3_1 U3362 ( .A(n2579), .B(n2580), .C(n2581), .Y(n1041)
         );
  sky130_fd_sc_hd__nor3_1 U3363 ( .A(n2579), .B(n2582), .C(n2581), .Y(n1040)
         );
  sky130_fd_sc_hd__nor3_1 U3364 ( .A(n2583), .B(n2584), .C(n2581), .Y(n1039)
         );
  sky130_fd_sc_hd__nand3b_1 U3365 ( .A_N(n2585), .B(n2586), .C(n2587), .Y(
        n2583) );
  sky130_fd_sc_hd__nor4_1 U3366 ( .A(n2588), .B(n2589), .C(n2582), .D(n2590), 
        .Y(n1038) );
  sky130_fd_sc_hd__nor4_1 U3367 ( .A(n2588), .B(n2589), .C(n2590), .D(n2580), 
        .Y(n1037) );
  sky130_fd_sc_hd__nor3_1 U3368 ( .A(n2579), .B(n2591), .C(n2582), .Y(n1036)
         );
  sky130_fd_sc_hd__nor3_1 U3369 ( .A(n2579), .B(n2591), .C(n2580), .Y(n1035)
         );
  sky130_fd_sc_hd__clkinv_1 U3370 ( .A(n2582), .Y(n2580) );
  sky130_fd_sc_hd__or3_1 U3371 ( .A(n2592), .B(n2588), .C(n2593), .X(n2579) );
  sky130_fd_sc_hd__o22ai_1 U3372 ( .A1(n1063), .A2(n2594), .B1(n2534), .B2(
        n2595), .Y(n1034) );
  sky130_fd_sc_hd__mux2i_1 U3373 ( .A0(n2596), .A1(n2597), .S(n2598), .Y(n1033) );
  sky130_fd_sc_hd__a32oi_1 U3374 ( .A1(cpu_state[1]), .A2(n2599), .A3(instr_sh), .B1(n2600), .B2(cpu_state[0]), .Y(n2597) );
  sky130_fd_sc_hd__clkinv_1 U3375 ( .A(instr_sb), .Y(n2599) );
  sky130_fd_sc_hd__mux2_1 U3376 ( .A0(n2601), .A1(pcpi_rs1[31]), .S(n2602), 
        .X(n1032) );
  sky130_fd_sc_hd__nor2_1 U3377 ( .A(n2603), .B(n2604), .Y(n2602) );
  sky130_fd_sc_hd__o2111ai_1 U3378 ( .A1(n2605), .A2(n2606), .B1(n2607), .C1(
        n2608), .D1(n2609), .Y(n2601) );
  sky130_fd_sc_hd__a222oi_1 U3379 ( .A1(reg_pc[31]), .A2(n2610), .B1(N752), 
        .B2(n2611), .C1(N1688), .C2(n2612), .Y(n2609) );
  sky130_fd_sc_hd__nand4_1 U3380 ( .A(pcpi_rs1[31]), .B(n2613), .C(n2614), .D(
        n2615), .Y(n2608) );
  sky130_fd_sc_hd__nand2_1 U3381 ( .A(pcpi_rs1[27]), .B(n2616), .Y(n2607) );
  sky130_fd_sc_hd__clkinv_1 U3382 ( .A(n2617), .Y(n2605) );
  sky130_fd_sc_hd__mux2i_1 U3383 ( .A0(n2618), .A1(n2619), .S(n2620), .Y(n1031) );
  sky130_fd_sc_hd__a2111oi_0 U3384 ( .A1(n2533), .A2(n2621), .B1(n2622), .C1(
        n2623), .D1(n2624), .Y(n2620) );
  sky130_fd_sc_hd__o21ai_0 U3385 ( .A1(n2615), .A2(n2530), .B1(n2625), .Y(
        n2622) );
  sky130_fd_sc_hd__o311ai_0 U3386 ( .A1(n2626), .A2(is_slli_srli_srai), .A3(
        n2627), .B1(n2628), .C1(n2629), .Y(n2621) );
  sky130_fd_sc_hd__a21oi_1 U3387 ( .A1(n2625), .A2(n2630), .B1(n2623), .Y(
        n2618) );
  sky130_fd_sc_hd__nor3_1 U3388 ( .A(n2631), .B(n2632), .C(n2529), .Y(n2623)
         );
  sky130_fd_sc_hd__o221ai_1 U3389 ( .A1(n2633), .A2(n2634), .B1(n2635), .B2(
        n2636), .C1(n2637), .Y(n2630) );
  sky130_fd_sc_hd__o22a_1 U3390 ( .A1(n2638), .A2(n2639), .B1(n2628), .B2(
        n2640), .X(n2637) );
  sky130_fd_sc_hd__clkinv_1 U3391 ( .A(n2534), .Y(n2625) );
  sky130_fd_sc_hd__o21ai_0 U3392 ( .A1(n2595), .A2(n2641), .B1(n2642), .Y(
        n1030) );
  sky130_fd_sc_hd__mux2i_1 U3393 ( .A0(n2643), .A1(mem_state[1]), .S(n2644), 
        .Y(n2642) );
  sky130_fd_sc_hd__clkinv_1 U3394 ( .A(n2645), .Y(n2643) );
  sky130_fd_sc_hd__mux2_1 U3395 ( .A0(n2646), .A1(mem_valid), .S(n2647), .X(
        n1029) );
  sky130_fd_sc_hd__a21oi_1 U3396 ( .A1(mem_ready), .A2(n2648), .B1(n2649), .Y(
        n2647) );
  sky130_fd_sc_hd__nand2_1 U3397 ( .A(n2650), .B(n2645), .Y(n1028) );
  sky130_fd_sc_hd__nand4_1 U3398 ( .A(n2651), .B(mem_state[0]), .C(n2652), .D(
        n2619), .Y(n2645) );
  sky130_fd_sc_hd__mux2i_1 U3399 ( .A0(n2653), .A1(mem_state[0]), .S(n2644), 
        .Y(n2650) );
  sky130_fd_sc_hd__a31oi_1 U3400 ( .A1(n2651), .A2(n2654), .A3(mem_do_rinst), 
        .B1(n2649), .Y(n2644) );
  sky130_fd_sc_hd__nand3_1 U3401 ( .A(n2655), .B(n2656), .C(n1053), .Y(n2649)
         );
  sky130_fd_sc_hd__nand4_1 U3402 ( .A(n2651), .B(n3571), .C(n2657), .D(n2658), 
        .Y(n2656) );
  sky130_fd_sc_hd__o21ai_0 U3403 ( .A1(mem_do_wdata), .A2(n2659), .B1(n2646), 
        .Y(n2655) );
  sky130_fd_sc_hd__clkinv_1 U3404 ( .A(n2657), .Y(n2654) );
  sky130_fd_sc_hd__nor2_1 U3405 ( .A(mem_do_wdata), .B(n2641), .Y(n2653) );
  sky130_fd_sc_hd__clkinv_1 U3406 ( .A(n2646), .Y(n2641) );
  sky130_fd_sc_hd__nor2_1 U3407 ( .A(n2648), .B(n2658), .Y(n2646) );
  sky130_fd_sc_hd__clkinv_1 U3408 ( .A(n2651), .Y(n2648) );
  sky130_fd_sc_hd__mux2i_1 U3409 ( .A0(n2632), .A1(n2660), .S(N258), .Y(n1027)
         );
  sky130_fd_sc_hd__or2_0 U3410 ( .A(n2584), .B(n2590), .X(n2660) );
  sky130_fd_sc_hd__or2_0 U3411 ( .A(n2593), .B(n2591), .X(n2590) );
  sky130_fd_sc_hd__clkinv_1 U3412 ( .A(n2581), .Y(n2591) );
  sky130_fd_sc_hd__mux2i_1 U3413 ( .A0(n2661), .A1(n2662), .S(n2598), .Y(n1026) );
  sky130_fd_sc_hd__o21a_1 U3414 ( .A1(n2663), .A2(n2664), .B1(n1053), .X(n2598) );
  sky130_fd_sc_hd__o21ai_0 U3415 ( .A1(n2665), .A2(n2594), .B1(n2528), .Y(
        n2664) );
  sky130_fd_sc_hd__clkinv_1 U3416 ( .A(n2666), .Y(n2594) );
  sky130_fd_sc_hd__o31a_1 U3417 ( .A1(n2600), .A2(instr_lw), .A3(n2667), .B1(
        n2541), .X(n2663) );
  sky130_fd_sc_hd__o21ba_1 U3418 ( .A1(instr_lhu), .A2(instr_lh), .B1_N(n2667), 
        .X(n2600) );
  sky130_fd_sc_hd__a22oi_1 U3419 ( .A1(cpu_state[0]), .A2(n2667), .B1(instr_sb), .B2(cpu_state[1]), .Y(n2662) );
  sky130_fd_sc_hd__or2_0 U3420 ( .A(instr_lbu), .B(instr_lb), .X(n2667) );
  sky130_fd_sc_hd__mux2_1 U3421 ( .A0(n2668), .A1(latched_store), .S(n2669), 
        .X(n1025) );
  sky130_fd_sc_hd__a2111oi_0 U3422 ( .A1(n2533), .A2(n2670), .B1(n2671), .C1(
        n2672), .D1(n2673), .Y(n2669) );
  sky130_fd_sc_hd__a31oi_1 U3423 ( .A1(n2674), .A2(n2675), .A3(n2639), .B1(
        n1063), .Y(n2668) );
  sky130_fd_sc_hd__o21ai_0 U3424 ( .A1(n2676), .A2(n2677), .B1(cpu_state[3]), 
        .Y(n2674) );
  sky130_fd_sc_hd__mux2i_1 U3425 ( .A0(n2542), .A1(n2678), .S(n2679), .Y(n1024) );
  sky130_fd_sc_hd__nor2b_1 U3426 ( .B_N(n2680), .A(n3538), .Y(n2679) );
  sky130_fd_sc_hd__mux2_1 U3427 ( .A0(latched_branch), .A1(n2681), .S(n2673), 
        .X(n1023) );
  sky130_fd_sc_hd__nand2b_1 U3428 ( .A_N(n3538), .B(n2529), .Y(n2673) );
  sky130_fd_sc_hd__nand2_1 U3429 ( .A(n1053), .B(n2528), .Y(n3538) );
  sky130_fd_sc_hd__o2bb2ai_1 U3430 ( .B1(n2542), .B2(n2682), .A1_N(
        cpu_state[6]), .A2_N(n2683), .Y(n2681) );
  sky130_fd_sc_hd__mux2i_1 U3431 ( .A0(instr_jalr), .A1(n2676), .S(
        is_beq_bne_blt_bge_bltu_bgeu), .Y(n2682) );
  sky130_fd_sc_hd__nor2_1 U3432 ( .A(n2534), .B(n2684), .Y(n1022) );
  sky130_fd_sc_hd__mux2i_1 U3433 ( .A0(mem_do_prefetch), .A1(n2685), .S(n2686), 
        .Y(n2684) );
  sky130_fd_sc_hd__nor2b_1 U3434 ( .B_N(n2635), .A(n2636), .Y(n2686) );
  sky130_fd_sc_hd__o22ai_1 U3435 ( .A1(n1063), .A2(n2687), .B1(n2534), .B2(
        n2652), .Y(n1021) );
  sky130_fd_sc_hd__nand2_1 U3436 ( .A(n1053), .B(n2688), .Y(n2534) );
  sky130_fd_sc_hd__mux2i_1 U3437 ( .A0(n2689), .A1(n2690), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[9]) );
  sky130_fd_sc_hd__mux2i_1 U3438 ( .A0(n2691), .A1(n2692), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[8]) );
  sky130_fd_sc_hd__mux2_1 U3439 ( .A0(mem_rdata[7]), .A1(mem_rdata_q[7]), .S(
        n2693), .X(mem_rdata_latched_noshuffle[7]) );
  sky130_fd_sc_hd__mux2i_1 U3440 ( .A0(n2694), .A1(n2695), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[31]) );
  sky130_fd_sc_hd__mux2i_1 U3441 ( .A0(n2696), .A1(n2697), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[30]) );
  sky130_fd_sc_hd__mux2_1 U3442 ( .A0(mem_rdata[29]), .A1(mem_rdata_q[29]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[29]) );
  sky130_fd_sc_hd__mux2_1 U3443 ( .A0(mem_rdata[28]), .A1(mem_rdata_q[28]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[28]) );
  sky130_fd_sc_hd__mux2i_1 U3444 ( .A0(n2698), .A1(n2699), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[27]) );
  sky130_fd_sc_hd__mux2_1 U3445 ( .A0(mem_rdata[26]), .A1(mem_rdata_q[26]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[26]) );
  sky130_fd_sc_hd__mux2_1 U3446 ( .A0(mem_rdata[25]), .A1(mem_rdata_q[25]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[25]) );
  sky130_fd_sc_hd__mux2i_1 U3447 ( .A0(n2700), .A1(n2701), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[24]) );
  sky130_fd_sc_hd__mux2i_1 U3448 ( .A0(n2702), .A1(n2703), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[23]) );
  sky130_fd_sc_hd__mux2i_1 U3449 ( .A0(n2704), .A1(n2705), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[22]) );
  sky130_fd_sc_hd__mux2i_1 U3450 ( .A0(n2706), .A1(n2707), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[21]) );
  sky130_fd_sc_hd__mux2i_1 U3451 ( .A0(n2708), .A1(n2709), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[20]) );
  sky130_fd_sc_hd__mux2i_1 U3452 ( .A0(n2710), .A1(n2711), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[19]) );
  sky130_fd_sc_hd__mux2i_1 U3453 ( .A0(n2712), .A1(n2713), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[18]) );
  sky130_fd_sc_hd__mux2i_1 U3454 ( .A0(n2714), .A1(n2715), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[17]) );
  sky130_fd_sc_hd__mux2_1 U3455 ( .A0(mem_rdata[16]), .A1(mem_rdata_q[16]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[16]) );
  sky130_fd_sc_hd__mux2_1 U3456 ( .A0(mem_rdata[15]), .A1(mem_rdata_q[15]), 
        .S(n2693), .X(mem_rdata_latched_noshuffle[15]) );
  sky130_fd_sc_hd__mux2i_1 U3457 ( .A0(n2716), .A1(n2717), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[14]) );
  sky130_fd_sc_hd__mux2i_1 U3458 ( .A0(n2718), .A1(n2719), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[13]) );
  sky130_fd_sc_hd__mux2i_1 U3459 ( .A0(n2720), .A1(n2721), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[12]) );
  sky130_fd_sc_hd__mux2i_1 U3460 ( .A0(n2722), .A1(n2723), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[11]) );
  sky130_fd_sc_hd__mux2i_1 U3461 ( .A0(n2724), .A1(n2725), .S(n3571), .Y(
        mem_rdata_latched_noshuffle[10]) );
  sky130_fd_sc_hd__o221ai_1 U3462 ( .A1(n2726), .A2(n2727), .B1(n2728), .B2(
        n2729), .C1(n2730), .Y(mem_la_addr[9]) );
  sky130_fd_sc_hd__nand2_1 U3463 ( .A(n2731), .B(reg_out[9]), .Y(n2730) );
  sky130_fd_sc_hd__o221ai_1 U3464 ( .A1(n2732), .A2(n2727), .B1(n2733), .B2(
        n2729), .C1(n2734), .Y(mem_la_addr[8]) );
  sky130_fd_sc_hd__nand2_1 U3465 ( .A(n2731), .B(reg_out[8]), .Y(n2734) );
  sky130_fd_sc_hd__o221ai_1 U3466 ( .A1(n2735), .A2(n2727), .B1(n2736), .B2(
        n2729), .C1(n2737), .Y(mem_la_addr[7]) );
  sky130_fd_sc_hd__nand2_1 U3467 ( .A(n2731), .B(reg_out[7]), .Y(n2737) );
  sky130_fd_sc_hd__o221ai_1 U3468 ( .A1(n2738), .A2(n2727), .B1(n2739), .B2(
        n2729), .C1(n2740), .Y(mem_la_addr[6]) );
  sky130_fd_sc_hd__nand2_1 U3469 ( .A(n2731), .B(reg_out[6]), .Y(n2740) );
  sky130_fd_sc_hd__o221ai_1 U3470 ( .A1(n2741), .A2(n2727), .B1(n2742), .B2(
        n2729), .C1(n2743), .Y(mem_la_addr[5]) );
  sky130_fd_sc_hd__nand2_1 U3471 ( .A(n2731), .B(reg_out[5]), .Y(n2743) );
  sky130_fd_sc_hd__o221ai_1 U3472 ( .A1(n2744), .A2(n2727), .B1(n2745), .B2(
        n2729), .C1(n2746), .Y(mem_la_addr[4]) );
  sky130_fd_sc_hd__nand2_1 U3473 ( .A(n2731), .B(reg_out[4]), .Y(n2746) );
  sky130_fd_sc_hd__o221ai_1 U3474 ( .A1(n2747), .A2(n2727), .B1(n2748), .B2(
        n2729), .C1(n2749), .Y(mem_la_addr[3]) );
  sky130_fd_sc_hd__nand2_1 U3475 ( .A(n2731), .B(reg_out[3]), .Y(n2749) );
  sky130_fd_sc_hd__o221ai_1 U3476 ( .A1(n2750), .A2(n2727), .B1(n2751), .B2(
        n2729), .C1(n2752), .Y(mem_la_addr[31]) );
  sky130_fd_sc_hd__nand2_1 U3477 ( .A(n2731), .B(reg_out[31]), .Y(n2752) );
  sky130_fd_sc_hd__o221ai_1 U3478 ( .A1(n2753), .A2(n2727), .B1(n2606), .B2(
        n2729), .C1(n2754), .Y(mem_la_addr[30]) );
  sky130_fd_sc_hd__nand2_1 U3479 ( .A(n2731), .B(reg_out[30]), .Y(n2754) );
  sky130_fd_sc_hd__o221ai_1 U3480 ( .A1(n2755), .A2(n2727), .B1(n2756), .B2(
        n2729), .C1(n2757), .Y(mem_la_addr[2]) );
  sky130_fd_sc_hd__nand2_1 U3481 ( .A(n2731), .B(reg_out[2]), .Y(n2757) );
  sky130_fd_sc_hd__o221ai_1 U3482 ( .A1(n2758), .A2(n2727), .B1(n2759), .B2(
        n2729), .C1(n2760), .Y(mem_la_addr[29]) );
  sky130_fd_sc_hd__nand2_1 U3483 ( .A(n2731), .B(reg_out[29]), .Y(n2760) );
  sky130_fd_sc_hd__o221ai_1 U3484 ( .A1(n2761), .A2(n2727), .B1(n2762), .B2(
        n2729), .C1(n2763), .Y(mem_la_addr[28]) );
  sky130_fd_sc_hd__nand2_1 U3485 ( .A(n2731), .B(reg_out[28]), .Y(n2763) );
  sky130_fd_sc_hd__o221ai_1 U3486 ( .A1(n2764), .A2(n2727), .B1(n2765), .B2(
        n2729), .C1(n2766), .Y(mem_la_addr[27]) );
  sky130_fd_sc_hd__nand2_1 U3487 ( .A(n2731), .B(reg_out[27]), .Y(n2766) );
  sky130_fd_sc_hd__o221ai_1 U3488 ( .A1(n2767), .A2(n2727), .B1(n2768), .B2(
        n2729), .C1(n2769), .Y(mem_la_addr[26]) );
  sky130_fd_sc_hd__nand2_1 U3489 ( .A(n2731), .B(reg_out[26]), .Y(n2769) );
  sky130_fd_sc_hd__o221ai_1 U3490 ( .A1(n2770), .A2(n2727), .B1(n2771), .B2(
        n2729), .C1(n2772), .Y(mem_la_addr[25]) );
  sky130_fd_sc_hd__nand2_1 U3491 ( .A(n2731), .B(reg_out[25]), .Y(n2772) );
  sky130_fd_sc_hd__o221ai_1 U3492 ( .A1(n2773), .A2(n2727), .B1(n2774), .B2(
        n2729), .C1(n2775), .Y(mem_la_addr[24]) );
  sky130_fd_sc_hd__nand2_1 U3493 ( .A(n2731), .B(reg_out[24]), .Y(n2775) );
  sky130_fd_sc_hd__o221ai_1 U3494 ( .A1(n2776), .A2(n2727), .B1(n2777), .B2(
        n2729), .C1(n2778), .Y(mem_la_addr[23]) );
  sky130_fd_sc_hd__nand2_1 U3495 ( .A(n2731), .B(reg_out[23]), .Y(n2778) );
  sky130_fd_sc_hd__o221ai_1 U3496 ( .A1(n2779), .A2(n2727), .B1(n2780), .B2(
        n2729), .C1(n2781), .Y(mem_la_addr[22]) );
  sky130_fd_sc_hd__nand2_1 U3497 ( .A(n2731), .B(reg_out[22]), .Y(n2781) );
  sky130_fd_sc_hd__o221ai_1 U3498 ( .A1(n2782), .A2(n2727), .B1(n2783), .B2(
        n2729), .C1(n2784), .Y(mem_la_addr[21]) );
  sky130_fd_sc_hd__nand2_1 U3499 ( .A(n2731), .B(reg_out[21]), .Y(n2784) );
  sky130_fd_sc_hd__o221ai_1 U3500 ( .A1(n2785), .A2(n2727), .B1(n2786), .B2(
        n2729), .C1(n2787), .Y(mem_la_addr[20]) );
  sky130_fd_sc_hd__nand2_1 U3501 ( .A(n2731), .B(reg_out[20]), .Y(n2787) );
  sky130_fd_sc_hd__o221ai_1 U3502 ( .A1(n2788), .A2(n2727), .B1(n2789), .B2(
        n2729), .C1(n2790), .Y(mem_la_addr[19]) );
  sky130_fd_sc_hd__nand2_1 U3503 ( .A(n2731), .B(reg_out[19]), .Y(n2790) );
  sky130_fd_sc_hd__o221ai_1 U3504 ( .A1(n2791), .A2(n2727), .B1(n2792), .B2(
        n2729), .C1(n2793), .Y(mem_la_addr[18]) );
  sky130_fd_sc_hd__nand2_1 U3505 ( .A(n2731), .B(reg_out[18]), .Y(n2793) );
  sky130_fd_sc_hd__o221ai_1 U3506 ( .A1(n2794), .A2(n2727), .B1(n2795), .B2(
        n2729), .C1(n2796), .Y(mem_la_addr[17]) );
  sky130_fd_sc_hd__nand2_1 U3507 ( .A(n2731), .B(reg_out[17]), .Y(n2796) );
  sky130_fd_sc_hd__o221ai_1 U3508 ( .A1(n2797), .A2(n2727), .B1(n2798), .B2(
        n2729), .C1(n2799), .Y(mem_la_addr[16]) );
  sky130_fd_sc_hd__nand2_1 U3509 ( .A(n2731), .B(reg_out[16]), .Y(n2799) );
  sky130_fd_sc_hd__o221ai_1 U3510 ( .A1(n2800), .A2(n2727), .B1(n2801), .B2(
        n2729), .C1(n2802), .Y(mem_la_addr[15]) );
  sky130_fd_sc_hd__nand2_1 U3511 ( .A(n2731), .B(reg_out[15]), .Y(n2802) );
  sky130_fd_sc_hd__o221ai_1 U3512 ( .A1(n2803), .A2(n2727), .B1(n2804), .B2(
        n2729), .C1(n2805), .Y(mem_la_addr[14]) );
  sky130_fd_sc_hd__nand2_1 U3513 ( .A(n2731), .B(reg_out[14]), .Y(n2805) );
  sky130_fd_sc_hd__o221ai_1 U3514 ( .A1(n2806), .A2(n2727), .B1(n2807), .B2(
        n2729), .C1(n2808), .Y(mem_la_addr[13]) );
  sky130_fd_sc_hd__nand2_1 U3515 ( .A(n2731), .B(reg_out[13]), .Y(n2808) );
  sky130_fd_sc_hd__o221ai_1 U3516 ( .A1(n2809), .A2(n2727), .B1(n2810), .B2(
        n2729), .C1(n2811), .Y(mem_la_addr[12]) );
  sky130_fd_sc_hd__nand2_1 U3517 ( .A(n2731), .B(reg_out[12]), .Y(n2811) );
  sky130_fd_sc_hd__o221ai_1 U3518 ( .A1(n2812), .A2(n2727), .B1(n2813), .B2(
        n2729), .C1(n2814), .Y(mem_la_addr[11]) );
  sky130_fd_sc_hd__nand2_1 U3519 ( .A(n2731), .B(reg_out[11]), .Y(n2814) );
  sky130_fd_sc_hd__o221ai_1 U3520 ( .A1(n2815), .A2(n2727), .B1(n2816), .B2(
        n2729), .C1(n2817), .Y(mem_la_addr[10]) );
  sky130_fd_sc_hd__nand2_1 U3521 ( .A(n2731), .B(reg_out[10]), .Y(n2817) );
  sky130_fd_sc_hd__nor2_1 U3522 ( .A(n2818), .B(n2543), .Y(n2731) );
  sky130_fd_sc_hd__nand2_1 U3523 ( .A(n2818), .B(n2729), .Y(n2727) );
  sky130_fd_sc_hd__a221o_1 U3524 ( .A1(N430), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[9]), .C1(n2821), .X(alu_out[9]) );
  sky130_fd_sc_hd__a221o_1 U3525 ( .A1(n2822), .A2(n2823), .B1(N398), .B2(
        n2824), .C1(n2825), .X(n2821) );
  sky130_fd_sc_hd__a21oi_1 U3526 ( .A1(n2826), .A2(n2827), .B1(n2828), .Y(
        n2825) );
  sky130_fd_sc_hd__mux2i_1 U3527 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[9]), 
        .Y(n2826) );
  sky130_fd_sc_hd__a221o_1 U3528 ( .A1(N429), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[8]), .C1(n2830), .X(alu_out[8]) );
  sky130_fd_sc_hd__a221o_1 U3529 ( .A1(n2831), .A2(n2823), .B1(N397), .B2(
        n2824), .C1(n2832), .X(n2830) );
  sky130_fd_sc_hd__a21oi_1 U3530 ( .A1(n2833), .A2(n2827), .B1(n2834), .Y(
        n2832) );
  sky130_fd_sc_hd__mux2i_1 U3531 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[8]), 
        .Y(n2833) );
  sky130_fd_sc_hd__a221o_1 U3532 ( .A1(N428), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[7]), .C1(n2835), .X(alu_out[7]) );
  sky130_fd_sc_hd__a221o_1 U3533 ( .A1(n2836), .A2(n2823), .B1(N396), .B2(
        n2824), .C1(n2837), .X(n2835) );
  sky130_fd_sc_hd__a21oi_1 U3534 ( .A1(n2838), .A2(n2827), .B1(n2839), .Y(
        n2837) );
  sky130_fd_sc_hd__mux2i_1 U3535 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[7]), 
        .Y(n2838) );
  sky130_fd_sc_hd__a221o_1 U3536 ( .A1(N427), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[6]), .C1(n2840), .X(alu_out[6]) );
  sky130_fd_sc_hd__a221o_1 U3537 ( .A1(n2841), .A2(n2823), .B1(N395), .B2(
        n2824), .C1(n2842), .X(n2840) );
  sky130_fd_sc_hd__a21oi_1 U3538 ( .A1(n2843), .A2(n2827), .B1(n2844), .Y(
        n2842) );
  sky130_fd_sc_hd__mux2i_1 U3539 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[6]), 
        .Y(n2843) );
  sky130_fd_sc_hd__a221o_1 U3540 ( .A1(N426), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[5]), .C1(n2845), .X(alu_out[5]) );
  sky130_fd_sc_hd__a221o_1 U3541 ( .A1(n2846), .A2(n2823), .B1(N394), .B2(
        n2824), .C1(n2847), .X(n2845) );
  sky130_fd_sc_hd__a21oi_1 U3542 ( .A1(n2848), .A2(n2827), .B1(n2849), .Y(
        n2847) );
  sky130_fd_sc_hd__mux2i_1 U3543 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[5]), 
        .Y(n2848) );
  sky130_fd_sc_hd__a221o_1 U3544 ( .A1(N425), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[4]), .C1(n2850), .X(alu_out[4]) );
  sky130_fd_sc_hd__a221o_1 U3545 ( .A1(n2851), .A2(n2823), .B1(N393), .B2(
        n2824), .C1(n2852), .X(n2850) );
  sky130_fd_sc_hd__a21oi_1 U3546 ( .A1(n2853), .A2(n2827), .B1(n2854), .Y(
        n2852) );
  sky130_fd_sc_hd__mux2i_1 U3547 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[4]), 
        .Y(n2853) );
  sky130_fd_sc_hd__a221o_1 U3548 ( .A1(N424), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[3]), .C1(n2855), .X(alu_out[3]) );
  sky130_fd_sc_hd__a221o_1 U3549 ( .A1(n2856), .A2(n2823), .B1(N392), .B2(
        n2824), .C1(n2857), .X(n2855) );
  sky130_fd_sc_hd__a21oi_1 U3550 ( .A1(n2858), .A2(n2827), .B1(n2859), .Y(
        n2857) );
  sky130_fd_sc_hd__mux2i_1 U3551 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[3]), 
        .Y(n2858) );
  sky130_fd_sc_hd__o211ai_1 U3552 ( .A1(n2860), .A2(n2751), .B1(n2861), .C1(
        n2862), .Y(alu_out[31]) );
  sky130_fd_sc_hd__a22oi_1 U3553 ( .A1(N420), .A2(n2824), .B1(N452), .B2(n2819), .Y(n2862) );
  sky130_fd_sc_hd__o21ai_0 U3554 ( .A1(n2820), .A2(n2863), .B1(pcpi_rs2[31]), 
        .Y(n2861) );
  sky130_fd_sc_hd__mux2i_1 U3555 ( .A0(n2864), .A1(n2865), .S(pcpi_rs1[31]), 
        .Y(n2863) );
  sky130_fd_sc_hd__a21oi_1 U3556 ( .A1(n2823), .A2(n2866), .B1(n2820), .Y(
        n2860) );
  sky130_fd_sc_hd__o211ai_1 U3557 ( .A1(n2867), .A2(n2606), .B1(n2868), .C1(
        n2869), .Y(alu_out[30]) );
  sky130_fd_sc_hd__a22oi_1 U3558 ( .A1(N419), .A2(n2824), .B1(N451), .B2(n2819), .Y(n2869) );
  sky130_fd_sc_hd__o21ai_0 U3559 ( .A1(n2820), .A2(n2870), .B1(pcpi_rs2[30]), 
        .Y(n2868) );
  sky130_fd_sc_hd__mux2i_1 U3560 ( .A0(n2864), .A1(n2865), .S(pcpi_rs1[30]), 
        .Y(n2870) );
  sky130_fd_sc_hd__a21oi_1 U3561 ( .A1(n2823), .A2(n2871), .B1(n2820), .Y(
        n2867) );
  sky130_fd_sc_hd__a221o_1 U3562 ( .A1(N423), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[2]), .C1(n2872), .X(alu_out[2]) );
  sky130_fd_sc_hd__a221o_1 U3563 ( .A1(n2873), .A2(n2823), .B1(N391), .B2(
        n2824), .C1(n2874), .X(n2872) );
  sky130_fd_sc_hd__a21oi_1 U3564 ( .A1(n2875), .A2(n2827), .B1(n2876), .Y(
        n2874) );
  sky130_fd_sc_hd__mux2i_1 U3565 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[2]), 
        .Y(n2875) );
  sky130_fd_sc_hd__o211ai_1 U3566 ( .A1(n2877), .A2(n2759), .B1(n2878), .C1(
        n2879), .Y(alu_out[29]) );
  sky130_fd_sc_hd__a22oi_1 U3567 ( .A1(N418), .A2(n2824), .B1(N450), .B2(n2819), .Y(n2879) );
  sky130_fd_sc_hd__o21ai_0 U3568 ( .A1(n2820), .A2(n2880), .B1(pcpi_rs2[29]), 
        .Y(n2878) );
  sky130_fd_sc_hd__mux2i_1 U3569 ( .A0(n2864), .A1(n2865), .S(pcpi_rs1[29]), 
        .Y(n2880) );
  sky130_fd_sc_hd__a21oi_1 U3570 ( .A1(n2823), .A2(n2881), .B1(n2820), .Y(
        n2877) );
  sky130_fd_sc_hd__a221o_1 U3571 ( .A1(N449), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[28]), .C1(n2882), .X(alu_out[28]) );
  sky130_fd_sc_hd__a221o_1 U3572 ( .A1(n2883), .A2(n2823), .B1(N417), .B2(
        n2824), .C1(n2884), .X(n2882) );
  sky130_fd_sc_hd__a21oi_1 U3573 ( .A1(n2885), .A2(n2827), .B1(n2886), .Y(
        n2884) );
  sky130_fd_sc_hd__mux2i_1 U3574 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[28]), 
        .Y(n2885) );
  sky130_fd_sc_hd__a221o_1 U3575 ( .A1(N448), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[27]), .C1(n2887), .X(alu_out[27]) );
  sky130_fd_sc_hd__a221o_1 U3576 ( .A1(n2888), .A2(n2823), .B1(N416), .B2(
        n2824), .C1(n2889), .X(n2887) );
  sky130_fd_sc_hd__a21oi_1 U3577 ( .A1(n2890), .A2(n2827), .B1(n2891), .Y(
        n2889) );
  sky130_fd_sc_hd__mux2i_1 U3578 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[27]), 
        .Y(n2890) );
  sky130_fd_sc_hd__clkinv_1 U3579 ( .A(n2892), .Y(n2888) );
  sky130_fd_sc_hd__a221o_1 U3580 ( .A1(N447), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[26]), .C1(n2893), .X(alu_out[26]) );
  sky130_fd_sc_hd__a221o_1 U3581 ( .A1(n2894), .A2(n2823), .B1(N415), .B2(
        n2824), .C1(n2895), .X(n2893) );
  sky130_fd_sc_hd__a21oi_1 U3582 ( .A1(n2896), .A2(n2827), .B1(n2897), .Y(
        n2895) );
  sky130_fd_sc_hd__mux2i_1 U3583 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[26]), 
        .Y(n2896) );
  sky130_fd_sc_hd__a221o_1 U3584 ( .A1(N446), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[25]), .C1(n2898), .X(alu_out[25]) );
  sky130_fd_sc_hd__a221o_1 U3585 ( .A1(n2899), .A2(n2823), .B1(N414), .B2(
        n2824), .C1(n2900), .X(n2898) );
  sky130_fd_sc_hd__a21oi_1 U3586 ( .A1(n2901), .A2(n2827), .B1(n2902), .Y(
        n2900) );
  sky130_fd_sc_hd__mux2i_1 U3587 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[25]), 
        .Y(n2901) );
  sky130_fd_sc_hd__a221o_1 U3588 ( .A1(N445), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[24]), .C1(n2903), .X(alu_out[24]) );
  sky130_fd_sc_hd__a221o_1 U3589 ( .A1(n2904), .A2(n2823), .B1(N413), .B2(
        n2824), .C1(n2905), .X(n2903) );
  sky130_fd_sc_hd__a21oi_1 U3590 ( .A1(n2906), .A2(n2827), .B1(n2907), .Y(
        n2905) );
  sky130_fd_sc_hd__mux2i_1 U3591 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[24]), 
        .Y(n2906) );
  sky130_fd_sc_hd__a221o_1 U3592 ( .A1(N444), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[23]), .C1(n2908), .X(alu_out[23]) );
  sky130_fd_sc_hd__a221o_1 U3593 ( .A1(n2909), .A2(n2823), .B1(N412), .B2(
        n2824), .C1(n2910), .X(n2908) );
  sky130_fd_sc_hd__a21oi_1 U3594 ( .A1(n2911), .A2(n2827), .B1(n2912), .Y(
        n2910) );
  sky130_fd_sc_hd__mux2i_1 U3595 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[23]), 
        .Y(n2911) );
  sky130_fd_sc_hd__a221o_1 U3596 ( .A1(N443), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[22]), .C1(n2913), .X(alu_out[22]) );
  sky130_fd_sc_hd__a221o_1 U3597 ( .A1(n2914), .A2(n2823), .B1(N411), .B2(
        n2824), .C1(n2915), .X(n2913) );
  sky130_fd_sc_hd__a21oi_1 U3598 ( .A1(n2916), .A2(n2827), .B1(n2917), .Y(
        n2915) );
  sky130_fd_sc_hd__mux2i_1 U3599 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[22]), 
        .Y(n2916) );
  sky130_fd_sc_hd__a221o_1 U3600 ( .A1(N442), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[21]), .C1(n2918), .X(alu_out[21]) );
  sky130_fd_sc_hd__a221o_1 U3601 ( .A1(n2919), .A2(n2823), .B1(N410), .B2(
        n2824), .C1(n2920), .X(n2918) );
  sky130_fd_sc_hd__a21oi_1 U3602 ( .A1(n2921), .A2(n2827), .B1(n2922), .Y(
        n2920) );
  sky130_fd_sc_hd__mux2i_1 U3603 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[21]), 
        .Y(n2921) );
  sky130_fd_sc_hd__a221o_1 U3604 ( .A1(N441), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[20]), .C1(n2923), .X(alu_out[20]) );
  sky130_fd_sc_hd__a221o_1 U3605 ( .A1(n2924), .A2(n2823), .B1(N409), .B2(
        n2824), .C1(n2925), .X(n2923) );
  sky130_fd_sc_hd__a21oi_1 U3606 ( .A1(n2926), .A2(n2827), .B1(n2927), .Y(
        n2925) );
  sky130_fd_sc_hd__mux2i_1 U3607 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[20]), 
        .Y(n2926) );
  sky130_fd_sc_hd__o211ai_1 U3608 ( .A1(n2928), .A2(n2929), .B1(n2930), .C1(
        n2931), .Y(alu_out[1]) );
  sky130_fd_sc_hd__a22oi_1 U3609 ( .A1(N390), .A2(n2824), .B1(N422), .B2(n2819), .Y(n2931) );
  sky130_fd_sc_hd__o21ai_0 U3610 ( .A1(n2820), .A2(n2932), .B1(pcpi_rs2[1]), 
        .Y(n2930) );
  sky130_fd_sc_hd__mux2i_1 U3611 ( .A0(n2864), .A1(n2865), .S(pcpi_rs1[1]), 
        .Y(n2932) );
  sky130_fd_sc_hd__a21oi_1 U3612 ( .A1(n2823), .A2(n2933), .B1(n2820), .Y(
        n2928) );
  sky130_fd_sc_hd__a221o_1 U3613 ( .A1(N440), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[19]), .C1(n2934), .X(alu_out[19]) );
  sky130_fd_sc_hd__a221o_1 U3614 ( .A1(n2935), .A2(n2823), .B1(N408), .B2(
        n2824), .C1(n2936), .X(n2934) );
  sky130_fd_sc_hd__a21oi_1 U3615 ( .A1(n2937), .A2(n2827), .B1(n2938), .Y(
        n2936) );
  sky130_fd_sc_hd__mux2i_1 U3616 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[19]), 
        .Y(n2937) );
  sky130_fd_sc_hd__a221o_1 U3617 ( .A1(N439), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[18]), .C1(n2939), .X(alu_out[18]) );
  sky130_fd_sc_hd__a221o_1 U3618 ( .A1(n2940), .A2(n2823), .B1(N407), .B2(
        n2824), .C1(n2941), .X(n2939) );
  sky130_fd_sc_hd__a21oi_1 U3619 ( .A1(n2942), .A2(n2827), .B1(n2943), .Y(
        n2941) );
  sky130_fd_sc_hd__mux2i_1 U3620 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[18]), 
        .Y(n2942) );
  sky130_fd_sc_hd__a221o_1 U3621 ( .A1(N438), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[17]), .C1(n2944), .X(alu_out[17]) );
  sky130_fd_sc_hd__a221o_1 U3622 ( .A1(n2945), .A2(n2823), .B1(N406), .B2(
        n2824), .C1(n2946), .X(n2944) );
  sky130_fd_sc_hd__a21oi_1 U3623 ( .A1(n2947), .A2(n2827), .B1(n2948), .Y(
        n2946) );
  sky130_fd_sc_hd__mux2i_1 U3624 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[17]), 
        .Y(n2947) );
  sky130_fd_sc_hd__a221o_1 U3625 ( .A1(N437), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[16]), .C1(n2949), .X(alu_out[16]) );
  sky130_fd_sc_hd__a221o_1 U3626 ( .A1(n2950), .A2(n2823), .B1(N405), .B2(
        n2824), .C1(n2951), .X(n2949) );
  sky130_fd_sc_hd__a21oi_1 U3627 ( .A1(n2952), .A2(n2827), .B1(n2953), .Y(
        n2951) );
  sky130_fd_sc_hd__mux2i_1 U3628 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[16]), 
        .Y(n2952) );
  sky130_fd_sc_hd__a221o_1 U3629 ( .A1(N436), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[15]), .C1(n2954), .X(alu_out[15]) );
  sky130_fd_sc_hd__a221o_1 U3630 ( .A1(n2955), .A2(n2823), .B1(N404), .B2(
        n2824), .C1(n2956), .X(n2954) );
  sky130_fd_sc_hd__a21oi_1 U3631 ( .A1(n2957), .A2(n2827), .B1(n2958), .Y(
        n2956) );
  sky130_fd_sc_hd__mux2i_1 U3632 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[15]), 
        .Y(n2957) );
  sky130_fd_sc_hd__a221o_1 U3633 ( .A1(N435), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[14]), .C1(n2959), .X(alu_out[14]) );
  sky130_fd_sc_hd__a221o_1 U3634 ( .A1(n2960), .A2(n2823), .B1(N403), .B2(
        n2824), .C1(n2961), .X(n2959) );
  sky130_fd_sc_hd__a21oi_1 U3635 ( .A1(n2962), .A2(n2827), .B1(n2963), .Y(
        n2961) );
  sky130_fd_sc_hd__mux2i_1 U3636 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[14]), 
        .Y(n2962) );
  sky130_fd_sc_hd__a221o_1 U3637 ( .A1(N434), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[13]), .C1(n2964), .X(alu_out[13]) );
  sky130_fd_sc_hd__a221o_1 U3638 ( .A1(n2965), .A2(n2823), .B1(N402), .B2(
        n2824), .C1(n2966), .X(n2964) );
  sky130_fd_sc_hd__a21oi_1 U3639 ( .A1(n2967), .A2(n2827), .B1(n2968), .Y(
        n2966) );
  sky130_fd_sc_hd__mux2i_1 U3640 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[13]), 
        .Y(n2967) );
  sky130_fd_sc_hd__a221o_1 U3641 ( .A1(N433), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[12]), .C1(n2969), .X(alu_out[12]) );
  sky130_fd_sc_hd__a221o_1 U3642 ( .A1(n2970), .A2(n2823), .B1(N401), .B2(
        n2824), .C1(n2971), .X(n2969) );
  sky130_fd_sc_hd__a21oi_1 U3643 ( .A1(n2972), .A2(n2827), .B1(n2973), .Y(
        n2971) );
  sky130_fd_sc_hd__mux2i_1 U3644 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[12]), 
        .Y(n2972) );
  sky130_fd_sc_hd__a221o_1 U3645 ( .A1(N432), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[11]), .C1(n2974), .X(alu_out[11]) );
  sky130_fd_sc_hd__a221o_1 U3646 ( .A1(n2975), .A2(n2823), .B1(N400), .B2(
        n2824), .C1(n2976), .X(n2974) );
  sky130_fd_sc_hd__a21oi_1 U3647 ( .A1(n2977), .A2(n2827), .B1(n2978), .Y(
        n2976) );
  sky130_fd_sc_hd__mux2i_1 U3648 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[11]), 
        .Y(n2977) );
  sky130_fd_sc_hd__a221o_1 U3649 ( .A1(N431), .A2(n2819), .B1(n2820), .B2(
        pcpi_rs1[10]), .C1(n2979), .X(alu_out[10]) );
  sky130_fd_sc_hd__a221o_1 U3650 ( .A1(n2980), .A2(n2823), .B1(N399), .B2(
        n2824), .C1(n2981), .X(n2979) );
  sky130_fd_sc_hd__a21oi_1 U3651 ( .A1(n2982), .A2(n2827), .B1(n2983), .Y(
        n2981) );
  sky130_fd_sc_hd__mux2i_1 U3652 ( .A0(n2823), .A1(n2829), .S(pcpi_rs1[10]), 
        .Y(n2982) );
  sky130_fd_sc_hd__o2111ai_1 U3653 ( .A1(n2984), .A2(n2985), .B1(n2986), .C1(
        n2987), .D1(n2988), .Y(alu_out[0]) );
  sky130_fd_sc_hd__a22oi_1 U3654 ( .A1(N389), .A2(n2824), .B1(N421), .B2(n2819), .Y(n2988) );
  sky130_fd_sc_hd__nor2_1 U3655 ( .A(n2989), .B(instr_sub), .Y(n2819) );
  sky130_fd_sc_hd__nor2_1 U3656 ( .A(n2989), .B(n2990), .Y(n2824) );
  sky130_fd_sc_hd__o21ai_0 U3657 ( .A1(n2820), .A2(n2991), .B1(pcpi_rs2[0]), 
        .Y(n2987) );
  sky130_fd_sc_hd__mux2i_1 U3658 ( .A0(n2864), .A1(n2865), .S(pcpi_rs1[0]), 
        .Y(n2991) );
  sky130_fd_sc_hd__clkinv_1 U3659 ( .A(n2829), .Y(n2865) );
  sky130_fd_sc_hd__nand3_1 U3660 ( .A(n2676), .B(n2989), .C(is_compare), .Y(
        n2986) );
  sky130_fd_sc_hd__a21oi_1 U3661 ( .A1(n2823), .A2(n2992), .B1(n2820), .Y(
        n2984) );
  sky130_fd_sc_hd__clkinv_1 U3662 ( .A(n2827), .Y(n2820) );
  sky130_fd_sc_hd__clkinv_1 U3663 ( .A(n2864), .Y(n2823) );
  sky130_fd_sc_hd__o211ai_1 U3664 ( .A1(instr_xori), .A2(instr_xor), .B1(n2993), .C1(n2989), .Y(n2864) );
  sky130_fd_sc_hd__clkinv_1 U3665 ( .A(is_lui_auipc_jal_jalr_addi_add_sub), 
        .Y(n2989) );
  sky130_fd_sc_hd__clkinv_1 U3666 ( .A(is_compare), .Y(n2993) );
  sky130_fd_sc_hd__and2_0 U3667 ( .A(N882), .B(n1055), .X(N946) );
  sky130_fd_sc_hd__and2_0 U3668 ( .A(N881), .B(N31), .X(N945) );
  sky130_fd_sc_hd__and2_0 U3669 ( .A(N880), .B(N31), .X(N944) );
  sky130_fd_sc_hd__and2_0 U3670 ( .A(N879), .B(N31), .X(N943) );
  sky130_fd_sc_hd__and2_0 U3671 ( .A(N878), .B(n1061), .X(N942) );
  sky130_fd_sc_hd__and2_0 U3672 ( .A(N877), .B(n1061), .X(N941) );
  sky130_fd_sc_hd__and2_0 U3673 ( .A(N876), .B(n1061), .X(N940) );
  sky130_fd_sc_hd__and2_0 U3674 ( .A(N875), .B(n1061), .X(N939) );
  sky130_fd_sc_hd__and2_0 U3675 ( .A(N874), .B(n1061), .X(N938) );
  sky130_fd_sc_hd__and2_0 U3676 ( .A(N873), .B(n1061), .X(N937) );
  sky130_fd_sc_hd__and2_0 U3677 ( .A(N872), .B(n1061), .X(N936) );
  sky130_fd_sc_hd__and2_0 U3678 ( .A(N871), .B(n1061), .X(N935) );
  sky130_fd_sc_hd__and2_0 U3679 ( .A(N870), .B(n1061), .X(N934) );
  sky130_fd_sc_hd__and2_0 U3680 ( .A(N869), .B(n1061), .X(N933) );
  sky130_fd_sc_hd__and2_0 U3681 ( .A(N868), .B(n1061), .X(N932) );
  sky130_fd_sc_hd__and2_0 U3682 ( .A(N867), .B(n1061), .X(N931) );
  sky130_fd_sc_hd__and2_0 U3683 ( .A(N866), .B(n1061), .X(N930) );
  sky130_fd_sc_hd__and2_0 U3684 ( .A(N865), .B(n1061), .X(N929) );
  sky130_fd_sc_hd__and2_0 U3685 ( .A(N864), .B(n1061), .X(N928) );
  sky130_fd_sc_hd__and2_0 U3686 ( .A(N863), .B(n1061), .X(N927) );
  sky130_fd_sc_hd__and2_0 U3687 ( .A(N862), .B(n1061), .X(N926) );
  sky130_fd_sc_hd__and2_0 U3688 ( .A(N861), .B(n1061), .X(N925) );
  sky130_fd_sc_hd__and2_0 U3689 ( .A(N860), .B(n1061), .X(N924) );
  sky130_fd_sc_hd__and2_0 U3690 ( .A(N859), .B(n1060), .X(N923) );
  sky130_fd_sc_hd__and2_0 U3691 ( .A(N858), .B(n1060), .X(N922) );
  sky130_fd_sc_hd__and2_0 U3692 ( .A(N857), .B(n1060), .X(N921) );
  sky130_fd_sc_hd__and2_0 U3693 ( .A(N856), .B(n1060), .X(N920) );
  sky130_fd_sc_hd__and2_0 U3694 ( .A(N855), .B(n1060), .X(N919) );
  sky130_fd_sc_hd__and2_0 U3695 ( .A(N854), .B(n1060), .X(N918) );
  sky130_fd_sc_hd__and2_0 U3696 ( .A(N853), .B(n1060), .X(N917) );
  sky130_fd_sc_hd__and2_0 U3697 ( .A(N852), .B(n1060), .X(N916) );
  sky130_fd_sc_hd__and2_0 U3698 ( .A(N851), .B(n1060), .X(N915) );
  sky130_fd_sc_hd__and2_0 U3699 ( .A(N850), .B(n1060), .X(N914) );
  sky130_fd_sc_hd__and2_0 U3700 ( .A(N849), .B(n1060), .X(N913) );
  sky130_fd_sc_hd__and2_0 U3701 ( .A(N848), .B(n1060), .X(N912) );
  sky130_fd_sc_hd__and2_0 U3702 ( .A(N847), .B(n1060), .X(N911) );
  sky130_fd_sc_hd__and2_0 U3703 ( .A(N846), .B(n1060), .X(N910) );
  sky130_fd_sc_hd__and2_0 U3704 ( .A(N845), .B(n1060), .X(N909) );
  sky130_fd_sc_hd__and2_0 U3705 ( .A(N844), .B(n1060), .X(N908) );
  sky130_fd_sc_hd__and2_0 U3706 ( .A(N843), .B(n1060), .X(N907) );
  sky130_fd_sc_hd__and2_0 U3707 ( .A(N842), .B(n1057), .X(N906) );
  sky130_fd_sc_hd__and2_0 U3708 ( .A(N841), .B(n1060), .X(N905) );
  sky130_fd_sc_hd__and2_0 U3709 ( .A(N840), .B(n1060), .X(N904) );
  sky130_fd_sc_hd__and2_0 U3710 ( .A(N839), .B(n1059), .X(N903) );
  sky130_fd_sc_hd__and2_0 U3711 ( .A(N838), .B(n1059), .X(N902) );
  sky130_fd_sc_hd__and2_0 U3712 ( .A(N837), .B(n1059), .X(N901) );
  sky130_fd_sc_hd__and2_0 U3713 ( .A(N836), .B(n1059), .X(N900) );
  sky130_fd_sc_hd__and2_0 U3714 ( .A(N835), .B(n1059), .X(N899) );
  sky130_fd_sc_hd__and2_0 U3715 ( .A(N834), .B(n1059), .X(N898) );
  sky130_fd_sc_hd__and2_0 U3716 ( .A(N833), .B(n1059), .X(N897) );
  sky130_fd_sc_hd__and2_0 U3717 ( .A(N832), .B(n1059), .X(N896) );
  sky130_fd_sc_hd__and2_0 U3718 ( .A(N831), .B(n1059), .X(N895) );
  sky130_fd_sc_hd__and2_0 U3719 ( .A(N830), .B(n1059), .X(N894) );
  sky130_fd_sc_hd__and2_0 U3720 ( .A(N829), .B(n1059), .X(N893) );
  sky130_fd_sc_hd__and2_0 U3721 ( .A(N828), .B(n1059), .X(N892) );
  sky130_fd_sc_hd__and2_0 U3722 ( .A(N827), .B(n1059), .X(N891) );
  sky130_fd_sc_hd__and2_0 U3723 ( .A(N826), .B(n1059), .X(N890) );
  sky130_fd_sc_hd__and2_0 U3724 ( .A(N825), .B(n1059), .X(N889) );
  sky130_fd_sc_hd__and2_0 U3725 ( .A(N824), .B(n1059), .X(N888) );
  sky130_fd_sc_hd__and2_0 U3726 ( .A(N823), .B(n1059), .X(N887) );
  sky130_fd_sc_hd__and2_0 U3727 ( .A(N822), .B(n1059), .X(N886) );
  sky130_fd_sc_hd__and2_0 U3728 ( .A(N821), .B(n1059), .X(N885) );
  sky130_fd_sc_hd__and2_0 U3729 ( .A(N820), .B(n1058), .X(N884) );
  sky130_fd_sc_hd__and2_0 U3730 ( .A(N819), .B(n1058), .X(N883) );
  sky130_fd_sc_hd__nor2_1 U3731 ( .A(n2994), .B(n2995), .Y(N748) );
  sky130_fd_sc_hd__nor2_1 U3732 ( .A(n2994), .B(n2996), .Y(N747) );
  sky130_fd_sc_hd__nor2_1 U3733 ( .A(n2994), .B(n2997), .Y(N746) );
  sky130_fd_sc_hd__nor2_1 U3734 ( .A(n2994), .B(n2998), .Y(N745) );
  sky130_fd_sc_hd__nor2_1 U3735 ( .A(n2994), .B(n2999), .Y(N744) );
  sky130_fd_sc_hd__nor2_1 U3736 ( .A(n2994), .B(n3000), .Y(N743) );
  sky130_fd_sc_hd__nor2_1 U3737 ( .A(n2994), .B(n3001), .Y(N742) );
  sky130_fd_sc_hd__nand3_1 U3738 ( .A(n3002), .B(n3003), .C(n3004), .Y(n2994)
         );
  sky130_fd_sc_hd__nor2_1 U3739 ( .A(n3005), .B(n3006), .Y(N741) );
  sky130_fd_sc_hd__nor2_1 U3740 ( .A(n2995), .B(n3005), .Y(N740) );
  sky130_fd_sc_hd__nor2_1 U3741 ( .A(n2996), .B(n3005), .Y(N739) );
  sky130_fd_sc_hd__nor2_1 U3742 ( .A(n2997), .B(n3005), .Y(N738) );
  sky130_fd_sc_hd__nor2_1 U3743 ( .A(n2998), .B(n3005), .Y(N737) );
  sky130_fd_sc_hd__nor2_1 U3744 ( .A(n2999), .B(n3005), .Y(N736) );
  sky130_fd_sc_hd__nor2_1 U3745 ( .A(n3000), .B(n3005), .Y(N735) );
  sky130_fd_sc_hd__nor2_1 U3746 ( .A(n3001), .B(n3005), .Y(N734) );
  sky130_fd_sc_hd__nand3_1 U3747 ( .A(n3004), .B(n3003), .C(latched_rd[3]), 
        .Y(n3005) );
  sky130_fd_sc_hd__clkinv_1 U3748 ( .A(latched_rd[4]), .Y(n3003) );
  sky130_fd_sc_hd__nor2_1 U3749 ( .A(n3006), .B(n3007), .Y(N733) );
  sky130_fd_sc_hd__nor2_1 U3750 ( .A(n2995), .B(n3007), .Y(N732) );
  sky130_fd_sc_hd__nor2_1 U3751 ( .A(n2996), .B(n3007), .Y(N731) );
  sky130_fd_sc_hd__nor2_1 U3752 ( .A(n2997), .B(n3007), .Y(N730) );
  sky130_fd_sc_hd__nor2_1 U3753 ( .A(n2998), .B(n3007), .Y(N729) );
  sky130_fd_sc_hd__nor2_1 U3754 ( .A(n2999), .B(n3007), .Y(N728) );
  sky130_fd_sc_hd__nor2_1 U3755 ( .A(n3000), .B(n3007), .Y(N727) );
  sky130_fd_sc_hd__nor2_1 U3756 ( .A(n3001), .B(n3007), .Y(N726) );
  sky130_fd_sc_hd__nand3_1 U3757 ( .A(n3004), .B(n3002), .C(latched_rd[4]), 
        .Y(n3007) );
  sky130_fd_sc_hd__clkinv_1 U3758 ( .A(latched_rd[3]), .Y(n3002) );
  sky130_fd_sc_hd__nor2_1 U3759 ( .A(n3006), .B(n3008), .Y(N725) );
  sky130_fd_sc_hd__nand3_1 U3760 ( .A(n3009), .B(n3010), .C(n3011), .Y(n3006)
         );
  sky130_fd_sc_hd__nor2_1 U3761 ( .A(n2995), .B(n3008), .Y(N724) );
  sky130_fd_sc_hd__nand3_1 U3762 ( .A(n3009), .B(n3010), .C(latched_rd[0]), 
        .Y(n2995) );
  sky130_fd_sc_hd__nor2_1 U3763 ( .A(n2996), .B(n3008), .Y(N723) );
  sky130_fd_sc_hd__nand3_1 U3764 ( .A(n3011), .B(n3010), .C(latched_rd[1]), 
        .Y(n2996) );
  sky130_fd_sc_hd__nor2_1 U3765 ( .A(n2997), .B(n3008), .Y(N722) );
  sky130_fd_sc_hd__nand3_1 U3766 ( .A(latched_rd[0]), .B(n3010), .C(
        latched_rd[1]), .Y(n2997) );
  sky130_fd_sc_hd__clkinv_1 U3767 ( .A(latched_rd[2]), .Y(n3010) );
  sky130_fd_sc_hd__nor2_1 U3768 ( .A(n2998), .B(n3008), .Y(N721) );
  sky130_fd_sc_hd__nand3_1 U3769 ( .A(n3011), .B(n3009), .C(latched_rd[2]), 
        .Y(n2998) );
  sky130_fd_sc_hd__nor2_1 U3770 ( .A(n2999), .B(n3008), .Y(N720) );
  sky130_fd_sc_hd__nand3_1 U3771 ( .A(latched_rd[0]), .B(n3009), .C(
        latched_rd[2]), .Y(n2999) );
  sky130_fd_sc_hd__clkinv_1 U3772 ( .A(latched_rd[1]), .Y(n3009) );
  sky130_fd_sc_hd__nor2_1 U3773 ( .A(n3000), .B(n3008), .Y(N719) );
  sky130_fd_sc_hd__nand3_1 U3774 ( .A(latched_rd[1]), .B(n3011), .C(
        latched_rd[2]), .Y(n3000) );
  sky130_fd_sc_hd__clkinv_1 U3775 ( .A(latched_rd[0]), .Y(n3011) );
  sky130_fd_sc_hd__nor2_1 U3776 ( .A(n3001), .B(n3008), .Y(N718) );
  sky130_fd_sc_hd__nand3_1 U3777 ( .A(latched_rd[3]), .B(n3004), .C(
        latched_rd[4]), .Y(n3008) );
  sky130_fd_sc_hd__o211a_1 U3778 ( .A1(latched_branch), .A2(latched_store), 
        .B1(N31), .C1(n2624), .X(n3004) );
  sky130_fd_sc_hd__nand3_1 U3779 ( .A(latched_rd[1]), .B(latched_rd[0]), .C(
        latched_rd[2]), .Y(n3001) );
  sky130_fd_sc_hd__a221o_1 U3780 ( .A1(alu_out_q[31]), .A2(n2577), .B1(
        reg_out[31]), .B2(n2578), .C1(n3012), .X(N682) );
  sky130_fd_sc_hd__and2_0 U3781 ( .A(N615), .B(latched_branch), .X(n3012) );
  sky130_fd_sc_hd__a221o_1 U3782 ( .A1(alu_out_q[30]), .A2(n2577), .B1(
        reg_out[30]), .B2(n2578), .C1(n3013), .X(N681) );
  sky130_fd_sc_hd__and2_0 U3783 ( .A(N614), .B(latched_branch), .X(n3013) );
  sky130_fd_sc_hd__a221o_1 U3784 ( .A1(alu_out_q[29]), .A2(n2577), .B1(
        reg_out[29]), .B2(n2578), .C1(n3014), .X(N680) );
  sky130_fd_sc_hd__and2_0 U3785 ( .A(N613), .B(latched_branch), .X(n3014) );
  sky130_fd_sc_hd__a221o_1 U3786 ( .A1(alu_out_q[28]), .A2(n2577), .B1(
        reg_out[28]), .B2(n2578), .C1(n3015), .X(N679) );
  sky130_fd_sc_hd__and2_0 U3787 ( .A(N612), .B(latched_branch), .X(n3015) );
  sky130_fd_sc_hd__a221o_1 U3788 ( .A1(alu_out_q[27]), .A2(n2577), .B1(
        reg_out[27]), .B2(n2578), .C1(n3016), .X(N678) );
  sky130_fd_sc_hd__and2_0 U3789 ( .A(N611), .B(latched_branch), .X(n3016) );
  sky130_fd_sc_hd__a221o_1 U3790 ( .A1(alu_out_q[26]), .A2(n2577), .B1(
        reg_out[26]), .B2(n2578), .C1(n3017), .X(N677) );
  sky130_fd_sc_hd__and2_0 U3791 ( .A(N610), .B(latched_branch), .X(n3017) );
  sky130_fd_sc_hd__a221o_1 U3792 ( .A1(alu_out_q[25]), .A2(n2577), .B1(
        reg_out[25]), .B2(n2578), .C1(n3018), .X(N676) );
  sky130_fd_sc_hd__and2_0 U3793 ( .A(N609), .B(latched_branch), .X(n3018) );
  sky130_fd_sc_hd__a221o_1 U3794 ( .A1(alu_out_q[24]), .A2(n2577), .B1(
        reg_out[24]), .B2(n2578), .C1(n3019), .X(N675) );
  sky130_fd_sc_hd__and2_0 U3795 ( .A(N608), .B(latched_branch), .X(n3019) );
  sky130_fd_sc_hd__a221o_1 U3796 ( .A1(alu_out_q[23]), .A2(n2577), .B1(
        reg_out[23]), .B2(n2578), .C1(n3020), .X(N674) );
  sky130_fd_sc_hd__and2_0 U3797 ( .A(N607), .B(latched_branch), .X(n3020) );
  sky130_fd_sc_hd__a221o_1 U3798 ( .A1(alu_out_q[22]), .A2(n2577), .B1(
        reg_out[22]), .B2(n2578), .C1(n3021), .X(N673) );
  sky130_fd_sc_hd__and2_0 U3799 ( .A(N606), .B(latched_branch), .X(n3021) );
  sky130_fd_sc_hd__a221o_1 U3800 ( .A1(alu_out_q[21]), .A2(n2577), .B1(
        reg_out[21]), .B2(n2578), .C1(n3022), .X(N672) );
  sky130_fd_sc_hd__and2_0 U3801 ( .A(N605), .B(latched_branch), .X(n3022) );
  sky130_fd_sc_hd__a221o_1 U3802 ( .A1(alu_out_q[20]), .A2(n2577), .B1(
        reg_out[20]), .B2(n2578), .C1(n3023), .X(N671) );
  sky130_fd_sc_hd__and2_0 U3803 ( .A(N604), .B(latched_branch), .X(n3023) );
  sky130_fd_sc_hd__a221o_1 U3804 ( .A1(alu_out_q[19]), .A2(n2577), .B1(
        reg_out[19]), .B2(n2578), .C1(n3024), .X(N670) );
  sky130_fd_sc_hd__and2_0 U3805 ( .A(N603), .B(latched_branch), .X(n3024) );
  sky130_fd_sc_hd__a221o_1 U3806 ( .A1(alu_out_q[18]), .A2(n2577), .B1(
        reg_out[18]), .B2(n2578), .C1(n3025), .X(N669) );
  sky130_fd_sc_hd__and2_0 U3807 ( .A(N602), .B(latched_branch), .X(n3025) );
  sky130_fd_sc_hd__a221o_1 U3808 ( .A1(alu_out_q[17]), .A2(n2577), .B1(
        reg_out[17]), .B2(n2578), .C1(n3026), .X(N668) );
  sky130_fd_sc_hd__and2_0 U3809 ( .A(N601), .B(latched_branch), .X(n3026) );
  sky130_fd_sc_hd__a221o_1 U3810 ( .A1(alu_out_q[16]), .A2(n2577), .B1(
        reg_out[16]), .B2(n2578), .C1(n3027), .X(N667) );
  sky130_fd_sc_hd__and2_0 U3811 ( .A(N600), .B(latched_branch), .X(n3027) );
  sky130_fd_sc_hd__a221o_1 U3812 ( .A1(alu_out_q[15]), .A2(n2577), .B1(
        reg_out[15]), .B2(n2578), .C1(n3028), .X(N666) );
  sky130_fd_sc_hd__and2_0 U3813 ( .A(N599), .B(latched_branch), .X(n3028) );
  sky130_fd_sc_hd__a221o_1 U3814 ( .A1(alu_out_q[14]), .A2(n2577), .B1(
        reg_out[14]), .B2(n2578), .C1(n3029), .X(N665) );
  sky130_fd_sc_hd__and2_0 U3815 ( .A(N598), .B(latched_branch), .X(n3029) );
  sky130_fd_sc_hd__a221o_1 U3816 ( .A1(alu_out_q[13]), .A2(n2577), .B1(
        reg_out[13]), .B2(n2578), .C1(n3030), .X(N664) );
  sky130_fd_sc_hd__and2_0 U3817 ( .A(N597), .B(latched_branch), .X(n3030) );
  sky130_fd_sc_hd__a221o_1 U3818 ( .A1(alu_out_q[12]), .A2(n2577), .B1(
        reg_out[12]), .B2(n2578), .C1(n3031), .X(N663) );
  sky130_fd_sc_hd__and2_0 U3819 ( .A(N596), .B(latched_branch), .X(n3031) );
  sky130_fd_sc_hd__a221o_1 U3820 ( .A1(alu_out_q[11]), .A2(n2577), .B1(
        reg_out[11]), .B2(n2578), .C1(n3032), .X(N662) );
  sky130_fd_sc_hd__and2_0 U3821 ( .A(N595), .B(latched_branch), .X(n3032) );
  sky130_fd_sc_hd__a221o_1 U3822 ( .A1(alu_out_q[10]), .A2(n2577), .B1(
        reg_out[10]), .B2(n2578), .C1(n3033), .X(N661) );
  sky130_fd_sc_hd__and2_0 U3823 ( .A(N594), .B(latched_branch), .X(n3033) );
  sky130_fd_sc_hd__a221o_1 U3824 ( .A1(alu_out_q[9]), .A2(n2577), .B1(
        reg_out[9]), .B2(n2578), .C1(n3034), .X(N660) );
  sky130_fd_sc_hd__and2_0 U3825 ( .A(N593), .B(latched_branch), .X(n3034) );
  sky130_fd_sc_hd__a221o_1 U3826 ( .A1(alu_out_q[8]), .A2(n2577), .B1(
        reg_out[8]), .B2(n2578), .C1(n3035), .X(N659) );
  sky130_fd_sc_hd__and2_0 U3827 ( .A(N592), .B(latched_branch), .X(n3035) );
  sky130_fd_sc_hd__a221o_1 U3828 ( .A1(alu_out_q[7]), .A2(n2577), .B1(
        reg_out[7]), .B2(n2578), .C1(n3036), .X(N658) );
  sky130_fd_sc_hd__and2_0 U3829 ( .A(N591), .B(latched_branch), .X(n3036) );
  sky130_fd_sc_hd__a221o_1 U3830 ( .A1(alu_out_q[6]), .A2(n2577), .B1(
        reg_out[6]), .B2(n2578), .C1(n3037), .X(N657) );
  sky130_fd_sc_hd__and2_0 U3831 ( .A(N590), .B(latched_branch), .X(n3037) );
  sky130_fd_sc_hd__a221o_1 U3832 ( .A1(alu_out_q[5]), .A2(n2577), .B1(
        reg_out[5]), .B2(n2578), .C1(n3038), .X(N656) );
  sky130_fd_sc_hd__and2_0 U3833 ( .A(N589), .B(latched_branch), .X(n3038) );
  sky130_fd_sc_hd__a221o_1 U3834 ( .A1(alu_out_q[4]), .A2(n2577), .B1(
        reg_out[4]), .B2(n2578), .C1(n3039), .X(N655) );
  sky130_fd_sc_hd__and2_0 U3835 ( .A(N588), .B(latched_branch), .X(n3039) );
  sky130_fd_sc_hd__a221o_1 U3836 ( .A1(alu_out_q[3]), .A2(n2577), .B1(
        reg_out[3]), .B2(n2578), .C1(n3040), .X(N654) );
  sky130_fd_sc_hd__and2_0 U3837 ( .A(N587), .B(latched_branch), .X(n3040) );
  sky130_fd_sc_hd__a221o_1 U3838 ( .A1(alu_out_q[2]), .A2(n2577), .B1(
        reg_out[2]), .B2(n2578), .C1(n3041), .X(N653) );
  sky130_fd_sc_hd__and2_0 U3839 ( .A(N586), .B(latched_branch), .X(n3041) );
  sky130_fd_sc_hd__a221o_1 U3840 ( .A1(alu_out_q[1]), .A2(n2577), .B1(
        reg_out[1]), .B2(n2578), .C1(n3042), .X(N652) );
  sky130_fd_sc_hd__and2_0 U3841 ( .A(N585), .B(latched_branch), .X(n3042) );
  sky130_fd_sc_hd__and3_1 U3842 ( .A(n3043), .B(n2678), .C(latched_store), .X(
        n2578) );
  sky130_fd_sc_hd__and3_1 U3843 ( .A(latched_store), .B(n3043), .C(
        latched_stalu), .X(n2577) );
  sky130_fd_sc_hd__clkinv_1 U3844 ( .A(latched_branch), .Y(n3043) );
  sky130_fd_sc_hd__nor4_1 U3845 ( .A(n3044), .B(n3045), .C(n1063), .D(n3046), 
        .Y(N374) );
  sky130_fd_sc_hd__nand3_1 U3846 ( .A(n3047), .B(n3048), .C(n3049), .Y(n3045)
         );
  sky130_fd_sc_hd__nand4_1 U3847 ( .A(mem_rdata_q[2]), .B(mem_rdata_q[0]), .C(
        n3050), .D(mem_rdata_q[3]), .Y(n3044) );
  sky130_fd_sc_hd__nor2_1 U3848 ( .A(n3051), .B(n3052), .Y(N373) );
  sky130_fd_sc_hd__nor2_1 U3849 ( .A(n3051), .B(n3053), .Y(N372) );
  sky130_fd_sc_hd__nor2_1 U3850 ( .A(n3054), .B(n3055), .Y(N371) );
  sky130_fd_sc_hd__nor2_1 U3851 ( .A(n3051), .B(n3054), .Y(N370) );
  sky130_fd_sc_hd__nor2_1 U3852 ( .A(n3051), .B(n3056), .Y(N369) );
  sky130_fd_sc_hd__nor2_1 U3853 ( .A(n3051), .B(n3057), .Y(N368) );
  sky130_fd_sc_hd__nor2_1 U3854 ( .A(n3051), .B(n3058), .Y(N367) );
  sky130_fd_sc_hd__nor2_1 U3855 ( .A(n3051), .B(n3059), .Y(N366) );
  sky130_fd_sc_hd__nor2_1 U3856 ( .A(n3060), .B(n3055), .Y(N365) );
  sky130_fd_sc_hd__nand4_1 U3857 ( .A(is_alu_reg_reg), .B(n3061), .C(
        mem_rdata_q[30]), .D(N31), .Y(n3055) );
  sky130_fd_sc_hd__nor2_1 U3858 ( .A(n3060), .B(n3051), .Y(N364) );
  sky130_fd_sc_hd__nand4_1 U3859 ( .A(is_alu_reg_reg), .B(n3061), .C(n1053), 
        .D(n2696), .Y(n3051) );
  sky130_fd_sc_hd__nor2_1 U3860 ( .A(n3052), .B(n3062), .Y(N363) );
  sky130_fd_sc_hd__nor2_1 U3861 ( .A(n3053), .B(n3062), .Y(N362) );
  sky130_fd_sc_hd__nor2_1 U3862 ( .A(n3056), .B(n3062), .Y(N361) );
  sky130_fd_sc_hd__nor2_1 U3863 ( .A(n3057), .B(n3062), .Y(N360) );
  sky130_fd_sc_hd__nand3_1 U3864 ( .A(mem_rdata_q[13]), .B(n2716), .C(
        mem_rdata_q[12]), .Y(n3057) );
  sky130_fd_sc_hd__nor2_1 U3865 ( .A(n3058), .B(n3062), .Y(N359) );
  sky130_fd_sc_hd__nor2_1 U3866 ( .A(n3060), .B(n3062), .Y(N358) );
  sky130_fd_sc_hd__nand2_1 U3867 ( .A(is_alu_reg_imm), .B(n1053), .Y(n3062) );
  sky130_fd_sc_hd__nor2_1 U3868 ( .A(n2632), .B(n3052), .Y(N357) );
  sky130_fd_sc_hd__nand2_1 U3869 ( .A(n3063), .B(mem_rdata_q[12]), .Y(n3052)
         );
  sky130_fd_sc_hd__nor2_1 U3870 ( .A(n2632), .B(n3053), .Y(N356) );
  sky130_fd_sc_hd__nand2_1 U3871 ( .A(n3063), .B(n2720), .Y(n3053) );
  sky130_fd_sc_hd__nor2_1 U3872 ( .A(n2718), .B(n2716), .Y(n3063) );
  sky130_fd_sc_hd__nor2_1 U3873 ( .A(n2632), .B(n3054), .Y(N355) );
  sky130_fd_sc_hd__nor2_1 U3874 ( .A(n2632), .B(n3056), .Y(N354) );
  sky130_fd_sc_hd__nor2_1 U3875 ( .A(n2632), .B(n3059), .Y(N353) );
  sky130_fd_sc_hd__nor2_1 U3876 ( .A(n2632), .B(n3060), .Y(N352) );
  sky130_fd_sc_hd__a31oi_1 U3877 ( .A1(n3064), .A2(n3065), .A3(n3066), .B1(
        N351), .Y(N350) );
  sky130_fd_sc_hd__or2_0 U3878 ( .A(N343), .B(n1063), .X(N351) );
  sky130_fd_sc_hd__nor3_1 U3879 ( .A(instr_sltiu), .B(
        is_beq_bne_blt_bge_bltu_bgeu), .C(instr_sltu), .Y(n3066) );
  sky130_fd_sc_hd__clkinv_1 U3880 ( .A(instr_slti), .Y(n3065) );
  sky130_fd_sc_hd__clkinv_1 U3881 ( .A(instr_slt), .Y(n3064) );
  sky130_fd_sc_hd__nor2_1 U3882 ( .A(N343), .B(n3067), .Y(N345) );
  sky130_fd_sc_hd__nor2_1 U3883 ( .A(decoder_pseudo_trigger), .B(n3068), .Y(
        N343) );
  sky130_fd_sc_hd__a221o_1 U3884 ( .A1(n3069), .A2(mem_rdata_q[31]), .B1(
        decoded_imm_j[31]), .B2(instr_jal), .C1(n3070), .X(N342) );
  sky130_fd_sc_hd__a221o_1 U3885 ( .A1(n3069), .A2(mem_rdata_q[30]), .B1(
        decoded_imm_j[30]), .B2(instr_jal), .C1(n3070), .X(N341) );
  sky130_fd_sc_hd__a221o_1 U3886 ( .A1(n3069), .A2(mem_rdata_q[29]), .B1(
        decoded_imm_j[29]), .B2(instr_jal), .C1(n3070), .X(N340) );
  sky130_fd_sc_hd__a221o_1 U3887 ( .A1(n3069), .A2(mem_rdata_q[28]), .B1(
        decoded_imm_j[28]), .B2(instr_jal), .C1(n3070), .X(N339) );
  sky130_fd_sc_hd__a221o_1 U3888 ( .A1(n3069), .A2(mem_rdata_q[27]), .B1(
        decoded_imm_j[27]), .B2(instr_jal), .C1(n3070), .X(N338) );
  sky130_fd_sc_hd__a221o_1 U3889 ( .A1(n3069), .A2(mem_rdata_q[26]), .B1(
        decoded_imm_j[26]), .B2(instr_jal), .C1(n3070), .X(N337) );
  sky130_fd_sc_hd__a221o_1 U3890 ( .A1(n3069), .A2(mem_rdata_q[25]), .B1(
        decoded_imm_j[25]), .B2(instr_jal), .C1(n3070), .X(N336) );
  sky130_fd_sc_hd__a221o_1 U3891 ( .A1(n3069), .A2(mem_rdata_q[24]), .B1(
        decoded_imm_j[24]), .B2(instr_jal), .C1(n3070), .X(N335) );
  sky130_fd_sc_hd__a221o_1 U3892 ( .A1(n3069), .A2(mem_rdata_q[23]), .B1(
        decoded_imm_j[23]), .B2(instr_jal), .C1(n3070), .X(N334) );
  sky130_fd_sc_hd__a221o_1 U3893 ( .A1(n3069), .A2(mem_rdata_q[22]), .B1(
        decoded_imm_j[22]), .B2(instr_jal), .C1(n3070), .X(N333) );
  sky130_fd_sc_hd__a221o_1 U3894 ( .A1(n3069), .A2(mem_rdata_q[21]), .B1(
        decoded_imm_j[21]), .B2(instr_jal), .C1(n3070), .X(N332) );
  sky130_fd_sc_hd__a221o_1 U3895 ( .A1(n3069), .A2(mem_rdata_q[20]), .B1(
        decoded_imm_j[20]), .B2(instr_jal), .C1(n3070), .X(N331) );
  sky130_fd_sc_hd__a221o_1 U3896 ( .A1(n3069), .A2(mem_rdata_q[19]), .B1(
        decoded_imm_j[19]), .B2(instr_jal), .C1(n3070), .X(N330) );
  sky130_fd_sc_hd__a221o_1 U3897 ( .A1(n3069), .A2(mem_rdata_q[18]), .B1(
        decoded_imm_j[18]), .B2(instr_jal), .C1(n3070), .X(N329) );
  sky130_fd_sc_hd__a221o_1 U3898 ( .A1(n3069), .A2(mem_rdata_q[17]), .B1(
        decoded_imm_j[17]), .B2(instr_jal), .C1(n3070), .X(N328) );
  sky130_fd_sc_hd__a221o_1 U3899 ( .A1(n3069), .A2(mem_rdata_q[16]), .B1(
        decoded_imm_j[16]), .B2(instr_jal), .C1(n3070), .X(N327) );
  sky130_fd_sc_hd__a221o_1 U3900 ( .A1(n3069), .A2(mem_rdata_q[15]), .B1(
        decoded_imm_j[15]), .B2(instr_jal), .C1(n3070), .X(N326) );
  sky130_fd_sc_hd__a221o_1 U3901 ( .A1(n3069), .A2(mem_rdata_q[14]), .B1(
        decoded_imm_j[14]), .B2(instr_jal), .C1(n3070), .X(N325) );
  sky130_fd_sc_hd__a221o_1 U3902 ( .A1(n3069), .A2(mem_rdata_q[13]), .B1(
        decoded_imm_j[13]), .B2(instr_jal), .C1(n3070), .X(N324) );
  sky130_fd_sc_hd__a221o_1 U3903 ( .A1(n3069), .A2(mem_rdata_q[12]), .B1(
        decoded_imm_j[12]), .B2(instr_jal), .C1(n3070), .X(N323) );
  sky130_fd_sc_hd__and2_0 U3904 ( .A(n3071), .B(mem_rdata_q[31]), .X(n3070) );
  sky130_fd_sc_hd__nor2_1 U3905 ( .A(n3072), .B(instr_jal), .Y(n3069) );
  sky130_fd_sc_hd__a221o_1 U3906 ( .A1(n3073), .A2(mem_rdata_q[7]), .B1(
        decoded_imm_j[11]), .B2(instr_jal), .C1(n3074), .X(N322) );
  sky130_fd_sc_hd__a21oi_1 U3907 ( .A1(n3075), .A2(n3076), .B1(n2694), .Y(
        n3074) );
  sky130_fd_sc_hd__clkinv_1 U3908 ( .A(mem_rdata_q[31]), .Y(n2694) );
  sky130_fd_sc_hd__a22o_1 U3909 ( .A1(n3071), .A2(mem_rdata_q[30]), .B1(
        decoded_imm_j[10]), .B2(instr_jal), .X(N321) );
  sky130_fd_sc_hd__a22o_1 U3910 ( .A1(n3071), .A2(mem_rdata_q[29]), .B1(
        decoded_imm_j[9]), .B2(instr_jal), .X(N320) );
  sky130_fd_sc_hd__a22o_1 U3911 ( .A1(n3071), .A2(mem_rdata_q[28]), .B1(
        decoded_imm_j[8]), .B2(instr_jal), .X(N319) );
  sky130_fd_sc_hd__a22o_1 U3912 ( .A1(n3071), .A2(mem_rdata_q[27]), .B1(
        decoded_imm_j[7]), .B2(instr_jal), .X(N318) );
  sky130_fd_sc_hd__a22o_1 U3913 ( .A1(n3071), .A2(mem_rdata_q[26]), .B1(
        decoded_imm_j[6]), .B2(instr_jal), .X(N317) );
  sky130_fd_sc_hd__a22o_1 U3914 ( .A1(n3071), .A2(mem_rdata_q[25]), .B1(
        decoded_imm_j[5]), .B2(instr_jal), .X(N316) );
  sky130_fd_sc_hd__nand2_1 U3915 ( .A(n3077), .B(n3075), .Y(n3071) );
  sky130_fd_sc_hd__o221ai_1 U3916 ( .A1(n3077), .A2(n2722), .B1(n2700), .B2(
        n3075), .C1(n3078), .Y(N315) );
  sky130_fd_sc_hd__nand2_1 U3917 ( .A(decoded_imm_j[4]), .B(instr_jal), .Y(
        n3078) );
  sky130_fd_sc_hd__clkinv_1 U3918 ( .A(mem_rdata_q[24]), .Y(n2700) );
  sky130_fd_sc_hd__clkinv_1 U3919 ( .A(mem_rdata_q[11]), .Y(n2722) );
  sky130_fd_sc_hd__o221ai_1 U3920 ( .A1(n3077), .A2(n2724), .B1(n2702), .B2(
        n3075), .C1(n3079), .Y(N314) );
  sky130_fd_sc_hd__nand2_1 U3921 ( .A(decoded_imm_j[3]), .B(instr_jal), .Y(
        n3079) );
  sky130_fd_sc_hd__clkinv_1 U3922 ( .A(mem_rdata_q[23]), .Y(n2702) );
  sky130_fd_sc_hd__clkinv_1 U3923 ( .A(mem_rdata_q[10]), .Y(n2724) );
  sky130_fd_sc_hd__o221ai_1 U3924 ( .A1(n3077), .A2(n2689), .B1(n2704), .B2(
        n3075), .C1(n3080), .Y(N313) );
  sky130_fd_sc_hd__nand2_1 U3925 ( .A(decoded_imm_j[2]), .B(instr_jal), .Y(
        n3080) );
  sky130_fd_sc_hd__clkinv_1 U3926 ( .A(mem_rdata_q[22]), .Y(n2704) );
  sky130_fd_sc_hd__clkinv_1 U3927 ( .A(mem_rdata_q[9]), .Y(n2689) );
  sky130_fd_sc_hd__o221ai_1 U3928 ( .A1(n3077), .A2(n2691), .B1(n2706), .B2(
        n3075), .C1(n3081), .Y(N312) );
  sky130_fd_sc_hd__nand2_1 U3929 ( .A(decoded_imm_j[1]), .B(instr_jal), .Y(
        n3081) );
  sky130_fd_sc_hd__clkinv_1 U3930 ( .A(mem_rdata_q[8]), .Y(n2691) );
  sky130_fd_sc_hd__nor2b_1 U3931 ( .B_N(n3076), .A(n3073), .Y(n3077) );
  sky130_fd_sc_hd__nor3_1 U3932 ( .A(n2677), .B(N252), .C(n3082), .Y(n3073) );
  sky130_fd_sc_hd__nand4_1 U3933 ( .A(n3083), .B(is_sb_sh_sw), .C(n3084), .D(
        n2677), .Y(n3076) );
  sky130_fd_sc_hd__o21ai_0 U3934 ( .A1(n2708), .A2(n3075), .B1(n3085), .Y(N311) );
  sky130_fd_sc_hd__nand4_1 U3935 ( .A(n3083), .B(mem_rdata_q[7]), .C(n3084), 
        .D(n2677), .Y(n3085) );
  sky130_fd_sc_hd__clkinv_1 U3936 ( .A(n3082), .Y(n3083) );
  sky130_fd_sc_hd__nand2_1 U3937 ( .A(n3082), .B(n3084), .Y(n3075) );
  sky130_fd_sc_hd__clkinv_1 U3938 ( .A(N252), .Y(n3084) );
  sky130_fd_sc_hd__nand3_1 U3939 ( .A(n3086), .B(n3087), .C(n2685), .Y(n3082)
         );
  sky130_fd_sc_hd__clkinv_1 U3940 ( .A(mem_rdata_q[20]), .Y(n2708) );
  sky130_fd_sc_hd__and3b_1 U3941 ( .B(is_alu_reg_reg), .C(n3061), .A_N(n3088), 
        .X(N302) );
  sky130_fd_sc_hd__o21ai_0 U3942 ( .A1(n3089), .A2(n3086), .B1(n2685), .Y(N301) );
  sky130_fd_sc_hd__clkinv_1 U3943 ( .A(is_alu_reg_imm), .Y(n3086) );
  sky130_fd_sc_hd__nor2_1 U3944 ( .A(n3088), .B(n3090), .Y(N300) );
  sky130_fd_sc_hd__a21boi_0 U3945 ( .A1(n2696), .A2(n3089), .B1_N(n3054), .Y(
        n3088) );
  sky130_fd_sc_hd__nor4_1 U3946 ( .A(mem_rdata_q[20]), .B(n2698), .C(n2706), 
        .D(n3091), .Y(N298) );
  sky130_fd_sc_hd__nor4_1 U3947 ( .A(mem_rdata_q[27]), .B(mem_rdata_q[20]), 
        .C(n2706), .D(n3091), .Y(N297) );
  sky130_fd_sc_hd__clkinv_1 U3948 ( .A(mem_rdata_q[21]), .Y(n2706) );
  sky130_fd_sc_hd__nor3_1 U3949 ( .A(n3091), .B(mem_rdata_q[21]), .C(n2698), 
        .Y(N296) );
  sky130_fd_sc_hd__clkinv_1 U3950 ( .A(mem_rdata_q[27]), .Y(n2698) );
  sky130_fd_sc_hd__nor3_1 U3951 ( .A(n3091), .B(mem_rdata_q[27]), .C(
        mem_rdata_q[21]), .Y(N295) );
  sky130_fd_sc_hd__nand4_1 U3952 ( .A(n3092), .B(n3093), .C(n3094), .D(n3095), 
        .Y(n3091) );
  sky130_fd_sc_hd__nor3_1 U3953 ( .A(n3096), .B(mem_rdata_q[23]), .C(
        mem_rdata_q[22]), .Y(n3095) );
  sky130_fd_sc_hd__or3_1 U3954 ( .A(mem_rdata_q[2]), .B(mem_rdata_q[3]), .C(
        mem_rdata_q[24]), .X(n3096) );
  sky130_fd_sc_hd__nor3_1 U3955 ( .A(n3097), .B(mem_rdata_q[16]), .C(
        mem_rdata_q[15]), .Y(n3094) );
  sky130_fd_sc_hd__nand3_1 U3956 ( .A(n2712), .B(n2710), .C(n2714), .Y(n3097)
         );
  sky130_fd_sc_hd__clkinv_1 U3957 ( .A(mem_rdata_q[17]), .Y(n2714) );
  sky130_fd_sc_hd__clkinv_1 U3958 ( .A(mem_rdata_q[19]), .Y(n2710) );
  sky130_fd_sc_hd__clkinv_1 U3959 ( .A(mem_rdata_q[18]), .Y(n2712) );
  sky130_fd_sc_hd__nor3_1 U3960 ( .A(n3098), .B(n3099), .C(n3100), .Y(n3093)
         );
  sky130_fd_sc_hd__nand3_1 U3961 ( .A(mem_rdata_q[31]), .B(mem_rdata_q[1]), 
        .C(mem_rdata_q[30]), .Y(n3098) );
  sky130_fd_sc_hd__nor4_1 U3962 ( .A(n3058), .B(n3049), .C(n3047), .D(n3048), 
        .Y(n3092) );
  sky130_fd_sc_hd__nor3_1 U3963 ( .A(n3090), .B(n2696), .C(n3054), .Y(N284) );
  sky130_fd_sc_hd__clkinv_1 U3964 ( .A(mem_rdata_q[30]), .Y(n2696) );
  sky130_fd_sc_hd__nor3_1 U3965 ( .A(n3090), .B(mem_rdata_q[30]), .C(n3054), 
        .Y(N283) );
  sky130_fd_sc_hd__nor3_1 U3966 ( .A(n3090), .B(mem_rdata_q[30]), .C(n3059), 
        .Y(N282) );
  sky130_fd_sc_hd__nand2_1 U3967 ( .A(is_alu_reg_imm), .B(n3061), .Y(n3090) );
  sky130_fd_sc_hd__nor3_1 U3968 ( .A(mem_rdata_q[27]), .B(mem_rdata_q[31]), 
        .C(n3100), .Y(n3061) );
  sky130_fd_sc_hd__or4_1 U3969 ( .A(mem_rdata_q[25]), .B(mem_rdata_q[26]), .C(
        mem_rdata_q[28]), .D(mem_rdata_q[29]), .X(n3100) );
  sky130_fd_sc_hd__nor2_1 U3970 ( .A(n2634), .B(n3058), .Y(N275) );
  sky130_fd_sc_hd__nor2_1 U3971 ( .A(n2634), .B(n3059), .Y(N274) );
  sky130_fd_sc_hd__nor2_1 U3972 ( .A(n2634), .B(n3060), .Y(N273) );
  sky130_fd_sc_hd__nor2_1 U3973 ( .A(n3087), .B(n3054), .Y(N272) );
  sky130_fd_sc_hd__nand2_1 U3974 ( .A(n3089), .B(mem_rdata_q[14]), .Y(n3054)
         );
  sky130_fd_sc_hd__nor2_1 U3975 ( .A(n3087), .B(n3056), .Y(N271) );
  sky130_fd_sc_hd__nand3_1 U3976 ( .A(n2720), .B(n2718), .C(mem_rdata_q[14]), 
        .Y(n3056) );
  sky130_fd_sc_hd__nor2_1 U3977 ( .A(n3087), .B(n3058), .Y(N270) );
  sky130_fd_sc_hd__nand3_1 U3978 ( .A(n2720), .B(n2716), .C(mem_rdata_q[13]), 
        .Y(n3058) );
  sky130_fd_sc_hd__nor2_1 U3979 ( .A(n3087), .B(n3059), .Y(N269) );
  sky130_fd_sc_hd__nand2_1 U3980 ( .A(n3089), .B(n2716), .Y(n3059) );
  sky130_fd_sc_hd__nor2_1 U3981 ( .A(n2720), .B(mem_rdata_q[13]), .Y(n3089) );
  sky130_fd_sc_hd__nor2_1 U3982 ( .A(n3087), .B(n3060), .Y(N268) );
  sky130_fd_sc_hd__nor4_1 U3983 ( .A(n2593), .B(n2581), .C(n2584), .D(n3101), 
        .Y(N259) );
  sky130_fd_sc_hd__mux2i_1 U3984 ( .A0(n3050), .A1(n3102), .S(n3571), .Y(n3101) );
  sky130_fd_sc_hd__nor3_1 U3985 ( .A(mem_rdata[12]), .B(mem_rdata[14]), .C(
        mem_rdata[13]), .Y(n3102) );
  sky130_fd_sc_hd__clkinv_1 U3986 ( .A(n3060), .Y(n3050) );
  sky130_fd_sc_hd__nand3_1 U3987 ( .A(n2718), .B(n2716), .C(n2720), .Y(n3060)
         );
  sky130_fd_sc_hd__clkinv_1 U3988 ( .A(mem_rdata_q[12]), .Y(n2720) );
  sky130_fd_sc_hd__clkinv_1 U3989 ( .A(mem_rdata_q[14]), .Y(n2716) );
  sky130_fd_sc_hd__clkinv_1 U3990 ( .A(mem_rdata_q[13]), .Y(n2718) );
  sky130_fd_sc_hd__nand3_1 U3991 ( .A(n2582), .B(n2592), .C(n2588), .Y(n2584)
         );
  sky130_fd_sc_hd__mux2i_1 U3992 ( .A0(n3048), .A1(n3103), .S(n3571), .Y(n2588) );
  sky130_fd_sc_hd__clkinv_1 U3993 ( .A(mem_rdata_q[6]), .Y(n3048) );
  sky130_fd_sc_hd__clkinv_1 U3994 ( .A(n2589), .Y(n2592) );
  sky130_fd_sc_hd__mux2i_1 U3995 ( .A0(n3049), .A1(n3104), .S(n3571), .Y(n2589) );
  sky130_fd_sc_hd__clkinv_1 U3996 ( .A(mem_rdata_q[4]), .Y(n3049) );
  sky130_fd_sc_hd__mux2i_1 U3997 ( .A0(n3047), .A1(n3105), .S(n3571), .Y(n2582) );
  sky130_fd_sc_hd__clkinv_1 U3998 ( .A(mem_rdata_q[5]), .Y(n3047) );
  sky130_fd_sc_hd__mux2i_1 U3999 ( .A0(mem_rdata_q[2]), .A1(mem_rdata[2]), .S(
        n3571), .Y(n2581) );
  sky130_fd_sc_hd__nand3_1 U4000 ( .A(n2585), .B(n2586), .C(n2587), .Y(n2593)
         );
  sky130_fd_sc_hd__mux2i_1 U4001 ( .A0(n3099), .A1(n3106), .S(n3571), .Y(n2587) );
  sky130_fd_sc_hd__clkinv_1 U4002 ( .A(mem_rdata_q[0]), .Y(n3099) );
  sky130_fd_sc_hd__mux2i_1 U4003 ( .A0(n3107), .A1(n3046), .S(n2693), .Y(n2586) );
  sky130_fd_sc_hd__clkinv_1 U4004 ( .A(mem_rdata_q[1]), .Y(n3046) );
  sky130_fd_sc_hd__mux2i_1 U4005 ( .A0(mem_rdata_q[3]), .A1(mem_rdata[3]), .S(
        n3571), .Y(n2585) );
  sky130_fd_sc_hd__clkinv_1 U4006 ( .A(n2693), .Y(n3571) );
  sky130_fd_sc_hd__clkinv_1 U4007 ( .A(n3108), .Y(N258) );
  sky130_fd_sc_hd__a21o_1 U4008 ( .A1(n2651), .A2(mem_la_read), .B1(N250), .X(
        N249) );
  sky130_fd_sc_hd__and2_0 U4009 ( .A(mem_la_write), .B(n2651), .X(N250) );
  sky130_fd_sc_hd__nor3_1 U4010 ( .A(n1062), .B(n3109), .C(n2658), .Y(
        mem_la_read) );
  sky130_fd_sc_hd__clkinv_1 U4011 ( .A(n2659), .Y(n3109) );
  sky130_fd_sc_hd__nor2_1 U4012 ( .A(trap), .B(n1063), .Y(n2651) );
  sky130_fd_sc_hd__and2_0 U4013 ( .A(mem_la_wstrb[3]), .B(n3110), .X(N242) );
  sky130_fd_sc_hd__and2_0 U4014 ( .A(mem_la_wstrb[2]), .B(n3110), .X(N241) );
  sky130_fd_sc_hd__and2_0 U4015 ( .A(mem_la_wstrb[1]), .B(n3110), .X(N240) );
  sky130_fd_sc_hd__and2_0 U4016 ( .A(mem_la_wstrb[0]), .B(n3110), .X(N239) );
  sky130_fd_sc_hd__nor2b_1 U4017 ( .B_N(mem_la_write), .A(n2659), .Y(n3110) );
  sky130_fd_sc_hd__nand2_1 U4018 ( .A(n2543), .B(n2652), .Y(n2659) );
  sky130_fd_sc_hd__clkinv_1 U4019 ( .A(n2729), .Y(n2543) );
  sky130_fd_sc_hd__nand2_1 U4020 ( .A(n2619), .B(n2638), .Y(n2729) );
  sky130_fd_sc_hd__nor3_1 U4021 ( .A(n2595), .B(n1063), .C(n2658), .Y(
        mem_la_write) );
  sky130_fd_sc_hd__clkinv_1 U4022 ( .A(mem_do_wdata), .Y(n2595) );
  sky130_fd_sc_hd__o31ai_1 U4023 ( .A1(n3111), .A2(n2640), .A3(n1062), .B1(
        n3112), .Y(N2115) );
  sky130_fd_sc_hd__a31oi_1 U4024 ( .A1(N31), .A2(n3113), .A3(n3114), .B1(n3115), .Y(N2114) );
  sky130_fd_sc_hd__a211oi_1 U4025 ( .A1(cpu_state[5]), .A2(n2670), .B1(
        cpu_state[3]), .C1(cpu_state[2]), .Y(n3114) );
  sky130_fd_sc_hd__clkinv_1 U4026 ( .A(n3116), .Y(n2670) );
  sky130_fd_sc_hd__nor2_1 U4027 ( .A(n2636), .B(n3117), .Y(N2113) );
  sky130_fd_sc_hd__nor2_1 U4028 ( .A(n3118), .B(n3117), .Y(N2112) );
  sky130_fd_sc_hd__o32a_1 U4029 ( .A1(is_sb_sh_sw), .A2(is_sll_srl_sra), .A3(
        n2633), .B1(n2629), .B2(n2640), .X(n3118) );
  sky130_fd_sc_hd__o21ai_0 U4030 ( .A1(n3119), .A2(is_lui_auipc_jal), .B1(
        n3120), .Y(n2629) );
  sky130_fd_sc_hd__and3_1 U4031 ( .A(is_jalr_addi_slti_sltiu_xori_ori_andi), 
        .B(n3121), .C(n3087), .X(n3119) );
  sky130_fd_sc_hd__a21oi_1 U4032 ( .A1(n3122), .A2(n3123), .B1(n3117), .Y(
        N2111) );
  sky130_fd_sc_hd__nand4_1 U4033 ( .A(n3124), .B(n3120), .C(n3087), .D(n3125), 
        .Y(n3123) );
  sky130_fd_sc_hd__clkinv_1 U4034 ( .A(is_lb_lh_lw_lbu_lhu), .Y(n3087) );
  sky130_fd_sc_hd__nand2b_1 U4035 ( .A_N(n2633), .B(n2627), .Y(n3122) );
  sky130_fd_sc_hd__and2_0 U4036 ( .A(is_sll_srl_sra), .B(n2634), .X(n2627) );
  sky130_fd_sc_hd__nor3_1 U4037 ( .A(n3117), .B(n2633), .C(n2634), .Y(N2110)
         );
  sky130_fd_sc_hd__clkinv_1 U4038 ( .A(is_sb_sh_sw), .Y(n2634) );
  sky130_fd_sc_hd__nand3_1 U4039 ( .A(n3126), .B(n3120), .C(n3127), .Y(n2633)
         );
  sky130_fd_sc_hd__nor3_1 U4040 ( .A(n2640), .B(is_slli_srli_srai), .C(
        is_lb_lh_lw_lbu_lhu), .Y(n3127) );
  sky130_fd_sc_hd__nor3_1 U4041 ( .A(n3117), .B(n2640), .C(n2628), .Y(N2109)
         );
  sky130_fd_sc_hd__nand3_1 U4042 ( .A(n3120), .B(n3125), .C(
        is_lb_lh_lw_lbu_lhu), .Y(n2628) );
  sky130_fd_sc_hd__clkinv_1 U4043 ( .A(n2626), .Y(n3120) );
  sky130_fd_sc_hd__nand2_1 U4044 ( .A(n3116), .B(n3111), .Y(n2626) );
  sky130_fd_sc_hd__nand4_1 U4045 ( .A(n3128), .B(n3129), .C(n3130), .D(n3131), 
        .Y(n3111) );
  sky130_fd_sc_hd__nor4_1 U4046 ( .A(n3132), .B(instr_sltiu), .C(instr_sra), 
        .D(instr_sltu), .Y(n3131) );
  sky130_fd_sc_hd__or3_1 U4047 ( .A(instr_xor), .B(instr_xori), .C(instr_srai), 
        .X(n3132) );
  sky130_fd_sc_hd__nor4_1 U4048 ( .A(n3133), .B(instr_bne), .C(instr_lb), .D(
        instr_fence), .Y(n3130) );
  sky130_fd_sc_hd__or3_1 U4049 ( .A(instr_or), .B(instr_ori), .C(instr_lh), 
        .X(n3133) );
  sky130_fd_sc_hd__nor4_1 U4050 ( .A(n3134), .B(instr_and), .C(instr_beq), .D(
        instr_andi), .Y(n3129) );
  sky130_fd_sc_hd__or3_1 U4051 ( .A(instr_bltu), .B(instr_bgeu), .C(instr_bge), 
        .X(n3134) );
  sky130_fd_sc_hd__nor4_1 U4052 ( .A(n3135), .B(n2603), .C(N256), .D(N254), 
        .Y(n3128) );
  sky130_fd_sc_hd__or3_1 U4053 ( .A(instr_slti), .B(instr_slt), .C(instr_blt), 
        .X(N254) );
  sky130_fd_sc_hd__or3_1 U4054 ( .A(instr_lhu), .B(instr_lw), .C(instr_lbu), 
        .X(N256) );
  sky130_fd_sc_hd__nand3_1 U4055 ( .A(n3067), .B(n2665), .C(n3116), .Y(n3135)
         );
  sky130_fd_sc_hd__nor3_1 U4056 ( .A(instr_sw), .B(instr_sh), .C(instr_sb), 
        .Y(n2665) );
  sky130_fd_sc_hd__nor4_1 U4057 ( .A(instr_add), .B(N252), .C(instr_addi), .D(
        n3136), .Y(n3067) );
  sky130_fd_sc_hd__nand2_1 U4058 ( .A(n2685), .B(n2990), .Y(n3136) );
  sky130_fd_sc_hd__clkinv_1 U4059 ( .A(instr_sub), .Y(n2990) );
  sky130_fd_sc_hd__clkinv_1 U4060 ( .A(instr_jalr), .Y(n2685) );
  sky130_fd_sc_hd__nand2_1 U4061 ( .A(n3072), .B(n3137), .Y(N252) );
  sky130_fd_sc_hd__nor2_1 U4062 ( .A(instr_auipc), .B(instr_lui), .Y(n3072) );
  sky130_fd_sc_hd__nor3b_1 U4063 ( .C_N(n3138), .A(instr_rdinstrh), .B(
        instr_rdinstr), .Y(n3116) );
  sky130_fd_sc_hd__nand4_1 U4064 ( .A(n2680), .B(n3139), .C(n3140), .D(n3141), 
        .Y(N2108) );
  sky130_fd_sc_hd__a221oi_1 U4065 ( .A1(n3142), .A2(n3143), .B1(n2624), .B2(
        n2635), .C1(n3117), .Y(n3141) );
  sky130_fd_sc_hd__nand2_1 U4066 ( .A(n3112), .B(n1053), .Y(n3117) );
  sky130_fd_sc_hd__clkinv_1 U4067 ( .A(n3115), .Y(n3112) );
  sky130_fd_sc_hd__o22ai_1 U4068 ( .A1(n3144), .A2(n3145), .B1(n1062), .B2(
        n3146), .Y(n3115) );
  sky130_fd_sc_hd__o21ai_0 U4069 ( .A1(reg_pc[0]), .A2(reg_pc[1]), .B1(
        mem_do_rinst), .Y(n3146) );
  sky130_fd_sc_hd__o21ai_0 U4070 ( .A1(mem_do_wdata), .A2(mem_do_rdata), .B1(
        N31), .Y(n3145) );
  sky130_fd_sc_hd__o211ai_1 U4071 ( .A1(pcpi_rs1[0]), .A2(n3147), .B1(n3148), 
        .C1(n3149), .Y(n3144) );
  sky130_fd_sc_hd__clkinv_1 U4072 ( .A(n2528), .Y(n2624) );
  sky130_fd_sc_hd__a21oi_1 U4073 ( .A1(n2672), .A2(n3150), .B1(n2533), .Y(
        n3140) );
  sky130_fd_sc_hd__clkinv_1 U4074 ( .A(n2530), .Y(n2672) );
  sky130_fd_sc_hd__o21ai_0 U4075 ( .A1(n3151), .A2(n3108), .B1(n3139), .Y(
        N2074) );
  sky130_fd_sc_hd__nand2_1 U4076 ( .A(n3142), .B(mem_do_rinst), .Y(n3108) );
  sky130_fd_sc_hd__nor3_1 U4077 ( .A(n3152), .B(n3153), .C(n2631), .Y(n3151)
         );
  sky130_fd_sc_hd__clkinv_1 U4078 ( .A(n2676), .Y(n2631) );
  sky130_fd_sc_hd__mux2i_1 U4079 ( .A0(n3154), .A1(n3155), .S(instr_beq), .Y(
        n2676) );
  sky130_fd_sc_hd__mux2i_1 U4080 ( .A0(n3156), .A1(n3155), .S(instr_bne), .Y(
        n3154) );
  sky130_fd_sc_hd__clkinv_1 U4081 ( .A(alu_eq), .Y(n3155) );
  sky130_fd_sc_hd__mux2i_1 U4082 ( .A0(n3157), .A1(n3158), .S(instr_bge), .Y(
        n3156) );
  sky130_fd_sc_hd__mux2i_1 U4083 ( .A0(n3159), .A1(n3160), .S(instr_bgeu), .Y(
        n3157) );
  sky130_fd_sc_hd__clkinv_1 U4084 ( .A(alu_ltu), .Y(n3160) );
  sky130_fd_sc_hd__mux2_1 U4085 ( .A0(alu_ltu), .A1(n3158), .S(is_slti_blt_slt), .X(n3159) );
  sky130_fd_sc_hd__maj3_1 U4086 ( .A(n3161), .B(n2866), .C(pcpi_rs1[31]), .X(
        n3158) );
  sky130_fd_sc_hd__a21oi_1 U4087 ( .A1(pcpi_rs1[30]), .A2(n2871), .B1(n3162), 
        .Y(n3161) );
  sky130_fd_sc_hd__a21oi_1 U4088 ( .A1(pcpi_rs2[30]), .A2(n2606), .B1(n3163), 
        .Y(n3162) );
  sky130_fd_sc_hd__a21oi_1 U4089 ( .A1(pcpi_rs1[29]), .A2(n2881), .B1(n3164), 
        .Y(n3163) );
  sky130_fd_sc_hd__a222oi_1 U4090 ( .A1(pcpi_rs2[29]), .A2(n2759), .B1(n3165), 
        .B2(n2892), .C1(pcpi_rs2[28]), .C2(n2762), .Y(n3164) );
  sky130_fd_sc_hd__nand2_1 U4091 ( .A(pcpi_rs1[27]), .B(n2891), .Y(n2892) );
  sky130_fd_sc_hd__a21oi_1 U4092 ( .A1(n3166), .A2(n3167), .B1(n2883), .Y(
        n3165) );
  sky130_fd_sc_hd__nor2_1 U4093 ( .A(n2762), .B(pcpi_rs2[28]), .Y(n2883) );
  sky130_fd_sc_hd__nand2_1 U4094 ( .A(pcpi_rs2[27]), .B(n2765), .Y(n3167) );
  sky130_fd_sc_hd__o32a_1 U4095 ( .A1(n2894), .A2(n3168), .A3(n2899), .B1(
        n2897), .B2(pcpi_rs1[26]), .X(n3166) );
  sky130_fd_sc_hd__nor2_1 U4096 ( .A(n2771), .B(pcpi_rs2[25]), .Y(n2899) );
  sky130_fd_sc_hd__o221a_1 U4097 ( .A1(pcpi_rs1[24]), .A2(n2907), .B1(
        pcpi_rs1[25]), .B2(n2902), .C1(n3169), .X(n3168) );
  sky130_fd_sc_hd__or3b_1 U4098 ( .A(n2904), .B(n2909), .C_N(n3170), .X(n3169)
         );
  sky130_fd_sc_hd__o221ai_1 U4099 ( .A1(pcpi_rs1[22]), .A2(n2917), .B1(
        pcpi_rs1[23]), .B2(n2912), .C1(n3171), .Y(n3170) );
  sky130_fd_sc_hd__or3b_1 U4100 ( .A(n2914), .B(n2919), .C_N(n3172), .X(n3171)
         );
  sky130_fd_sc_hd__o221ai_1 U4101 ( .A1(pcpi_rs1[20]), .A2(n2927), .B1(
        pcpi_rs1[21]), .B2(n2922), .C1(n3173), .Y(n3172) );
  sky130_fd_sc_hd__or3b_1 U4102 ( .A(n2924), .B(n2935), .C_N(n3174), .X(n3173)
         );
  sky130_fd_sc_hd__o221ai_1 U4103 ( .A1(pcpi_rs1[18]), .A2(n2943), .B1(
        pcpi_rs1[19]), .B2(n2938), .C1(n3175), .Y(n3174) );
  sky130_fd_sc_hd__or3b_1 U4104 ( .A(n2940), .B(n2945), .C_N(n3176), .X(n3175)
         );
  sky130_fd_sc_hd__o221ai_1 U4105 ( .A1(pcpi_rs1[16]), .A2(n2953), .B1(
        pcpi_rs1[17]), .B2(n2948), .C1(n3177), .Y(n3176) );
  sky130_fd_sc_hd__or3b_1 U4106 ( .A(n2950), .B(n2955), .C_N(n3178), .X(n3177)
         );
  sky130_fd_sc_hd__o221ai_1 U4107 ( .A1(pcpi_rs1[14]), .A2(n2963), .B1(
        pcpi_rs1[15]), .B2(n2958), .C1(n3179), .Y(n3178) );
  sky130_fd_sc_hd__or3b_1 U4108 ( .A(n2960), .B(n2965), .C_N(n3180), .X(n3179)
         );
  sky130_fd_sc_hd__o221ai_1 U4109 ( .A1(pcpi_rs1[12]), .A2(n2973), .B1(
        pcpi_rs1[13]), .B2(n2968), .C1(n3181), .Y(n3180) );
  sky130_fd_sc_hd__or3b_1 U4110 ( .A(n2970), .B(n2975), .C_N(n3182), .X(n3181)
         );
  sky130_fd_sc_hd__o221ai_1 U4111 ( .A1(pcpi_rs1[10]), .A2(n2983), .B1(
        pcpi_rs1[11]), .B2(n2978), .C1(n3183), .Y(n3182) );
  sky130_fd_sc_hd__or3b_1 U4112 ( .A(n2822), .B(n2980), .C_N(n3184), .X(n3183)
         );
  sky130_fd_sc_hd__o221ai_1 U4113 ( .A1(pcpi_rs1[8]), .A2(n2834), .B1(
        pcpi_rs1[9]), .B2(n2828), .C1(n3185), .Y(n3184) );
  sky130_fd_sc_hd__or3b_1 U4114 ( .A(n2831), .B(n2836), .C_N(n3186), .X(n3185)
         );
  sky130_fd_sc_hd__o221ai_1 U4115 ( .A1(pcpi_rs1[6]), .A2(n2844), .B1(
        pcpi_rs1[7]), .B2(n2839), .C1(n3187), .Y(n3186) );
  sky130_fd_sc_hd__or3b_1 U4116 ( .A(n2841), .B(n2846), .C_N(n3188), .X(n3187)
         );
  sky130_fd_sc_hd__o221ai_1 U4117 ( .A1(pcpi_rs1[4]), .A2(n2854), .B1(
        pcpi_rs1[5]), .B2(n2849), .C1(n3189), .Y(n3188) );
  sky130_fd_sc_hd__or3b_1 U4118 ( .A(n2851), .B(n2856), .C_N(n3190), .X(n3189)
         );
  sky130_fd_sc_hd__o221ai_1 U4119 ( .A1(pcpi_rs1[2]), .A2(n2876), .B1(
        pcpi_rs1[3]), .B2(n2859), .C1(n3191), .Y(n3190) );
  sky130_fd_sc_hd__nand3b_1 U4120 ( .A_N(n2873), .B(n3192), .C(n3193), .Y(
        n3191) );
  sky130_fd_sc_hd__o21ai_0 U4121 ( .A1(pcpi_rs1[0]), .A2(n2992), .B1(
        pcpi_rs1[1]), .Y(n3193) );
  sky130_fd_sc_hd__o21ai_0 U4122 ( .A1(n3148), .A2(n2992), .B1(n2933), .Y(
        n3192) );
  sky130_fd_sc_hd__nor2_1 U4123 ( .A(n2756), .B(pcpi_rs2[2]), .Y(n2873) );
  sky130_fd_sc_hd__clkinv_1 U4124 ( .A(pcpi_rs1[2]), .Y(n2756) );
  sky130_fd_sc_hd__nor2_1 U4125 ( .A(n2748), .B(pcpi_rs2[3]), .Y(n2856) );
  sky130_fd_sc_hd__clkinv_1 U4126 ( .A(pcpi_rs1[3]), .Y(n2748) );
  sky130_fd_sc_hd__nor2_1 U4127 ( .A(n2745), .B(pcpi_rs2[4]), .Y(n2851) );
  sky130_fd_sc_hd__clkinv_1 U4128 ( .A(pcpi_rs1[4]), .Y(n2745) );
  sky130_fd_sc_hd__nor2_1 U4129 ( .A(n2742), .B(pcpi_rs2[5]), .Y(n2846) );
  sky130_fd_sc_hd__nor2_1 U4130 ( .A(n2739), .B(pcpi_rs2[6]), .Y(n2841) );
  sky130_fd_sc_hd__nor2_1 U4131 ( .A(n2736), .B(pcpi_rs2[7]), .Y(n2836) );
  sky130_fd_sc_hd__nor2_1 U4132 ( .A(n2733), .B(pcpi_rs2[8]), .Y(n2831) );
  sky130_fd_sc_hd__nor2_1 U4133 ( .A(n2816), .B(pcpi_rs2[10]), .Y(n2980) );
  sky130_fd_sc_hd__nor2_1 U4134 ( .A(n2728), .B(pcpi_rs2[9]), .Y(n2822) );
  sky130_fd_sc_hd__nor2_1 U4135 ( .A(n2813), .B(pcpi_rs2[11]), .Y(n2975) );
  sky130_fd_sc_hd__nor2_1 U4136 ( .A(n2810), .B(pcpi_rs2[12]), .Y(n2970) );
  sky130_fd_sc_hd__nor2_1 U4137 ( .A(n2807), .B(pcpi_rs2[13]), .Y(n2965) );
  sky130_fd_sc_hd__nor2_1 U4138 ( .A(n2804), .B(pcpi_rs2[14]), .Y(n2960) );
  sky130_fd_sc_hd__nor2_1 U4139 ( .A(n2801), .B(pcpi_rs2[15]), .Y(n2955) );
  sky130_fd_sc_hd__nor2_1 U4140 ( .A(n2798), .B(pcpi_rs2[16]), .Y(n2950) );
  sky130_fd_sc_hd__nor2_1 U4141 ( .A(n2795), .B(pcpi_rs2[17]), .Y(n2945) );
  sky130_fd_sc_hd__nor2_1 U4142 ( .A(n2792), .B(pcpi_rs2[18]), .Y(n2940) );
  sky130_fd_sc_hd__nor2_1 U4143 ( .A(n2789), .B(pcpi_rs2[19]), .Y(n2935) );
  sky130_fd_sc_hd__nor2_1 U4144 ( .A(n2786), .B(pcpi_rs2[20]), .Y(n2924) );
  sky130_fd_sc_hd__nor2_1 U4145 ( .A(n2783), .B(pcpi_rs2[21]), .Y(n2919) );
  sky130_fd_sc_hd__nor2_1 U4146 ( .A(n2780), .B(pcpi_rs2[22]), .Y(n2914) );
  sky130_fd_sc_hd__nor2_1 U4147 ( .A(n2777), .B(pcpi_rs2[23]), .Y(n2909) );
  sky130_fd_sc_hd__nor2_1 U4148 ( .A(n2774), .B(pcpi_rs2[24]), .Y(n2904) );
  sky130_fd_sc_hd__nor2_1 U4149 ( .A(n2768), .B(pcpi_rs2[26]), .Y(n2894) );
  sky130_fd_sc_hd__nand3_1 U4150 ( .A(n2680), .B(n3194), .C(n3195), .Y(n3152)
         );
  sky130_fd_sc_hd__nand2_1 U4151 ( .A(n3143), .B(n2677), .Y(n2680) );
  sky130_fd_sc_hd__clkinv_1 U4152 ( .A(is_beq_bne_blt_bge_bltu_bgeu), .Y(n2677) );
  sky130_fd_sc_hd__clkinv_1 U4153 ( .A(n2529), .Y(n3143) );
  sky130_fd_sc_hd__clkinv_1 U4154 ( .A(n3196), .Y(N2072) );
  sky130_fd_sc_hd__o21ai_0 U4155 ( .A1(n3197), .A2(n1062), .B1(n3196), .Y(
        N2071) );
  sky130_fd_sc_hd__nand2_1 U4156 ( .A(n2533), .B(n1053), .Y(n3196) );
  sky130_fd_sc_hd__nor4b_1 U4157 ( .D_N(n3195), .A(n2640), .B(cpu_state[2]), 
        .C(cpu_state[3]), .Y(n2533) );
  sky130_fd_sc_hd__nor3_1 U4158 ( .A(n3198), .B(n2541), .C(n2666), .Y(n3197)
         );
  sky130_fd_sc_hd__a211oi_1 U4159 ( .A1(n2688), .A2(mem_do_prefetch), .B1(
        mem_do_wdata), .C1(n3199), .Y(n2666) );
  sky130_fd_sc_hd__clkinv_1 U4160 ( .A(n2687), .Y(n2541) );
  sky130_fd_sc_hd__o211ai_1 U4161 ( .A1(n3142), .A2(n2638), .B1(n2652), .C1(
        n2671), .Y(n2687) );
  sky130_fd_sc_hd__clkinv_1 U4162 ( .A(mem_do_rdata), .Y(n2652) );
  sky130_fd_sc_hd__a211oi_1 U4163 ( .A1(n3200), .A2(n3201), .B1(n2530), .C1(
        n3150), .Y(n3198) );
  sky130_fd_sc_hd__nand4_1 U4164 ( .A(cpu_state[2]), .B(n3195), .C(n3202), .D(
        n2640), .Y(n2530) );
  sky130_fd_sc_hd__o22ai_1 U4165 ( .A1(n1063), .A2(n2528), .B1(n2632), .B2(
        n2529), .Y(N2069) );
  sky130_fd_sc_hd__nand3_1 U4166 ( .A(n2639), .B(n3195), .C(cpu_state[3]), .Y(
        n2529) );
  sky130_fd_sc_hd__nor3_1 U4167 ( .A(cpu_state[6]), .B(cpu_state[7]), .C(n2612), .Y(n3195) );
  sky130_fd_sc_hd__nand2_1 U4168 ( .A(is_beq_bne_blt_bge_bltu_bgeu), .B(n1053), 
        .Y(n2632) );
  sky130_fd_sc_hd__clkinv_1 U4169 ( .A(n3139), .Y(N2068) );
  sky130_fd_sc_hd__nand3_1 U4170 ( .A(n2532), .B(n2638), .C(n3142), .Y(n3139)
         );
  sky130_fd_sc_hd__clkinv_1 U4171 ( .A(n2688), .Y(n3142) );
  sky130_fd_sc_hd__nand2_1 U4172 ( .A(n1055), .B(n3203), .Y(n2688) );
  sky130_fd_sc_hd__o22ai_1 U4173 ( .A1(n2693), .A2(n3204), .B1(n2657), .B2(
        n2619), .Y(n3203) );
  sky130_fd_sc_hd__clkinv_1 U4174 ( .A(mem_do_rinst), .Y(n2619) );
  sky130_fd_sc_hd__nand2_1 U4175 ( .A(mem_state[1]), .B(mem_state[0]), .Y(
        n2657) );
  sky130_fd_sc_hd__o31ai_1 U4176 ( .A1(mem_do_rdata), .A2(mem_do_wdata), .A3(
        mem_do_rinst), .B1(n2658), .Y(n3204) );
  sky130_fd_sc_hd__or2_0 U4177 ( .A(mem_state[0]), .B(mem_state[1]), .X(n2658)
         );
  sky130_fd_sc_hd__nand2_1 U4178 ( .A(mem_valid), .B(mem_ready), .Y(n2693) );
  sky130_fd_sc_hd__clkinv_1 U4179 ( .A(mem_do_prefetch), .Y(n2638) );
  sky130_fd_sc_hd__nand2b_1 U4180 ( .A_N(n2671), .B(n3199), .Y(n2532) );
  sky130_fd_sc_hd__nand4_1 U4181 ( .A(cpu_state[1]), .B(n3205), .C(n2675), .D(
        n2636), .Y(n3199) );
  sky130_fd_sc_hd__nor4b_1 U4182 ( .D_N(n3205), .A(n2675), .B(cpu_state[1]), 
        .C(cpu_state[6]), .Y(n2671) );
  sky130_fd_sc_hd__nor4b_1 U4183 ( .D_N(cpu_state[7]), .A(n2612), .B(n3194), 
        .C(n2542), .Y(N2064) );
  sky130_fd_sc_hd__nand2_1 U4184 ( .A(N31), .B(n2636), .Y(n2542) );
  sky130_fd_sc_hd__clkinv_1 U4185 ( .A(cpu_state[6]), .Y(n2636) );
  sky130_fd_sc_hd__and2_0 U4186 ( .A(N1217), .B(n1058), .X(N2044) );
  sky130_fd_sc_hd__and2_0 U4187 ( .A(N1216), .B(n1058), .X(N2043) );
  sky130_fd_sc_hd__and2_0 U4188 ( .A(N1215), .B(n1058), .X(N2042) );
  sky130_fd_sc_hd__and2_0 U4189 ( .A(N1214), .B(n1058), .X(N2041) );
  sky130_fd_sc_hd__and2_0 U4190 ( .A(N1213), .B(n1058), .X(N2040) );
  sky130_fd_sc_hd__and2_0 U4191 ( .A(N1212), .B(n1058), .X(N2039) );
  sky130_fd_sc_hd__and2_0 U4192 ( .A(N1211), .B(n1058), .X(N2038) );
  sky130_fd_sc_hd__and2_0 U4193 ( .A(N1210), .B(n1058), .X(N2037) );
  sky130_fd_sc_hd__and2_0 U4194 ( .A(N1209), .B(n1058), .X(N2036) );
  sky130_fd_sc_hd__and2_0 U4195 ( .A(N1208), .B(n1058), .X(N2035) );
  sky130_fd_sc_hd__and2_0 U4196 ( .A(N1207), .B(n1058), .X(N2034) );
  sky130_fd_sc_hd__and2_0 U4197 ( .A(N1206), .B(n1058), .X(N2033) );
  sky130_fd_sc_hd__and2_0 U4198 ( .A(N1205), .B(n1058), .X(N2032) );
  sky130_fd_sc_hd__and2_0 U4199 ( .A(N1204), .B(n1058), .X(N2031) );
  sky130_fd_sc_hd__and2_0 U4200 ( .A(N1203), .B(n1058), .X(N2030) );
  sky130_fd_sc_hd__and2_0 U4201 ( .A(N1202), .B(n1058), .X(N2029) );
  sky130_fd_sc_hd__and2_0 U4202 ( .A(N1201), .B(n1058), .X(N2028) );
  sky130_fd_sc_hd__and2_0 U4203 ( .A(N1200), .B(n1057), .X(N2027) );
  sky130_fd_sc_hd__and2_0 U4204 ( .A(N1199), .B(n1057), .X(N2026) );
  sky130_fd_sc_hd__and2_0 U4205 ( .A(N1198), .B(n1057), .X(N2025) );
  sky130_fd_sc_hd__and2_0 U4206 ( .A(N1197), .B(n1057), .X(N2024) );
  sky130_fd_sc_hd__and2_0 U4207 ( .A(N1196), .B(n1057), .X(N2023) );
  sky130_fd_sc_hd__and2_0 U4208 ( .A(N1195), .B(n1057), .X(N2022) );
  sky130_fd_sc_hd__and2_0 U4209 ( .A(N1194), .B(n1057), .X(N2021) );
  sky130_fd_sc_hd__and2_0 U4210 ( .A(N1193), .B(n1057), .X(N2020) );
  sky130_fd_sc_hd__nor2_1 U4211 ( .A(n2695), .B(n3206), .Y(N202) );
  sky130_fd_sc_hd__and2_0 U4212 ( .A(N1192), .B(n1057), .X(N2019) );
  sky130_fd_sc_hd__and2_0 U4213 ( .A(N1191), .B(n1057), .X(N2018) );
  sky130_fd_sc_hd__and2_0 U4214 ( .A(N1190), .B(n1057), .X(N2017) );
  sky130_fd_sc_hd__and2_0 U4215 ( .A(N1189), .B(n1057), .X(N2016) );
  sky130_fd_sc_hd__and2_0 U4216 ( .A(N1188), .B(n1057), .X(N2015) );
  sky130_fd_sc_hd__and2_0 U4217 ( .A(N1187), .B(n1057), .X(N2014) );
  sky130_fd_sc_hd__and2_0 U4218 ( .A(N1186), .B(n1057), .X(N2013) );
  sky130_fd_sc_hd__and2_0 U4219 ( .A(N1185), .B(n1057), .X(N2012) );
  sky130_fd_sc_hd__and2_0 U4220 ( .A(N1184), .B(n1057), .X(N2011) );
  sky130_fd_sc_hd__and2_0 U4221 ( .A(N1183), .B(n1056), .X(N2010) );
  sky130_fd_sc_hd__nor2_1 U4222 ( .A(n2697), .B(n3206), .Y(N201) );
  sky130_fd_sc_hd__and2_0 U4223 ( .A(N1182), .B(n1056), .X(N2009) );
  sky130_fd_sc_hd__and2_0 U4224 ( .A(N1181), .B(n1056), .X(N2008) );
  sky130_fd_sc_hd__and2_0 U4225 ( .A(N1180), .B(n1056), .X(N2007) );
  sky130_fd_sc_hd__and2_0 U4226 ( .A(N1179), .B(n1057), .X(N2006) );
  sky130_fd_sc_hd__and2_0 U4227 ( .A(N1178), .B(n1056), .X(N2005) );
  sky130_fd_sc_hd__and2_0 U4228 ( .A(N1177), .B(n1056), .X(N2004) );
  sky130_fd_sc_hd__and2_0 U4229 ( .A(N1176), .B(n1056), .X(N2003) );
  sky130_fd_sc_hd__and2_0 U4230 ( .A(N1175), .B(n1056), .X(N2002) );
  sky130_fd_sc_hd__and2_0 U4231 ( .A(N1174), .B(n1056), .X(N2001) );
  sky130_fd_sc_hd__and2_0 U4232 ( .A(N1173), .B(n1056), .X(N2000) );
  sky130_fd_sc_hd__nor2_1 U4233 ( .A(n3207), .B(n3206), .Y(N200) );
  sky130_fd_sc_hd__and2_0 U4234 ( .A(N1172), .B(n1056), .X(N1999) );
  sky130_fd_sc_hd__and2_0 U4235 ( .A(N1171), .B(n1056), .X(N1998) );
  sky130_fd_sc_hd__and2_0 U4236 ( .A(N1170), .B(n1056), .X(N1997) );
  sky130_fd_sc_hd__and2_0 U4237 ( .A(N1169), .B(n1056), .X(N1996) );
  sky130_fd_sc_hd__and2_0 U4238 ( .A(N1168), .B(N31), .X(N1995) );
  sky130_fd_sc_hd__and2_0 U4239 ( .A(N1167), .B(N31), .X(N1994) );
  sky130_fd_sc_hd__and2_0 U4240 ( .A(N1166), .B(n1056), .X(N1993) );
  sky130_fd_sc_hd__and2_0 U4241 ( .A(N1165), .B(N31), .X(N1992) );
  sky130_fd_sc_hd__and2_0 U4242 ( .A(N1164), .B(N31), .X(N1991) );
  sky130_fd_sc_hd__and2_0 U4243 ( .A(N1163), .B(n1056), .X(N1990) );
  sky130_fd_sc_hd__nor2_1 U4244 ( .A(n3208), .B(n3206), .Y(N199) );
  sky130_fd_sc_hd__and2_0 U4245 ( .A(N1162), .B(n1057), .X(N1989) );
  sky130_fd_sc_hd__and2_0 U4246 ( .A(N1161), .B(n1058), .X(N1988) );
  sky130_fd_sc_hd__and2_0 U4247 ( .A(N1160), .B(n1061), .X(N1987) );
  sky130_fd_sc_hd__and2_0 U4248 ( .A(N1159), .B(n1056), .X(N1986) );
  sky130_fd_sc_hd__and2_0 U4249 ( .A(N1158), .B(n1056), .X(N1985) );
  sky130_fd_sc_hd__and2_0 U4250 ( .A(N1157), .B(n1060), .X(N1984) );
  sky130_fd_sc_hd__and2_0 U4251 ( .A(N1156), .B(n1056), .X(N1983) );
  sky130_fd_sc_hd__and2_0 U4252 ( .A(N1155), .B(n1056), .X(N1982) );
  sky130_fd_sc_hd__and2_0 U4253 ( .A(N1154), .B(n1059), .X(N1981) );
  sky130_fd_sc_hd__o21ai_0 U4254 ( .A1(n3068), .A2(n2528), .B1(N31), .Y(N1980)
         );
  sky130_fd_sc_hd__nand3_1 U4255 ( .A(n3205), .B(n3113), .C(cpu_state[6]), .Y(
        n2528) );
  sky130_fd_sc_hd__nor2_1 U4256 ( .A(n3194), .B(cpu_state[7]), .Y(n3205) );
  sky130_fd_sc_hd__nand2_1 U4257 ( .A(n2639), .B(n3202), .Y(n3194) );
  sky130_fd_sc_hd__clkinv_1 U4258 ( .A(cpu_state[3]), .Y(n3202) );
  sky130_fd_sc_hd__clkinv_1 U4259 ( .A(n3153), .Y(n2639) );
  sky130_fd_sc_hd__nand2_1 U4260 ( .A(n2640), .B(n3209), .Y(n3153) );
  sky130_fd_sc_hd__nor2_1 U4261 ( .A(n2699), .B(n3206), .Y(N198) );
  sky130_fd_sc_hd__o21ai_0 U4262 ( .A1(decoder_trigger), .A2(n2544), .B1(n3210), .Y(N1979) );
  sky130_fd_sc_hd__a22oi_1 U4263 ( .A1(N1250), .A2(n2683), .B1(N1153), .B2(
        n3211), .Y(n3210) );
  sky130_fd_sc_hd__nand2_1 U4264 ( .A(n1055), .B(N1119), .Y(n2544) );
  sky130_fd_sc_hd__o21ai_0 U4265 ( .A1(decoder_trigger), .A2(n2545), .B1(n3212), .Y(N1978) );
  sky130_fd_sc_hd__a22oi_1 U4266 ( .A1(N1249), .A2(n2683), .B1(N1152), .B2(
        n3211), .Y(n3212) );
  sky130_fd_sc_hd__nand2_1 U4267 ( .A(n1055), .B(N1118), .Y(n2545) );
  sky130_fd_sc_hd__o21ai_0 U4268 ( .A1(decoder_trigger), .A2(n2546), .B1(n3213), .Y(N1977) );
  sky130_fd_sc_hd__a22oi_1 U4269 ( .A1(N1248), .A2(n2683), .B1(N1151), .B2(
        n3211), .Y(n3213) );
  sky130_fd_sc_hd__nand2_1 U4270 ( .A(n1055), .B(N1117), .Y(n2546) );
  sky130_fd_sc_hd__o21ai_0 U4271 ( .A1(decoder_trigger), .A2(n2547), .B1(n3214), .Y(N1976) );
  sky130_fd_sc_hd__a22oi_1 U4272 ( .A1(N1247), .A2(n2683), .B1(N1150), .B2(
        n3211), .Y(n3214) );
  sky130_fd_sc_hd__nand2_1 U4273 ( .A(n1055), .B(N1116), .Y(n2547) );
  sky130_fd_sc_hd__o21ai_0 U4274 ( .A1(decoder_trigger), .A2(n2548), .B1(n3215), .Y(N1975) );
  sky130_fd_sc_hd__a22oi_1 U4275 ( .A1(N1246), .A2(n2683), .B1(N1149), .B2(
        n3211), .Y(n3215) );
  sky130_fd_sc_hd__nand2_1 U4276 ( .A(n1055), .B(N1115), .Y(n2548) );
  sky130_fd_sc_hd__o21ai_0 U4277 ( .A1(decoder_trigger), .A2(n2549), .B1(n3216), .Y(N1974) );
  sky130_fd_sc_hd__a22oi_1 U4278 ( .A1(N1245), .A2(n2683), .B1(N1148), .B2(
        n3211), .Y(n3216) );
  sky130_fd_sc_hd__nand2_1 U4279 ( .A(n1055), .B(N1114), .Y(n2549) );
  sky130_fd_sc_hd__o21ai_0 U4280 ( .A1(decoder_trigger), .A2(n2550), .B1(n3217), .Y(N1973) );
  sky130_fd_sc_hd__a22oi_1 U4281 ( .A1(N1244), .A2(n2683), .B1(N1147), .B2(
        n3211), .Y(n3217) );
  sky130_fd_sc_hd__nand2_1 U4282 ( .A(n1055), .B(N1113), .Y(n2550) );
  sky130_fd_sc_hd__o21ai_0 U4283 ( .A1(decoder_trigger), .A2(n2551), .B1(n3218), .Y(N1972) );
  sky130_fd_sc_hd__a22oi_1 U4284 ( .A1(N1243), .A2(n2683), .B1(N1146), .B2(
        n3211), .Y(n3218) );
  sky130_fd_sc_hd__nand2_1 U4285 ( .A(n1055), .B(N1112), .Y(n2551) );
  sky130_fd_sc_hd__o21ai_0 U4286 ( .A1(decoder_trigger), .A2(n2552), .B1(n3219), .Y(N1971) );
  sky130_fd_sc_hd__a22oi_1 U4287 ( .A1(N1242), .A2(n2683), .B1(N1145), .B2(
        n3211), .Y(n3219) );
  sky130_fd_sc_hd__nand2_1 U4288 ( .A(n1055), .B(N1111), .Y(n2552) );
  sky130_fd_sc_hd__o21ai_0 U4289 ( .A1(decoder_trigger), .A2(n2553), .B1(n3220), .Y(N1970) );
  sky130_fd_sc_hd__a22oi_1 U4290 ( .A1(N1241), .A2(n2683), .B1(N1144), .B2(
        n3211), .Y(n3220) );
  sky130_fd_sc_hd__nand2_1 U4291 ( .A(n1055), .B(N1110), .Y(n2553) );
  sky130_fd_sc_hd__nor2_1 U4292 ( .A(n3221), .B(n3206), .Y(N197) );
  sky130_fd_sc_hd__o21ai_0 U4293 ( .A1(decoder_trigger), .A2(n2554), .B1(n3222), .Y(N1969) );
  sky130_fd_sc_hd__a22oi_1 U4294 ( .A1(N1240), .A2(n2683), .B1(N1143), .B2(
        n3211), .Y(n3222) );
  sky130_fd_sc_hd__nand2_1 U4295 ( .A(n1054), .B(N1109), .Y(n2554) );
  sky130_fd_sc_hd__o21ai_0 U4296 ( .A1(decoder_trigger), .A2(n2555), .B1(n3223), .Y(N1968) );
  sky130_fd_sc_hd__a22oi_1 U4297 ( .A1(N1239), .A2(n2683), .B1(N1142), .B2(
        n3211), .Y(n3223) );
  sky130_fd_sc_hd__nand2_1 U4298 ( .A(n1054), .B(N1108), .Y(n2555) );
  sky130_fd_sc_hd__o21ai_0 U4299 ( .A1(decoder_trigger), .A2(n2556), .B1(n3224), .Y(N1967) );
  sky130_fd_sc_hd__a22oi_1 U4300 ( .A1(N1238), .A2(n2683), .B1(N1141), .B2(
        n3211), .Y(n3224) );
  sky130_fd_sc_hd__nand2_1 U4301 ( .A(n1055), .B(N1107), .Y(n2556) );
  sky130_fd_sc_hd__o21ai_0 U4302 ( .A1(decoder_trigger), .A2(n2557), .B1(n3225), .Y(N1966) );
  sky130_fd_sc_hd__a22oi_1 U4303 ( .A1(N1237), .A2(n2683), .B1(N1140), .B2(
        n3211), .Y(n3225) );
  sky130_fd_sc_hd__nand2_1 U4304 ( .A(n1054), .B(N1106), .Y(n2557) );
  sky130_fd_sc_hd__o21ai_0 U4305 ( .A1(decoder_trigger), .A2(n2558), .B1(n3226), .Y(N1965) );
  sky130_fd_sc_hd__a22oi_1 U4306 ( .A1(N1236), .A2(n2683), .B1(N1139), .B2(
        n3211), .Y(n3226) );
  sky130_fd_sc_hd__nand2_1 U4307 ( .A(n1054), .B(N1105), .Y(n2558) );
  sky130_fd_sc_hd__o21ai_0 U4308 ( .A1(decoder_trigger), .A2(n2559), .B1(n3227), .Y(N1964) );
  sky130_fd_sc_hd__a22oi_1 U4309 ( .A1(N1235), .A2(n2683), .B1(N1138), .B2(
        n3211), .Y(n3227) );
  sky130_fd_sc_hd__nand2_1 U4310 ( .A(n1054), .B(N1104), .Y(n2559) );
  sky130_fd_sc_hd__o21ai_0 U4311 ( .A1(decoder_trigger), .A2(n2560), .B1(n3228), .Y(N1963) );
  sky130_fd_sc_hd__a22oi_1 U4312 ( .A1(N1234), .A2(n2683), .B1(N1137), .B2(
        n3211), .Y(n3228) );
  sky130_fd_sc_hd__nand2_1 U4313 ( .A(n1055), .B(N1103), .Y(n2560) );
  sky130_fd_sc_hd__o21ai_0 U4314 ( .A1(decoder_trigger), .A2(n2561), .B1(n3229), .Y(N1962) );
  sky130_fd_sc_hd__a22oi_1 U4315 ( .A1(N1233), .A2(n2683), .B1(N1136), .B2(
        n3211), .Y(n3229) );
  sky130_fd_sc_hd__nand2_1 U4316 ( .A(n1054), .B(N1102), .Y(n2561) );
  sky130_fd_sc_hd__o21ai_0 U4317 ( .A1(decoder_trigger), .A2(n2562), .B1(n3230), .Y(N1961) );
  sky130_fd_sc_hd__a22oi_1 U4318 ( .A1(N1232), .A2(n2683), .B1(N1135), .B2(
        n3211), .Y(n3230) );
  sky130_fd_sc_hd__nand2_1 U4319 ( .A(n1054), .B(N1101), .Y(n2562) );
  sky130_fd_sc_hd__o21ai_0 U4320 ( .A1(decoder_trigger), .A2(n2563), .B1(n3231), .Y(N1960) );
  sky130_fd_sc_hd__a22oi_1 U4321 ( .A1(N1231), .A2(n2683), .B1(N1134), .B2(
        n3211), .Y(n3231) );
  sky130_fd_sc_hd__nand2_1 U4322 ( .A(n1054), .B(N1100), .Y(n2563) );
  sky130_fd_sc_hd__nor2_1 U4323 ( .A(n3232), .B(n3206), .Y(N196) );
  sky130_fd_sc_hd__o21ai_0 U4324 ( .A1(decoder_trigger), .A2(n2564), .B1(n3233), .Y(N1959) );
  sky130_fd_sc_hd__a22oi_1 U4325 ( .A1(N1230), .A2(n2683), .B1(N1133), .B2(
        n3211), .Y(n3233) );
  sky130_fd_sc_hd__nand2_1 U4326 ( .A(n1055), .B(N1099), .Y(n2564) );
  sky130_fd_sc_hd__o21ai_0 U4327 ( .A1(decoder_trigger), .A2(n2565), .B1(n3234), .Y(N1958) );
  sky130_fd_sc_hd__a22oi_1 U4328 ( .A1(N1229), .A2(n2683), .B1(N1132), .B2(
        n3211), .Y(n3234) );
  sky130_fd_sc_hd__nand2_1 U4329 ( .A(n1054), .B(N1098), .Y(n2565) );
  sky130_fd_sc_hd__o21ai_0 U4330 ( .A1(decoder_trigger), .A2(n2566), .B1(n3235), .Y(N1957) );
  sky130_fd_sc_hd__a22oi_1 U4331 ( .A1(N1228), .A2(n2683), .B1(N1131), .B2(
        n3211), .Y(n3235) );
  sky130_fd_sc_hd__nand2_1 U4332 ( .A(n1054), .B(N1097), .Y(n2566) );
  sky130_fd_sc_hd__o21ai_0 U4333 ( .A1(decoder_trigger), .A2(n2567), .B1(n3236), .Y(N1956) );
  sky130_fd_sc_hd__a22oi_1 U4334 ( .A1(N1227), .A2(n2683), .B1(N1130), .B2(
        n3211), .Y(n3236) );
  sky130_fd_sc_hd__nand2_1 U4335 ( .A(n1054), .B(N1096), .Y(n2567) );
  sky130_fd_sc_hd__o21ai_0 U4336 ( .A1(decoder_trigger), .A2(n2568), .B1(n3237), .Y(N1955) );
  sky130_fd_sc_hd__a22oi_1 U4337 ( .A1(N1226), .A2(n2683), .B1(N1129), .B2(
        n3211), .Y(n3237) );
  sky130_fd_sc_hd__nand2_1 U4338 ( .A(n1054), .B(N1095), .Y(n2568) );
  sky130_fd_sc_hd__o21ai_0 U4339 ( .A1(decoder_trigger), .A2(n2569), .B1(n3238), .Y(N1954) );
  sky130_fd_sc_hd__a22oi_1 U4340 ( .A1(N1225), .A2(n2683), .B1(N1128), .B2(
        n3211), .Y(n3238) );
  sky130_fd_sc_hd__nand2_1 U4341 ( .A(n1053), .B(N1094), .Y(n2569) );
  sky130_fd_sc_hd__o21ai_0 U4342 ( .A1(decoder_trigger), .A2(n2570), .B1(n3239), .Y(N1953) );
  sky130_fd_sc_hd__a22oi_1 U4343 ( .A1(N1224), .A2(n2683), .B1(N1127), .B2(
        n3211), .Y(n3239) );
  sky130_fd_sc_hd__nand2_1 U4344 ( .A(n1053), .B(N1093), .Y(n2570) );
  sky130_fd_sc_hd__o21ai_0 U4345 ( .A1(decoder_trigger), .A2(n2571), .B1(n3240), .Y(N1952) );
  sky130_fd_sc_hd__a22oi_1 U4346 ( .A1(N1223), .A2(n2683), .B1(N1126), .B2(
        n3211), .Y(n3240) );
  sky130_fd_sc_hd__nand2_1 U4347 ( .A(n1054), .B(N1092), .Y(n2571) );
  sky130_fd_sc_hd__o21ai_0 U4348 ( .A1(decoder_trigger), .A2(n2572), .B1(n3241), .Y(N1951) );
  sky130_fd_sc_hd__a22oi_1 U4349 ( .A1(N1222), .A2(n2683), .B1(N1125), .B2(
        n3211), .Y(n3241) );
  sky130_fd_sc_hd__nand2_1 U4350 ( .A(n1054), .B(N1091), .Y(n2572) );
  sky130_fd_sc_hd__o21ai_0 U4351 ( .A1(decoder_trigger), .A2(n2573), .B1(n3242), .Y(N1950) );
  sky130_fd_sc_hd__a22oi_1 U4352 ( .A1(N1221), .A2(n2683), .B1(N1124), .B2(
        n3211), .Y(n3242) );
  sky130_fd_sc_hd__nand2_1 U4353 ( .A(n1053), .B(N1090), .Y(n2573) );
  sky130_fd_sc_hd__nor2_1 U4354 ( .A(n2701), .B(n3206), .Y(N195) );
  sky130_fd_sc_hd__o21ai_0 U4355 ( .A1(decoder_trigger), .A2(n2574), .B1(n3243), .Y(N1949) );
  sky130_fd_sc_hd__a22oi_1 U4356 ( .A1(N1220), .A2(n2683), .B1(N1123), .B2(
        n3211), .Y(n3243) );
  sky130_fd_sc_hd__nand2_1 U4357 ( .A(n1053), .B(N1089), .Y(n2574) );
  sky130_fd_sc_hd__o21ai_0 U4358 ( .A1(decoder_trigger), .A2(n2575), .B1(n3244), .Y(N1948) );
  sky130_fd_sc_hd__a22oi_1 U4359 ( .A1(N1219), .A2(n2683), .B1(N1122), .B2(
        n3211), .Y(n3244) );
  sky130_fd_sc_hd__nor2b_1 U4360 ( .B_N(n2635), .A(n1063), .Y(n3211) );
  sky130_fd_sc_hd__nor2_1 U4361 ( .A(n3068), .B(instr_jal), .Y(n2635) );
  sky130_fd_sc_hd__clkinv_1 U4362 ( .A(instr_jal), .Y(n3137) );
  sky130_fd_sc_hd__clkinv_1 U4363 ( .A(decoder_trigger), .Y(n3068) );
  sky130_fd_sc_hd__nand2_1 U4364 ( .A(N1088), .B(n1053), .Y(n2575) );
  sky130_fd_sc_hd__nor2_1 U4365 ( .A(n2703), .B(n3206), .Y(N194) );
  sky130_fd_sc_hd__clkinv_1 U4366 ( .A(mem_rdata[23]), .Y(n2703) );
  sky130_fd_sc_hd__nor2_1 U4367 ( .A(n2705), .B(n3206), .Y(N193) );
  sky130_fd_sc_hd__clkinv_1 U4368 ( .A(mem_rdata[22]), .Y(n2705) );
  sky130_fd_sc_hd__nor2_1 U4369 ( .A(n2707), .B(n3206), .Y(N192) );
  sky130_fd_sc_hd__clkinv_1 U4370 ( .A(mem_rdata[21]), .Y(n2707) );
  sky130_fd_sc_hd__nor2_1 U4371 ( .A(n2709), .B(n3206), .Y(N191) );
  sky130_fd_sc_hd__clkinv_1 U4372 ( .A(mem_rdata[20]), .Y(n2709) );
  sky130_fd_sc_hd__o2111ai_1 U4373 ( .A1(n3209), .A2(n2751), .B1(n3245), .C1(
        n3246), .D1(n3247), .Y(N1909) );
  sky130_fd_sc_hd__a221oi_1 U4374 ( .A1(mem_rdata_word[31]), .A2(n3248), .B1(
        count_instr[31]), .B2(n3249), .C1(n3250), .Y(n3247) );
  sky130_fd_sc_hd__a22o_1 U4375 ( .A1(count_cycle[31]), .A2(n3251), .B1(
        count_instr[63]), .B2(n3252), .X(n3250) );
  sky130_fd_sc_hd__a22oi_1 U4376 ( .A1(count_cycle[63]), .A2(n3253), .B1(N1514), .B2(cpu_state[3]), .Y(n3246) );
  sky130_fd_sc_hd__o2111ai_1 U4377 ( .A1(n3209), .A2(n2606), .B1(n3245), .C1(
        n3254), .D1(n3255), .Y(N1908) );
  sky130_fd_sc_hd__a221oi_1 U4378 ( .A1(mem_rdata_word[30]), .A2(n3248), .B1(
        count_instr[30]), .B2(n3249), .C1(n3256), .Y(n3255) );
  sky130_fd_sc_hd__a22o_1 U4379 ( .A1(count_cycle[30]), .A2(n3251), .B1(
        count_instr[62]), .B2(n3252), .X(n3256) );
  sky130_fd_sc_hd__a22oi_1 U4380 ( .A1(count_cycle[62]), .A2(n3253), .B1(N1513), .B2(cpu_state[3]), .Y(n3254) );
  sky130_fd_sc_hd__o2111ai_1 U4381 ( .A1(n3209), .A2(n2759), .B1(n3245), .C1(
        n3257), .D1(n3258), .Y(N1907) );
  sky130_fd_sc_hd__a221oi_1 U4382 ( .A1(mem_rdata_word[29]), .A2(n3248), .B1(
        count_instr[29]), .B2(n3249), .C1(n3259), .Y(n3258) );
  sky130_fd_sc_hd__a22o_1 U4383 ( .A1(count_cycle[29]), .A2(n3251), .B1(
        count_instr[61]), .B2(n3252), .X(n3259) );
  sky130_fd_sc_hd__a22oi_1 U4384 ( .A1(count_cycle[61]), .A2(n3253), .B1(N1512), .B2(cpu_state[3]), .Y(n3257) );
  sky130_fd_sc_hd__o2111ai_1 U4385 ( .A1(n3209), .A2(n2762), .B1(n3245), .C1(
        n3260), .D1(n3261), .Y(N1906) );
  sky130_fd_sc_hd__a221oi_1 U4386 ( .A1(mem_rdata_word[28]), .A2(n3248), .B1(
        count_instr[28]), .B2(n3249), .C1(n3262), .Y(n3261) );
  sky130_fd_sc_hd__a22o_1 U4387 ( .A1(count_cycle[28]), .A2(n3251), .B1(
        count_instr[60]), .B2(n3252), .X(n3262) );
  sky130_fd_sc_hd__a22oi_1 U4388 ( .A1(count_cycle[60]), .A2(n3253), .B1(N1511), .B2(cpu_state[3]), .Y(n3260) );
  sky130_fd_sc_hd__o2111ai_1 U4389 ( .A1(n3209), .A2(n2765), .B1(n3245), .C1(
        n3263), .D1(n3264), .Y(N1905) );
  sky130_fd_sc_hd__a221oi_1 U4390 ( .A1(mem_rdata_word[27]), .A2(n3248), .B1(
        count_instr[27]), .B2(n3249), .C1(n3265), .Y(n3264) );
  sky130_fd_sc_hd__a22o_1 U4391 ( .A1(count_cycle[27]), .A2(n3251), .B1(
        count_instr[59]), .B2(n3252), .X(n3265) );
  sky130_fd_sc_hd__a22oi_1 U4392 ( .A1(count_cycle[59]), .A2(n3253), .B1(N1510), .B2(cpu_state[3]), .Y(n3263) );
  sky130_fd_sc_hd__o2111ai_1 U4393 ( .A1(n3209), .A2(n2768), .B1(n3245), .C1(
        n3266), .D1(n3267), .Y(N1904) );
  sky130_fd_sc_hd__a221oi_1 U4394 ( .A1(mem_rdata_word[26]), .A2(n3248), .B1(
        count_instr[26]), .B2(n3249), .C1(n3268), .Y(n3267) );
  sky130_fd_sc_hd__a22o_1 U4395 ( .A1(count_cycle[26]), .A2(n3251), .B1(
        count_instr[58]), .B2(n3252), .X(n3268) );
  sky130_fd_sc_hd__a22oi_1 U4396 ( .A1(count_cycle[58]), .A2(n3253), .B1(N1509), .B2(cpu_state[3]), .Y(n3266) );
  sky130_fd_sc_hd__o2111ai_1 U4397 ( .A1(n3209), .A2(n2771), .B1(n3245), .C1(
        n3269), .D1(n3270), .Y(N1903) );
  sky130_fd_sc_hd__a221oi_1 U4398 ( .A1(mem_rdata_word[25]), .A2(n3248), .B1(
        count_instr[25]), .B2(n3249), .C1(n3271), .Y(n3270) );
  sky130_fd_sc_hd__a22o_1 U4399 ( .A1(count_cycle[25]), .A2(n3251), .B1(
        count_instr[57]), .B2(n3252), .X(n3271) );
  sky130_fd_sc_hd__a22oi_1 U4400 ( .A1(count_cycle[57]), .A2(n3253), .B1(N1508), .B2(cpu_state[3]), .Y(n3269) );
  sky130_fd_sc_hd__o2111ai_1 U4401 ( .A1(n3209), .A2(n2774), .B1(n3245), .C1(
        n3272), .D1(n3273), .Y(N1902) );
  sky130_fd_sc_hd__a221oi_1 U4402 ( .A1(mem_rdata_word[24]), .A2(n3248), .B1(
        count_instr[24]), .B2(n3249), .C1(n3274), .Y(n3273) );
  sky130_fd_sc_hd__a22o_1 U4403 ( .A1(count_cycle[24]), .A2(n3251), .B1(
        count_instr[56]), .B2(n3252), .X(n3274) );
  sky130_fd_sc_hd__a22oi_1 U4404 ( .A1(count_cycle[56]), .A2(n3253), .B1(N1507), .B2(cpu_state[3]), .Y(n3272) );
  sky130_fd_sc_hd__o2111ai_1 U4405 ( .A1(n3209), .A2(n2777), .B1(n3245), .C1(
        n3275), .D1(n3276), .Y(N1901) );
  sky130_fd_sc_hd__a221oi_1 U4406 ( .A1(mem_rdata_word[23]), .A2(n3248), .B1(
        count_instr[23]), .B2(n3249), .C1(n3277), .Y(n3276) );
  sky130_fd_sc_hd__a22o_1 U4407 ( .A1(count_cycle[23]), .A2(n3251), .B1(
        count_instr[55]), .B2(n3252), .X(n3277) );
  sky130_fd_sc_hd__a22oi_1 U4408 ( .A1(count_cycle[55]), .A2(n3253), .B1(N1506), .B2(cpu_state[3]), .Y(n3275) );
  sky130_fd_sc_hd__o2111ai_1 U4409 ( .A1(n3209), .A2(n2780), .B1(n3245), .C1(
        n3278), .D1(n3279), .Y(N1900) );
  sky130_fd_sc_hd__a221oi_1 U4410 ( .A1(mem_rdata_word[22]), .A2(n3248), .B1(
        count_instr[22]), .B2(n3249), .C1(n3280), .Y(n3279) );
  sky130_fd_sc_hd__a22o_1 U4411 ( .A1(count_cycle[22]), .A2(n3251), .B1(
        count_instr[54]), .B2(n3252), .X(n3280) );
  sky130_fd_sc_hd__a22oi_1 U4412 ( .A1(count_cycle[54]), .A2(n3253), .B1(N1505), .B2(cpu_state[3]), .Y(n3278) );
  sky130_fd_sc_hd__nor2_1 U4413 ( .A(n2711), .B(n3206), .Y(N190) );
  sky130_fd_sc_hd__clkinv_1 U4414 ( .A(mem_rdata[19]), .Y(n2711) );
  sky130_fd_sc_hd__o2111ai_1 U4415 ( .A1(n3209), .A2(n2783), .B1(n3245), .C1(
        n3281), .D1(n3282), .Y(N1899) );
  sky130_fd_sc_hd__a221oi_1 U4416 ( .A1(mem_rdata_word[21]), .A2(n3248), .B1(
        count_instr[21]), .B2(n3249), .C1(n3283), .Y(n3282) );
  sky130_fd_sc_hd__a22o_1 U4417 ( .A1(count_cycle[21]), .A2(n3251), .B1(
        count_instr[53]), .B2(n3252), .X(n3283) );
  sky130_fd_sc_hd__a22oi_1 U4418 ( .A1(count_cycle[53]), .A2(n3253), .B1(N1504), .B2(cpu_state[3]), .Y(n3281) );
  sky130_fd_sc_hd__o2111ai_1 U4419 ( .A1(n3209), .A2(n2786), .B1(n3245), .C1(
        n3284), .D1(n3285), .Y(N1898) );
  sky130_fd_sc_hd__a221oi_1 U4420 ( .A1(mem_rdata_word[20]), .A2(n3248), .B1(
        count_instr[20]), .B2(n3249), .C1(n3286), .Y(n3285) );
  sky130_fd_sc_hd__a22o_1 U4421 ( .A1(count_cycle[20]), .A2(n3251), .B1(
        count_instr[52]), .B2(n3252), .X(n3286) );
  sky130_fd_sc_hd__a22oi_1 U4422 ( .A1(count_cycle[52]), .A2(n3253), .B1(N1503), .B2(cpu_state[3]), .Y(n3284) );
  sky130_fd_sc_hd__o2111ai_1 U4423 ( .A1(n3209), .A2(n2789), .B1(n3245), .C1(
        n3287), .D1(n3288), .Y(N1897) );
  sky130_fd_sc_hd__a221oi_1 U4424 ( .A1(mem_rdata_word[19]), .A2(n3248), .B1(
        count_instr[19]), .B2(n3249), .C1(n3289), .Y(n3288) );
  sky130_fd_sc_hd__a22o_1 U4425 ( .A1(count_cycle[19]), .A2(n3251), .B1(
        count_instr[51]), .B2(n3252), .X(n3289) );
  sky130_fd_sc_hd__a22oi_1 U4426 ( .A1(count_cycle[51]), .A2(n3253), .B1(N1502), .B2(cpu_state[3]), .Y(n3287) );
  sky130_fd_sc_hd__o2111ai_1 U4427 ( .A1(n3209), .A2(n2792), .B1(n3245), .C1(
        n3290), .D1(n3291), .Y(N1896) );
  sky130_fd_sc_hd__a221oi_1 U4428 ( .A1(mem_rdata_word[18]), .A2(n3248), .B1(
        count_instr[18]), .B2(n3249), .C1(n3292), .Y(n3291) );
  sky130_fd_sc_hd__a22o_1 U4429 ( .A1(count_cycle[18]), .A2(n3251), .B1(
        count_instr[50]), .B2(n3252), .X(n3292) );
  sky130_fd_sc_hd__a22oi_1 U4430 ( .A1(count_cycle[50]), .A2(n3253), .B1(N1501), .B2(cpu_state[3]), .Y(n3290) );
  sky130_fd_sc_hd__o2111ai_1 U4431 ( .A1(n3209), .A2(n2795), .B1(n3245), .C1(
        n3293), .D1(n3294), .Y(N1895) );
  sky130_fd_sc_hd__a221oi_1 U4432 ( .A1(mem_rdata_word[17]), .A2(n3248), .B1(
        count_instr[17]), .B2(n3249), .C1(n3295), .Y(n3294) );
  sky130_fd_sc_hd__a22o_1 U4433 ( .A1(count_cycle[17]), .A2(n3251), .B1(
        count_instr[49]), .B2(n3252), .X(n3295) );
  sky130_fd_sc_hd__a22oi_1 U4434 ( .A1(count_cycle[49]), .A2(n3253), .B1(N1500), .B2(cpu_state[3]), .Y(n3293) );
  sky130_fd_sc_hd__o2111ai_1 U4435 ( .A1(n3209), .A2(n2798), .B1(n3245), .C1(
        n3296), .D1(n3297), .Y(N1894) );
  sky130_fd_sc_hd__a221oi_1 U4436 ( .A1(mem_rdata_word[16]), .A2(n3248), .B1(
        count_instr[16]), .B2(n3249), .C1(n3298), .Y(n3297) );
  sky130_fd_sc_hd__a22o_1 U4437 ( .A1(count_cycle[16]), .A2(n3251), .B1(
        count_instr[48]), .B2(n3252), .X(n3298) );
  sky130_fd_sc_hd__a22oi_1 U4438 ( .A1(count_cycle[48]), .A2(n3253), .B1(N1499), .B2(cpu_state[3]), .Y(n3296) );
  sky130_fd_sc_hd__o2111ai_1 U4439 ( .A1(n3209), .A2(n2801), .B1(n3245), .C1(
        n3299), .D1(n3300), .Y(N1893) );
  sky130_fd_sc_hd__a221oi_1 U4440 ( .A1(count_instr[47]), .A2(n3252), .B1(
        count_cycle[15]), .B2(n3251), .C1(n3301), .Y(n3300) );
  sky130_fd_sc_hd__a22o_1 U4441 ( .A1(mem_rdata_word[15]), .A2(n3248), .B1(
        count_instr[15]), .B2(n3249), .X(n3301) );
  sky130_fd_sc_hd__a22oi_1 U4442 ( .A1(count_cycle[47]), .A2(n3253), .B1(N1498), .B2(cpu_state[3]), .Y(n3299) );
  sky130_fd_sc_hd__a41oi_1 U4443 ( .A1(n2540), .A2(cpu_state[0]), .A3(
        latched_is_lh), .A4(mem_rdata_word[15]), .B1(n3302), .Y(n3245) );
  sky130_fd_sc_hd__nand4_1 U4444 ( .A(n3303), .B(n3304), .C(n3305), .D(n3306), 
        .Y(N1892) );
  sky130_fd_sc_hd__a21oi_1 U4445 ( .A1(mem_rdata_word[14]), .A2(n3307), .B1(
        n3302), .Y(n3306) );
  sky130_fd_sc_hd__a22oi_1 U4446 ( .A1(count_instr[14]), .A2(n3249), .B1(
        count_instr[46]), .B2(n3252), .Y(n3305) );
  sky130_fd_sc_hd__a22oi_1 U4447 ( .A1(count_cycle[14]), .A2(n3251), .B1(
        count_cycle[46]), .B2(n3253), .Y(n3304) );
  sky130_fd_sc_hd__a22oi_1 U4448 ( .A1(N1497), .A2(cpu_state[3]), .B1(
        pcpi_rs1[14]), .B2(cpu_state[2]), .Y(n3303) );
  sky130_fd_sc_hd__nand4_1 U4449 ( .A(n3308), .B(n3309), .C(n3310), .D(n3311), 
        .Y(N1891) );
  sky130_fd_sc_hd__a21oi_1 U4450 ( .A1(mem_rdata_word[13]), .A2(n3307), .B1(
        n3302), .Y(n3311) );
  sky130_fd_sc_hd__a22oi_1 U4451 ( .A1(count_instr[13]), .A2(n3249), .B1(
        count_instr[45]), .B2(n3252), .Y(n3310) );
  sky130_fd_sc_hd__a22oi_1 U4452 ( .A1(count_cycle[13]), .A2(n3251), .B1(
        count_cycle[45]), .B2(n3253), .Y(n3309) );
  sky130_fd_sc_hd__a22oi_1 U4453 ( .A1(N1496), .A2(cpu_state[3]), .B1(
        pcpi_rs1[13]), .B2(cpu_state[2]), .Y(n3308) );
  sky130_fd_sc_hd__nand4_1 U4454 ( .A(n3312), .B(n3313), .C(n3314), .D(n3315), 
        .Y(N1890) );
  sky130_fd_sc_hd__a21oi_1 U4455 ( .A1(mem_rdata_word[12]), .A2(n3307), .B1(
        n3302), .Y(n3315) );
  sky130_fd_sc_hd__a22oi_1 U4456 ( .A1(count_instr[12]), .A2(n3249), .B1(
        count_instr[44]), .B2(n3252), .Y(n3314) );
  sky130_fd_sc_hd__a22oi_1 U4457 ( .A1(count_cycle[12]), .A2(n3251), .B1(
        count_cycle[44]), .B2(n3253), .Y(n3313) );
  sky130_fd_sc_hd__a22oi_1 U4458 ( .A1(N1495), .A2(cpu_state[3]), .B1(
        pcpi_rs1[12]), .B2(cpu_state[2]), .Y(n3312) );
  sky130_fd_sc_hd__nor2_1 U4459 ( .A(n2713), .B(n3206), .Y(N189) );
  sky130_fd_sc_hd__clkinv_1 U4460 ( .A(mem_rdata[18]), .Y(n2713) );
  sky130_fd_sc_hd__nand4_1 U4461 ( .A(n3316), .B(n3317), .C(n3318), .D(n3319), 
        .Y(N1889) );
  sky130_fd_sc_hd__a21oi_1 U4462 ( .A1(mem_rdata_word[11]), .A2(n3307), .B1(
        n3302), .Y(n3319) );
  sky130_fd_sc_hd__a22oi_1 U4463 ( .A1(count_instr[11]), .A2(n3249), .B1(
        count_instr[43]), .B2(n3252), .Y(n3318) );
  sky130_fd_sc_hd__a22oi_1 U4464 ( .A1(count_cycle[11]), .A2(n3251), .B1(
        count_cycle[43]), .B2(n3253), .Y(n3317) );
  sky130_fd_sc_hd__a22oi_1 U4465 ( .A1(N1494), .A2(cpu_state[3]), .B1(
        pcpi_rs1[11]), .B2(cpu_state[2]), .Y(n3316) );
  sky130_fd_sc_hd__nand4_1 U4466 ( .A(n3320), .B(n3321), .C(n3322), .D(n3323), 
        .Y(N1888) );
  sky130_fd_sc_hd__a21oi_1 U4467 ( .A1(mem_rdata_word[10]), .A2(n3307), .B1(
        n3302), .Y(n3323) );
  sky130_fd_sc_hd__a22oi_1 U4468 ( .A1(count_instr[10]), .A2(n3249), .B1(
        count_instr[42]), .B2(n3252), .Y(n3322) );
  sky130_fd_sc_hd__a22oi_1 U4469 ( .A1(count_cycle[10]), .A2(n3251), .B1(
        count_cycle[42]), .B2(n3253), .Y(n3321) );
  sky130_fd_sc_hd__a22oi_1 U4470 ( .A1(N1493), .A2(cpu_state[3]), .B1(
        pcpi_rs1[10]), .B2(cpu_state[2]), .Y(n3320) );
  sky130_fd_sc_hd__nand4_1 U4471 ( .A(n3324), .B(n3325), .C(n3326), .D(n3327), 
        .Y(N1887) );
  sky130_fd_sc_hd__a21oi_1 U4472 ( .A1(mem_rdata_word[9]), .A2(n3307), .B1(
        n3302), .Y(n3327) );
  sky130_fd_sc_hd__a22oi_1 U4473 ( .A1(count_instr[9]), .A2(n3249), .B1(
        count_instr[41]), .B2(n3252), .Y(n3326) );
  sky130_fd_sc_hd__a22oi_1 U4474 ( .A1(count_cycle[9]), .A2(n3251), .B1(
        count_cycle[41]), .B2(n3253), .Y(n3325) );
  sky130_fd_sc_hd__a22oi_1 U4475 ( .A1(N1492), .A2(cpu_state[3]), .B1(
        pcpi_rs1[9]), .B2(cpu_state[2]), .Y(n3324) );
  sky130_fd_sc_hd__nand4_1 U4476 ( .A(n3328), .B(n3329), .C(n3330), .D(n3331), 
        .Y(N1886) );
  sky130_fd_sc_hd__a21oi_1 U4477 ( .A1(mem_rdata_word[8]), .A2(n3307), .B1(
        n3302), .Y(n3331) );
  sky130_fd_sc_hd__and4_1 U4478 ( .A(mem_rdata_word[7]), .B(cpu_state[0]), .C(
        n2536), .D(n2540), .X(n3302) );
  sky130_fd_sc_hd__clkinv_1 U4479 ( .A(latched_is_lh), .Y(n2536) );
  sky130_fd_sc_hd__a21o_1 U4480 ( .A1(cpu_state[0]), .A2(latched_is_lh), .B1(
        n3248), .X(n3307) );
  sky130_fd_sc_hd__nor2_1 U4481 ( .A(n2540), .B(n2675), .Y(n3248) );
  sky130_fd_sc_hd__clkinv_1 U4482 ( .A(cpu_state[0]), .Y(n2675) );
  sky130_fd_sc_hd__clkinv_1 U4483 ( .A(latched_is_lu), .Y(n2540) );
  sky130_fd_sc_hd__a22oi_1 U4484 ( .A1(count_instr[8]), .A2(n3249), .B1(
        count_instr[40]), .B2(n3252), .Y(n3330) );
  sky130_fd_sc_hd__a22oi_1 U4485 ( .A1(count_cycle[8]), .A2(n3251), .B1(
        count_cycle[40]), .B2(n3253), .Y(n3329) );
  sky130_fd_sc_hd__a22oi_1 U4486 ( .A1(N1491), .A2(cpu_state[3]), .B1(
        pcpi_rs1[8]), .B2(cpu_state[2]), .Y(n3328) );
  sky130_fd_sc_hd__nand3_1 U4487 ( .A(n3332), .B(n3333), .C(n3334), .Y(N1885)
         );
  sky130_fd_sc_hd__a222oi_1 U4488 ( .A1(pcpi_rs1[7]), .A2(cpu_state[2]), .B1(
        N1490), .B2(cpu_state[3]), .C1(mem_rdata_word[7]), .C2(cpu_state[0]), 
        .Y(n3334) );
  sky130_fd_sc_hd__a22oi_1 U4489 ( .A1(count_instr[7]), .A2(n3249), .B1(
        count_instr[39]), .B2(n3252), .Y(n3333) );
  sky130_fd_sc_hd__a22oi_1 U4490 ( .A1(count_cycle[7]), .A2(n3251), .B1(
        count_cycle[39]), .B2(n3253), .Y(n3332) );
  sky130_fd_sc_hd__nand3_1 U4491 ( .A(n3335), .B(n3336), .C(n3337), .Y(N1884)
         );
  sky130_fd_sc_hd__a222oi_1 U4492 ( .A1(pcpi_rs1[6]), .A2(cpu_state[2]), .B1(
        N1489), .B2(cpu_state[3]), .C1(mem_rdata_word[6]), .C2(cpu_state[0]), 
        .Y(n3337) );
  sky130_fd_sc_hd__a22oi_1 U4493 ( .A1(count_instr[6]), .A2(n3249), .B1(
        count_instr[38]), .B2(n3252), .Y(n3336) );
  sky130_fd_sc_hd__a22oi_1 U4494 ( .A1(count_cycle[6]), .A2(n3251), .B1(
        count_cycle[38]), .B2(n3253), .Y(n3335) );
  sky130_fd_sc_hd__nand3_1 U4495 ( .A(n3338), .B(n3339), .C(n3340), .Y(N1883)
         );
  sky130_fd_sc_hd__a222oi_1 U4496 ( .A1(pcpi_rs1[5]), .A2(cpu_state[2]), .B1(
        N1488), .B2(cpu_state[3]), .C1(mem_rdata_word[5]), .C2(cpu_state[0]), 
        .Y(n3340) );
  sky130_fd_sc_hd__a22oi_1 U4497 ( .A1(count_instr[5]), .A2(n3249), .B1(
        count_instr[37]), .B2(n3252), .Y(n3339) );
  sky130_fd_sc_hd__a22oi_1 U4498 ( .A1(count_cycle[5]), .A2(n3251), .B1(
        count_cycle[37]), .B2(n3253), .Y(n3338) );
  sky130_fd_sc_hd__nand3_1 U4499 ( .A(n3341), .B(n3342), .C(n3343), .Y(N1882)
         );
  sky130_fd_sc_hd__a222oi_1 U4500 ( .A1(pcpi_rs1[4]), .A2(cpu_state[2]), .B1(
        N1487), .B2(cpu_state[3]), .C1(mem_rdata_word[4]), .C2(cpu_state[0]), 
        .Y(n3343) );
  sky130_fd_sc_hd__a22oi_1 U4501 ( .A1(count_instr[4]), .A2(n3249), .B1(
        count_instr[36]), .B2(n3252), .Y(n3342) );
  sky130_fd_sc_hd__a22oi_1 U4502 ( .A1(count_cycle[4]), .A2(n3251), .B1(
        count_cycle[36]), .B2(n3253), .Y(n3341) );
  sky130_fd_sc_hd__nand3_1 U4503 ( .A(n3344), .B(n3345), .C(n3346), .Y(N1881)
         );
  sky130_fd_sc_hd__a222oi_1 U4504 ( .A1(pcpi_rs1[3]), .A2(cpu_state[2]), .B1(
        N1486), .B2(cpu_state[3]), .C1(mem_rdata_word[3]), .C2(cpu_state[0]), 
        .Y(n3346) );
  sky130_fd_sc_hd__a22oi_1 U4505 ( .A1(count_instr[3]), .A2(n3249), .B1(
        count_instr[35]), .B2(n3252), .Y(n3345) );
  sky130_fd_sc_hd__a22oi_1 U4506 ( .A1(count_cycle[3]), .A2(n3251), .B1(
        count_cycle[35]), .B2(n3253), .Y(n3344) );
  sky130_fd_sc_hd__nand3_1 U4507 ( .A(n3347), .B(n3348), .C(n3349), .Y(N1880)
         );
  sky130_fd_sc_hd__a222oi_1 U4508 ( .A1(pcpi_rs1[2]), .A2(cpu_state[2]), .B1(
        N1485), .B2(cpu_state[3]), .C1(mem_rdata_word[2]), .C2(cpu_state[0]), 
        .Y(n3349) );
  sky130_fd_sc_hd__a22oi_1 U4509 ( .A1(count_instr[2]), .A2(n3249), .B1(
        count_instr[34]), .B2(n3252), .Y(n3348) );
  sky130_fd_sc_hd__a22oi_1 U4510 ( .A1(count_cycle[2]), .A2(n3251), .B1(
        count_cycle[34]), .B2(n3253), .Y(n3347) );
  sky130_fd_sc_hd__nor2_1 U4511 ( .A(n2715), .B(n3206), .Y(N188) );
  sky130_fd_sc_hd__clkinv_1 U4512 ( .A(mem_rdata[17]), .Y(n2715) );
  sky130_fd_sc_hd__nand3_1 U4513 ( .A(n3350), .B(n3351), .C(n3352), .Y(N1879)
         );
  sky130_fd_sc_hd__a222oi_1 U4514 ( .A1(pcpi_rs1[1]), .A2(cpu_state[2]), .B1(
        N1484), .B2(cpu_state[3]), .C1(mem_rdata_word[1]), .C2(cpu_state[0]), 
        .Y(n3352) );
  sky130_fd_sc_hd__a22oi_1 U4515 ( .A1(count_instr[1]), .A2(n3249), .B1(
        count_instr[33]), .B2(n3252), .Y(n3351) );
  sky130_fd_sc_hd__a22oi_1 U4516 ( .A1(count_cycle[1]), .A2(n3251), .B1(
        count_cycle[33]), .B2(n3253), .Y(n3350) );
  sky130_fd_sc_hd__nand3_1 U4517 ( .A(n3353), .B(n3354), .C(n3355), .Y(N1878)
         );
  sky130_fd_sc_hd__a222oi_1 U4518 ( .A1(pcpi_rs1[0]), .A2(cpu_state[2]), .B1(
        N1483), .B2(cpu_state[3]), .C1(mem_rdata_word[0]), .C2(cpu_state[0]), 
        .Y(n3355) );
  sky130_fd_sc_hd__a22oi_1 U4519 ( .A1(count_instr[0]), .A2(n3249), .B1(
        count_instr[32]), .B2(n3252), .Y(n3354) );
  sky130_fd_sc_hd__and3_1 U4520 ( .A(n3138), .B(cpu_state[5]), .C(
        instr_rdinstr), .X(n3249) );
  sky130_fd_sc_hd__nor2_1 U4521 ( .A(instr_rdcycle), .B(instr_rdcycleh), .Y(
        n3138) );
  sky130_fd_sc_hd__a22oi_1 U4522 ( .A1(count_cycle[0]), .A2(n3251), .B1(
        count_cycle[32]), .B2(n3253), .Y(n3353) );
  sky130_fd_sc_hd__nor2b_1 U4523 ( .B_N(instr_rdcycle), .A(n2640), .Y(n3251)
         );
  sky130_fd_sc_hd__o221ai_1 U4524 ( .A1(n3356), .A2(n3357), .B1(n3358), .B2(
        n3359), .C1(n3360), .Y(N1877) );
  sky130_fd_sc_hd__a22oi_1 U4525 ( .A1(N813), .A2(n3361), .B1(N91), .B2(n3124), 
        .Y(n3360) );
  sky130_fd_sc_hd__clkinv_1 U4526 ( .A(reg_sh[4]), .Y(n3359) );
  sky130_fd_sc_hd__a21oi_1 U4527 ( .A1(reg_sh[3]), .A2(n3362), .B1(n3363), .Y(
        n3358) );
  sky130_fd_sc_hd__a221o_1 U4528 ( .A1(n3361), .A2(N814), .B1(n3124), .B2(N90), 
        .C1(n3364), .X(N1876) );
  sky130_fd_sc_hd__mux2_1 U4529 ( .A0(n3365), .A1(n3363), .S(reg_sh[3]), .X(
        n3364) );
  sky130_fd_sc_hd__nor2b_1 U4530 ( .B_N(reg_sh[2]), .A(n2604), .Y(n3363) );
  sky130_fd_sc_hd__a221o_1 U4531 ( .A1(n3361), .A2(N815), .B1(n3124), .B2(N89), 
        .C1(n3365), .X(N1875) );
  sky130_fd_sc_hd__o22ai_1 U4532 ( .A1(reg_sh[2]), .A2(n2604), .B1(n3356), 
        .B2(n3357), .Y(n3365) );
  sky130_fd_sc_hd__clkinv_1 U4533 ( .A(n3366), .Y(n3356) );
  sky130_fd_sc_hd__a221o_1 U4534 ( .A1(N1564), .A2(n3367), .B1(n2613), .B2(
        n3366), .C1(n3368), .X(N1874) );
  sky130_fd_sc_hd__a22o_1 U4535 ( .A1(n3124), .A2(N88), .B1(n3361), .B2(N816), 
        .X(n3368) );
  sky130_fd_sc_hd__a21o_1 U4536 ( .A1(n2613), .A2(N1563), .B1(n3362), .X(n3367) );
  sky130_fd_sc_hd__clkinv_1 U4537 ( .A(n3357), .Y(n2613) );
  sky130_fd_sc_hd__a221o_1 U4538 ( .A1(n3361), .A2(N817), .B1(n3124), .B2(N87), 
        .C1(n3369), .X(N1873) );
  sky130_fd_sc_hd__mux2i_1 U4539 ( .A0(n3357), .A1(n2604), .S(N1563), .Y(n3369) );
  sky130_fd_sc_hd__nor2_1 U4540 ( .A(n3121), .B(n2640), .Y(n3124) );
  sky130_fd_sc_hd__and3_1 U4541 ( .A(n3370), .B(n3121), .C(cpu_state[5]), .X(
        n3361) );
  sky130_fd_sc_hd__clkinv_1 U4542 ( .A(is_slli_srli_srai), .Y(n3121) );
  sky130_fd_sc_hd__a22o_1 U4543 ( .A1(decoded_imm[31]), .A2(n3371), .B1(N786), 
        .B2(n3372), .X(N1872) );
  sky130_fd_sc_hd__a22o_1 U4544 ( .A1(decoded_imm[30]), .A2(n3371), .B1(N787), 
        .B2(n3372), .X(N1871) );
  sky130_fd_sc_hd__a22o_1 U4545 ( .A1(decoded_imm[29]), .A2(n3371), .B1(N788), 
        .B2(n3372), .X(N1870) );
  sky130_fd_sc_hd__nor2b_1 U4546 ( .B_N(mem_rdata[16]), .A(n3206), .Y(N187) );
  sky130_fd_sc_hd__a22o_1 U4547 ( .A1(decoded_imm[28]), .A2(n3371), .B1(N789), 
        .B2(n3372), .X(N1869) );
  sky130_fd_sc_hd__a22o_1 U4548 ( .A1(decoded_imm[27]), .A2(n3371), .B1(N790), 
        .B2(n3372), .X(N1868) );
  sky130_fd_sc_hd__a22o_1 U4549 ( .A1(decoded_imm[26]), .A2(n3371), .B1(N791), 
        .B2(n3372), .X(N1867) );
  sky130_fd_sc_hd__a22o_1 U4550 ( .A1(decoded_imm[25]), .A2(n3371), .B1(N792), 
        .B2(n3372), .X(N1866) );
  sky130_fd_sc_hd__a22o_1 U4551 ( .A1(decoded_imm[24]), .A2(n3371), .B1(N793), 
        .B2(n3372), .X(N1865) );
  sky130_fd_sc_hd__a22o_1 U4552 ( .A1(decoded_imm[23]), .A2(n3371), .B1(N794), 
        .B2(n3372), .X(N1864) );
  sky130_fd_sc_hd__a22o_1 U4553 ( .A1(decoded_imm[22]), .A2(n3371), .B1(N795), 
        .B2(n3372), .X(N1863) );
  sky130_fd_sc_hd__a22o_1 U4554 ( .A1(decoded_imm[21]), .A2(n3371), .B1(N796), 
        .B2(n3372), .X(N1862) );
  sky130_fd_sc_hd__a22o_1 U4555 ( .A1(decoded_imm[20]), .A2(n3371), .B1(N797), 
        .B2(n3372), .X(N1861) );
  sky130_fd_sc_hd__a22o_1 U4556 ( .A1(decoded_imm[19]), .A2(n3371), .B1(N798), 
        .B2(n3372), .X(N1860) );
  sky130_fd_sc_hd__o22ai_1 U4557 ( .A1(n3373), .A2(n3374), .B1(n2695), .B2(
        n3375), .Y(N186) );
  sky130_fd_sc_hd__clkinv_1 U4558 ( .A(mem_rdata[31]), .Y(n2695) );
  sky130_fd_sc_hd__a22o_1 U4559 ( .A1(decoded_imm[18]), .A2(n3371), .B1(N799), 
        .B2(n3372), .X(N1859) );
  sky130_fd_sc_hd__a22o_1 U4560 ( .A1(decoded_imm[17]), .A2(n3371), .B1(N800), 
        .B2(n3372), .X(N1858) );
  sky130_fd_sc_hd__a22o_1 U4561 ( .A1(decoded_imm[16]), .A2(n3371), .B1(N801), 
        .B2(n3372), .X(N1857) );
  sky130_fd_sc_hd__a22o_1 U4562 ( .A1(decoded_imm[15]), .A2(n3371), .B1(N802), 
        .B2(n3372), .X(N1856) );
  sky130_fd_sc_hd__a22o_1 U4563 ( .A1(decoded_imm[14]), .A2(n3371), .B1(N803), 
        .B2(n3372), .X(N1855) );
  sky130_fd_sc_hd__a22o_1 U4564 ( .A1(decoded_imm[13]), .A2(n3371), .B1(N804), 
        .B2(n3372), .X(N1854) );
  sky130_fd_sc_hd__a22o_1 U4565 ( .A1(decoded_imm[12]), .A2(n3371), .B1(N805), 
        .B2(n3372), .X(N1853) );
  sky130_fd_sc_hd__a22o_1 U4566 ( .A1(decoded_imm[11]), .A2(n3371), .B1(N806), 
        .B2(n3372), .X(N1852) );
  sky130_fd_sc_hd__a22o_1 U4567 ( .A1(decoded_imm[10]), .A2(n3371), .B1(N807), 
        .B2(n3372), .X(N1851) );
  sky130_fd_sc_hd__a22o_1 U4568 ( .A1(decoded_imm[9]), .A2(n3371), .B1(N808), 
        .B2(n3372), .X(N1850) );
  sky130_fd_sc_hd__o22ai_1 U4569 ( .A1(n2717), .A2(n3374), .B1(n2697), .B2(
        n3375), .Y(N185) );
  sky130_fd_sc_hd__clkinv_1 U4570 ( .A(mem_rdata[30]), .Y(n2697) );
  sky130_fd_sc_hd__a22o_1 U4571 ( .A1(decoded_imm[8]), .A2(n3371), .B1(N809), 
        .B2(n3372), .X(N1849) );
  sky130_fd_sc_hd__a22o_1 U4572 ( .A1(decoded_imm[7]), .A2(n3371), .B1(N810), 
        .B2(n3372), .X(N1848) );
  sky130_fd_sc_hd__a22o_1 U4573 ( .A1(decoded_imm[6]), .A2(n3371), .B1(N811), 
        .B2(n3372), .X(N1847) );
  sky130_fd_sc_hd__a22o_1 U4574 ( .A1(decoded_imm[5]), .A2(n3371), .B1(N812), 
        .B2(n3372), .X(N1846) );
  sky130_fd_sc_hd__a22o_1 U4575 ( .A1(decoded_imm[4]), .A2(n3371), .B1(n3372), 
        .B2(N813), .X(N1845) );
  sky130_fd_sc_hd__a22o_1 U4576 ( .A1(decoded_imm[3]), .A2(n3371), .B1(n3372), 
        .B2(N814), .X(N1844) );
  sky130_fd_sc_hd__a22o_1 U4577 ( .A1(decoded_imm[2]), .A2(n3371), .B1(n3372), 
        .B2(N815), .X(N1843) );
  sky130_fd_sc_hd__a22o_1 U4578 ( .A1(decoded_imm[1]), .A2(n3371), .B1(n3372), 
        .B2(N816), .X(N1842) );
  sky130_fd_sc_hd__a22o_1 U4579 ( .A1(decoded_imm[0]), .A2(n3371), .B1(n3372), 
        .B2(N817), .X(N1841) );
  sky130_fd_sc_hd__nor2b_1 U4580 ( .B_N(n3370), .A(n3371), .Y(n3372) );
  sky130_fd_sc_hd__or4b_1 U4581 ( .A(N89), .B(N87), .C(N88), .D_N(n3376), .X(
        n3370) );
  sky130_fd_sc_hd__nor2_1 U4582 ( .A(N91), .B(N90), .Y(n3376) );
  sky130_fd_sc_hd__clkinv_1 U4583 ( .A(n3126), .Y(n3371) );
  sky130_fd_sc_hd__nor2_1 U4584 ( .A(is_lui_auipc_jal), .B(
        is_jalr_addi_slti_sltiu_xori_ori_andi), .Y(n3126) );
  sky130_fd_sc_hd__o22ai_1 U4585 ( .A1(n2719), .A2(n3374), .B1(n3207), .B2(
        n3375), .Y(N184) );
  sky130_fd_sc_hd__clkinv_1 U4586 ( .A(mem_rdata[29]), .Y(n3207) );
  sky130_fd_sc_hd__o2111ai_1 U4587 ( .A1(n3377), .A2(n2768), .B1(n3378), .C1(
        n3379), .D1(n3380), .Y(N1838) );
  sky130_fd_sc_hd__a222oi_1 U4588 ( .A1(reg_pc[30]), .A2(n2610), .B1(N753), 
        .B2(n2611), .C1(N1687), .C2(n2612), .Y(n3380) );
  sky130_fd_sc_hd__a22oi_1 U4589 ( .A1(pcpi_rs1[29]), .A2(n2617), .B1(n3381), 
        .B2(pcpi_rs1[31]), .Y(n3379) );
  sky130_fd_sc_hd__o2111ai_1 U4590 ( .A1(n3377), .A2(n2771), .B1(n3378), .C1(
        n3382), .D1(n3383), .Y(N1837) );
  sky130_fd_sc_hd__a222oi_1 U4591 ( .A1(reg_pc[29]), .A2(n2610), .B1(N754), 
        .B2(n2611), .C1(N1686), .C2(n2612), .Y(n3383) );
  sky130_fd_sc_hd__a22oi_1 U4592 ( .A1(pcpi_rs1[28]), .A2(n2617), .B1(n3381), 
        .B2(pcpi_rs1[30]), .Y(n3382) );
  sky130_fd_sc_hd__o2111ai_1 U4593 ( .A1(n3377), .A2(n2774), .B1(n3378), .C1(
        n3384), .D1(n3385), .Y(N1836) );
  sky130_fd_sc_hd__a222oi_1 U4594 ( .A1(reg_pc[28]), .A2(n2610), .B1(N755), 
        .B2(n2611), .C1(N1685), .C2(n2612), .Y(n3385) );
  sky130_fd_sc_hd__a22oi_1 U4595 ( .A1(n2617), .A2(pcpi_rs1[27]), .B1(n3381), 
        .B2(pcpi_rs1[29]), .Y(n3384) );
  sky130_fd_sc_hd__nand3_1 U4596 ( .A(pcpi_rs1[31]), .B(n2614), .C(n3362), .Y(
        n3378) );
  sky130_fd_sc_hd__clkinv_1 U4597 ( .A(n2616), .Y(n3377) );
  sky130_fd_sc_hd__nand2_1 U4598 ( .A(n3386), .B(n3387), .Y(N1835) );
  sky130_fd_sc_hd__a221oi_1 U4599 ( .A1(pcpi_rs1[23]), .A2(n2616), .B1(
        pcpi_rs1[26]), .B2(n2617), .C1(n3388), .Y(n3387) );
  sky130_fd_sc_hd__o22ai_1 U4600 ( .A1(n2751), .A2(n3389), .B1(n2762), .B2(
        n3390), .Y(n3388) );
  sky130_fd_sc_hd__clkinv_1 U4601 ( .A(pcpi_rs1[31]), .Y(n2751) );
  sky130_fd_sc_hd__a222oi_1 U4602 ( .A1(reg_pc[27]), .A2(n2610), .B1(N756), 
        .B2(n2611), .C1(N1684), .C2(n2612), .Y(n3386) );
  sky130_fd_sc_hd__nand2_1 U4603 ( .A(n3391), .B(n3392), .Y(N1834) );
  sky130_fd_sc_hd__a221oi_1 U4604 ( .A1(pcpi_rs1[22]), .A2(n2616), .B1(
        pcpi_rs1[25]), .B2(n2617), .C1(n3393), .Y(n3392) );
  sky130_fd_sc_hd__o22ai_1 U4605 ( .A1(n2606), .A2(n3389), .B1(n2765), .B2(
        n3390), .Y(n3393) );
  sky130_fd_sc_hd__clkinv_1 U4606 ( .A(pcpi_rs1[30]), .Y(n2606) );
  sky130_fd_sc_hd__a222oi_1 U4607 ( .A1(reg_pc[26]), .A2(n2610), .B1(N757), 
        .B2(n2611), .C1(N1683), .C2(n2612), .Y(n3391) );
  sky130_fd_sc_hd__nand2_1 U4608 ( .A(n3394), .B(n3395), .Y(N1833) );
  sky130_fd_sc_hd__a221oi_1 U4609 ( .A1(pcpi_rs1[21]), .A2(n2616), .B1(
        pcpi_rs1[24]), .B2(n2617), .C1(n3396), .Y(n3395) );
  sky130_fd_sc_hd__o22ai_1 U4610 ( .A1(n2759), .A2(n3389), .B1(n2768), .B2(
        n3390), .Y(n3396) );
  sky130_fd_sc_hd__clkinv_1 U4611 ( .A(pcpi_rs1[29]), .Y(n2759) );
  sky130_fd_sc_hd__a222oi_1 U4612 ( .A1(reg_pc[25]), .A2(n2610), .B1(N758), 
        .B2(n2611), .C1(N1682), .C2(n2612), .Y(n3394) );
  sky130_fd_sc_hd__nand2_1 U4613 ( .A(n3397), .B(n3398), .Y(N1832) );
  sky130_fd_sc_hd__a221oi_1 U4614 ( .A1(pcpi_rs1[20]), .A2(n2616), .B1(
        pcpi_rs1[23]), .B2(n2617), .C1(n3399), .Y(n3398) );
  sky130_fd_sc_hd__o22ai_1 U4615 ( .A1(n2762), .A2(n3389), .B1(n2771), .B2(
        n3390), .Y(n3399) );
  sky130_fd_sc_hd__clkinv_1 U4616 ( .A(pcpi_rs1[28]), .Y(n2762) );
  sky130_fd_sc_hd__a222oi_1 U4617 ( .A1(reg_pc[24]), .A2(n2610), .B1(N759), 
        .B2(n2611), .C1(N1681), .C2(n2612), .Y(n3397) );
  sky130_fd_sc_hd__nand2_1 U4618 ( .A(n3400), .B(n3401), .Y(N1831) );
  sky130_fd_sc_hd__a221oi_1 U4619 ( .A1(pcpi_rs1[19]), .A2(n2616), .B1(
        pcpi_rs1[22]), .B2(n2617), .C1(n3402), .Y(n3401) );
  sky130_fd_sc_hd__o22ai_1 U4620 ( .A1(n2765), .A2(n3389), .B1(n2774), .B2(
        n3390), .Y(n3402) );
  sky130_fd_sc_hd__clkinv_1 U4621 ( .A(pcpi_rs1[27]), .Y(n2765) );
  sky130_fd_sc_hd__a222oi_1 U4622 ( .A1(reg_pc[23]), .A2(n2610), .B1(N760), 
        .B2(n2611), .C1(N1680), .C2(n2612), .Y(n3400) );
  sky130_fd_sc_hd__nand2_1 U4623 ( .A(n3403), .B(n3404), .Y(N1830) );
  sky130_fd_sc_hd__a221oi_1 U4624 ( .A1(pcpi_rs1[18]), .A2(n2616), .B1(
        pcpi_rs1[21]), .B2(n2617), .C1(n3405), .Y(n3404) );
  sky130_fd_sc_hd__o22ai_1 U4625 ( .A1(n2768), .A2(n3389), .B1(n2777), .B2(
        n3390), .Y(n3405) );
  sky130_fd_sc_hd__clkinv_1 U4626 ( .A(pcpi_rs1[26]), .Y(n2768) );
  sky130_fd_sc_hd__a222oi_1 U4627 ( .A1(reg_pc[22]), .A2(n2610), .B1(N761), 
        .B2(n2611), .C1(N1679), .C2(n2612), .Y(n3403) );
  sky130_fd_sc_hd__o22ai_1 U4628 ( .A1(n2721), .A2(n3374), .B1(n3208), .B2(
        n3375), .Y(N183) );
  sky130_fd_sc_hd__clkinv_1 U4629 ( .A(mem_rdata[28]), .Y(n3208) );
  sky130_fd_sc_hd__nand2_1 U4630 ( .A(n3406), .B(n3407), .Y(N1829) );
  sky130_fd_sc_hd__a221oi_1 U4631 ( .A1(pcpi_rs1[17]), .A2(n2616), .B1(
        pcpi_rs1[20]), .B2(n2617), .C1(n3408), .Y(n3407) );
  sky130_fd_sc_hd__o22ai_1 U4632 ( .A1(n2771), .A2(n3389), .B1(n2780), .B2(
        n3390), .Y(n3408) );
  sky130_fd_sc_hd__clkinv_1 U4633 ( .A(pcpi_rs1[25]), .Y(n2771) );
  sky130_fd_sc_hd__a222oi_1 U4634 ( .A1(reg_pc[21]), .A2(n2610), .B1(N762), 
        .B2(n2611), .C1(N1678), .C2(n2612), .Y(n3406) );
  sky130_fd_sc_hd__nand2_1 U4635 ( .A(n3409), .B(n3410), .Y(N1828) );
  sky130_fd_sc_hd__a221oi_1 U4636 ( .A1(pcpi_rs1[16]), .A2(n2616), .B1(
        pcpi_rs1[19]), .B2(n2617), .C1(n3411), .Y(n3410) );
  sky130_fd_sc_hd__o22ai_1 U4637 ( .A1(n2774), .A2(n3389), .B1(n2783), .B2(
        n3390), .Y(n3411) );
  sky130_fd_sc_hd__clkinv_1 U4638 ( .A(pcpi_rs1[24]), .Y(n2774) );
  sky130_fd_sc_hd__a222oi_1 U4639 ( .A1(reg_pc[20]), .A2(n2610), .B1(N763), 
        .B2(n2611), .C1(N1677), .C2(n2612), .Y(n3409) );
  sky130_fd_sc_hd__nand2_1 U4640 ( .A(n3412), .B(n3413), .Y(N1827) );
  sky130_fd_sc_hd__a221oi_1 U4641 ( .A1(pcpi_rs1[15]), .A2(n2616), .B1(
        pcpi_rs1[18]), .B2(n2617), .C1(n3414), .Y(n3413) );
  sky130_fd_sc_hd__o22ai_1 U4642 ( .A1(n2777), .A2(n3389), .B1(n2786), .B2(
        n3390), .Y(n3414) );
  sky130_fd_sc_hd__clkinv_1 U4643 ( .A(pcpi_rs1[23]), .Y(n2777) );
  sky130_fd_sc_hd__a222oi_1 U4644 ( .A1(reg_pc[19]), .A2(n2610), .B1(N764), 
        .B2(n2611), .C1(N1676), .C2(n2612), .Y(n3412) );
  sky130_fd_sc_hd__nand2_1 U4645 ( .A(n3415), .B(n3416), .Y(N1826) );
  sky130_fd_sc_hd__a221oi_1 U4646 ( .A1(pcpi_rs1[14]), .A2(n2616), .B1(
        pcpi_rs1[17]), .B2(n2617), .C1(n3417), .Y(n3416) );
  sky130_fd_sc_hd__o22ai_1 U4647 ( .A1(n2780), .A2(n3389), .B1(n2789), .B2(
        n3390), .Y(n3417) );
  sky130_fd_sc_hd__clkinv_1 U4648 ( .A(pcpi_rs1[22]), .Y(n2780) );
  sky130_fd_sc_hd__a222oi_1 U4649 ( .A1(reg_pc[18]), .A2(n2610), .B1(N765), 
        .B2(n2611), .C1(N1675), .C2(n2612), .Y(n3415) );
  sky130_fd_sc_hd__nand2_1 U4650 ( .A(n3418), .B(n3419), .Y(N1825) );
  sky130_fd_sc_hd__a221oi_1 U4651 ( .A1(pcpi_rs1[13]), .A2(n2616), .B1(
        pcpi_rs1[16]), .B2(n2617), .C1(n3420), .Y(n3419) );
  sky130_fd_sc_hd__o22ai_1 U4652 ( .A1(n2783), .A2(n3389), .B1(n2792), .B2(
        n3390), .Y(n3420) );
  sky130_fd_sc_hd__clkinv_1 U4653 ( .A(pcpi_rs1[21]), .Y(n2783) );
  sky130_fd_sc_hd__a222oi_1 U4654 ( .A1(reg_pc[17]), .A2(n2610), .B1(N766), 
        .B2(n2611), .C1(N1674), .C2(n2612), .Y(n3418) );
  sky130_fd_sc_hd__nand2_1 U4655 ( .A(n3421), .B(n3422), .Y(N1824) );
  sky130_fd_sc_hd__a221oi_1 U4656 ( .A1(pcpi_rs1[12]), .A2(n2616), .B1(
        pcpi_rs1[15]), .B2(n2617), .C1(n3423), .Y(n3422) );
  sky130_fd_sc_hd__o22ai_1 U4657 ( .A1(n2786), .A2(n3389), .B1(n2795), .B2(
        n3390), .Y(n3423) );
  sky130_fd_sc_hd__clkinv_1 U4658 ( .A(pcpi_rs1[20]), .Y(n2786) );
  sky130_fd_sc_hd__a222oi_1 U4659 ( .A1(reg_pc[16]), .A2(n2610), .B1(N767), 
        .B2(n2611), .C1(N1673), .C2(n2612), .Y(n3421) );
  sky130_fd_sc_hd__nand2_1 U4660 ( .A(n3424), .B(n3425), .Y(N1823) );
  sky130_fd_sc_hd__a221oi_1 U4661 ( .A1(pcpi_rs1[11]), .A2(n2616), .B1(
        pcpi_rs1[14]), .B2(n2617), .C1(n3426), .Y(n3425) );
  sky130_fd_sc_hd__o22ai_1 U4662 ( .A1(n2789), .A2(n3389), .B1(n2798), .B2(
        n3390), .Y(n3426) );
  sky130_fd_sc_hd__clkinv_1 U4663 ( .A(pcpi_rs1[19]), .Y(n2789) );
  sky130_fd_sc_hd__a222oi_1 U4664 ( .A1(reg_pc[15]), .A2(n2610), .B1(N768), 
        .B2(n2611), .C1(N1672), .C2(n2612), .Y(n3424) );
  sky130_fd_sc_hd__nand2_1 U4665 ( .A(n3427), .B(n3428), .Y(N1822) );
  sky130_fd_sc_hd__a221oi_1 U4666 ( .A1(pcpi_rs1[10]), .A2(n2616), .B1(
        pcpi_rs1[13]), .B2(n2617), .C1(n3429), .Y(n3428) );
  sky130_fd_sc_hd__o22ai_1 U4667 ( .A1(n2792), .A2(n3389), .B1(n2801), .B2(
        n3390), .Y(n3429) );
  sky130_fd_sc_hd__clkinv_1 U4668 ( .A(pcpi_rs1[18]), .Y(n2792) );
  sky130_fd_sc_hd__a222oi_1 U4669 ( .A1(reg_pc[14]), .A2(n2610), .B1(N769), 
        .B2(n2611), .C1(N1671), .C2(n2612), .Y(n3427) );
  sky130_fd_sc_hd__nand2_1 U4670 ( .A(n3430), .B(n3431), .Y(N1821) );
  sky130_fd_sc_hd__a221oi_1 U4671 ( .A1(pcpi_rs1[9]), .A2(n2616), .B1(
        pcpi_rs1[12]), .B2(n2617), .C1(n3432), .Y(n3431) );
  sky130_fd_sc_hd__o22ai_1 U4672 ( .A1(n2795), .A2(n3389), .B1(n2804), .B2(
        n3390), .Y(n3432) );
  sky130_fd_sc_hd__clkinv_1 U4673 ( .A(pcpi_rs1[17]), .Y(n2795) );
  sky130_fd_sc_hd__a222oi_1 U4674 ( .A1(reg_pc[13]), .A2(n2610), .B1(N770), 
        .B2(n2611), .C1(N1670), .C2(n2612), .Y(n3430) );
  sky130_fd_sc_hd__nand2_1 U4675 ( .A(n3433), .B(n3434), .Y(N1820) );
  sky130_fd_sc_hd__a221oi_1 U4676 ( .A1(pcpi_rs1[8]), .A2(n2616), .B1(
        pcpi_rs1[11]), .B2(n2617), .C1(n3435), .Y(n3434) );
  sky130_fd_sc_hd__o22ai_1 U4677 ( .A1(n2798), .A2(n3389), .B1(n2807), .B2(
        n3390), .Y(n3435) );
  sky130_fd_sc_hd__clkinv_1 U4678 ( .A(pcpi_rs1[16]), .Y(n2798) );
  sky130_fd_sc_hd__a222oi_1 U4679 ( .A1(reg_pc[12]), .A2(n2610), .B1(N771), 
        .B2(n2611), .C1(N1669), .C2(n2612), .Y(n3433) );
  sky130_fd_sc_hd__o22ai_1 U4680 ( .A1(n2723), .A2(n3374), .B1(n2699), .B2(
        n3375), .Y(N182) );
  sky130_fd_sc_hd__clkinv_1 U4681 ( .A(mem_rdata[27]), .Y(n2699) );
  sky130_fd_sc_hd__nand2_1 U4682 ( .A(n3436), .B(n3437), .Y(N1819) );
  sky130_fd_sc_hd__a221oi_1 U4683 ( .A1(pcpi_rs1[7]), .A2(n2616), .B1(
        pcpi_rs1[10]), .B2(n2617), .C1(n3438), .Y(n3437) );
  sky130_fd_sc_hd__o22ai_1 U4684 ( .A1(n2801), .A2(n3389), .B1(n2810), .B2(
        n3390), .Y(n3438) );
  sky130_fd_sc_hd__clkinv_1 U4685 ( .A(pcpi_rs1[15]), .Y(n2801) );
  sky130_fd_sc_hd__a222oi_1 U4686 ( .A1(reg_pc[11]), .A2(n2610), .B1(N772), 
        .B2(n2611), .C1(N1668), .C2(n2612), .Y(n3436) );
  sky130_fd_sc_hd__nand2_1 U4687 ( .A(n3439), .B(n3440), .Y(N1818) );
  sky130_fd_sc_hd__a221oi_1 U4688 ( .A1(pcpi_rs1[6]), .A2(n2616), .B1(
        pcpi_rs1[9]), .B2(n2617), .C1(n3441), .Y(n3440) );
  sky130_fd_sc_hd__o22ai_1 U4689 ( .A1(n2804), .A2(n3389), .B1(n2813), .B2(
        n3390), .Y(n3441) );
  sky130_fd_sc_hd__clkinv_1 U4690 ( .A(pcpi_rs1[14]), .Y(n2804) );
  sky130_fd_sc_hd__a222oi_1 U4691 ( .A1(reg_pc[10]), .A2(n2610), .B1(N773), 
        .B2(n2611), .C1(N1667), .C2(n2612), .Y(n3439) );
  sky130_fd_sc_hd__nand2_1 U4692 ( .A(n3442), .B(n3443), .Y(N1817) );
  sky130_fd_sc_hd__a221oi_1 U4693 ( .A1(pcpi_rs1[5]), .A2(n2616), .B1(
        pcpi_rs1[8]), .B2(n2617), .C1(n3444), .Y(n3443) );
  sky130_fd_sc_hd__o22ai_1 U4694 ( .A1(n2807), .A2(n3389), .B1(n2816), .B2(
        n3390), .Y(n3444) );
  sky130_fd_sc_hd__clkinv_1 U4695 ( .A(pcpi_rs1[13]), .Y(n2807) );
  sky130_fd_sc_hd__a222oi_1 U4696 ( .A1(reg_pc[9]), .A2(n2610), .B1(N774), 
        .B2(n2611), .C1(N1666), .C2(n2612), .Y(n3442) );
  sky130_fd_sc_hd__nand2_1 U4697 ( .A(n3445), .B(n3446), .Y(N1816) );
  sky130_fd_sc_hd__a221oi_1 U4698 ( .A1(pcpi_rs1[4]), .A2(n2616), .B1(
        pcpi_rs1[7]), .B2(n2617), .C1(n3447), .Y(n3446) );
  sky130_fd_sc_hd__o22ai_1 U4699 ( .A1(n2810), .A2(n3389), .B1(n2728), .B2(
        n3390), .Y(n3447) );
  sky130_fd_sc_hd__clkinv_1 U4700 ( .A(pcpi_rs1[12]), .Y(n2810) );
  sky130_fd_sc_hd__a222oi_1 U4701 ( .A1(reg_pc[8]), .A2(n2610), .B1(N775), 
        .B2(n2611), .C1(N1665), .C2(n2612), .Y(n3445) );
  sky130_fd_sc_hd__nand2_1 U4702 ( .A(n3448), .B(n3449), .Y(N1815) );
  sky130_fd_sc_hd__a221oi_1 U4703 ( .A1(pcpi_rs1[3]), .A2(n2616), .B1(
        pcpi_rs1[6]), .B2(n2617), .C1(n3450), .Y(n3449) );
  sky130_fd_sc_hd__o22ai_1 U4704 ( .A1(n2813), .A2(n3389), .B1(n2733), .B2(
        n3390), .Y(n3450) );
  sky130_fd_sc_hd__clkinv_1 U4705 ( .A(pcpi_rs1[11]), .Y(n2813) );
  sky130_fd_sc_hd__a222oi_1 U4706 ( .A1(reg_pc[7]), .A2(n2610), .B1(N776), 
        .B2(n2611), .C1(N1664), .C2(n2612), .Y(n3448) );
  sky130_fd_sc_hd__nand2_1 U4707 ( .A(n3451), .B(n3452), .Y(N1814) );
  sky130_fd_sc_hd__a221oi_1 U4708 ( .A1(pcpi_rs1[2]), .A2(n2616), .B1(
        pcpi_rs1[5]), .B2(n2617), .C1(n3453), .Y(n3452) );
  sky130_fd_sc_hd__o22ai_1 U4709 ( .A1(n2816), .A2(n3389), .B1(n2736), .B2(
        n3390), .Y(n3453) );
  sky130_fd_sc_hd__clkinv_1 U4710 ( .A(pcpi_rs1[7]), .Y(n2736) );
  sky130_fd_sc_hd__clkinv_1 U4711 ( .A(pcpi_rs1[10]), .Y(n2816) );
  sky130_fd_sc_hd__a222oi_1 U4712 ( .A1(reg_pc[6]), .A2(n2610), .B1(N777), 
        .B2(n2611), .C1(N1663), .C2(n2612), .Y(n3451) );
  sky130_fd_sc_hd__nand2_1 U4713 ( .A(n3454), .B(n3455), .Y(N1813) );
  sky130_fd_sc_hd__a221oi_1 U4714 ( .A1(pcpi_rs1[1]), .A2(n2616), .B1(
        pcpi_rs1[4]), .B2(n2617), .C1(n3456), .Y(n3455) );
  sky130_fd_sc_hd__o22ai_1 U4715 ( .A1(n2728), .A2(n3389), .B1(n2739), .B2(
        n3390), .Y(n3456) );
  sky130_fd_sc_hd__clkinv_1 U4716 ( .A(pcpi_rs1[6]), .Y(n2739) );
  sky130_fd_sc_hd__clkinv_1 U4717 ( .A(pcpi_rs1[9]), .Y(n2728) );
  sky130_fd_sc_hd__a222oi_1 U4718 ( .A1(reg_pc[5]), .A2(n2610), .B1(N778), 
        .B2(n2611), .C1(N1662), .C2(n2612), .Y(n3454) );
  sky130_fd_sc_hd__nand2_1 U4719 ( .A(n3457), .B(n3458), .Y(N1812) );
  sky130_fd_sc_hd__a221oi_1 U4720 ( .A1(pcpi_rs1[0]), .A2(n2616), .B1(
        pcpi_rs1[3]), .B2(n2617), .C1(n3459), .Y(n3458) );
  sky130_fd_sc_hd__o22ai_1 U4721 ( .A1(n2733), .A2(n3389), .B1(n2742), .B2(
        n3390), .Y(n3459) );
  sky130_fd_sc_hd__clkinv_1 U4722 ( .A(n3381), .Y(n3390) );
  sky130_fd_sc_hd__clkinv_1 U4723 ( .A(pcpi_rs1[5]), .Y(n2742) );
  sky130_fd_sc_hd__clkinv_1 U4724 ( .A(n3460), .Y(n3389) );
  sky130_fd_sc_hd__clkinv_1 U4725 ( .A(pcpi_rs1[8]), .Y(n2733) );
  sky130_fd_sc_hd__nor2_1 U4726 ( .A(n2604), .B(n3201), .Y(n2616) );
  sky130_fd_sc_hd__a222oi_1 U4727 ( .A1(reg_pc[4]), .A2(n2610), .B1(N779), 
        .B2(n2611), .C1(N1661), .C2(n2612), .Y(n3457) );
  sky130_fd_sc_hd__nand2_1 U4728 ( .A(n3461), .B(n3462), .Y(N1811) );
  sky130_fd_sc_hd__a222oi_1 U4729 ( .A1(n3460), .A2(pcpi_rs1[7]), .B1(
        pcpi_rs1[2]), .B2(n2617), .C1(n3381), .C2(pcpi_rs1[4]), .Y(n3462) );
  sky130_fd_sc_hd__a222oi_1 U4730 ( .A1(reg_pc[3]), .A2(n2610), .B1(N780), 
        .B2(n2611), .C1(N1660), .C2(n2612), .Y(n3461) );
  sky130_fd_sc_hd__nand2_1 U4731 ( .A(n3463), .B(n3464), .Y(N1810) );
  sky130_fd_sc_hd__a222oi_1 U4732 ( .A1(n3460), .A2(pcpi_rs1[6]), .B1(
        pcpi_rs1[1]), .B2(n2617), .C1(n3381), .C2(pcpi_rs1[3]), .Y(n3464) );
  sky130_fd_sc_hd__a222oi_1 U4733 ( .A1(reg_pc[2]), .A2(n2610), .B1(N781), 
        .B2(n2611), .C1(N1659), .C2(n2612), .Y(n3463) );
  sky130_fd_sc_hd__o22ai_1 U4734 ( .A1(n2725), .A2(n3374), .B1(n3221), .B2(
        n3375), .Y(N181) );
  sky130_fd_sc_hd__clkinv_1 U4735 ( .A(mem_rdata[26]), .Y(n3221) );
  sky130_fd_sc_hd__nand2_1 U4736 ( .A(n3465), .B(n3466), .Y(N1809) );
  sky130_fd_sc_hd__a222oi_1 U4737 ( .A1(n3460), .A2(pcpi_rs1[5]), .B1(
        pcpi_rs1[0]), .B2(n2617), .C1(n3381), .C2(pcpi_rs1[2]), .Y(n3466) );
  sky130_fd_sc_hd__a222oi_1 U4738 ( .A1(reg_pc[1]), .A2(n2610), .B1(N782), 
        .B2(n2611), .C1(N1658), .C2(n2612), .Y(n3465) );
  sky130_fd_sc_hd__nand2_1 U4739 ( .A(n3467), .B(n3468), .Y(N1808) );
  sky130_fd_sc_hd__a222oi_1 U4740 ( .A1(N783), .A2(n2611), .B1(n3381), .B2(
        pcpi_rs1[1]), .C1(n3460), .C2(pcpi_rs1[4]), .Y(n3468) );
  sky130_fd_sc_hd__nor2_1 U4741 ( .A(n2604), .B(n3200), .Y(n3460) );
  sky130_fd_sc_hd__clkinv_1 U4742 ( .A(n3362), .Y(n2604) );
  sky130_fd_sc_hd__nor2_1 U4743 ( .A(n3209), .B(n3469), .Y(n3362) );
  sky130_fd_sc_hd__clkinv_1 U4744 ( .A(cpu_state[2]), .Y(n3209) );
  sky130_fd_sc_hd__nor3_1 U4745 ( .A(n3200), .B(n3150), .C(n3357), .Y(n3381)
         );
  sky130_fd_sc_hd__nand2_1 U4746 ( .A(n3469), .B(cpu_state[2]), .Y(n3357) );
  sky130_fd_sc_hd__clkinv_1 U4747 ( .A(n2615), .Y(n3150) );
  sky130_fd_sc_hd__nand2_1 U4748 ( .A(n3366), .B(n3469), .Y(n2615) );
  sky130_fd_sc_hd__nor3_1 U4749 ( .A(reg_sh[3]), .B(reg_sh[4]), .C(reg_sh[2]), 
        .Y(n3469) );
  sky130_fd_sc_hd__nor2_1 U4750 ( .A(N1564), .B(N1563), .Y(n3366) );
  sky130_fd_sc_hd__a21oi_1 U4751 ( .A1(n3470), .A2(n3201), .B1(n2614), .Y(
        n3200) );
  sky130_fd_sc_hd__o21ba_1 U4752 ( .A1(instr_srai), .A2(instr_sra), .B1_N(
        n2603), .X(n2614) );
  sky130_fd_sc_hd__nand2_1 U4753 ( .A(n3201), .B(n3471), .Y(n2603) );
  sky130_fd_sc_hd__nor2_1 U4754 ( .A(instr_slli), .B(instr_sll), .Y(n3201) );
  sky130_fd_sc_hd__clkinv_1 U4755 ( .A(n3471), .Y(n3470) );
  sky130_fd_sc_hd__nor2_1 U4756 ( .A(instr_srl), .B(instr_srli), .Y(n3471) );
  sky130_fd_sc_hd__o311a_1 U4757 ( .A1(n3472), .A2(N83), .A3(N82), .B1(n3125), 
        .C1(cpu_state[5]), .X(n2611) );
  sky130_fd_sc_hd__or3_1 U4758 ( .A(N86), .B(N85), .C(N84), .X(n3472) );
  sky130_fd_sc_hd__a22oi_1 U4759 ( .A1(N1657), .A2(n2612), .B1(reg_pc[0]), 
        .B2(n2610), .Y(n3467) );
  sky130_fd_sc_hd__clkinv_1 U4760 ( .A(is_lui_auipc_jal), .Y(n3125) );
  sky130_fd_sc_hd__clkinv_1 U4761 ( .A(n3113), .Y(n2612) );
  sky130_fd_sc_hd__nor2_1 U4762 ( .A(cpu_state[0]), .B(cpu_state[1]), .Y(n3113) );
  sky130_fd_sc_hd__o22ai_1 U4763 ( .A1(n2690), .A2(n3374), .B1(n3232), .B2(
        n3375), .Y(N180) );
  sky130_fd_sc_hd__clkinv_1 U4764 ( .A(mem_rdata[25]), .Y(n3232) );
  sky130_fd_sc_hd__and2_0 U4765 ( .A(decoded_rd[4]), .B(cpu_state[6]), .X(
        N1796) );
  sky130_fd_sc_hd__and2_0 U4766 ( .A(decoded_rd[3]), .B(cpu_state[6]), .X(
        N1795) );
  sky130_fd_sc_hd__and2_0 U4767 ( .A(decoded_rd[2]), .B(cpu_state[6]), .X(
        N1794) );
  sky130_fd_sc_hd__and2_0 U4768 ( .A(decoded_rd[1]), .B(cpu_state[6]), .X(
        N1793) );
  sky130_fd_sc_hd__and2_0 U4769 ( .A(decoded_rd[0]), .B(cpu_state[6]), .X(
        N1792) );
  sky130_fd_sc_hd__o22ai_1 U4770 ( .A1(n2692), .A2(n3374), .B1(n2701), .B2(
        n3375), .Y(N179) );
  sky130_fd_sc_hd__clkinv_1 U4771 ( .A(mem_rdata[24]), .Y(n2701) );
  sky130_fd_sc_hd__o221ai_1 U4772 ( .A1(n3373), .A2(n3473), .B1(n3474), .B2(
        n3475), .C1(n3476), .Y(N178) );
  sky130_fd_sc_hd__a22oi_1 U4773 ( .A1(n3477), .A2(mem_rdata[31]), .B1(
        mem_rdata[23]), .B2(n3478), .Y(n3476) );
  sky130_fd_sc_hd__clkinv_1 U4774 ( .A(mem_rdata[7]), .Y(n3475) );
  sky130_fd_sc_hd__clkinv_1 U4775 ( .A(mem_rdata[15]), .Y(n3373) );
  sky130_fd_sc_hd__o221ai_1 U4776 ( .A1(n2717), .A2(n3473), .B1(n3474), .B2(
        n3103), .C1(n3479), .Y(N177) );
  sky130_fd_sc_hd__a22oi_1 U4777 ( .A1(n3477), .A2(mem_rdata[30]), .B1(
        mem_rdata[22]), .B2(n3478), .Y(n3479) );
  sky130_fd_sc_hd__clkinv_1 U4778 ( .A(mem_rdata[6]), .Y(n3103) );
  sky130_fd_sc_hd__clkinv_1 U4779 ( .A(mem_rdata[14]), .Y(n2717) );
  sky130_fd_sc_hd__o221ai_1 U4780 ( .A1(n2719), .A2(n3473), .B1(n3474), .B2(
        n3105), .C1(n3480), .Y(N176) );
  sky130_fd_sc_hd__a22oi_1 U4781 ( .A1(n3477), .A2(mem_rdata[29]), .B1(
        mem_rdata[21]), .B2(n3478), .Y(n3480) );
  sky130_fd_sc_hd__clkinv_1 U4782 ( .A(mem_rdata[5]), .Y(n3105) );
  sky130_fd_sc_hd__clkinv_1 U4783 ( .A(mem_rdata[13]), .Y(n2719) );
  sky130_fd_sc_hd__o221ai_1 U4784 ( .A1(n2721), .A2(n3473), .B1(n3474), .B2(
        n3104), .C1(n3481), .Y(N175) );
  sky130_fd_sc_hd__a22oi_1 U4785 ( .A1(n3477), .A2(mem_rdata[28]), .B1(
        mem_rdata[20]), .B2(n3478), .Y(n3481) );
  sky130_fd_sc_hd__clkinv_1 U4786 ( .A(mem_rdata[4]), .Y(n3104) );
  sky130_fd_sc_hd__clkinv_1 U4787 ( .A(mem_rdata[12]), .Y(n2721) );
  sky130_fd_sc_hd__o221ai_1 U4788 ( .A1(n2723), .A2(n3473), .B1(n3474), .B2(
        n3482), .C1(n3483), .Y(N174) );
  sky130_fd_sc_hd__a22oi_1 U4789 ( .A1(n3477), .A2(mem_rdata[27]), .B1(
        mem_rdata[19]), .B2(n3478), .Y(n3483) );
  sky130_fd_sc_hd__clkinv_1 U4790 ( .A(mem_rdata[3]), .Y(n3482) );
  sky130_fd_sc_hd__clkinv_1 U4791 ( .A(mem_rdata[11]), .Y(n2723) );
  sky130_fd_sc_hd__o221ai_1 U4792 ( .A1(n2725), .A2(n3473), .B1(n3474), .B2(
        n3484), .C1(n3485), .Y(N173) );
  sky130_fd_sc_hd__a22oi_1 U4793 ( .A1(n3477), .A2(mem_rdata[26]), .B1(
        mem_rdata[18]), .B2(n3478), .Y(n3485) );
  sky130_fd_sc_hd__clkinv_1 U4794 ( .A(mem_rdata[2]), .Y(n3484) );
  sky130_fd_sc_hd__clkinv_1 U4795 ( .A(mem_rdata[10]), .Y(n2725) );
  sky130_fd_sc_hd__o221ai_1 U4796 ( .A1(n2690), .A2(n3473), .B1(n3474), .B2(
        n3107), .C1(n3486), .Y(N172) );
  sky130_fd_sc_hd__a22oi_1 U4797 ( .A1(n3477), .A2(mem_rdata[25]), .B1(
        mem_rdata[17]), .B2(n3478), .Y(n3486) );
  sky130_fd_sc_hd__clkinv_1 U4798 ( .A(mem_rdata[1]), .Y(n3107) );
  sky130_fd_sc_hd__clkinv_1 U4799 ( .A(mem_rdata[9]), .Y(n2690) );
  sky130_fd_sc_hd__o221ai_1 U4800 ( .A1(n2692), .A2(n3473), .B1(n3474), .B2(
        n3106), .C1(n3487), .Y(N171) );
  sky130_fd_sc_hd__a22oi_1 U4801 ( .A1(n3477), .A2(mem_rdata[24]), .B1(
        mem_rdata[16]), .B2(n3478), .Y(n3487) );
  sky130_fd_sc_hd__clkinv_1 U4802 ( .A(mem_rdata[0]), .Y(n3106) );
  sky130_fd_sc_hd__clkinv_1 U4803 ( .A(N167), .Y(n3474) );
  sky130_fd_sc_hd__clkinv_1 U4804 ( .A(mem_rdata[8]), .Y(n2692) );
  sky130_fd_sc_hd__nand3b_1 U4805 ( .A_N(n3477), .B(n3375), .C(n3206), .Y(N170) );
  sky130_fd_sc_hd__nor3_1 U4806 ( .A(n2985), .B(n2929), .C(n3488), .Y(n3477)
         );
  sky130_fd_sc_hd__or2_0 U4807 ( .A(n3478), .B(n3147), .X(N169) );
  sky130_fd_sc_hd__o31ai_1 U4808 ( .A1(n3488), .A2(pcpi_rs1[0]), .A3(n2929), 
        .B1(n3375), .Y(n3478) );
  sky130_fd_sc_hd__nand2_1 U4809 ( .A(n3489), .B(pcpi_rs1[1]), .Y(n3375) );
  sky130_fd_sc_hd__nand2_1 U4810 ( .A(n3374), .B(n3473), .Y(N168) );
  sky130_fd_sc_hd__nand3_1 U4811 ( .A(pcpi_rs1[0]), .B(n2929), .C(n3490), .Y(
        n3473) );
  sky130_fd_sc_hd__o21ai_0 U4812 ( .A1(n3148), .A2(n3488), .B1(n3374), .Y(N167) );
  sky130_fd_sc_hd__o21ai_0 U4813 ( .A1(n3147), .A2(n2929), .B1(n3149), .Y(
        n3374) );
  sky130_fd_sc_hd__clkinv_1 U4814 ( .A(n3491), .Y(n3149) );
  sky130_fd_sc_hd__nand2_1 U4815 ( .A(n2985), .B(n2929), .Y(n3148) );
  sky130_fd_sc_hd__clkinv_1 U4816 ( .A(pcpi_rs1[1]), .Y(n2929) );
  sky130_fd_sc_hd__clkinv_1 U4817 ( .A(pcpi_rs1[0]), .Y(n2985) );
  sky130_fd_sc_hd__o221ai_1 U4818 ( .A1(n2839), .A2(n3488), .B1(n2866), .B2(
        n3206), .C1(n3492), .Y(N166) );
  sky130_fd_sc_hd__nand2_1 U4819 ( .A(n3489), .B(pcpi_rs2[15]), .Y(n3492) );
  sky130_fd_sc_hd__clkinv_1 U4820 ( .A(pcpi_rs2[31]), .Y(n2866) );
  sky130_fd_sc_hd__o221ai_1 U4821 ( .A1(n2844), .A2(n3488), .B1(n2871), .B2(
        n3206), .C1(n3493), .Y(N165) );
  sky130_fd_sc_hd__nand2_1 U4822 ( .A(n3489), .B(pcpi_rs2[14]), .Y(n3493) );
  sky130_fd_sc_hd__clkinv_1 U4823 ( .A(pcpi_rs2[30]), .Y(n2871) );
  sky130_fd_sc_hd__o221ai_1 U4824 ( .A1(n2849), .A2(n3488), .B1(n2881), .B2(
        n3206), .C1(n3494), .Y(N164) );
  sky130_fd_sc_hd__nand2_1 U4825 ( .A(n3489), .B(pcpi_rs2[13]), .Y(n3494) );
  sky130_fd_sc_hd__clkinv_1 U4826 ( .A(pcpi_rs2[29]), .Y(n2881) );
  sky130_fd_sc_hd__o221ai_1 U4827 ( .A1(n2854), .A2(n3488), .B1(n2886), .B2(
        n3206), .C1(n3495), .Y(N163) );
  sky130_fd_sc_hd__nand2_1 U4828 ( .A(n3489), .B(pcpi_rs2[12]), .Y(n3495) );
  sky130_fd_sc_hd__clkinv_1 U4829 ( .A(pcpi_rs2[28]), .Y(n2886) );
  sky130_fd_sc_hd__o221ai_1 U4830 ( .A1(n2859), .A2(n3488), .B1(n2891), .B2(
        n3206), .C1(n3496), .Y(N162) );
  sky130_fd_sc_hd__nand2_1 U4831 ( .A(n3489), .B(pcpi_rs2[11]), .Y(n3496) );
  sky130_fd_sc_hd__clkinv_1 U4832 ( .A(pcpi_rs2[27]), .Y(n2891) );
  sky130_fd_sc_hd__o221ai_1 U4833 ( .A1(n2876), .A2(n3488), .B1(n2897), .B2(
        n3206), .C1(n3497), .Y(N161) );
  sky130_fd_sc_hd__nand2_1 U4834 ( .A(n3489), .B(pcpi_rs2[10]), .Y(n3497) );
  sky130_fd_sc_hd__clkinv_1 U4835 ( .A(pcpi_rs2[26]), .Y(n2897) );
  sky130_fd_sc_hd__o221ai_1 U4836 ( .A1(n2933), .A2(n3488), .B1(n2902), .B2(
        n3206), .C1(n3498), .Y(N160) );
  sky130_fd_sc_hd__nand2_1 U4837 ( .A(n3489), .B(pcpi_rs2[9]), .Y(n3498) );
  sky130_fd_sc_hd__clkinv_1 U4838 ( .A(pcpi_rs2[25]), .Y(n2902) );
  sky130_fd_sc_hd__o221ai_1 U4839 ( .A1(n2992), .A2(n3488), .B1(n2907), .B2(
        n3206), .C1(n3499), .Y(N159) );
  sky130_fd_sc_hd__nand2_1 U4840 ( .A(n3489), .B(pcpi_rs2[8]), .Y(n3499) );
  sky130_fd_sc_hd__clkinv_1 U4841 ( .A(pcpi_rs2[24]), .Y(n2907) );
  sky130_fd_sc_hd__o22ai_1 U4842 ( .A1(n2912), .A2(n3206), .B1(n3500), .B2(
        n2839), .Y(N158) );
  sky130_fd_sc_hd__clkinv_1 U4843 ( .A(pcpi_rs2[23]), .Y(n2912) );
  sky130_fd_sc_hd__o22ai_1 U4844 ( .A1(n2917), .A2(n3206), .B1(n3500), .B2(
        n2844), .Y(N157) );
  sky130_fd_sc_hd__clkinv_1 U4845 ( .A(pcpi_rs2[22]), .Y(n2917) );
  sky130_fd_sc_hd__o22ai_1 U4846 ( .A1(n2922), .A2(n3206), .B1(n3500), .B2(
        n2849), .Y(N156) );
  sky130_fd_sc_hd__clkinv_1 U4847 ( .A(pcpi_rs2[21]), .Y(n2922) );
  sky130_fd_sc_hd__o22ai_1 U4848 ( .A1(n2927), .A2(n3206), .B1(n3500), .B2(
        n2854), .Y(N155) );
  sky130_fd_sc_hd__clkinv_1 U4849 ( .A(pcpi_rs2[20]), .Y(n2927) );
  sky130_fd_sc_hd__o22ai_1 U4850 ( .A1(n2938), .A2(n3206), .B1(n3500), .B2(
        n2859), .Y(N154) );
  sky130_fd_sc_hd__clkinv_1 U4851 ( .A(pcpi_rs2[19]), .Y(n2938) );
  sky130_fd_sc_hd__o22ai_1 U4852 ( .A1(n2943), .A2(n3206), .B1(n3500), .B2(
        n2876), .Y(N153) );
  sky130_fd_sc_hd__clkinv_1 U4853 ( .A(pcpi_rs2[18]), .Y(n2943) );
  sky130_fd_sc_hd__o22ai_1 U4854 ( .A1(n2948), .A2(n3206), .B1(n3500), .B2(
        n2933), .Y(N152) );
  sky130_fd_sc_hd__clkinv_1 U4855 ( .A(pcpi_rs2[17]), .Y(n2948) );
  sky130_fd_sc_hd__o22ai_1 U4856 ( .A1(n2953), .A2(n3206), .B1(n3500), .B2(
        n2992), .Y(N151) );
  sky130_fd_sc_hd__nor2_1 U4857 ( .A(n3490), .B(n3489), .Y(n3500) );
  sky130_fd_sc_hd__clkinv_1 U4858 ( .A(n3488), .Y(n3490) );
  sky130_fd_sc_hd__clkinv_1 U4859 ( .A(pcpi_rs2[16]), .Y(n2953) );
  sky130_fd_sc_hd__o22ai_1 U4860 ( .A1(n3491), .A2(n2958), .B1(n2839), .B2(
        n3488), .Y(N150) );
  sky130_fd_sc_hd__clkinv_1 U4861 ( .A(pcpi_rs2[7]), .Y(n2839) );
  sky130_fd_sc_hd__clkinv_1 U4862 ( .A(pcpi_rs2[15]), .Y(n2958) );
  sky130_fd_sc_hd__o22ai_1 U4863 ( .A1(n3491), .A2(n2963), .B1(n2844), .B2(
        n3488), .Y(N149) );
  sky130_fd_sc_hd__clkinv_1 U4864 ( .A(pcpi_rs2[6]), .Y(n2844) );
  sky130_fd_sc_hd__clkinv_1 U4865 ( .A(pcpi_rs2[14]), .Y(n2963) );
  sky130_fd_sc_hd__o22ai_1 U4866 ( .A1(n3491), .A2(n2968), .B1(n2849), .B2(
        n3488), .Y(N148) );
  sky130_fd_sc_hd__clkinv_1 U4867 ( .A(pcpi_rs2[5]), .Y(n2849) );
  sky130_fd_sc_hd__clkinv_1 U4868 ( .A(pcpi_rs2[13]), .Y(n2968) );
  sky130_fd_sc_hd__o22ai_1 U4869 ( .A1(n3491), .A2(n2973), .B1(n2854), .B2(
        n3488), .Y(N147) );
  sky130_fd_sc_hd__clkinv_1 U4870 ( .A(pcpi_rs2[4]), .Y(n2854) );
  sky130_fd_sc_hd__clkinv_1 U4871 ( .A(pcpi_rs2[12]), .Y(n2973) );
  sky130_fd_sc_hd__o22ai_1 U4872 ( .A1(n3491), .A2(n2978), .B1(n2859), .B2(
        n3488), .Y(N146) );
  sky130_fd_sc_hd__clkinv_1 U4873 ( .A(pcpi_rs2[3]), .Y(n2859) );
  sky130_fd_sc_hd__clkinv_1 U4874 ( .A(pcpi_rs2[11]), .Y(n2978) );
  sky130_fd_sc_hd__o22ai_1 U4875 ( .A1(n3491), .A2(n2983), .B1(n2876), .B2(
        n3488), .Y(N145) );
  sky130_fd_sc_hd__clkinv_1 U4876 ( .A(pcpi_rs2[2]), .Y(n2876) );
  sky130_fd_sc_hd__clkinv_1 U4877 ( .A(pcpi_rs2[10]), .Y(n2983) );
  sky130_fd_sc_hd__o22ai_1 U4878 ( .A1(n3491), .A2(n2828), .B1(n2933), .B2(
        n3488), .Y(N144) );
  sky130_fd_sc_hd__clkinv_1 U4879 ( .A(pcpi_rs2[1]), .Y(n2933) );
  sky130_fd_sc_hd__clkinv_1 U4880 ( .A(pcpi_rs2[9]), .Y(n2828) );
  sky130_fd_sc_hd__o22ai_1 U4881 ( .A1(n3491), .A2(n2834), .B1(n2992), .B2(
        n3488), .Y(N143) );
  sky130_fd_sc_hd__clkinv_1 U4882 ( .A(pcpi_rs2[0]), .Y(n2992) );
  sky130_fd_sc_hd__clkinv_1 U4883 ( .A(pcpi_rs2[8]), .Y(n2834) );
  sky130_fd_sc_hd__nand2_1 U4884 ( .A(n3491), .B(n3488), .Y(N142) );
  sky130_fd_sc_hd__nand2_1 U4885 ( .A(mem_wordsize[1]), .B(n2596), .Y(n3488)
         );
  sky130_fd_sc_hd__nor2_1 U4886 ( .A(n3489), .B(n3147), .Y(n3491) );
  sky130_fd_sc_hd__clkinv_1 U4887 ( .A(n3206), .Y(n3147) );
  sky130_fd_sc_hd__nand2_1 U4888 ( .A(n2596), .B(n2661), .Y(n3206) );
  sky130_fd_sc_hd__clkinv_1 U4889 ( .A(mem_wordsize[1]), .Y(n2661) );
  sky130_fd_sc_hd__nor2_1 U4890 ( .A(n2596), .B(mem_wordsize[1]), .Y(n3489) );
  sky130_fd_sc_hd__clkinv_1 U4891 ( .A(mem_wordsize[0]), .Y(n2596) );
  sky130_fd_sc_hd__o21ai_0 U4892 ( .A1(n3501), .A2(n2750), .B1(n3502), .Y(
        N1119) );
  sky130_fd_sc_hd__a22oi_1 U4893 ( .A1(alu_out_q[31]), .A2(n3503), .B1(
        reg_out[31]), .B2(n3504), .Y(n3502) );
  sky130_fd_sc_hd__clkinv_1 U4894 ( .A(reg_next_pc[31]), .Y(n2750) );
  sky130_fd_sc_hd__o21ai_0 U4895 ( .A1(n3501), .A2(n2753), .B1(n3505), .Y(
        N1118) );
  sky130_fd_sc_hd__a22oi_1 U4896 ( .A1(alu_out_q[30]), .A2(n3503), .B1(
        reg_out[30]), .B2(n3504), .Y(n3505) );
  sky130_fd_sc_hd__clkinv_1 U4897 ( .A(reg_next_pc[30]), .Y(n2753) );
  sky130_fd_sc_hd__o21ai_0 U4898 ( .A1(n3501), .A2(n2758), .B1(n3506), .Y(
        N1117) );
  sky130_fd_sc_hd__a22oi_1 U4899 ( .A1(alu_out_q[29]), .A2(n3503), .B1(
        reg_out[29]), .B2(n3504), .Y(n3506) );
  sky130_fd_sc_hd__clkinv_1 U4900 ( .A(reg_next_pc[29]), .Y(n2758) );
  sky130_fd_sc_hd__o21ai_0 U4901 ( .A1(n3501), .A2(n2761), .B1(n3507), .Y(
        N1116) );
  sky130_fd_sc_hd__a22oi_1 U4902 ( .A1(alu_out_q[28]), .A2(n3503), .B1(
        reg_out[28]), .B2(n3504), .Y(n3507) );
  sky130_fd_sc_hd__clkinv_1 U4903 ( .A(reg_next_pc[28]), .Y(n2761) );
  sky130_fd_sc_hd__o21ai_0 U4904 ( .A1(n3501), .A2(n2764), .B1(n3508), .Y(
        N1115) );
  sky130_fd_sc_hd__a22oi_1 U4905 ( .A1(alu_out_q[27]), .A2(n3503), .B1(
        reg_out[27]), .B2(n3504), .Y(n3508) );
  sky130_fd_sc_hd__clkinv_1 U4906 ( .A(reg_next_pc[27]), .Y(n2764) );
  sky130_fd_sc_hd__o21ai_0 U4907 ( .A1(n3501), .A2(n2767), .B1(n3509), .Y(
        N1114) );
  sky130_fd_sc_hd__a22oi_1 U4908 ( .A1(alu_out_q[26]), .A2(n3503), .B1(
        reg_out[26]), .B2(n3504), .Y(n3509) );
  sky130_fd_sc_hd__clkinv_1 U4909 ( .A(reg_next_pc[26]), .Y(n2767) );
  sky130_fd_sc_hd__o21ai_0 U4910 ( .A1(n3501), .A2(n2770), .B1(n3510), .Y(
        N1113) );
  sky130_fd_sc_hd__a22oi_1 U4911 ( .A1(alu_out_q[25]), .A2(n3503), .B1(
        reg_out[25]), .B2(n3504), .Y(n3510) );
  sky130_fd_sc_hd__clkinv_1 U4912 ( .A(reg_next_pc[25]), .Y(n2770) );
  sky130_fd_sc_hd__o21ai_0 U4913 ( .A1(n3501), .A2(n2773), .B1(n3511), .Y(
        N1112) );
  sky130_fd_sc_hd__a22oi_1 U4914 ( .A1(alu_out_q[24]), .A2(n3503), .B1(
        reg_out[24]), .B2(n3504), .Y(n3511) );
  sky130_fd_sc_hd__clkinv_1 U4915 ( .A(reg_next_pc[24]), .Y(n2773) );
  sky130_fd_sc_hd__o21ai_0 U4916 ( .A1(n3501), .A2(n2776), .B1(n3512), .Y(
        N1111) );
  sky130_fd_sc_hd__a22oi_1 U4917 ( .A1(alu_out_q[23]), .A2(n3503), .B1(
        reg_out[23]), .B2(n3504), .Y(n3512) );
  sky130_fd_sc_hd__clkinv_1 U4918 ( .A(reg_next_pc[23]), .Y(n2776) );
  sky130_fd_sc_hd__o21ai_0 U4919 ( .A1(n3501), .A2(n2779), .B1(n3513), .Y(
        N1110) );
  sky130_fd_sc_hd__a22oi_1 U4920 ( .A1(alu_out_q[22]), .A2(n3503), .B1(
        reg_out[22]), .B2(n3504), .Y(n3513) );
  sky130_fd_sc_hd__clkinv_1 U4921 ( .A(reg_next_pc[22]), .Y(n2779) );
  sky130_fd_sc_hd__o21ai_0 U4922 ( .A1(n3501), .A2(n2782), .B1(n3514), .Y(
        N1109) );
  sky130_fd_sc_hd__a22oi_1 U4923 ( .A1(alu_out_q[21]), .A2(n3503), .B1(
        reg_out[21]), .B2(n3504), .Y(n3514) );
  sky130_fd_sc_hd__clkinv_1 U4924 ( .A(reg_next_pc[21]), .Y(n2782) );
  sky130_fd_sc_hd__o21ai_0 U4925 ( .A1(n3501), .A2(n2785), .B1(n3515), .Y(
        N1108) );
  sky130_fd_sc_hd__a22oi_1 U4926 ( .A1(alu_out_q[20]), .A2(n3503), .B1(
        reg_out[20]), .B2(n3504), .Y(n3515) );
  sky130_fd_sc_hd__clkinv_1 U4927 ( .A(reg_next_pc[20]), .Y(n2785) );
  sky130_fd_sc_hd__o21ai_0 U4928 ( .A1(n3501), .A2(n2788), .B1(n3516), .Y(
        N1107) );
  sky130_fd_sc_hd__a22oi_1 U4929 ( .A1(alu_out_q[19]), .A2(n3503), .B1(
        reg_out[19]), .B2(n3504), .Y(n3516) );
  sky130_fd_sc_hd__clkinv_1 U4930 ( .A(reg_next_pc[19]), .Y(n2788) );
  sky130_fd_sc_hd__o21ai_0 U4931 ( .A1(n3501), .A2(n2791), .B1(n3517), .Y(
        N1106) );
  sky130_fd_sc_hd__a22oi_1 U4932 ( .A1(alu_out_q[18]), .A2(n3503), .B1(
        reg_out[18]), .B2(n3504), .Y(n3517) );
  sky130_fd_sc_hd__clkinv_1 U4933 ( .A(reg_next_pc[18]), .Y(n2791) );
  sky130_fd_sc_hd__o21ai_0 U4934 ( .A1(n3501), .A2(n2794), .B1(n3518), .Y(
        N1105) );
  sky130_fd_sc_hd__a22oi_1 U4935 ( .A1(alu_out_q[17]), .A2(n3503), .B1(
        reg_out[17]), .B2(n3504), .Y(n3518) );
  sky130_fd_sc_hd__clkinv_1 U4936 ( .A(reg_next_pc[17]), .Y(n2794) );
  sky130_fd_sc_hd__o21ai_0 U4937 ( .A1(n3501), .A2(n2797), .B1(n3519), .Y(
        N1104) );
  sky130_fd_sc_hd__a22oi_1 U4938 ( .A1(alu_out_q[16]), .A2(n3503), .B1(
        reg_out[16]), .B2(n3504), .Y(n3519) );
  sky130_fd_sc_hd__clkinv_1 U4939 ( .A(reg_next_pc[16]), .Y(n2797) );
  sky130_fd_sc_hd__o21ai_0 U4940 ( .A1(n3501), .A2(n2800), .B1(n3520), .Y(
        N1103) );
  sky130_fd_sc_hd__a22oi_1 U4941 ( .A1(alu_out_q[15]), .A2(n3503), .B1(
        reg_out[15]), .B2(n3504), .Y(n3520) );
  sky130_fd_sc_hd__clkinv_1 U4942 ( .A(reg_next_pc[15]), .Y(n2800) );
  sky130_fd_sc_hd__o21ai_0 U4943 ( .A1(n3501), .A2(n2803), .B1(n3521), .Y(
        N1102) );
  sky130_fd_sc_hd__a22oi_1 U4944 ( .A1(alu_out_q[14]), .A2(n3503), .B1(
        reg_out[14]), .B2(n3504), .Y(n3521) );
  sky130_fd_sc_hd__clkinv_1 U4945 ( .A(reg_next_pc[14]), .Y(n2803) );
  sky130_fd_sc_hd__o21ai_0 U4946 ( .A1(n3501), .A2(n2806), .B1(n3522), .Y(
        N1101) );
  sky130_fd_sc_hd__a22oi_1 U4947 ( .A1(alu_out_q[13]), .A2(n3503), .B1(
        reg_out[13]), .B2(n3504), .Y(n3522) );
  sky130_fd_sc_hd__clkinv_1 U4948 ( .A(reg_next_pc[13]), .Y(n2806) );
  sky130_fd_sc_hd__o21ai_0 U4949 ( .A1(n3501), .A2(n2809), .B1(n3523), .Y(
        N1100) );
  sky130_fd_sc_hd__a22oi_1 U4950 ( .A1(alu_out_q[12]), .A2(n3503), .B1(
        reg_out[12]), .B2(n3504), .Y(n3523) );
  sky130_fd_sc_hd__clkinv_1 U4951 ( .A(reg_next_pc[12]), .Y(n2809) );
  sky130_fd_sc_hd__o21ai_0 U4952 ( .A1(n3501), .A2(n2812), .B1(n3524), .Y(
        N1099) );
  sky130_fd_sc_hd__a22oi_1 U4953 ( .A1(alu_out_q[11]), .A2(n3503), .B1(
        reg_out[11]), .B2(n3504), .Y(n3524) );
  sky130_fd_sc_hd__clkinv_1 U4954 ( .A(reg_next_pc[11]), .Y(n2812) );
  sky130_fd_sc_hd__o21ai_0 U4955 ( .A1(n3501), .A2(n2815), .B1(n3525), .Y(
        N1098) );
  sky130_fd_sc_hd__a22oi_1 U4956 ( .A1(alu_out_q[10]), .A2(n3503), .B1(
        reg_out[10]), .B2(n3504), .Y(n3525) );
  sky130_fd_sc_hd__clkinv_1 U4957 ( .A(reg_next_pc[10]), .Y(n2815) );
  sky130_fd_sc_hd__o21ai_0 U4958 ( .A1(n3501), .A2(n2726), .B1(n3526), .Y(
        N1097) );
  sky130_fd_sc_hd__a22oi_1 U4959 ( .A1(alu_out_q[9]), .A2(n3503), .B1(
        reg_out[9]), .B2(n3504), .Y(n3526) );
  sky130_fd_sc_hd__clkinv_1 U4960 ( .A(reg_next_pc[9]), .Y(n2726) );
  sky130_fd_sc_hd__o21ai_0 U4961 ( .A1(n3501), .A2(n2732), .B1(n3527), .Y(
        N1096) );
  sky130_fd_sc_hd__a22oi_1 U4962 ( .A1(alu_out_q[8]), .A2(n3503), .B1(
        reg_out[8]), .B2(n3504), .Y(n3527) );
  sky130_fd_sc_hd__clkinv_1 U4963 ( .A(reg_next_pc[8]), .Y(n2732) );
  sky130_fd_sc_hd__o21ai_0 U4964 ( .A1(n3501), .A2(n2735), .B1(n3528), .Y(
        N1095) );
  sky130_fd_sc_hd__a22oi_1 U4965 ( .A1(alu_out_q[7]), .A2(n3503), .B1(
        reg_out[7]), .B2(n3504), .Y(n3528) );
  sky130_fd_sc_hd__clkinv_1 U4966 ( .A(reg_next_pc[7]), .Y(n2735) );
  sky130_fd_sc_hd__o21ai_0 U4967 ( .A1(n3501), .A2(n2738), .B1(n3529), .Y(
        N1094) );
  sky130_fd_sc_hd__a22oi_1 U4968 ( .A1(alu_out_q[6]), .A2(n3503), .B1(
        reg_out[6]), .B2(n3504), .Y(n3529) );
  sky130_fd_sc_hd__clkinv_1 U4969 ( .A(reg_next_pc[6]), .Y(n2738) );
  sky130_fd_sc_hd__o21ai_0 U4970 ( .A1(n3501), .A2(n2741), .B1(n3530), .Y(
        N1093) );
  sky130_fd_sc_hd__a22oi_1 U4971 ( .A1(alu_out_q[5]), .A2(n3503), .B1(
        reg_out[5]), .B2(n3504), .Y(n3530) );
  sky130_fd_sc_hd__clkinv_1 U4972 ( .A(reg_next_pc[5]), .Y(n2741) );
  sky130_fd_sc_hd__o21ai_0 U4973 ( .A1(n3501), .A2(n2744), .B1(n3531), .Y(
        N1092) );
  sky130_fd_sc_hd__a22oi_1 U4974 ( .A1(alu_out_q[4]), .A2(n3503), .B1(
        reg_out[4]), .B2(n3504), .Y(n3531) );
  sky130_fd_sc_hd__clkinv_1 U4975 ( .A(reg_next_pc[4]), .Y(n2744) );
  sky130_fd_sc_hd__o21ai_0 U4976 ( .A1(n3501), .A2(n2747), .B1(n3532), .Y(
        N1091) );
  sky130_fd_sc_hd__a22oi_1 U4977 ( .A1(alu_out_q[3]), .A2(n3503), .B1(
        reg_out[3]), .B2(n3504), .Y(n3532) );
  sky130_fd_sc_hd__clkinv_1 U4978 ( .A(reg_next_pc[3]), .Y(n2747) );
  sky130_fd_sc_hd__o21ai_0 U4979 ( .A1(n3501), .A2(n2755), .B1(n3533), .Y(
        N1090) );
  sky130_fd_sc_hd__a22oi_1 U4980 ( .A1(alu_out_q[2]), .A2(n3503), .B1(
        reg_out[2]), .B2(n3504), .Y(n3533) );
  sky130_fd_sc_hd__clkinv_1 U4981 ( .A(reg_next_pc[2]), .Y(n2755) );
  sky130_fd_sc_hd__a221o_1 U4982 ( .A1(n3503), .A2(alu_out_q[1]), .B1(n3504), 
        .B2(reg_out[1]), .C1(n3534), .X(N1089) );
  sky130_fd_sc_hd__and2_0 U4983 ( .A(reg_next_pc[1]), .B(n2818), .X(n3534) );
  sky130_fd_sc_hd__nor2_1 U4984 ( .A(n2818), .B(latched_stalu), .Y(n3504) );
  sky130_fd_sc_hd__nor2_1 U4985 ( .A(n2678), .B(n2818), .Y(n3503) );
  sky130_fd_sc_hd__clkinv_1 U4986 ( .A(latched_stalu), .Y(n2678) );
  sky130_fd_sc_hd__nor2b_1 U4987 ( .B_N(reg_next_pc[0]), .A(n3501), .Y(N1088)
         );
  sky130_fd_sc_hd__clkinv_1 U4988 ( .A(n2818), .Y(n3501) );
  sky130_fd_sc_hd__nand2_1 U4989 ( .A(latched_store), .B(latched_branch), .Y(
        n2818) );
endmodule

