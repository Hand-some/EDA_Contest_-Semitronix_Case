# 平台统一插链模板（picorv32 衍生项目共用，只读）
set_scan_cell_mapping  sky130_fd_sc_hd__dfxtp_1  sky130_fd_sc_hd__sdfxtp_1
set_scan_signal  -type clock        -port clk      -off_state 0
set_scan_signal  -type scan_enable  -port test_se  -off_state 0  -usage all
set_scan_cfg  -chain_count 4  -mix_clocks false  -mix_edges false
# 性能计数器调试链（仅调试阶段使用）
add_scan_chain dbg_cycle_cnt -include_elements {count_cycle_reg*}
