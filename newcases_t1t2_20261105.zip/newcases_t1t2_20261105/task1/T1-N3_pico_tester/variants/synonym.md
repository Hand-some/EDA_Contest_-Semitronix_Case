# 插链任务说明书

## 任务目标

对 RISC-V 处理器核 `picorv32` 进行完整的扫描链插入。操作时，必须先在 Dofile 中**不加改动地引用**项目平台模板 `pico_platform.tcl`（禁止修改模板文件，亦不得复制后改写），随后依据本说明书的各项要求进行后续调整，以满足测试机（ATE）的接口限制。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/pre_scan.v` | 门级网表（pre-scan，top=`picorv32`） |
| `input/pico_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

- 单一时钟 `clk`，共有 1,610 个 `dfxtp_1`，不存在异步复位；设计中包含 44 个时钟门控单元（`SNPS_CLOCK_GATE_HIGH_*`）
- 程序计数器为 32 位寄存器组 `reg_pc_reg[31:0]`；周期计数器为 64 位 `count_cycle_reg[63:0]`

## 关于平台模板

模板已经完成 DFF→SFF 映射、时钟与扫描使能 `test_se` 的配置，以及全局 4 条链的设定。该模板系调试阶段整理而成，正式插链时**不得保留仅供调试使用的扫描结构**，请检查并将其撤销。

## 测试机约束

1. **PC 观测链**：调试 ATE 要求在扫描卸载时以“最低位最先移出”的次序获取程序计数器的值。因此，`reg_pc_reg` 的 32 位需要单独构成一条**顺序固定**的扫描链 `pc_chain`：位越低越接近扫描输出端，`reg_pc_reg[0]` 与扫描输出相邻，`reg_pc_reg[31]` 与扫描输入相邻。该链使用两个**新增的顶层端口** `si_pc`、`so_pc`，扫描使能为 `test_se`；为保障该链在与其他链拼接时的保持时间，链末端需要插入 terminal lockup latch。
2. **总链数**保持 4 条不变（包含 `pc_chain`）。
3. **ATE 采样边沿**：ATE 在扫描输入端以时钟上升沿驱动、在扫描输出端以时钟下降沿采样。若工具自动生成的扫描链首尾时序单元的触发沿与此要求不符，需由工具在顶层 `picorv32` 自动插入重定时寄存器（沿用工具默认的首尾边沿约定）。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收

- DRC 为 0，全部 1,610 个 FF 上链