# 插链任务说明书

## 任务目标

对 RISC-V 处理器核 `picorv32` 执行完整 Scan Insertion。Dofile 中必须**原样引用**项目平台模板 `pico_platform.tcl`（不得修改模板文件，也不得拷贝改写），随后在该模板基础上按本说明书进行调整，以满足测试机（ATE）的接口约束。

## 输入文件

- `input/lib/sky130.lib` —— sky130 HD 标准单元库
- `input/netlist/pre_scan.v` —— 门级网表（pre-scan，top=`picorv32`）
- `input/pico_platform.tcl` —— 平台统一插链模板（只读）

## 设计信息

- 单时钟 `clk`，1,610 个 `dfxtp_1`，无异步复位；设计中存在 44 个时钟门控单元（`SNPS_CLOCK_GATE_HIGH_*`）
- 程序计数器为 32 位寄存器组 `reg_pc_reg[31:0]`；周期计数器为 64 位 `count_cycle_reg[63:0]`

## 关于平台模板

模板已完成 DFF→SFF 映射、时钟与扫描使能 `test_se`、全局 4 条链。模板系调试阶段整理而成，正式插链**不得保留仅用于调试的扫描结构**，请检查并撤销。

## 测试机约束

1. **PC 观测链**：调试 ATE 要求在扫描卸载时按“最低位最先移出”的顺序取得程序计数器的值。因此，`reg_pc_reg` 的 32 位必须单独构成一条**固定顺序**的扫描链 `pc_chain`：越低位越靠近扫描输出，`reg_pc_reg[0]` 紧邻扫描输出，`reg_pc_reg[31]` 紧邻扫描输入。该链使用两个**新增的顶层端口** `si_pc`、`so_pc`，扫描使能为 `test_se`；为保证该链与其他链拼接时的保持时间，链末端插入 terminal lockup latch。
2. **总链数**仍为 4 条（含 `pc_chain`）。
3. **ATE 采样边沿**：ATE 在扫描输入端以时钟上升沿驱动、在扫描输出端以时钟下降沿采样。工具自动生成的扫描链若首尾时序单元的触发沿与此不匹配，需由工具在顶层 `picorv32` 自动插入重定时寄存器（沿用工具默认的首尾边沿约定）。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收

- DRC 为 0，全部 1,610 个 FF 上链