# 插链任务说明书

## 任务目标

对 RISC-V 处理器核 CV32E40P（top=`cv32e40p_top`）执行完整 Scan Insertion，满足本项目规定的测试通道预算约束以及交付物命名规范。

## 输入文件

- `input/lib/sky130.lib`：sky130 HD 标准单元库。
- `input/netlist/cv32e40p.v`：插链前的层次化门级网表，触发器数量约为 2,257 个。

## 设计信息

- 单一时钟域，时钟端口为 `clk_i`。
- 全局复位端口 `rst_ni`：有效电平需依据端口命名及网表中的实际连接加以确认。
- 时钟门控单元共 74 个，类型为 `sdlclkp_1`，封装于 `SNPS_CLOCK_GATE_HIGH_*` 层次中。其功能使能来自内部信号，测试使能（TE）当前未连接或固定为常量 0。
- 另含一个核心级手工时钟门控：门控使能为功能信号 `pulp_clock_en_i` 与 `scan_cg_en_i` 的逻辑或。
- `scan_cg_en_i` 为扫描控制端口。
- 触发器类型及数量：
  - `dfrtp_1`：2,249 个（异步复位）
  - `dfrtp_4`：1 个（异步复位）
  - `dfstp_2`：6 个（异步置位）
  - `dfsbp_1`：1 个（异步置位）
- ICG 内部锁存器在 DRC 仿真中会产生 TIE0 / TIE1 类提示，属于预期行为。

## 要求

1. 扫描时钟为 `clk_i`；复位为 `rst_ni`，在扫描期间需保持非激活状态。
2. 扫描使能采用 `scan_cg_en_i`。在移位阶段，该端口控制扫描单元，并确保所有时钟门控均处于导通状态。
3. 测试模式下，`pulp_clock_en_i` 由测试设备固定驱动为 1。插链时应将其显式声明为常量。
4. **测试通道预算**：本核被分配 24 对扫描输入 / 输出通道。单条扫描链长度不得超过 100；扫描链总数不得超出通道预算。
5. 时钟不混合；允许不同触发沿的寄存器混合在同一条链中；需插入 lockup；不按内部时钟拆分扫描链。
6. TIE0 / TIE1 类提示按项目规范不作为违例上报；其余 DRC 违例必须为 0。
7. **命名规范**：
   - 扫描数据输入端口：`cv32_si_<n>`
   - 扫描数据输出端口：`cv32_so_<n>`
   - 所有报告及产物文件名均以 `cv32_` 开头，具体见下文输出要求。

## 输出要求

| 文件 | 内容 |
|---|---|
| `output/golden/report/cv32_drc.rpt` | DRC 违例报告 |
| `output/golden/report/cv32_insertion.rpt` | 插链信息 |
| `output/golden/report/cv32_chain.rpt` | 扫描链 |
| `output/golden/report/cv32_chain_cell.rpt` | 链上单元明细 |
| `output/golden/report/cv32_scan_cfg.rpt` | 插链配置 |
| `output/golden/report/cv32_scan_signal.rpt` | 扫描信号 |
| `output/golden/report/cv32_rule_handling.rpt` | DRC 规则处理配置 |
| `output/golden/output/cv32_post_scan.v` | 插链后网表 |
| `output/golden/output/cv32_post_scan.ctl` | CTL 文件 |
| `output/golden/output/cv32_post_scan.def` | SCANDEF 文件 |

此外，需在日志中打印工具版本信息。