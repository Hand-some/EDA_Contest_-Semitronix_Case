# 插链任务说明书

## 任务目标

对 RISC-V 处理器核 CV32E40P（top=`cv32e40p_top`）实施完整的 Scan Insertion 流程，使其符合本项目在测试通道预算与交付物命名规则方面的要求。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/cv32e40p.v` | 门级网表（pre-scan，层次化，约 2,257 个触发器） |

## 设计信息

- 单一时钟域，时钟信号为 `clk_i`
- 全局复位 `rst_ni`：其有效电平请依据端口命名及网表中的实际连接加以确认
- 74 个时钟门控单元（`sdlclkp_1`，封装于 `SNPS_CLOCK_GATE_HIGH_*` 内），功能使能来自内部信号，测试使能（TE）当前接常量 0
- 另含一个核心级手工时钟门控：门控使能为功能信号 `pulp_clock_en_i` 与 `scan_cg_en_i` 的逻辑或
- `scan_cg_en_i`：扫描控制端口
- 触发器类型：`dfrtp_1` × 2,249、`dfrtp_4` × 1（异步复位）；`dfstp_2` × 6、`dfsbp_1` × 1（异步置位）
- ICG 内部 latch 在 DRC 仿真中会引发 TIE0 / TIE1 类提示，属于预期行为

## 要求

1. 扫描时钟采用 `clk_i`；复位由 `rst_ni` 承担，扫描期间需保持非激活状态。
2. 扫描使能由 `scan_cg_en_i` 充当，在移位阶段负责控制扫描单元，并确保所有时钟门控均处于导通状态。
3. 测试模式下 `pulp_clock_en_i` 由测试机恒定驱动为 1，插链时须将其声明为常量。
4. **测试通道预算**：本核被分配 24 对扫描输入 / 输出通道；任一条扫描链的长度不得超过 100。链数不可超出预算。
5. 不混时钟；允许不同触发沿的寄存器混合同一条链；插入 lockup；不按内部时钟拆链。
6. TIE0 / TIE1 类提示依照项目规范不作为违例上报；其余 DRC 必须为 0。
7. **命名规范**：扫描数据端口命名为 `cv32_si_<n>` / `cv32_so_<n>`；全部报告与产物文件均以 `cv32_` 开头，详见下表。

## 输出要求

| 文件 | 内容 |
|---|---|
| `output/golden/report/cv32_drc.rpt` | DRC 违例报告 |
| `output/golden/report/cv32_insertion.rpt` | 插链信息 |
| `output/golden/report/cv32_chain.rpt` | 扫描链 |
| `output/golden/report/cv32_chain_cell.rpt` | 链上单元明细 |
| `output/golden/report/cv32_scan_cfg.rpt` | 插链配置 |
| `output/golden/report/cv32_scan_signal.rpt` | 扫描信号 |
| `output/golden/report/cv32_rule_handling.rpt` | DRC 规则处理配置 |
| `output/golden/output/cv32_post_scan.v` / `.ctl` / `.def` | 插链后网表 / CTL / SCANDEF |

此外需在日志中输出工具版本信息。