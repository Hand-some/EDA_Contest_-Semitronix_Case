# 新增用例：task1 × 9、task2 × 12

针对之前分析出的不足做的补充：
- **task1**：自建说明书写得太直白（直接给出命令和取值），测的是"抄写"不是"推断"。新的说明书只描述设计结构和目标，不出现命令。
- **task2**：注入的问题种类窄、偏语法、配比固定。新的问题按 6 个层次组织，配比随用例变化，现象带证据。

两边都用**结构丰富、已验证**的底座：能力用例 C1~C11（含新补的命令）+ 官方 cv32e40p + 新造的 s13207 门控网表。

## 目录

```
task1/T1-N*/input/      task_spec.md、limitations.md、golden.dofile、lib/、netlist/、（模板 / ctl / db）
task1/T1-N*/variants/   synonym.md、restructure.md —— 措辞变体（事实保真检查通过），用于变形测试
task1/T1-N7_*/alt/      golden_assoc.dofile —— 等价的另一种答案（时钟关联方式）
task2/T2-N*/input/      task_spec.md、limitations.md、golden.dofile、original.dofile、preset_issues.json、lib/、netlist/、…
tools/                  生成与验证脚本
task1_verify.json  task2_build_summary.json  task2_recheck.json   验证结果
```

## task1（9 个）

| 用例 | 底座 / 答案 | agent 需要推断的内容 |
|---|---|---|
| T1-N1_eth_mii | C1 ethernet | 由端口功能认出 mcoll/mcrs 不是时钟并撤销模板声明；由"同一测试时钟源"推出 skew 组；由"低电平透明、驱动 2"从库里挑出 dlxtn_2 |
| T1-N2_ac97_codec | C2 ac97 | 从模板里找出调试链并撤销；按模块功能合并分区；专用端口自定义链；按实例的 skew 组 |
| T1-N3_pico_tester | C3 picorv32 | 由"最低位最先移出"推出链序；由 ATE 采样边沿推出默认重定时 |
| T1-N4_e902_hardip | C4 e902 | 由"已签核硬核、单独测试"推出 hard IP；清理模板的端口级例外；TIE 规则处理 |
| T1-N5_soc_crypto | C5 SoC | 由"加密核走独立通道"推出 hard IP；由链首/尾边沿要求推出 retiming 参数 |
| T1-N6_des3_wrapper | C6 des3 | 由"驱动 2 的 MUX、无复位单 Q DFF"挑库单元给 WC_D1；总线端口撤销 |
| T1-N7_tv80_latchclk | C7 tv80 | latch 时钟处理方式自选（pseudo PI 或关联，`alt/` 中有等价答案）；由 3 级级联推出初始化周期 |
| T1-N8_spi_stage2 | C8 spi | 从数据库加载；对照端口功能找出错误的时钟定义；按前缀找出调试端口 |
| T1-N9_cv32_budget | 官方 cv32e40p（新 golden） | 复位极性要核对；常量端口；由 24 对通道 + 链长 100 推出链数；交付件命名规范 |

验证：`tools/verify_t1.py` 重跑 9 个 golden，**9/9 通过**——报错 0、DRC 符合预期、说明书列出的报告/产物齐全，并复用能力用例的命令效果检查（T1-N9 单独检查通道预算、覆盖率、常量、复位极性、命名）。T1-N7 的关联方式答案也实跑通过（DRC 0、359 FF、10 个重定时寄存器）。

措辞变体：18 份（每个用例同义改写 + 重组表述各 1 份），全部通过事实保真检查（标识符和数字一字不差）；首轮有 2 份因"SI/SO"缩写被改写而丢弃，重新生成后通过。

## task2（12 个，75 个问题）

| 用例 | 执行/DRC/配置 | 分阶段可见 | original 报错 / DRC |
|---|---|---|---|
| T2-N1_eth_mii | 2/1/3 | 0 | 3 / 26 |
| T2-N2_ac97_codec | 1/1/4 | 1 | 2 / 222 |
| T2-N3_pico_tester | 2/1/3 | 2 | 4 / 1432 |
| T2-N4_e902_hardip | 3/1/2 | 3 | 4 / 2756 |
| T2-N5_tv80_latchclk | 2/2/2 | 0 | 4 / 11 |
| T2-N6_des3_wrapper | 3/1/2 | 0 | 6 / 8808 |
| T2-N7_spi_stage2 | 2/2/3 | 1 | 3 / 531 |
| T2-N8_usb_stage2 | 2/1/3 | 0 | 4 / 235 |
| T2-N9_led_eco | 1/2/4 | 0 | 1 / 28 |
| T2-N10_s13207_cg | 1/2/3 | 0 | 1 / 60 |
| T2-N11_cv32_budget | 2/2/3 | 2 | 2 / 5893 |
| T2-N12_soc_sections | 2/1/3 | 3 | 0 / 728 |

问题层次分布：语义 24、多余或缺失 26、对象引用 11、语法 7、网表 4、结构 3；与新补命令直接相关的 34 个。语法类占比约 9%（v1 每个用例 6 个问题中有 3 个是拼写 / 取值 / 顺序类，占 50%）。

### 验证方法（`tools/task2_v2.py build` + `tools/recheck_t2.py`）

1. **单独注入**：每个问题单独注入 golden 跑一次，必须出现预期现象，否则整个用例失败。现象判定覆盖报错码、DRC 规则、报告内容（分区、端口属性 pre_existing / tool_created、链成员与顺序、lockup 单元类型、重定时寄存器位置与时钟、wrapper 实现、IP 分组）、产物文件。
2. **DRC 指纹**：DRC 类问题记下单独注入时独有的违例消息（含实例名），组合运行中必须全部出现才算可见；现象里附上这些实例作为证据，同一用例的多个 DRC 问题因此可以区分。
3. **组合 + 分阶段**：组合注入成 original 后逐条判定；不可见的去掉可能遮蔽它的问题（先 DRC 类，再加执行类）重跑，可见则在现象里写明"被 ISSUE-xx 遮蔽，修复后可见"。共 12 个问题属于这种情况。
4. **独立复查**：只读生成好的 input 目录重跑 golden 与 original，核对文件、字段、类别和差异；N9、N10 的 golden 另跑 LEC（N10 在 scan_mode=0 约束下等价，scan_mode=1 时不等价作为反例）。**12/12 通过**。

### 生成中实测到的工具行为（对 agent 修复策略有用）

- 很多错误**不报错**：`delete_inst` / `remove_scan_partition` 写了不存在的对象只给警告或静默跳过；`set_scan_skew_grp` 引用不存在的时钟静默忽略。这类问题只能靠报告对比发现。
- 对已声明的端口再次 `set_scan_signal` 会报 SCAN-1621；修改信号属性要先 `remove_scan_signal`。
- Tcl 会把唯一前缀补全成命令（`rpt_scan_cell_select` 能执行），命令名笔误不一定报错。
- 把 e902 的处理器时钟 off_state 改成 1 会让工具在插链阶段卡死（CPU 满载超过 16 分钟），这类配置会直接导致超时。
- 把时钟 off_state 改成 1 在 des3、usb 上不产生任何 DRC，不能作为 DRC 问题。

## 注意

- golden 与说明书是我们编写并经工具验收的，不是官方答案。
- 评测 agent 前，把 `golden.dofile`、`preset_issues.json` 移出 `input/`；`variants/`、`alt/` 也不要给 agent。
- 多复位需求没能补上：cv32e40p 只有一个复位，另外两个多复位设计（官方 t1c5、t2c5）规模过大。
- 生成脚本依赖本机的基础镜像与 license；`tools/cases_t2.py` 中保留了全部候选问题（含因冲突或不可复现而未选用的），便于继续扩充。
