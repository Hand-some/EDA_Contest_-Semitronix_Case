"""带常量约束的 LEC：给 gold / gate 各包一层顶层，把指定输入端口接常量，再调用 lec.sh。

用法（在 lec 工作目录下）：python lec_tie.py <lib> <gold.v> <gate.v> <top> <端口=值>...
例：python lec_tie.py sky130.lib ref.v netlist_fixed.v s13207 scan_mode=0
"""
import re
import subprocess
import sys
from pathlib import Path


def wrap(src: str, dst: str, top: str, ties: dict[str, str]) -> None:
    t = Path(src).read_text()
    body = re.search(rf"^module\s+{top}\s*\((.*?)\);(.*?)^endmodule", t, re.S | re.M)
    ports = [p.strip() for p in body.group(1).replace("\n", " ").split(",") if p.strip()]
    decl = {}
    for d, w, names in re.findall(r"^\s*(input|output)\s*(\[[^\]]+\])?\s*([^;]+);", body.group(2), re.M):
        for n in names.split(","):
            decl[n.strip()] = (d, w or "")
    keep = [p for p in ports if p not in ties]
    lines = [f"module lec_top ({', '.join(keep)});"]
    lines += [f"  {decl[p][0]} {decl[p][1]} {p};" for p in keep]
    conns = [f".{p}({ties[p] if p in ties else p})" for p in ports]
    lines += [f"  {top} u ({', '.join(conns)});", "endmodule", ""]
    Path(dst).write_text(t + "\n" + "\n".join(lines))


lib, gold, gate, top, *tie = sys.argv[1:]
ties = dict(x.split("=") for x in tie)
ties = {k: f"1'b{v}" for k, v in ties.items()}
wrap(gold, ".gold_w.v", top, ties)
wrap(gate, ".gate_w.v", top, ties)
here = Path(__file__).parent
p = subprocess.run([str(here / "lec.sh"), lib, ".gold_w.v", ".gate_w.v", "lec_top"], capture_output=True, text=True)
print(p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-500:])
