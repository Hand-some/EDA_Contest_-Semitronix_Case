"""独立复查生成好的 task2 用例：只读 task2/<用例>/input 下的文件，不复用生成过程的中间结果。

检查：
  * input 只含官方要求的文件（+ 底座自带的模板 / ctl / db）；task_spec 含 original.dofile 一行
  * golden.dofile：报错 0，DRC 等于预期（C1/eth 允许 21 个固有 DFTR10，ac97 允许 1 个）
  * original.dofile：至少有报错或 DRC 或配置偏差（与 golden 不同）
  * preset_issues.json：8 个字段齐全、≥6 个问题、三类都有
  * ECO 用例（N9、N10）：golden 的 netlist_fixed.v 过 LEC
用法：python recheck_t2.py [T2-N3 ...]
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from cap import run  # noqa: E402

FIELDS = ["问题编号", "类型", "对象", "现象", "根因", "修复方式", "禁止修复方式", "修复成功判据"]
CATS = {"Dofile执行问题", "DRC问题", "DFT配置不符合任务要求"}
DRC_OK = {"T2-N1": 21, "T2-N2": 1}
LEC = {"T2-N9_led_eco": (HERE.parents[1] / "_capability_cases/C10_led_eco_cleanup/verify/ref_fixed.v", "led_drv", []),
       "T2-N10_s13207_cg": (ROOT / "_bases/N10_s13207_cg/verify/s13207_cg_ref.v", "s13207", ["scan_mode=0"])}


def drc_of(log: str):
    m = re.findall(r"Total violations: (\d+)", log)
    return int(m[-1]) if m else None


def main() -> int:
    only = sys.argv[1:]
    res = {}
    for d in sorted((ROOT / "task2").iterdir(), key=lambda p: int(re.search(r"N(\d+)", p.name).group(1))):
        case = d.name
        if only and not any(case.startswith(o) for o in only):
            continue
        inp = d / "input"
        bad = []
        names = {p.name for p in inp.iterdir()}
        need = {"task_spec.md", "limitations.md", "golden.dofile", "original.dofile", "preset_issues.json", "lib"}
        if need - names:
            bad.append(f"缺文件 {sorted(need - names)}")
        if "original.dofile" not in (inp / "task_spec.md").read_text():
            bad.append("task_spec 未列 original.dofile")
        pj = json.loads((inp / "preset_issues.json").read_text())
        issues = pj["问题列表"]
        if len(issues) < 6:
            bad.append(f"问题数 {len(issues)} < 6")
        for it in issues:
            if list(it) != FIELDS:
                bad.append(f"{it.get('问题编号')} 字段不符")
            if it["类型"] not in CATS:
                bad.append(f"{it['问题编号']} 类型 {it['类型']}")
            if "未能复现" in it["现象"]:
                bad.append(f"{it['问题编号']} 现象未复现")
        cats = {c: sum(i["类型"] == c for i in issues) for c in CATS}
        if not all(cats.values()):
            bad.append(f"类别不全 {cats}")
        # 用一个独立副本运行（input 只读挂载）
        w = ROOT / "_work" / "recheck" / case
        if w.exists():
            shutil.rmtree(w, ignore_errors=True)
        shutil.copytree(inp, w / "input", symlinks=True)
        g = run(w / "input", "golden.dofile", w / "output")
        o = run(w / "input", "original.dofile", w / "output")
        exp = next((v for k, v in DRC_OK.items() if case.startswith(k + "_")), 0)
        gd, od = drc_of(g["log"]), drc_of(o["log"])
        if g["errors"]:
            bad.append(f"golden 报错 {g['errors'][:1]}")
        if gd != exp:
            bad.append(f"golden DRC={gd}，预期 {exp}")
        g_chain = sorted(g["chains"])
        if not (o["errors"] or (od or 0) > exp or sorted(o["chains"]) != g_chain or set(o["reports"]) != set(g["reports"])):
            bad.append("original 与 golden 无差异")
        lec = None
        if case in LEC:
            ref, top, ties = LEC[case]
            lw = w / "lec"
            lw.mkdir()
            shutil.copy(ref, lw / "ref.v")
            shutil.copy(g["out"] / "output" / "netlist_fixed.v", lw / "fixed.v")
            shutil.copy(next((inp / "lib").glob("*.lib")), lw / "cells.lib")
            p = subprocess.run([sys.executable, str(HERE / "lec_tie.py"), "cells.lib", "ref.v", "fixed.v", top, *ties]
                               if ties else [str(HERE / "lec.sh"), "cells.lib", "ref.v", "fixed.v", top],
                               cwd=lw, capture_output=True, text=True)
            lec = "LEC: EQUIVALENT" in p.stdout
            if not lec:
                bad.append("golden netlist_fixed.v 未通过 LEC")
        res[case] = dict(ok=not bad, problems=bad, issues=len(issues), categories=cats,
                         golden=dict(errors=len(g["errors"]), drc=gd, chains=len(g["chains"])),
                         original=dict(errors=len(o["errors"]), drc=od, chains=len(o["chains"])), lec=lec)
        print(f"{'PASS' if not bad else 'FAIL'}  {case:22} golden ERR={len(g['errors'])} DRC={gd} 链={len(g['chains'])} | "
              f"original ERR={len(o['errors'])} DRC={od} 链={len(o['chains'])} | 问题 {len(issues)} "
              f"(执行{cats['Dofile执行问题']}/DRC{cats['DRC问题']}/配置{cats['DFT配置不符合任务要求']})"
              + (f" | LEC {'✓' if lec else '✗'}" if lec is not None else ""))
        for b in bad:
            print(f"      ✗ {b}")
    p = ROOT / "task2_recheck.json"
    old = json.loads(p.read_text()) if p.exists() else {}
    old.update(res)
    p.write_text(json.dumps(old, ensure_ascii=False, indent=1))
    print(f"\n{sum(v['ok'] for v in res.values())}/{len(res)} 通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
