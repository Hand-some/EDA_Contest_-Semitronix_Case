#!/usr/bin/env bash
# 用镜像内 yosys 做组合 + 时序等价检查（同名寄存器配对）。
# 用法：lec.sh <lib> <gold.v> <gate.v> <top>   （路径需在当前目录之下）
# ICG（sdlclkp/dlclkp）没有 SAT 模型，统一建模为组合门控 GCLK = CLK & (GATE | SCE)，两侧同用。
# 结果：打印 equiv_status，等价时最后一行为 "LEC: EQUIVALENT"
set -euo pipefail
LIB=$1; GOLD=$2; GATE=$3; TOP=$4
cat > .lec_icg.v <<V
module sky130_fd_sc_hd__sdlclkp_1 (GATE, SCE, CLK, GCLK); input GATE, SCE, CLK; output GCLK; assign GCLK = CLK & (GATE | SCE); endmodule
module sky130_fd_sc_hd__sdlclkp_2 (GATE, SCE, CLK, GCLK); input GATE, SCE, CLK; output GCLK; assign GCLK = CLK & (GATE | SCE); endmodule
module sky130_fd_sc_hd__sdlclkp_4 (GATE, SCE, CLK, GCLK); input GATE, SCE, CLK; output GCLK; assign GCLK = CLK & (GATE | SCE); endmodule
module sky130_fd_sc_hd__dlclkp_1 (GATE, CLK, GCLK); input GATE, CLK; output GCLK; assign GCLK = CLK & GATE; endmodule
V
cat > .lec.ys <<YS
read_liberty -ignore_miss_func -ignore_miss_dir $LIB
read_verilog -overwrite .lec_icg.v
read_verilog -noblackbox $GOLD
hierarchy -top $TOP
flatten
rename $TOP gold
design -stash gold
read_liberty -ignore_miss_func -ignore_miss_dir $LIB
read_verilog -overwrite .lec_icg.v
read_verilog -noblackbox $GATE
hierarchy -top $TOP
flatten
rename $TOP gate
design -stash gate
design -copy-from gold -as gold gold
design -copy-from gate -as gate gate
proc
opt_clean
equiv_make gold gate equiv
hierarchy -top equiv
equiv_simple -seq 2
equiv_induct -seq 2
equiv_status -assert
YS
docker run --rm --platform linux/amd64 -v "$PWD:/w" -w /w --entrypoint /opt/oss-cad-suite/bin/yosys scan-agent-base:ubuntu24 -q -s .lec.ys > .lec.log 2>&1 && { grep -E "Found|equiv" .lec.log | tail -3; echo "LEC: EQUIVALENT"; } || { tail -15 .lec.log; echo "LEC: NOT EQUIVALENT / ERROR"; }
