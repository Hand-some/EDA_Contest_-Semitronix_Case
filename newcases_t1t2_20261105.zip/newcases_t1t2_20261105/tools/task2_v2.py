"""task2 用例生成器 v2：在已验证的 golden 上按"缺陷目录"注入问题，并用工具逐条实测。

与 v1（eval/suites/task2_gen.py）的区别：
  * 底座换成结构丰富、已验证的 golden（能力用例 C1~C11、官方设计），不再局限于平铺网表；
  * 缺陷按层次组织：语法 / 对象引用 / 语义 / 多余或缺失 / 结构 / 网表，每个用例手工挑选，类别配比随用例变化；
  * 现象判定除报错码、DRC 外，还看报告内容（分区、端口属性、链成员与顺序、lockup 单元、重定时、wrapper 实现）；
  * 现象里带证据（报错行号与原文、违例实例、报告片段）。

用法：
    python task2_v2.py probe  [用例 ...]   # 逐个单独注入候选缺陷，看现象是否出现（不出文件）
    python task2_v2.py build  [用例 ...]   # 按 cases_t2.CASES 选定的缺陷生成 original + preset_issues 并验证
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

sys.path.insert(0, str(Path(__file__).parent))
from cap import run as tool_run  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]          # _newcases
WORK = ROOT / "_work" / "t2"
OUT = ROOT / "task2"


# ───────────────────────────── 运行结果 ─────────────────────────────
@dataclass
class Res:
    log: str
    errors: list            # (行号, 码, 消息, 源行)
    out: Path               # <output>/<tag>
    text: str               # 本次运行的 dofile 文本

    @property
    def drc_total(self) -> int | None:
        m = re.findall(r"Total violations: (\d+)", self.log)
        return int(m[-1]) if m else None

    @property
    def drc_rules(self) -> dict[str, int]:
        d: dict[str, int] = {}
        for n, rule in re.findall(r"There were (\d+) DRC rule '([^']+)'", self.log):
            d[rule] = int(n)          # 同一规则多次出现时取最后一次
        return d

    def drc_examples(self, rule: str, k: int = 2) -> list[str]:
        ex = re.findall(rf"\] (.*?)\. Use the 'man [^']+' command[^\n]*\({re.escape(rule)}-\d+\)", self.log)
        return ex[:k]

    def drc_msgs(self) -> set[str]:
        """违例消息（去掉末尾的序号），用作 DRC 问题的"指纹"。"""
        return set(re.findall(r"\[(?:WARNING|ERROR)\] \[DFTDRC-\d+\] (.*?) \(DFTR[\w-]*?-\d+\)", self.log))

    def rpt(self, name: str) -> str:
        p = self.out / "report" / name
        return p.read_text(errors="replace") if p.is_file() else ""

    def outp(self, name: str) -> str:
        p = self.out / "output" / name
        return p.read_text(errors="replace") if p.is_file() else ""

    def reports(self) -> set[str]:
        d = self.out / "report"
        return {p.name for p in d.iterdir()} if d.is_dir() else set()

    def outputs(self) -> set[str]:
        d = self.out / "output"
        return {p.name for p in d.iterdir()} if d.is_dir() else set()

    def chains(self, rpt: str = "scan_chain.rpt") -> list[list[str]]:
        return [l.split() for l in self.rpt(rpt).splitlines() if re.match(r"^[IW] ", l)]

    def chain_cells(self, chain: str, rpt: str = "scan_chain_cell.rpt") -> list[tuple[str, str]]:
        """(实例, 单元类型)，按链上位置。"""
        out, cur = [], None
        for l in self.rpt(rpt).splitlines():
            m = re.match(r"^[IW]\s+(\S+)\s+\S+\s+(\S+)\s+\S+\s+\([+-]\)\s+(\S+)", l)
            if m:
                cur = m.group(1)
                if cur == chain:
                    out.append((m.group(2), m.group(3)))
                continue
            m = re.match(r"^\s+\S+\s+(\S+)\s+\S+\s+\([+-]\)\s+(\S+)", l)
            if m and cur == chain:
                out.append((m.group(1), m.group(2)))
        return out

    def lockups(self, rpt: str = "scan_chain_cell.rpt") -> list[str]:
        return [l.split()[-3] for l in self.rpt(rpt).splitlines() if "LOCKUP" in l]


def run_text(case: str, base_input: Path, text: str, tag: str, extra: dict[str, str] | None = None) -> Res:
    """把 text 作为 <tag>.dofile 写进 base_input 的副本运行。每次用独立目录（避免 Docker 挂载竞争）。"""
    w = WORK / case / tag
    if w.exists():
        shutil.rmtree(w, ignore_errors=True)
    shutil.copytree(base_input, w / "input", symlinks=True,
                    ignore=shutil.ignore_patterns("golden.dofile", "original.dofile", "preset_issues.json"))
    for k, v in (extra or {}).items():
        (w / "input" / k).write_text(v)
    t = text.replace("output golden ", f"output {tag} ").replace("output golden]", f"output {tag}]")
    (w / "input" / f"{tag}.dofile").write_text(t)
    for _ in range(3):
        r = tool_run(w / "input", f"{tag}.dofile", w / "output")
        if "ScanInsertion version" in r["log"] or "CMD-0034" in r["log"]:
            break
    return Res(log=r["log"], errors=r["errors"], out=w / "output" / tag, text=t)


# ───────────────────────────── 缺陷描述 ─────────────────────────────
@dataclass
class Defect:
    key: str
    cat: str                  # Dofile执行问题 / DRC问题 / DFT配置不符合任务要求
    layer: str                # 语法 / 对象引用 / 语义 / 多余或缺失 / 结构 / 网表
    obj: str                  # 对象
    edit: list                # [("sub", 正则, 替换) | ("del", 正则) | ("ins_after", 锚点正则, 文本) | ("move_after", 行正则, 锚点正则)]
    check: Callable           # (r: Res, g: Res) -> str | None    现象（None = 未出现）
    root: str
    fix: str
    forbid: str
    success: str


def apply(text: str, edits: list) -> str:
    for e in edits:
        op = e[0]
        if op == "sub":
            new, n = re.subn(e[1], e[2], text, flags=re.M)
            if n != 1:
                raise ValueError(f"sub 匹配 {n} 次：{e[1]!r}")
            text = new
        elif op == "del":
            new, n = re.subn(rf"^(?:{e[1]})[^\n]*\n", "", text, flags=re.M)
            if n < 1:
                raise ValueError(f"del 未匹配：{e[1]!r}")
            text = new
        elif op == "delblock":       # 删除从起始行到结束行（含）之间的整段
            m = re.search(rf"^{e[1]}.*?^{e[2]}[^\n]*\n", text, flags=re.M | re.S)
            if not m:
                raise ValueError(f"delblock 未匹配：{e[1]!r}..{e[2]!r}")
            text = text[:m.start()] + text[m.end():]
        elif op == "ins_after":
            m = list(re.finditer(rf"^(?:{e[1]})[^\n]*\n", text, flags=re.M))
            if len(m) != 1:
                raise ValueError(f"ins_after 锚点匹配 {len(m)} 次：{e[1]!r}")
            text = text[:m[0].end()] + e[2].rstrip("\n") + "\n" + text[m[0].end():]
        elif op == "move_after":
            m = list(re.finditer(rf"^(?:{e[1]})[^\n]*\n", text, flags=re.M))
            if len(m) != 1:
                raise ValueError(f"move_after 行匹配 {len(m)} 次：{e[1]!r}")
            line = m[0].group(0)
            text = text[:m[0].start()] + text[m[0].end():]
            a = list(re.finditer(rf"^(?:{e[2]})[^\n]*\n", text, flags=re.M))
            if len(a) != 1:
                raise ValueError(f"move_after 锚点匹配 {len(a)} 次：{e[2]!r}")
            text = text[:a[0].end()] + line + text[a[0].end():]
        else:
            raise ValueError(op)
    return text


# ───────────────────────────── 现象判定（检查器工厂）─────────────────────────────
def line_of(text: str, pat: str) -> int | None:
    for i, l in enumerate(text.splitlines(), 1):
        if re.search(pat, l):
            return i
    return None


def ERR(src_pat: str, code: str | None = None, desc: str = "") -> Callable:
    """在源行匹配 src_pat 的命令上出现（golden 中没有的）报错。"""
    def f(r: Res, g: Res):
        gold = {(e[1], e[2]) for e in g.errors}
        hits = [e for e in r.errors if re.search(src_pat, e[3]) and (code is None or e[1] == code)
                and (e[1], e[2]) not in gold]
        if not hits:
            return None
        e = hits[0]
        extra = "；" + "；".join(f"[{h[1]}] {h[2]}" for h in hits[1:2]) if len(hits) > 1 else ""
        return f"original.dofile 第 {e[0]} 行（`{e[3][:70]}`）执行时工具报错 [{e[1]}] {e[2]}{extra}{desc}"
    return f


def DRC(rule: str | None = None, desc: str = "") -> Callable:
    def f(r: Res, g: Res):
        if rule:
            n, n0 = r.drc_rules.get(rule, 0), g.drc_rules.get(rule, 0)
            if n <= n0:
                return None
            ex = r.drc_examples(rule)
            exs = f"，例如：{'；'.join(ex)}" if ex else ""
            return f"examine_scan_drc 报 {rule} × {n}（golden 为 {n0}）{exs}{desc}"
        t, t0 = r.drc_total or 0, g.drc_total or 0
        if t <= t0:
            return None
        rules = "，".join(f"{k} × {v}" for k, v in sorted(r.drc_rules.items()))
        return f"examine_scan_drc 违例总数 {t}（golden 为 {t0}）：{rules}{desc}"
    return f


def WHEN(pred: Callable, phen: Callable | str) -> Callable:
    """pred(r, g) 为真时出现；phen 为固定文本或 (r, g) -> 文本。"""
    def f(r: Res, g: Res):
        try:
            ok = pred(r, g)
        except Exception:      # 报告缺失等
            ok = False
        if not ok:
            return None
        return phen(r, g) if callable(phen) else phen
    return f


def ANY(*fs: Callable) -> Callable:
    def f(r: Res, g: Res):
        out = [x for x in (h(r, g) for h in fs) if x]
        return "；".join(out) if out else None
    return f


# ───────────────────────────── 生成 ─────────────────────────────
def golden_run(case: str, cfg: dict) -> Res:
    base = cfg["base"]
    g = run_text(case, base, (base / "golden.dofile").read_text(), "golden")
    assert not g.errors, f"{case} golden 报错：{g.errors[:2]}"
    return g


def probe(case: str, cfg: dict) -> dict:
    g = golden_run(case, cfg)
    gtext = (cfg["base"] / "golden.dofile").read_text()
    res = {}
    for d in cfg["defects"]:
        try:
            t = apply(gtext, d.edit)
        except ValueError as e:
            print(f"  ✗ {d.key:22} 注入失败：{e}")
            res[d.key] = None
            continue
        r = run_text(case, cfg["base"], t, f"p_{d.key}")
        ph = d.check(r, g)
        res[d.key] = ph
        extra = f" | ERR={len(r.errors)} DRC={r.drc_total}"
        print(f"  {'✓' if ph else '✗'} {d.key:22} [{d.cat[:4]}] {(ph or '未出现预期现象')[:150]}{'' if ph else extra}", flush=True)
    return res


def build(case: str, cfg: dict) -> dict:
    """单独注入 → 组合注入 → 分阶段。

    每个缺陷先单独注入，必须出现预期现象（否则整个用例失败）；DRC 类缺陷记下单独注入时独有的
    违例消息作为指纹。组合后，缺陷可见 = 检查函数成立，且（DRC 类）指纹全部出现在组合运行中。
    不可见的，去掉可能遮蔽它的缺陷（先 DRC 类，再加执行类）重跑，可见则记为分阶段可见。
    """
    g = golden_run(case, cfg)
    gtext = (cfg["base"] / "golden.dofile").read_text()
    defects: list[Defect] = [d for d in cfg["defects"] if d.key in cfg["select"]]
    order = {k: i for i, k in enumerate(cfg["select"])}
    defects.sort(key=lambda d: order[d.key])
    finger, solo_bad = {}, []
    gmsgs = g.drc_msgs()
    for d in defects:
        rs = run_text(case, cfg["base"], apply(gtext, d.edit), f"solo_{d.key}")
        if not d.check(rs, g):
            solo_bad.append(d.key)
        if d.cat == "DRC问题":
            finger[d.key] = sorted(rs.drc_msgs() - gmsgs)[:5]

    def visible(d: Defect, run: Res) -> str | None:
        ph = d.check(run, g)
        if ph and d.cat == "DRC问题" and finger.get(d.key):
            if not set(finger[d.key]) <= run.drc_msgs():
                return None
            ph += "；其中由本问题引起的违例示例：" + "；".join(finger[d.key][:2])
        return ph

    orig = apply(gtext, [e for d in defects for e in d.edit])
    r = run_text(case, cfg["base"], orig, "original")
    phen, staged = {}, {}
    for d in defects:
        ph = visible(d, r)
        if ph:
            phen[d.key] = ph
    missing = [d for d in defects if d.key not in phen]
    # 分阶段：去掉"遮蔽者"（DRC 类、再加执行类），看是否出现
    for d in missing:
        for lvl, drop_cats in enumerate((("DRC问题",), ("DRC问题", "Dofile执行问题")), 1):
            keep = [x for x in defects if x is d or x.cat not in drop_cats]
            dropped = [x for x in defects if x not in keep]
            if not dropped:
                continue
            t = apply(gtext, [e for x in keep for e in x.edit])
            rs = run_text(case, cfg["base"], t, f"stage{lvl}_{d.key}")   # 每级独立目录，避免 Docker 挂载竞争
            ph = visible(d, rs)
            if ph:
                staged[d.key] = ([x.key for x in dropped], ph)
                break
    ok = not solo_bad and all(d.key in phen or d.key in staged for d in defects)
    if solo_bad:
        print(f"  单独注入未复现：{solo_bad}")
    issues = []
    for i, d in enumerate(defects, 1):
        if d.key in phen:
            ph = phen[d.key]
        elif d.key in staged:
            masks = staged[d.key][0]
            ids = "、".join(f"ISSUE-{[x.key for x in defects].index(k) + 1:02d}" for k in masks)
            ph = f"在 original.dofile 中被 {ids} 遮蔽；修复后重新运行可见：{staged[d.key][1]}"
        else:
            ph = "（未能复现）"
        issues.append({"问题编号": f"ISSUE-{i:02d}", "类型": d.cat, "对象": d.obj, "现象": ph,
                       "根因": d.root, "修复方式": d.fix, "禁止修复方式": d.forbid, "修复成功判据": d.success})
    return dict(ok=ok, orig=orig, issues=issues, golden=g, original=r,
                layers={d.key: d.layer for d in defects}, staged=staged)


def write_case(case: str, cfg: dict, b: dict) -> Path:
    dst = OUT / case / "input"
    if dst.parent.exists():
        shutil.rmtree(dst.parent)
    shutil.copytree(cfg["base"], dst, symlinks=True, ignore=shutil.ignore_patterns("task_spec.md", "verify"))
    (dst / "original.dofile").write_text(b["orig"].replace("output golden ", "output original "))
    (dst / "preset_issues.json").write_text(json.dumps({"case_id": case, "问题列表": b["issues"]},
                                                       ensure_ascii=False, indent=2))
    spec = cfg["spec"].read_text()
    spec = re.sub(r"\n## 验收(要点)?\n.*?(?=\n## |\Z)", "\n", spec, flags=re.S)
    row = "| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |\n"
    spec = re.sub(r"(\| 文件 \| 说明 \|\n\|[-| ]+\|\n)", lambda m: m.group(1) + row, spec, count=1)
    assert "original.dofile" in spec, case
    spec = spec.replace("## 任务目标\n", "## 任务目标\n\n> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。\n", 1)
    (dst / "task_spec.md").write_text(spec)
    for k, v in cfg.get("extra_files", {}).items():
        (dst / k).write_text(v)
    return dst


def main() -> int:
    from cases_t2 import CASES
    mode, only = sys.argv[1], sys.argv[2:]
    summary = {}
    for case, cfg in CASES.items():
        if only and not any(case.startswith(o) for o in only):
            continue
        print(f"== {case}", flush=True)
        if mode == "probe":
            probe(case, cfg)
            continue
        b = build(case, cfg)
        o = b["original"]
        cats = {}
        for it in b["issues"]:
            cats[it["类型"]] = cats.get(it["类型"], 0) + 1
        print(f"  original：ERROR={len(o.errors)} DRC={o.drc_total}  {cats}  分阶段={list(b['staged'])}")
        for it in b["issues"]:
            print(f"   {it['问题编号']} [{it['类型'][:4]}] {it['对象'][:40]:40} {it['现象'][:120]}")
        if b["ok"]:
            write_case(case, cfg, b)
        summary[case] = dict(ok=b["ok"], categories=cats, layers=b["layers"], staged=b["staged"],
                             original=dict(errors=len(o.errors), drc=o.drc_total))
        print(f"  {'通过，已写出' if b['ok'] else '失败：有问题未能复现'}", flush=True)
    if mode == "build":
        p = ROOT / "task2_build_summary.json"
        old = json.loads(p.read_text()) if p.exists() else {}
        old.update(summary)
        p.write_text(json.dumps(old, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
