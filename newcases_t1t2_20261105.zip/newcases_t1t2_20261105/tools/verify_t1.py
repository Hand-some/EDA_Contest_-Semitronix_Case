"""重跑新增 task1 用例的 golden，核对说明书要求。

T1-N1~N8 的答案与能力用例 C1~C8 相同：复用 _capability_cases/tools/verify_all.py 的命令效果检查，
只是把读取目录指向本用例的输出。T1-N9（cv32e40p）单独检查。

用法：python verify_t1.py [T1-N3 ...]
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "task1"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / "_capability_cases" / "tools"))
import verify_all as V  # noqa: E402
from cap import run  # noqa: E402

MAP = {"T1-N1_eth_mii": "C1_eth_skew_lockup", "T1-N2_ac97_codec": "C2_ac97_userchain_skew",
       "T1-N3_pico_tester": "C3_pico_ordered_retiming", "T1-N4_e902_hardip": "C4_e902_hardip_wrapper",
       "T1-N5_soc_crypto": "C5_soc_hardip_retiming", "T1-N6_des3_wrapper": "C6_des3_wrapper_cells",
       "T1-N7_tv80_latchclk": "C7_tv80_pseudopi_retiming", "T1-N8_spi_stage2": "C8_spi_incremental"}


def spec_outputs(spec: str) -> set[str]:
    sec = spec.split("## 输出要求", 1)[-1]
    return {m.split("/")[-1] for m in re.findall(r"`([\w./-]+\.(?:rpt|v|ctl|def|db))`", sec)}


def cv32_checks(out: Path) -> list[tuple[str, str, bool]]:
    rpt = lambda n: (out / "report" / n).read_text(errors="replace") if (out / "report" / n).is_file() else ""  # noqa: E731
    ch = [l.split() for l in rpt("cv32_chain.rpt").splitlines() if re.match(r"^[IW] ", l)]
    sig = rpt("cv32_scan_signal.rpt")
    return [
        ("通道预算", "链数 ≤ 24 且每条 ≤ 100", 0 < len(ch) <= 24 and max(int(c[2]) for c in ch) <= 100),
        ("覆盖", "2,257 个 FF 全部上链", sum(int(c[2]) for c in ch) == 2257),
        ("常量端口", "pulp_clock_en_i 为 constant 1", bool(re.search(r"pulp_clock_en_i\s+\S+\s+constant\s+1", sig))),
        ("复位极性", "rst_ni 为 reset、off_state 1", bool(re.search(r"rst_ni\s+\S+\s+reset\s+1", sig))),
        ("命名", "SI/SO 为 cv32_si_<n> / cv32_so_<n>", all(c[3].startswith("cv32_si_") and c[4].startswith("cv32_so_") for c in ch)),
        ("规则处理", "TIE0/TIE1 为 Ignore", len(re.findall(r"DFTR-TIE[01]\s+\S+\s+Ignore", rpt("cv32_rule_handling.rpt"))) == 2),
    ]


def main() -> int:
    only = sys.argv[1:]
    res = {}
    for case in sorted(p.name for p in ROOT.iterdir() if p.is_dir()):
        if only and not any(case.startswith(o) for o in only):
            continue
        inp = ROOT / case / "input"
        r = run(inp, "golden.dofile", ROOT / case / "output")
        out = ROOT / case / "output" / "golden"
        drc = re.findall(r"Total violations: (\d+)", r["log"])
        drc = int(drc[-1]) if drc else None
        spec = (inp / "task_spec.md").read_text()
        want = spec_outputs(spec)
        if case.startswith("T1-N9"):
            want |= {"cv32_post_scan.ctl", "cv32_post_scan.def"}
        have = set(r["reports"]) | set(r["outputs"])
        items = [("(通用)", "ERROR=0", not r["errors"]),
                 ("(通用)", "说明书要求的报告/产物齐全" + (f"（缺 {sorted(want - have)}）" if want - have else ""), want <= have),
                 ("(通用)", "日志打印工具版本", "ScanInsertion version" in r["log"])]
        if case in MAP:
            c = MAP[case]
            exp = V.SPEC[c]
            items.append(("(通用)", f"DRC={exp['drc']}", drc == exp["drc"]))
            V.OUT[c] = out
            try:
                items += V.checks(c)
            finally:
                V.OUT.pop(c)
        else:
            items.append(("(通用)", "DRC=0", drc == 0))
            items += cv32_checks(out)
        ok = all(x[2] for x in items)
        res[case] = dict(ok=ok, seconds=r["seconds"], drc=drc, checks=[dict(cmd=a, desc=b, ok=c) for a, b, c in items])
        print(f"{'PASS' if ok else 'FAIL'}  {case:24} {r['seconds']:5}s ERROR={len(r['errors'])} DRC={drc}")
        for a, b, c in items:
            if not c:
                print(f"      ✗ {a:30} {b}")
    p = HERE.parent / "task1_verify.json"
    old = json.loads(p.read_text()) if p.exists() else {}
    old.update(res)
    p.write_text(json.dumps(old, ensure_ascii=False, indent=1))
    print(f"\n{sum(v['ok'] for v in res.values())}/{len(res)} 通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
