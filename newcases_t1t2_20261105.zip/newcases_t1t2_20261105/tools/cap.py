"""能力用例的工具实跑脚手架：python cap.py <input_dir> <dofile名> [--grep 正则]

在基础镜像里以官方布局运行 <input>/<dofile>，打印：报错（带 dofile 行号与命令）、DRC、链摘要、报告清单。
"""
import argparse, os, re, subprocess, sys, time
from pathlib import Path

IMAGE = "scan-agent-base:ubuntu24"
LICENSE = "8273@121.40.209.111"


def run(inp: Path, dofile: str, out: Path | None = None, timeout: int = 600) -> dict:
    inp = inp.resolve()
    out = (out or inp.parent / "output").resolve()
    tag = re.sub(r"\.dofile$", "", dofile)
    out.mkdir(parents=True, exist_ok=True)
    if (out / tag).exists():   # 只清理本次运行的子目录（容器内 root 写入，需在容器里删）
        subprocess.run(["docker", "run", "--rm", "-v", f"{out}:/t", "--entrypoint", "rm", IMAGE,
                        "-rf", f"/t/{tag}"], capture_output=True)
    t0 = time.monotonic()
    name = f"cap_{os.getpid()}_{int(time.time() * 1000)}"
    cmd = ["docker", "run", "--rm", "--name", name, "--platform", "linux/amd64",
                        "-e", f"SCANINSERTION_LICENSE_SERVER={LICENSE}",
                        "-v", f"{inp}:/work/case/input:ro", "-v", f"{out}:/work/case/output",
                        "-w", "/work/case/output",
                        "--entrypoint", "dftexp_scan", IMAGE, "-f", f"/work/case/input/{dofile}"]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        log = p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:   # 工具卡死：停掉容器，按超时记录
        subprocess.run(["docker", "kill", name], capture_output=True)
        log = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        log += f"\n[TIMEOUT] 运行超过 {timeout}s，已终止\n"
    (out / f"{dofile}.log").write_text(log)
    lines = (inp / dofile).read_text(errors="replace").splitlines()
    errs, warns, cur = [], [], 0
    for ln in log.splitlines():
        m = re.search(r"CMD-0034\] @(\d+): (.?)", ln)
        if m:
            if not m.group(2).isspace():   # 续行（以空白开头）沿用命令首行的行号
                cur = int(m.group(1))
            continue
        m = re.search(r"\[(ERROR|WARN\w*)\] \[\s*([A-Z0-9-]+)\] (.*)", ln)
        if m:
            src = lines[cur - 1].strip()[:90] if 0 < cur <= len(lines) else ""
            (errs if m.group(1) == "ERROR" else warns).append((cur, m.group(2), m.group(3).strip()[:220], src))
    rpt = out / tag / "report"
    drc = None
    if (rpt / "drc.rpt").is_file():
        t = (rpt / "drc.rpt").read_text(errors="replace")
        m = re.findall(r"Total violations: (\d+)", t)
        drc = int(m[-1]) if m else None
    chains = []
    if (rpt / "scan_chain.rpt").is_file():
        chains = [l for l in (rpt / "scan_chain.rpt").read_text(errors="replace").splitlines() if re.match(r"^[IW] ", l)]
    return dict(log=log, errors=errs, warns=warns, drc=drc, chains=chains, seconds=round(time.monotonic() - t0, 1),
                reports=sorted(p.name for p in rpt.iterdir()) if rpt.is_dir() else [],
                outputs=sorted(p.name for p in (out / tag / "output").iterdir()) if (out / tag / "output").is_dir() else [],
                out=out / tag)


def show(r: dict, grep: str | None = None, warn_codes: bool = True) -> None:
    print(f"耗时 {r['seconds']}s  ERROR={len(r['errors'])}  DRC={r['drc']}  链数={len(r['chains'])}")
    for e in r["errors"]:
        print(f"  ERR @{e[0]} [{e[1]}] {e[2]}\n        ← {e[3]}")
    if warn_codes:
        seen = {}
        for w in r["warns"]:
            seen.setdefault(w[1], w)
        for code, w in seen.items():
            print(f"  WARN @{w[0]} [{code}] {w[2][:160]}")
    for c in r["chains"][:12]:
        print("  CHAIN", re.sub(r"\s+", " ", c)[:160])
    print("  报告:", " ".join(r["reports"]))
    print("  产物:", " ".join(r["outputs"]))
    if grep:
        for ln in r["log"].splitlines():
            if re.search(grep, ln):
                print("  LOG", ln[:220])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("dofile"); ap.add_argument("--grep")
    ap.add_argument("--nowarn", action="store_true")
    a = ap.parse_args()
    show(run(Path(a.input), a.dofile), a.grep, not a.nowarn)
