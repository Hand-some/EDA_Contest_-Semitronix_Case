# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对以太网 MAC 核 `eth_top` 执行完整 Scan Insertion。项目组有一份所有以太网项目共用的平台插链模板 `eth_platform.tcl`，本次必须在 Dofile 中**原样引用**该模板（不得修改模板文件，也不得把模板内容拷贝进 Dofile 再改），再根据本设计的实际情况在其后做必要的调整，使最终配置满足本说明书。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/stdcells.lib` | sky130 HD 标准单元库 |
| `input/netlist/ethernet_sky130.v` | 门级网表（pre-scan，top=`eth_top`） |
| `input/eth_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

`eth_top` 是 WISHBONE 总线接口的 10/100M 以太网 MAC，约 10,500 个触发器，内部大量使用时钟门控。

### 端口功能

| 端口 | 方向 | 功能 |
|---|---|---|
| `wb_clk_i` | in | WISHBONE 总线时钟，驱动寄存器、DMA、缓冲控制等绝大部分逻辑（约 10,000 FF） |
| `wb_rst_i` | in | 全局异步复位，高电平有效 |
| `mtx_clk_pad_i` | in | 来自 PHY 的 MII 发送时钟，驱动发送通路（约 231 FF） |
| `mrx_clk_pad_i` | in | 来自 PHY 的 MII 接收时钟，驱动接收通路（约 297 FF） |
| `mrxd_pad_i[3:0]`、`mrxdv_pad_i`、`mrxerr_pad_i` | in | MII 接收数据 / 有效 / 错误 |
| `mcoll_pad_i` | in | MII 冲突检测信号（电平信号，由接收时钟域采样） |
| `mcrs_pad_i` | in | MII 载波侦听信号（电平信号） |
| `md_pad_i` | in | MDIO 管理数据输入 |
| 其余 `wb_*`、`m_wb_*`、`mtx*_pad_o`、`md*_pad_o`、`int_o` | — | 总线、MII 发送与管理接口的数据端口 |

### 测试环境

- 测试模式下 `mtx_clk_pad_i` 与 `mrx_clk_pad_i` 由 ATE 的**同一个**测试时钟源驱动，二者之间不存在时钟偏斜问题；`wb_clk_i` 为独立的测试时钟。
- 测试模式扫描使能端口：`test_se`（默认）、`se_wb`（WB 域）、`se_mac`（MAC 收发域，新端口）。
- 设计中有 21 处时钟直接接到触发器数据端（DFTR10），属于设计固有结构，允许保留；其余 DRC 必须为 0。

## 关于平台模板

模板按"通用以太网 MAC"编写，包含 DFF→SFF 映射、时钟/复位声明、全局 scan_cfg、TIE1 规则处理，以及按时钟划分的 WB / TX / RX 三个分区。模板对端口用途的假设**不一定适用于本设计**，请对照上文端口功能逐项核对，对不适用的声明予以撤销（不能保留错误声明再在后面另行覆盖）。

## 扫描结构要求

1. **WB 域**：沿用模板中的 WB 分区配置不变。
2. **MAC 收发域**：发送、接收两部分的触发器合并到同一个分区 `mac_partition`，共 2 条扫描链，单链不超过 300，使用 `se_mac` 作为扫描使能；允许收发两个时钟的触发器混在同一条链上；每条链末端插入 terminal lockup latch。模板中不再使用的分区必须从配置中移除。
3. **跨时钟处理**：根据上文"测试环境"中的时钟关系，收发两个时钟之间不应插入 lockup latch；请用工具提供的时钟偏斜分组机制表达这一点（组名 `mac_skew`）。
4. **lockup latch 选型**：本项目所有 lockup latch 统一采用标准单元库中**低电平透明、单 Q 输出、驱动强度 2** 的 D latch。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_partition.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`scan_cell_selection.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息
