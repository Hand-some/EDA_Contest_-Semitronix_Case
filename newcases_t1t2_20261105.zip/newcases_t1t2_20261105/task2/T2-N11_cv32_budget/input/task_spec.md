# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对 RISC-V 处理器核 CV32E40P（top=`cv32e40p_top`）执行完整 Scan Insertion，满足本项目的测试通道预算与交付件命名规范。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/cv32e40p.v` | 门级网表（pre-scan，层次化，约 2,257 个触发器） |

## 设计信息

- 单时钟域，时钟 `clk_i`
- 全局复位 `rst_ni`：请根据端口命名与网表中的实际连接确认其有效电平
- 74 个时钟门控单元（`sdlclkp_1`，封装在 `SNPS_CLOCK_GATE_HIGH_*` 中），功能使能由内部信号驱动，测试使能（TE）当前接常量 0
- 另有一个核心级手工时钟门控：其门控使能为功能信号 `pulp_clock_en_i` 与 `scan_cg_en_i` 的逻辑或
- `scan_cg_en_i`：扫描控制端口
- 触发器类型：`dfrtp_1` × 2,249、`dfrtp_4` × 1（异步复位）；`dfstp_2` × 6、`dfsbp_1` × 1（异步置位）
- ICG 内部 latch 在 DRC 仿真中会产生 TIE0 / TIE1 类提示，属正常现象

## 要求

1. `clk_i` 为扫描时钟；`rst_ni` 为复位，扫描期间保持非激活。
2. `scan_cg_en_i` 作为扫描使能，在移位阶段控制扫描单元，并保证全部时钟门控导通。
3. 测试模式下 `pulp_clock_en_i` 由测试机固定驱动为 1，请在插链中将其声明为常量。
4. **测试通道预算**：芯片为本核分配了 24 对扫描输入 / 输出通道；任何一条扫描链长度不得超过 100。链数不得超出预算。
5. 不混时钟；允许不同触发沿的寄存器混合在同一条链中；插 lockup；不按内部时钟拆链。
6. TIE0 / TIE1 类提示按项目规范不作为违例报告；其他 DRC 必须为 0。
7. **命名规范**：扫描数据端口命名为 `cv32_si_<n>` / `cv32_so_<n>`；所有报告与产物文件名以 `cv32_` 开头，见下表。

## 输出要求

| 文件 | 内容 |
|---|---|
| `output/golden/report/cv32_drc.rpt` | DRC 违例报告 |
| `output/golden/report/cv32_insertion.rpt` | 插链信息 |
| `output/golden/report/cv32_chain.rpt` | 扫描链 |
| `output/golden/report/cv32_chain_cell.rpt` | 链上单元明细 |
| `output/golden/report/cv32_scan_cfg.rpt` | 插链配置 |
| `output/golden/report/cv32_scan_signal.rpt` | 扫描信号 |
| `output/golden/report/cv32_rule_handling.rpt` | DRC 规则处理配置 |
| `output/golden/output/cv32_post_scan.v` / `.ctl` / `.def` | 插链后网表 / CTL / SCANDEF |

另在日志中打印工具版本信息。
