# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对 Z80 兼容处理器 `tv80s` 执行完整 Scan Insertion，使 DRC 为 0、全部可扫描 FF 上链。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/tv80.v` | 门级网表（pre-scan，top=`tv80s`；CPU 核实例 `i_tv80_core`） |

## 设计信息

- 主时钟 `clk`，测试时保持高电平为非激活态
- 共 359 个可扫描 FF；36 个时钟门控单元（`SNPS_CLOCK_GATE_HIGH_*`，内部为 `sdlclkp_1`）。时钟门控构成多级级联：部分下级门控单元的时钟输入来自上级门控单元的门控时钟输出，**最深为 3 级**
- `scan_cg_en`：时钟门控旁路信号，测试模式下打开全部门控单元，同时作为扫描使能
- 闩锁 `u_clk_latch`（`sky130_fd_sc_hd__dlxtp_1`）：其数据端接主时钟 `clk`，输出端驱动一小组寄存器的时钟引脚。工具无法自动推导经过该闩锁的时钟，**若不处理，这组寄存器的时钟在 DRC 中不可控**

## 要求

1. 时钟与扫描使能按上文配置；闩锁 `u_clk_latch` 本身不作为扫描元素。
2. 经闩锁传出的时钟必须在扫描中可控。工具提供多种等价的处理方式，任选其一，但不得通过排除寄存器或豁免 DRC 规则来回避。
3. 时钟门控级联较深，DRC 仿真需为门控使能的逐级传播预留足够的初始化周期。
4. 扫描链：单链不超过 100；不按内部时钟拆链；允许混合时钟沿；插 lockup；SI/SO 端口命名为 `scan_si_<n>` / `scan_so_<n>`。
5. **重定时**：每条扫描链的首、尾时序单元都必须是上升沿触发；不满足时由工具插入重定时寄存器。重定时寄存器必须放在 CPU 核 `i_tv80_core` 的层次内，并且由主时钟 `clk` 驱动。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`pseudo_pi.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`
- 在日志中打印工具版本信息
