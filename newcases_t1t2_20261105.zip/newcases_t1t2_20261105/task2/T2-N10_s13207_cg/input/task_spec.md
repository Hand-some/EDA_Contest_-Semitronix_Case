# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对 ISCAS'89 基准电路 `s13207` 的门级网表执行完整 Scan Insertion。该网表在综合后被手工加入了时钟门控结构，其中**存在网表层面的可测性缺陷**，仅调整扫描声明无法使 DRC 清零，必须用工具的网表编辑（ECO）命令修复；同时网表中残留一段调试观测逻辑，需要清理。

1. DFF 替换为扫描 FF，638 个 FF 全部上链；
2. 用 ECO 命令修复网表缺陷，使 DRC 为 0；
3. 清理调试观测逻辑；
4. 导出 ECO 后、插链前的网表 `netlist_fixed.v`，以及插链后网表。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/s13207_cg.v` | 门级网表（pre-scan，top=`s13207`，单层平铺） |

## 网表说明

- 单时钟 `CK`；638 个 `sky130_fd_sc_hd__dfxtp_1`
- 时钟门控结构（位于顶层）：

| 对象 | 说明 |
|---|---|
| `U_CG_FN`（`sdlclkp_1`） | 门控 `DFF_100`~`DFF_139` 共 40 个 FF 的时钟（门控时钟线网 `gclk_fn`）；功能使能接 `\DFF_5.Q`，测试使能 `SCE` 的连接以网表为准 |
| `U_CG_OK`（`sdlclkp_1`） | 门控 `DFF_300`~`DFF_339` 共 40 个 FF 的时钟（`gclk_ok`）；测试使能接常量 0，插链时由扫描使能接管 |
| `U_CKAND`（`and2_1`） | 与 `DFF_200`~`DFF_219` 共 20 个 FF 的时钟相关（线网 `gclk_and`），具体结构以网表为准 |

- 端口 `scan_mode`：测试模式选择，**1=测试模式，0=功能模式**，网表中目前无负载；DRC 与插链属于测试模式，须声明为常量 1
- 端口 `blk_en`：块使能（功能信号）
- 遗留的调试观测逻辑（输出悬空、无负载）：端口 `dbg_sel`，单元 `U_DBG_A`（buf_1）、`U_DBG_B`（inv_1）、`U_DBG_C`（nand2_1），线网 `dbg_w0`、`dbg_w1`、`dbg_w2`

## 修复原则（网表 ECO）

1. **最小修改**：只改动违例根因所在的连接，原有功能逻辑保留。
2. **功能态透传**：修复在功能模式（`scan_mode=0`）下必须与原网表逐拍一致；`netlist_fixed.v` 在 `scan_mode=0` 时须与原网表（去掉调试逻辑后）形式等价。
3. **MUX 接法**：被修引脚的原连接改道接 MUX 的 `A0`，修复引入的测试逻辑接 `A1`，`S=scan_mode`，MUX 输出继续驱动原线网。需要常量 1 时使用 `sky130_fd_sc_hd__conb_1` 的 `HI`。
4. **禁止绕过**：不得排除任何 FF；不得豁免 DFTR1 / DFTR9；不得用 pseudo PI 加常量的声明代替网表修复。

## 调试逻辑清理

删除 3 个调试单元、3 根线网（线网须显式删除）与端口 `dbg_sel`，并执行一次网表连线整理（`rewire`），在导出 `netlist_fixed.v` 之前完成。

## 配置要求

1. 扫描时钟 `CK`（off_state 0）；扫描使能为新端口 `test_se`（`-usage all`，off_state 0）；`scan_mode` 声明为常量 1。
2. ICG 内部 latch 引起的 TIE0 / TIE1 类提示按项目规范设为 Ignore。
3. DFF 替换 `dfxtp_1` → `sdfxtp_1`。
4. 扫描分区 `main_partition`（`-clocks {CK}`），4 条链，max_length 300，不混时钟/边沿，插 lockup；SI/SO 命名 `scan_data_in_%d` / `scan_data_out_%d`。

## 输出要求

- 产物（`output/golden/output/`）：`netlist_fixed.v`、`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息
