# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对 3DES 加密核 `des3` 执行 Internal Scan 与 Wrapper Scan 插入。必须在 Dofile 中**原样引用**项目平台模板 `des_platform.tcl`（模板中已含全部 scan segment 定义；不得修改模板文件，也不得拷贝改写），再在其后按本说明书调整 wrapper 策略。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/des_perf.v` | 3DES 核门级网表（top=`des3`） |
| `input/netlist/dedicated_wrp_cell.v` | 用户自定义 dedicated wrapper cell `dedicated_wrp_cell` |
| `input/des_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

- 时钟 `clk`；`decrypt` 兼作扫描使能；wrapper 控制端口 `wrapper_in_shift_en`、`wrapper_out_shift_en`、`wrapper_in_cap_en`、`wrapper_out_cap_en`
- 数据输入 `desIn[63:0]` 在 `u0` 中由 `desIn_r_reg[*]` 直接寄存
- 三组 56 位密钥输入 `key1`、`key2`、`key3`，后级为移位寄存器结构（模板已声明为 scan segment）

## 关于平台模板

模板已完成全局 scan_cfg、wrapper 信号、用户自定义 dedicated cell 类型、全局 shared 风格 wrapper（WC_S1）、全部 segment，以及若干**端口级 / 寄存器级例外**。本项目对例外的要求与模板编写时不同，见下文。

## wrapper 策略

| 端口 / 对象 | 本项目要求 |
|---|---|
| `key1` | 需要 wrapper 隔离。模板中针对 `key1` 的端口级例外必须撤销，使其回到全局 wrapper 规则，由工具按后级结构自行选择 wrapper 方式 |
| `key2` | 维持模板配置（用户自定义 dedicated cell） |
| `key3` | 改用工具**内建**的 WC_D1 型 dedicated wrapper cell；WC_D1 内部的 2 选 1 MUX 与 D 触发器分别选用标准单元库中**驱动强度为 2** 的 2 选 1 MUX 和**无复位、单 Q 输出**的 D 触发器 |
| `desIn[*]` | 原有的功能 bypass 已取消，所有数据输入寄存器均可复用为 shared wrapper 单元；模板中对部分寄存器的排除必须撤销 |

> 所有"撤销"必须通过撤销模板中的对应配置完成，不能保留后再追加相反配置覆盖。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`scan_segment.rpt`、`wrapper_cfg.rpt`、`wrapper_implementation.rpt`、`dedicated_wrapper_cell_type.rpt`、`scan_cell_selection.rpt`
- 在日志中打印工具版本信息

