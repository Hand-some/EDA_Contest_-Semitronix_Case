// led_drv.v —— 教学示例门级网表（含 2 处网表缺陷，见 preset_issues.json）
// 工艺库: sky130_fd_sc_hd

module cfg_unit ( clk, load_i, data_i, mode_i, cfg_o );
  input        clk;
  input        load_i;
  input        data_i;
  input        mode_i;
  output [13:0] cfg_o;
  wire  [13:0] cfg_q;
  wire   n_ld0;

  sky130_fd_sc_hd__and2_1 U900 ( .A(load_i), .B(data_i), .X(n_ld0) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[0]  ( .CLK(clk), .D(n_ld0), .Q(cfg_q[0]) );
  sky130_fd_sc_hd__or2_1 U1000 ( .A(cfg_q[4]), .B(data_i), .X(d_cfg_q_1) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[1]  ( .CLK(clk), .D(d_cfg_q_1), .Q(cfg_q[1]) );
  sky130_fd_sc_hd__xor2_1 U1001 ( .A(cfg_q[5]), .B(mode_i), .X(d_cfg_q_2) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[2]  ( .CLK(clk), .D(d_cfg_q_2), .Q(cfg_q[2]) );
  sky130_fd_sc_hd__nand2_1 U1002 ( .A(cfg_q[6]), .B(load_i), .Y(d_cfg_q_3) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[3]  ( .CLK(clk), .D(d_cfg_q_3), .Q(cfg_q[3]) );
  sky130_fd_sc_hd__and2_1 U1003 ( .A(cfg_q[7]), .B(data_i), .X(d_cfg_q_4) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[4]  ( .CLK(clk), .D(d_cfg_q_4), .Q(cfg_q[4]) );
  sky130_fd_sc_hd__or2_1 U1004 ( .A(cfg_q[8]), .B(mode_i), .X(d_cfg_q_5) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[5]  ( .CLK(clk), .D(d_cfg_q_5), .Q(cfg_q[5]) );
  sky130_fd_sc_hd__xor2_1 U1005 ( .A(cfg_q[9]), .B(load_i), .X(d_cfg_q_6) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[6]  ( .CLK(clk), .D(d_cfg_q_6), .Q(cfg_q[6]) );
  sky130_fd_sc_hd__nand2_1 U1006 ( .A(cfg_q[10]), .B(data_i), .Y(d_cfg_q_7) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[7]  ( .CLK(clk), .D(d_cfg_q_7), .Q(cfg_q[7]) );
  sky130_fd_sc_hd__and2_1 U1007 ( .A(cfg_q[11]), .B(mode_i), .X(d_cfg_q_8) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[8]  ( .CLK(clk), .D(d_cfg_q_8), .Q(cfg_q[8]) );
  sky130_fd_sc_hd__or2_1 U1008 ( .A(cfg_q[12]), .B(load_i), .X(d_cfg_q_9) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[9]  ( .CLK(clk), .D(d_cfg_q_9), .Q(cfg_q[9]) );
  sky130_fd_sc_hd__xor2_1 U1009 ( .A(cfg_q[13]), .B(data_i), .X(d_cfg_q_10) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[10]  ( .CLK(clk), .D(d_cfg_q_10), .Q(cfg_q[10]) );
  sky130_fd_sc_hd__nand2_1 U1010 ( .A(cfg_q[0]), .B(mode_i), .Y(d_cfg_q_11) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[11]  ( .CLK(clk), .D(d_cfg_q_11), .Q(cfg_q[11]) );
  sky130_fd_sc_hd__and2_1 U1011 ( .A(cfg_q[1]), .B(load_i), .X(d_cfg_q_12) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[12]  ( .CLK(clk), .D(d_cfg_q_12), .Q(cfg_q[12]) );
  sky130_fd_sc_hd__or2_1 U1012 ( .A(cfg_q[2]), .B(data_i), .X(d_cfg_q_13) );
  sky130_fd_sc_hd__dfxtp_1 \cfg_reg[13]  ( .CLK(clk), .D(d_cfg_q_13), .Q(cfg_q[13]) );
  assign cfg_o = cfg_q;
endmodule

// ---- 缺陷 A：本组时钟由 clk_a 与 en_i 经 AND 组合门产生——时钟路径上有组合逻辑：
//      扫描时钟不可控（DRC 报该组 12 条时钟违例），把 clk_a 声明为扫描时钟也无法
//      清零（时钟仍穿过组合门）；en_i=1 时功能上时钟正常 ----
module stat_unit ( clk_a, en_i, data_i, load_i, status_o );
  input        clk_a;   // 功能时钟
  input        en_i;    // 与时钟做组合门控的使能（注入缺陷所在，见 U901）
  input        data_i;
  input        load_i;
  output [11:0] status_o;
  wire  [11:0] st_q;
  wire   nclk_a;     // clk_a & en_i 组合门后的时钟 net，12 个 FF 的当前时钟

  sky130_fd_sc_hd__and2_1 U901 ( .A(clk_a), .B(en_i), .X(nclk_a) );
  sky130_fd_sc_hd__and2_1 U1013 ( .A(st_q[3]), .B(data_i), .X(d_st_q_0) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[0]  ( .CLK(nclk_a), .D(d_st_q_0), .Q(st_q[0]) );
  sky130_fd_sc_hd__or2_1 U1014 ( .A(st_q[4]), .B(load_i), .X(d_st_q_1) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[1]  ( .CLK(nclk_a), .D(d_st_q_1), .Q(st_q[1]) );
  sky130_fd_sc_hd__xor2_1 U1015 ( .A(st_q[5]), .B(data_i), .X(d_st_q_2) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[2]  ( .CLK(nclk_a), .D(d_st_q_2), .Q(st_q[2]) );
  sky130_fd_sc_hd__nand2_1 U1016 ( .A(st_q[6]), .B(load_i), .Y(d_st_q_3) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[3]  ( .CLK(nclk_a), .D(d_st_q_3), .Q(st_q[3]) );
  sky130_fd_sc_hd__and2_1 U1017 ( .A(st_q[7]), .B(data_i), .X(d_st_q_4) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[4]  ( .CLK(nclk_a), .D(d_st_q_4), .Q(st_q[4]) );
  sky130_fd_sc_hd__or2_1 U1018 ( .A(st_q[8]), .B(load_i), .X(d_st_q_5) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[5]  ( .CLK(nclk_a), .D(d_st_q_5), .Q(st_q[5]) );
  sky130_fd_sc_hd__xor2_1 U1019 ( .A(st_q[9]), .B(data_i), .X(d_st_q_6) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[6]  ( .CLK(nclk_a), .D(d_st_q_6), .Q(st_q[6]) );
  sky130_fd_sc_hd__nand2_1 U1020 ( .A(st_q[10]), .B(load_i), .Y(d_st_q_7) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[7]  ( .CLK(nclk_a), .D(d_st_q_7), .Q(st_q[7]) );
  sky130_fd_sc_hd__and2_1 U1021 ( .A(st_q[11]), .B(data_i), .X(d_st_q_8) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[8]  ( .CLK(nclk_a), .D(d_st_q_8), .Q(st_q[8]) );
  sky130_fd_sc_hd__or2_1 U1022 ( .A(st_q[0]), .B(load_i), .X(d_st_q_9) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[9]  ( .CLK(nclk_a), .D(d_st_q_9), .Q(st_q[9]) );
  sky130_fd_sc_hd__xor2_1 U1023 ( .A(st_q[1]), .B(data_i), .X(d_st_q_10) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[10]  ( .CLK(nclk_a), .D(d_st_q_10), .Q(st_q[10]) );
  sky130_fd_sc_hd__nand2_1 U1024 ( .A(st_q[2]), .B(load_i), .Y(d_st_q_11) );
  sky130_fd_sc_hd__dfxtp_1 \status_reg[11]  ( .CLK(nclk_a), .D(d_st_q_11), .Q(st_q[11]) );
  assign status_o = st_q;
endmodule

// ---- 缺陷 B：ICG 的测试使能端 SCE(TE) 被功能组合链占据，扫描态不受控（时钟被关断）----
module pwm_unit ( clk, en_i, mode_i, data_i, pwm_o );
  input        clk;
  input        en_i;
  input        mode_i;
  input        data_i;
  output [15:0] pwm_o;
  wire  [15:0] pwm_q;
  wire   n_en1;    // 功能组合链输出，占据 SCE(TE)（注入缺陷）
  wire   n_enf;    // 功能门控使能（GATE）
  wire   gclk_pwm; // ICG 门控时钟输出

  sky130_fd_sc_hd__sdlclkp_1 clk_gate_pwm ( .CLK(clk), .GATE(n_enf), .SCE(n_en1), .GCLK(gclk_pwm) );
  sky130_fd_sc_hd__and2_1 U903 ( .A(pwm_q[3]), .B(pwm_q[7]), .X(n_en1) );
  sky130_fd_sc_hd__and2_1 U904 ( .A(pwm_q[11]), .B(mode_i), .X(n_enf) );
  sky130_fd_sc_hd__and2_1 U1025 ( .A(pwm_q[3]), .B(en_i), .X(d_pwm_q_0) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[0]  ( .CLK(gclk_pwm), .D(d_pwm_q_0), .Q(pwm_q[0]) );
  sky130_fd_sc_hd__or2_1 U1026 ( .A(pwm_q[4]), .B(data_i), .X(d_pwm_q_1) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[1]  ( .CLK(gclk_pwm), .D(d_pwm_q_1), .Q(pwm_q[1]) );
  sky130_fd_sc_hd__xor2_1 U1027 ( .A(pwm_q[5]), .B(mode_i), .X(d_pwm_q_2) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[2]  ( .CLK(gclk_pwm), .D(d_pwm_q_2), .Q(pwm_q[2]) );
  sky130_fd_sc_hd__nand2_1 U1028 ( .A(pwm_q[6]), .B(en_i), .Y(d_pwm_q_3) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[3]  ( .CLK(gclk_pwm), .D(d_pwm_q_3), .Q(pwm_q[3]) );
  sky130_fd_sc_hd__and2_1 U1029 ( .A(pwm_q[7]), .B(data_i), .X(d_pwm_q_4) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[4]  ( .CLK(gclk_pwm), .D(d_pwm_q_4), .Q(pwm_q[4]) );
  sky130_fd_sc_hd__or2_1 U1030 ( .A(pwm_q[8]), .B(mode_i), .X(d_pwm_q_5) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[5]  ( .CLK(gclk_pwm), .D(d_pwm_q_5), .Q(pwm_q[5]) );
  sky130_fd_sc_hd__xor2_1 U1031 ( .A(pwm_q[9]), .B(en_i), .X(d_pwm_q_6) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[6]  ( .CLK(gclk_pwm), .D(d_pwm_q_6), .Q(pwm_q[6]) );
  sky130_fd_sc_hd__nand2_1 U1032 ( .A(pwm_q[10]), .B(data_i), .Y(d_pwm_q_7) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[7]  ( .CLK(gclk_pwm), .D(d_pwm_q_7), .Q(pwm_q[7]) );
  sky130_fd_sc_hd__and2_1 U1033 ( .A(pwm_q[11]), .B(mode_i), .X(d_pwm_q_8) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[8]  ( .CLK(gclk_pwm), .D(d_pwm_q_8), .Q(pwm_q[8]) );
  sky130_fd_sc_hd__or2_1 U1034 ( .A(pwm_q[12]), .B(en_i), .X(d_pwm_q_9) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[9]  ( .CLK(gclk_pwm), .D(d_pwm_q_9), .Q(pwm_q[9]) );
  sky130_fd_sc_hd__xor2_1 U1035 ( .A(pwm_q[13]), .B(data_i), .X(d_pwm_q_10) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[10]  ( .CLK(gclk_pwm), .D(d_pwm_q_10), .Q(pwm_q[10]) );
  sky130_fd_sc_hd__nand2_1 U1036 ( .A(pwm_q[14]), .B(mode_i), .Y(d_pwm_q_11) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[11]  ( .CLK(gclk_pwm), .D(d_pwm_q_11), .Q(pwm_q[11]) );
  sky130_fd_sc_hd__and2_1 U1037 ( .A(pwm_q[15]), .B(en_i), .X(d_pwm_q_12) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[12]  ( .CLK(gclk_pwm), .D(d_pwm_q_12), .Q(pwm_q[12]) );
  sky130_fd_sc_hd__or2_1 U1038 ( .A(pwm_q[0]), .B(data_i), .X(d_pwm_q_13) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[13]  ( .CLK(gclk_pwm), .D(d_pwm_q_13), .Q(pwm_q[13]) );
  sky130_fd_sc_hd__xor2_1 U1039 ( .A(pwm_q[1]), .B(mode_i), .X(d_pwm_q_14) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[14]  ( .CLK(gclk_pwm), .D(d_pwm_q_14), .Q(pwm_q[14]) );
  sky130_fd_sc_hd__nand2_1 U1040 ( .A(pwm_q[2]), .B(en_i), .Y(d_pwm_q_15) );
  sky130_fd_sc_hd__dfxtp_1 \pwm_reg[15]  ( .CLK(gclk_pwm), .D(d_pwm_q_15), .Q(pwm_q[15]) );
  assign pwm_o = pwm_q;
endmodule

module led_drv ( clk, clk_a, scan_mode, load_i, en_i, mode_i, data_i, cfg_o, status_o, pwm_o, dbg_probe );
  input        clk;        // 时钟（DFT 扫描时钟；u_pwm 门控时钟源）
  input        clk_a;      // u_stat 组的功能时钟（经 U901 与 en_i 组合门控后驱动本组，见缺陷 A）
  input        scan_mode;  // 测试模式选择（网表中暂未被使用，修复时接入 ECO MUX 的 S）
  input        load_i;
  input        en_i;
  input        mode_i;
  input        data_i;
  output [13:0] cfg_o;
  output [11:0] status_o;
  output [15:0] pwm_o;
  input        dbg_probe;  // 调试探针输入（bring-up 阶段遗留）
  wire         dbg_n0, dbg_n1;

  // ---- bring-up 阶段遗留的调试观测逻辑：输出悬空，无任何负载 ----
  sky130_fd_sc_hd__buf_2  U_DBG0 ( .A(dbg_probe), .X(dbg_n0) );
  sky130_fd_sc_hd__xor2_1 U_DBG1 ( .A(dbg_n0), .B(en_i), .X(dbg_n1) );

  cfg_unit u_cfg ( .clk(clk), .load_i(load_i), .data_i(data_i), .mode_i(mode_i), .cfg_o(cfg_o) );
  stat_unit u_stat ( .clk_a(clk_a), .en_i(en_i), .data_i(data_i), .load_i(load_i), .status_o(status_o) );
  pwm_unit u_pwm ( .clk(clk), .en_i(en_i), .mode_i(mode_i), .data_i(data_i), .pwm_o(pwm_o) );
endmodule
