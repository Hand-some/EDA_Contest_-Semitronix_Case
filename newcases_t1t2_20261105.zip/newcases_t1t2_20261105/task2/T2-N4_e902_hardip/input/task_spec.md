# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

对集成了 3 个 AES 加密核的 RISC-V 处理器 `openE902_with_aes_core` 执行 Internal Scan 与 Wrapper Scan 插入。必须在 Dofile 中**原样引用**项目平台模板 `e902_platform.tcl`（不得修改模板文件，也不得拷贝改写），再在其后按本说明书调整。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/lib/sky130_hd.lib` | sky130 HD 标准单元库 |
| `input/lib/aes_cipher_top_liberty.lib` | AES 加密核的时序模型（宏单元，`dont_touch`） |
| `input/netlist/open_aes_core_in_e902.v` | 门级网表（top=`openE902_with_aes_core`），AES 加密核以黑盒形式例化 |
| `input/ctl/aes_cipher_top.ctl` | AES 加密核（模块 `aes_cipher_top`）的内部扫描结构描述 |
| `input/e902_platform.tcl` | 平台统一插链模板（只读） |

## 设计信息

- 处理器时钟 `pll_core_cpuclk`、JTAG 时钟 `pad_had_jtg_tclk`；测试模式信号 `pad_yy_test_mode` 兼作扫描使能
- AES 加密核共 3 个实例：`U_AES_CIPHER_TOP_0`、`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`
- 设计中有大量 ICG，ICG 内部 latch 在 DRC 仿真时会产生 TIE0/TIE1 类提示

## 关于平台模板

模板已完成时钟、扫描使能、CLIC 控制器的扫描排除与回收、70 条内部链与 15 条 wrapper 链的配置，wrapper 默认为 dedicated 风格。模板末尾有一段沿用自早期项目的**端口级 wrapper 例外**配置，本项目不再适用。

## 要求

1. **加密核**：3 个 AES 加密核是已经签核的硬核，芯片级测试时通过各自 CTL 描述的内部扫描链**单独**测试；它们的内部扫描结构不得被顶层 wrapper 复用为 wrapper 单元，也不得被重新组织。请按工具的 IP 机制声明它们。
2. **IP 分组**：测试计划把加密核分为两组，请在设计中登记：
   - `aes_grp_a`：`U_AES_CIPHER_TOP_0`
   - `aes_grp_b`：`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`

   本轮不为各组单独配置 wrapper。
3. **wrapper**：本项目所有端口统一使用 dedicated wrapper，不允许任何端口复用功能寄存器作 wrapper 单元。模板中的端口级例外必须撤销（不能保留后再追加一条相反配置覆盖）。
4. **DRC 提示**：ICG 内部 latch 引起的 TIE0 / TIE1 类提示属于正常现象，按项目规范不作为违例报告；其他规则保持默认。

## 输出要求

- 产物（`output/golden/output/`）：`e902_aes_scan.v`、`e902_aes_scan.ctl`、`e902_aes_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`black_box.rpt`、`dft_ip_group.rpt`、`scan_drc_rule_handling.rpt`、`scan_cfg.rpt`、`wrapper_cfg.rpt`、`wrapper_implementation.rpt`、`scan_signal.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息
