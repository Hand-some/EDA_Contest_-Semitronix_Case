# 插链任务说明书

## 任务目标

> 本任务提供一份存在问题的 `input/original.dofile`。请找出并修复其中的全部问题，使最终 Dofile 满足下述要求。

SPI 控制器 `spi_top` 的插链分两个阶段。第一阶段由其他同事完成：给时钟分频模块 `clgen` 建了一条扫描链，并把工程保存为数据库。本任务是**第二阶段**：直接在该数据库上继续，完成其余部分的插链。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/original.dofile` | 现有的 Scan Insertion Dofile（存在问题，需检查并修复） |
| `input/db/spi_stage1.db` | 第一阶段工程数据库（含库、第一阶段网表、部分扫描信号定义）。**请直接加载该数据库**，不要重新读入库和网表 |
| `input/netlist/spi_top_partial.v` | 第一阶段导出的网表，仅供查阅 |
| `input/lib/sky130.lib` | 标准单元库，仅供查阅 |

## 设计信息

### 端口功能

| 端口 | 功能 |
|---|---|
| `wb_clk_i` | WISHBONE 时钟，全部寄存器的时钟 |
| `wb_rst_i` | 异步复位，高有效 |
| `wb_adr_i[4:0]`、`wb_dat_i[31:0]`、`wb_sel_i[3:0]` | WISHBONE 地址 / 写数据 / 字节选择 |
| `wb_we_i`、`wb_stb_i`、`wb_cyc_i` | WISHBONE 写使能 / 选通 / 周期（数据控制信号） |
| `wb_dat_o`、`wb_ack_o`、`wb_err_o`、`wb_int_o` | WISHBONE 输出 |
| `ss_pad_o`、`sclk_pad_o`、`mosi_pad_o`、`miso_pad_i` | SPI 主接口 |
| `test_se`、`scan_in_clgen`、`scan_out_clgen` | 第一阶段新增的扫描端口 |

- 共 364 个时序单元：`clgen` 内 19 个已替换为扫描单元并串成一条链（`scan_in_clgen` → … → `scan_out_clgen`，使能 `test_se`）；其余 345 个仍为普通 DFF（`dfrtp_1`、`dfstp_2`）

### 第一阶段的遗留情况

- 数据库中的扫描信号定义**未经审核**，请对照上表的端口功能逐项核对，撤销与端口功能不符的定义。
- 第一阶段为调试临时添加过一个**未连接任何逻辑**、名称以 `dbg_` 开头的输入端口，交付前必须从设计中删除。

## 要求

1. 新增输入端口 `test_mode`，插链期间保持为 1。
2. 扫描使能 `test_se`，同时作用于扫描单元与时钟门控，off 态为 0。
3. 第一阶段的 clgen 链必须**原样保留**（不得重新拆分或重新串接），在工具中把它作为已存在的扫描链 `clgen_chain` 标识出来。
4. 其余 DFF 替换为对应扫描 FF；扫描链**总数**为 4 条（含 `clgen_chain`）；不混时钟；插 lockup；新建链的 SI/SO 端口命名为 `scan_data_in_<n>` / `scan_data_out_<n>`。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`，以及插链后的数据库 `post_scan.db`
- 报告（`output/golden/report/`）：`scan_signal_loaded.rpt`（加载数据库后、做任何修改前的信号报告）、`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息
