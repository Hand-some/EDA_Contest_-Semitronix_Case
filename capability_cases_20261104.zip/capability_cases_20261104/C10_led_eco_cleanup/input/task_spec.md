# 插链任务说明书

## 任务目标

对 LED 驱动控制器 `led_drv` 的门级网表执行完整 Scan Insertion，修复其中**位于网表的缺陷**，并**清理 bring-up 阶段遗留的调试观测逻辑**，使扫描 DRC 违例清零。与前几个 public case（缺陷全部在 dofile 配置层）不同，本 case 的违例根因在网表本身：仅调整 dofile 的扫描声明无法清零，必须使用工具提供的**网表编辑（ECO）命令**把修复落到网表（`disconnect_net` / `connect_net` / `add_net` / `add_inst` / `connect_pin`）。

具体工作：

1. **DFF 替换为扫描 FF** — 全部 42 个可扫描 FF 完成替换。
2. **ICG 测试受控** — 时钟门控单元在测试模式下受控，门控时钟在 shift 阶段保持打开。
3. **网表缺陷修复** — 定位违例的网表根因，以 ECO 命令修复。
4. **调试逻辑清理** — 用 ECO 命令删除遗留的调试单元、线网与端口，并整理网表连线。
5. **扫描链构建与插入** — 构建 2 条扫描链，DRC 违例清零。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元时序库 |
| `input/netlist/led_drv.v` | 门级网表（含 2 处网表缺陷，以及一段遗留的调试观测逻辑） |

## 网表说明

### 基本信息

- **设计名称**: led_drv（LED 驱动控制器，教学示例）
- **工艺库**: sky130 HD
- **Top 模块**: led_drv；层次：`u_cfg`（cfg_unit，14 FF）、`u_stat`（stat_unit，12 FF）、`u_pwm`（pwm_unit，16 FF + ICG×1）
- **时序单元**:

| 单元 | 数量 | 说明 | 扫描映射 |
|------|------|------|----------|
| `sky130_fd_sc_hd__dfxtp_1` | 42 | 基本 DFF，无复位 | → `sdfxtp_1` |
| `sky130_fd_sc_hd__sdlclkp_1` | 1 | ICG（`u_pwm/clk_gate_pwm`），测试使能 pin 为 `SCE` | — |

### 时钟结构

主时钟端口 `clk` 为扫描时钟。`u_pwm` 组 FF 的时钟经 ICG 门控（`GCLK`）；`u_stat` 组由独立功能时钟端口 `clk_a` 驱动，其时钟路径存在缺陷（以实际 DRC 报告为准定位）。

### 测试模式信号

| 端口 | 功能 |
|------|------|
| `scan_mode` | 测试模式选择：**1=测试模式，0=功能模式**。当前网表中该端口无负载。**DRC 检查与插链属于测试模式**，须在 dofile 中将其声明为常值 1（`set_scan_signal -type constant -port scan_mode -constant_value 1`），否则网表修复在测试态不可见 |

### 遗留的调试观测逻辑

顶层 `led_drv` 中保留了 bring-up 阶段的调试观测逻辑，量产网表中必须删除：

| 对象 | 类型 | 说明 |
|---|---|---|
| `dbg_probe` | 输入端口 | 调试探针输入 |
| `U_DBG0` | `sky130_fd_sc_hd__buf_2` | `dbg_probe` → `dbg_n0` |
| `U_DBG1` | `sky130_fd_sc_hd__xor2_1` | `dbg_n0`、`en_i` → `dbg_n1`（输出悬空，无负载） |
| `dbg_n0`、`dbg_n1` | 线网 | 调试逻辑内部线网 |

要求：删除上述 2 个单元、2 根线网（**线网必须显式删除**，不能只删单元而把线网留在设计数据库中）和端口 `dbg_probe`，然后执行一次网表连线整理（`rewire`）。该清理在功能上没有任何影响：清理后的 `netlist_fixed.v` 必须与"不含调试逻辑、只做缺陷修复"的网表**形式等价**。

### 其它端口

时钟输入 `clk`（扫描时钟）与 `clk_a`（u_stat 组功能时钟）；功能输入 `load_i` / `en_i` / `mode_i` / `data_i`；功能输出 `cfg_o[13:0]` / `status_o[11:0]` / `pwm_o[15:0]`。

### DFT 控制信号

| 端口 | 功能 |
|------|------|
| `test_se` | 扫描使能端口（新建），需覆盖扫描 FF 与时钟门控（`-usage all`） |

## 修复原则（网表 ECO）

1. **最小修改**：只改动违例根因所在的连接/pin，其余网表结构与单元保留（缺陷处的原有驱动、功能逻辑链不得删除）。
2. **功能态透传**：修复在功能模式（`scan_mode=0`）必须与原网表行为逐拍一致——MUX 选通原连接，不改功能。据此 `original` 与 `netlist_fixed` 在功能态应**顶层等价**（零功能副作用，可形式化验证）。
3. **MUX 接法约定（A/B 统一）**：被修 pin 的原连接（原逻辑）改道接 `A0`，修复引入的测试逻辑接 `A1`，`S=scan_mode`，MUX 输出继续驱动原 net——被修引脚的连接一律不动（不做断开/重连到源）。
4. **禁止绕过**：不得删除/排除任何 FF 使其脱离扫描覆盖；不得用 DRC 规则豁免（`set_scan_drc_rule_handling` 对 DFTR1/DFTR9）消除违例；不得把缺陷改由 dofile 声明（如 `add_pseudo_pi` + 常量）替代网表修复。

## 任务要求

1. 读取标准单元库和门级网表，设置 `led_drv` 为当前设计。
2. 指定 DFF→SFF 映射（`dfxtp_1` → `sdfxtp_1`）。
3. 扫描时钟配置为 `clk`（`-off_state 0`）。
4. 扫描使能新建端口 `test_se`，`-usage all` 覆盖扫描 FF 与 ICG；`scan_mode` 声明常值 1。
5. 构建 **2 条扫描链**（单时钟域 `clk`）。
6. 执行 DRC 检查，按上述修复原则用 ECO 命令修复网表缺陷，直至 **DRC 违例为 0、42 个 FF 全部替换并入链**。
7. 按上文要求清理调试逻辑（在导出 `netlist_fixed.v` 之前完成）。
8. 导出 ECO 后、插链前的网表 `netlist_fixed.v` 与插链后网表 `post_scan.v`。
9. TIE 类规则（`DFTR-TIE0`、`DFTR-TIE1`，ICG 内部 latch 引起）按项目规范设为 Ignore；DFTR1/DFTR9 不得豁免。

## 输出要求

- 产物（`output/golden/output/`）：`netlist_fixed.v`、`post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；2 条链共 42 个 FF
- `netlist_fixed.v` 中不含 `U_DBG0`、`U_DBG1`、`dbg_n0`、`dbg_n1`、`dbg_probe`
- `netlist_fixed.v` 与"原网表去掉调试逻辑后只做缺陷修复"的参考网表形式等价

## 原始输出清单（沿用官方 case6）

- 满足任务要求的修改后 dofile
- ECO 后插链前网表（`netlist_fixed.v`，Verilog 格式）
- 插链后网表（Verilog 格式）
- DRC 报告
- 扫描链报告
- 扫描链上单元明细报告
- scan insertion 工具每一轮的完整运行日志
- Agent 系统执行摘要与决策记录
