# 插链任务说明书

## 任务目标

对 ISCAS'89 基准电路 `s13207` 的门级网表执行完整 Scan Insertion。网表中残留了一段调试观测逻辑，插链前需要先用 ECO 命令清理，并交付清理后、插链前的网表供形式验证：

1. 读取库与网表；
2. 用 ECO 命令删除遗留的调试单元、线网和端口，并整理网表连线；
3. 导出清理后的网表 `netlist_fixed.v`；
4. 完成扫描配置、DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/s13207.v` | 门级网表（pre-scan，top=`s13207`，单层平铺） |

## 设计信息

- 单时钟 `CK`，无复位；638 个 `sky130_fd_sc_hd__dfxtp_1`
- 遗留的调试观测逻辑（位于顶层，输出悬空、无任何负载）：

| 对象 | 类型 | 说明 |
|---|---|---|
| `dbg_sel` | 输入端口 | 调试选择输入 |
| `U_DBG_A` | `sky130_fd_sc_hd__buf_1` | `dbg_sel` → `dbg_w0` |
| `U_DBG_B` | `sky130_fd_sc_hd__inv_1` | `dbg_w0` → `dbg_w1` |
| `U_DBG_C` | `sky130_fd_sc_hd__nand2_1` | `dbg_w1`、`g1` → `dbg_w2`（悬空） |
| `dbg_w0`、`dbg_w1`、`dbg_w2` | 线网 | 调试逻辑内部线网 |

## 配置要求

1. **网表清理**：删除上述 3 个单元、3 根线网（线网必须显式删除，不能只删单元把线网留在设计数据库中）以及端口 `dbg_sel`，然后执行一次网表连线整理（`rewire`）。清理后立即导出 `netlist_fixed.v`。清理不得改变电路功能：`netlist_fixed.v` 必须与原始网表（去掉 `dbg_sel` 端口后）形式等价。
2. 扫描时钟 `CK`（off_state 0）；scan_enable 为新端口 `test_se`（`-usage all`，off_state 0）。
3. DFF 替换：`dfxtp_1` → `sdfxtp_1`。
4. 扫描分区 `main_partition`（`-clocks {CK}`），4 条链，max_length 300，不混时钟/边沿，插 lockup；SI/SO 命名 `scan_data_in_%d` / `scan_data_out_%d`。

## 输出要求

- 产物（`output/golden/output/`）：`netlist_fixed.v`、`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；4 条链共 638 个 FF
- `netlist_fixed.v` 中不含 `U_DBG_A/B/C`、`dbg_w0/1/2`、`dbg_sel`
- `netlist_fixed.v` 与原始网表形式等价
