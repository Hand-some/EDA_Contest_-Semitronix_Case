# 插链任务说明书

## 任务目标

对 3DES 加密核 `des3` 执行 Internal Scan 与 Wrapper Scan 插入。必须**原样引用**平台模板 `des_platform.tcl`（其中已含全部 scan segment 定义），再按本说明书调整 wrapper 配置：

1. 引用平台模板（不得修改模板文件，也不得把其内容拷贝改写进 Dofile）；
2. 撤销模板中对 `key1` 端口和 4 个输入寄存器的特殊处理；
3. `key3` 端口改用工具内建的 WC_D1 型 dedicated wrapper cell，并指定其内部 MUX、DFF 所用的库单元；
4. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/des_perf.v` | 3DES 核门级网表（top=`des3`） |
| `input/netlist/dedicated_wrp_cell.v` | 用户自定义 dedicated wrapper cell `dedicated_wrp_cell` |
| `input/des_platform.tcl` | 平台统一插链模板（只读，需在 Dofile 中 `source`） |

## 设计信息

- 顶层 `des3`，时钟 `clk`；scan_enable 复用 `decrypt`；wrapper 控制端口 `wrapper_in_shift_en` / `wrapper_out_shift_en` / `wrapper_in_cap_en` / `wrapper_out_cap_en`
- 输入 `desIn[63:0]` 由 `u0/desIn_r_reg[*]` 寄存；密钥输入 `key1`、`key2`、`key3` 各 56 位，后级是移位寄存器（已由模板声明为 scan segment）

## 平台模板的内容（摘要）

全局 scan_cfg、wrapper 信号、用户自定义 dedicated cell 类型、全局 shared 风格 wrapper（WC_S1）、280 个 scan segment，以及按端口的 wrapper 策略：`key1` 不插 wrapper（none），`key2` 使用用户自定义 dedicated cell，`key3` 使用 shared WC_S1。模板末尾还把 `u0/desIn_r_reg[0]`~`[3]` 排除在 shared wrapper 之外。

## 调整要求

1. **key1**：本项目 `key1` 需要 wrapper 隔离。撤销模板中对 `key1` 全部 56 位的端口级配置，使其回到全局 wrapper 规则（由工具按后级结构选择 wrapper 方式）。
2. **desIn_r_reg[0..3]**：功能 bypass 已取消，撤销模板对这 4 个寄存器的排除，使 `desIn[0]`~`desIn[3]` 与其他输入一样复用寄存器作 shared wrapper cell。
3. **key3**：改用工具内建的 **WC_D1** 型 dedicated wrapper cell。WC_D1 内部的库单元指定为：
   - MUX：`sky130_fd_sc_hd__mux2_2`（选择端 `S`，数据 `A0`、`A1`，输出 `X`）
   - DFF：`sky130_fd_sc_hd__dfxtp_2`（时钟 `CLK`，数据 `D`，输出 `Q`）
4. `key2` 保持模板配置（用户自定义 dedicated cell）。

> 撤销必须通过撤销模板中的对应配置完成，不能靠在后面追加一条相反的配置来覆盖。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`scan_segment.rpt`、`wrapper_cfg.rpt`、`wrapper_implementation.rpt`、`dedicated_wrapper_cell_type.rpt`、`scan_cell_selection.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；106 条内部链、3 条 wrapper 链
- wrapper_implementation：`key1` 56 位均为 dedicated（不再是 none）；`key2` 为 user_defined；`key3` 为 WC_D1；`desIn[0]`~`[3]` 为 shared，使用 `u0/desIn_r_reg[0]`~`[3]`
- 插链后网表中 WC_D1 由 `mux2_2`、`dfxtp_2` 实现（112 个 `dfxtp_2`）
