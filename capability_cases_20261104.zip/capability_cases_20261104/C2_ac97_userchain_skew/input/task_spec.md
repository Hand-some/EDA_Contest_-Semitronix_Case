# 插链任务说明书

## 任务目标

对 AC97 音频控制器 `ac97_top` 的门级网表执行完整 Scan Insertion。项目组共用的平台模板 `ac97_platform.tcl` 必须**原样引用**，在其后按本设计要求调整：

1. 引用平台模板（不得修改模板文件，也不得把其内容拷贝改写进 Dofile）；
2. 撤销模板中仅用于调试的扫描链；
3. 合并两个 SERDES 分区；
4. 为 Codec 同步控制器建立一条使用专用端口的用户自定义扫描链，并按 skew 组处理其内部的跨时钟拼接；
5. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元时序库 |
| `input/netlist/ac97_ctrl.v` | 综合后门级网表（pre-scan，top=`ac97_top`） |
| `input/ac97_platform.tcl` | 平台统一插链模板（只读，需在 Dofile 中 `source`） |

## 设计信息

- 顶层 `ac97_top`，共 2,229 个可扫描 FF
- 时钟：`clk_i`（系统 / WISHBONE 时钟）、`bit_clk_pad_i`（AC97 串行位时钟）；复位 `rst_i` 低有效
- 主要子模块实例：

| 实例 | 模块 | FF 数 | 说明 |
|---|---|---|---|
| `u0` | ac97_sout | 196 | 串行输出（TX SERDES） |
| `u1` | ac97_sin | 137 | 串行输入（RX SERDES） |
| `u2` | ac97_soc | 35 | Codec 同步控制器，内部同时含 `clk_i` 与 `bit_clk_pad_i` 两个时钟域的 FF |
| `u3`~`u8` | ac97_out_fifo | 6×158 | 输出 FIFO |
| `u9`~`u11` | ac97_in_fifo | 3×187 | 输入 FIFO |
| `u12` | ac97_wb_if | 79 | WISHBONE 接口 |
| `u13` | ac97_rf | 157 | 寄存器堆 |

- 设计中有 1 处时钟接到触发器数据端（DFTR10），属于设计固有结构，**允许保留**；其余 DRC 必须为 0。

## 平台模板的内容（摘要）

模板完成了时钟/复位声明、全局 scan_cfg（lockup、替换、`scan_data_in_%d` / `scan_data_out_%d` 命名）、7 个分区（`rx_fifo` / `tx_fifo` / `rx_serdes` / `tx_serdes` / `reg` / `wb` / `ctrl`）及各自的链数、链长和 scan_enable，并在末尾为寄存器堆 `u13` 建了一条调试用的用户链 `dbg_chain`。

## 调整要求

1. **撤销调试链**：`dbg_chain` 只在模板调试阶段使用，正式插链必须移除，`u13` 回到 `reg_partition` 由工具自动建链。
2. **合并 SERDES 分区**：移除 `rx_serdes_partition` 与 `tx_serdes_partition`，新建 `serdes_partition`（包含 `u0`、`u1`），2 条链，max_length 300，允许混时钟，scan_enable 为 `se_serdes`。
3. **Codec 同步控制器专用链**：
   - `u2` 的全部 FF 组成一条用户自定义链 `soc_chain`；
   - 该链使用新增的专用端口：扫描输入 `si_soc`、扫描输出 `so_soc`（网表中原本没有这两个端口，需要新建），scan_enable 使用 `se_ctrl`；
   - `u2` 内两个时钟在测试模式下由同一测试时钟驱动，链内跨时钟处**不插 lockup**：把 `u2` 声明为一个 scan skew group（组名 `soc_skew`）。
4. 其余分区沿用模板。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`，以及 `ac97.ctl`、`ac97.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`scan_partition.rpt`
- 在日志中打印工具版本信息

## 验收要点

- DRC 仅 1 个 DFTR10；2,229 个 FF 全部上链
- 不存在 `dbg_chain`、`rx_serdes_partition`、`tx_serdes_partition`
- `soc_chain` 为 user_defined，含 35 个 FF，SI/SO 为 `si_soc` / `so_soc`，链内无 lockup
