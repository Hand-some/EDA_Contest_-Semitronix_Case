# 插链任务说明书

## 任务目标

对 RISC-V 处理器核 `picorv32` 的门级网表执行完整 Scan Insertion。必须**原样引用**项目平台模板 `pico_platform.tcl`，再按本说明书调整：

1. 引用平台模板（不得修改模板文件，也不得把其内容拷贝改写进 Dofile）；
2. 移除模板中的调试链；
3. 为程序计数器建立一条固定顺序的扫描链，使用专用端口并在链尾插入 lockup；
4. 为工具自动生成的扫描链插入 scan-out 重定时寄存器；
5. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元时序库 |
| `input/netlist/pre_scan.v` | 综合后门级网表（pre-scan，top=`picorv32`） |
| `input/pico_platform.tcl` | 平台统一插链模板（只读，需在 Dofile 中 `source`） |

## 设计信息

- 顶层 `picorv32`，单时钟 `clk`，共 1,610 个 `sky130_fd_sc_hd__dfxtp_1`，无异步复位
- 程序计数器寄存器 `reg_pc_reg[31]` ~ `reg_pc_reg[0]`（32 个）
- 性能计数器 `count_cycle_reg[63:0]`（64 个）

## 平台模板的内容（摘要）

DFF→SFF 映射、时钟 `clk`、scan_enable `test_se`（`-usage all`）、全局 4 条链；末尾把 `count_cycle_reg*` 建成了一条调试用的用户链 `dbg_cycle_cnt`。

## 调整要求

1. **移除调试链** `dbg_cycle_cnt`，性能计数器回到普通链中由工具自动分配。
2. **程序计数器有序链** `pc_chain`：
   - 成员为 `reg_pc_reg[31]` ~ `reg_pc_reg[0]`，**扫描移位顺序固定为从 bit31 到 bit0**（bit31 最靠近扫描输入）；
   - 使用新建的专用端口：扫描输入 `si_pc`、扫描输出 `so_pc`（网表原本没有这两个端口）；scan_enable 为 `test_se`；
   - 链尾插入 terminal lockup latch。
3. 总链数保持 4 条（含 `pc_chain`）。
4. **重定时**：在顶层 `picorv32` 为工具生成的扫描链插入 scan-out 重定时寄存器（边沿取工具默认值）。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- DRC 为 0；1,610 个 FF 全部上链，共 4 条链
- 不存在 `dbg_cycle_cnt`
- `pc_chain` 为 user_defined，32 个 FF，首位 `reg_pc_reg[31]`、末位 `reg_pc_reg[0]`，末尾有 1 个 lockup
- 网表中有 3 个 `U_SCAN_RETIMING_*` 重定时寄存器
