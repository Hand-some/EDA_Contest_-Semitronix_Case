# 插链任务说明书

## 任务目标

对集成了 3 个 AES 加密黑盒的 RISC-V 处理器 `openE902_with_aes_core` 执行 Internal Scan 与 Wrapper Scan 插入。必须**原样引用**平台模板 `e902_platform.tcl`，再按本说明书调整：

1. 引用平台模板（不得修改模板文件，也不得把其内容拷贝改写进 Dofile）；
2. 将 3 个 AES 黑盒声明为 hard IP，并按测试计划登记 IP 分组；
3. 撤销模板中不适用于本项目的 wrapper 端口配置；
4. 按项目规范处理 TIE 类 DRC 规则；
5. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130_hd.lib` | sky130 HD 标准单元库 |
| `input/lib/aes_cipher_top_liberty.lib` | AES Cipher Top 的黑盒时序模型（`is_macro_cell`、`dont_touch`） |
| `input/netlist/open_aes_core_in_e902.v` | 门级网表（pre-scan，top=`openE902_with_aes_core`） |
| `input/ctl/aes_cipher_top.ctl` | AES Cipher Top 内部扫描链描述（CTL，模块 `aes_cipher_top`） |
| `input/e902_platform.tcl` | 平台统一插链模板（只读，需在 Dofile 中 `source`） |

## 设计信息

- 时钟 `pll_core_cpuclk`、`pad_had_jtg_tclk`；scan_enable 复用 `pad_yy_test_mode`
- 3 个 AES 黑盒实例：`U_AES_CIPHER_TOP_0`、`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`（均为 `aes_cipher_top`，内部扫描结构由 CTL 描述）

## 平台模板的内容（摘要）

时钟与 scan_enable 声明、CLIC 控制器的扫描排除 / 回收、dedicated 风格 wrapper（15 条 wrapper 链，链长 100）、70 条内部链（混时钟，链长 100）；末尾把中断类输入 `pad_cpu_nmi`、`pad_cpu_ext_int_b`、`pad_cpu_wakeup_event` 配置成了 shared 风格 wrapper（复用功能寄存器）。

## 调整要求

1. **hard IP**：3 个 AES 黑盒都是已验证的硬核，必须声明为 hard IP，其内部扫描结构**不得**被当作 wrapper 单元复用进顶层 wrapper 链。
2. **IP 分组登记**：按测试计划把黑盒登记为两组，供后续 ATPG 分组使用：
   - `aes_grp_a`：`U_AES_CIPHER_TOP_0`
   - `aes_grp_b`：`U_AES_CIPHER_TOP_1`、`U_AES_CIPHER_TOP_2`
   本轮不为分组单独配置 wrapper，沿用全局 wrapper 配置。
3. **wrapper 端口**：本项目所有端口统一使用 dedicated wrapper，必须撤销模板中 3 个中断输入的 shared 配置（不能在模板之后再写一条覆盖配置了事）。
4. **DRC 规则**：按项目规范，`DFTR-TIE0`、`DFTR-TIE1` 两条规则设为 Ignore。

## 输出要求

- 产物（`output/golden/output/`）：`e902_aes_scan.v`、`e902_aes_scan.ctl`、`e902_aes_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`black_box.rpt`、`dft_ip_group.rpt`、`scan_drc_rule_handling.rpt`、`scan_cfg.rpt`、`wrapper_cfg.rpt`、`scan_signal.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；内部链 55 条、wrapper 链 15 条
- insertion_info 中 Shared Wrapper Cell Count 为 0（`-`），Wrapper Chain Cell Count 为 594
- `dft_ip_group.rpt` 中有 `aes_grp_a`、`aes_grp_b` 两组；`scan_drc_rule_handling.rpt` 中两条 TIE 规则为 Ignore
