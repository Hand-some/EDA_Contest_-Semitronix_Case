# 插链任务说明书

## 任务目标

对以太网 MAC 核 `eth_top` 的门级网表执行完整 Scan Insertion。项目组有一份各项目共用的平台插链模板 `eth_platform.tcl`，本次插链必须**原样引用**该模板，再根据本设计的实际情况在其后做调整：

1. 引用平台模板（不得修改模板文件本身，也不得把其内容拷贝改写进 Dofile）；
2. 纠正模板中对本设计不适用的信号声明，按本说明书重新划分扫描分区；
3. TX / RX 两个 MAC 时钟视为同一 skew 组，处理跨时钟混链；
4. 指定 lockup latch 使用的库单元；
5. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/stdcells.lib` | sky130 HD 标准单元时序库 |
| `input/netlist/ethernet_sky130.v` | 综合后的门级网表（pre-scan，top=`eth_top`） |
| `input/eth_platform.tcl` | 平台统一插链模板（只读，需在 Dofile 中 `source`） |

## 设计信息

- 顶层：`eth_top`，约 10,500 个可扫描 FF
- 时钟：`wb_clk_i`（WB 域，约 10,000 FF）、`mtx_clk_pad_i`（TX 域，约 231 FF）、`mrx_clk_pad_i`（RX 域，约 297 FF）
- 复位：`wb_rst_i`，高有效
- `mcoll_pad_i`、`mcrs_pad_i` 是 MII 接口的冲突检测 / 载波侦听**数据输入**，不是时钟
- 设计中有 21 处时钟直接接到触发器数据端（DFTR10），属于设计固有结构，本任务**允许保留**这 21 个 DFTR10，其余 DRC 必须为 0

## 平台模板的内容（摘要）

模板已经完成：DFF→SFF 映射、三个时钟和复位的声明、全局 `-internal_clocks multi -add_lockup true -mix_edges false`、TIE1 规则忽略，以及按时钟划分的 `wb_partition` / `tx_partition` / `rx_partition` 三个分区（各自的链数、链长和 scan_enable）。

但模板是按通用以太网项目写的，**把 `mcoll_pad_i` 也声明成了时钟**，这在本设计中是错误的，需要撤销该声明。

## 扫描分区要求

| 分区 | 划分 | chain_count | max_length | scan_enable | 其他 |
|---|---|---|---|---|---|
| `wb_partition` | `wb_clk_i` | 34 | 300 | `se_wb` | 沿用模板，不改 |
| `mac_partition` | `mtx_clk_pad_i`、`mrx_clk_pad_i` | 2 | 300 | `se_mac` | 允许 TX/RX 混链；每条链末端插入 terminal lockup |

- 模板中的 `tx_partition`、`rx_partition` 不再使用，必须从配置中移除（不能只是闲置）。
- 默认分区的 scan_enable 仍为 `test_se`（模板已配置）。

## 时钟混链与 lockup

- 测试模式下 `mtx_clk_pad_i` 与 `mrx_clk_pad_i` 由同一测试时钟驱动，二者之间**不需要** lockup latch：请将这两个时钟声明为同一个 scan skew group（组名 `mac_skew`）。
- 本项目 lockup latch 统一使用 `sky130_fd_sc_hd__dlxtn_2`（低电平透明 latch，使能端 `GATE_N`、数据 `D`、输出 `Q`）。

## 输出要求

- 插链后网表：`output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_partition.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`scan_cell_selection.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- DRC 只剩 21 个 DFTR10；
- 分区只有 `wb_partition`、`mac_partition`（及默认分区）；`mcoll_pad_i` 不再是扫描信号；
- `mac_partition` 2 条链，链中不含跨 TX/RX 的 lockup，链尾 lockup 为 `dlxtn_2`；`wb_partition` 34 条链。
