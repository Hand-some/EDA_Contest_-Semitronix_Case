# 插链任务说明书

## 任务目标

对一个小型 SoC `spi_aes_soc`（SPI 控制器 + 2 个 AES 加密硬核）执行 Internal Scan 插入：

1. 读取标准单元库、AES 黑盒模型、两份网表文件以及 AES 的 CTL；
2. 将 2 个 AES 硬核声明为 hard IP 并登记为一个 IP 组；
3. 为顶层扫描链插入扫描输入端重定时寄存器；
4. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/lib/aes_cipher_top_liberty.lib` | AES Cipher Top 黑盒时序模型 |
| `input/netlist/spi_top.v` | SPI 控制器门级网表（模块 `spi_top` 及其子模块） |
| `input/netlist/spi_aes_soc.v` | SoC 顶层（top=`spi_aes_soc`），例化 `u_spi` 与 `U_AES_0`、`U_AES_1` |
| `input/ctl/aes_cipher_top.ctl` | AES Cipher Top 内部扫描链描述（CTL，模块 `aes_cipher_top`） |

## 设计信息

- 顶层端口与 `spi_top` 相同；时钟 `wb_clk_i`，复位 `wb_rst_i`（高有效）
- SPI 部分共 364 个可扫描 FF（`dfrtp_1`、`dfstp_2`）
- `U_AES_0`、`U_AES_1` 为 AES 硬核黑盒，内部已有扫描链（见 CTL），由 `wb_clk_i` 驱动

## 配置要求

1. scan_enable 为新端口 `test_se`（`-usage all`，off_state 0）；时钟 off_state 0，复位 off_state 0。
2. 4 条扫描链，max_length 200，不混时钟，插 lockup，DFF 替换为 SFF；SI/SO 端口命名 `scan_data_in_%d` / `scan_data_out_%d`。
3. **hard IP**：2 个 AES 硬核声明为 hard IP。它们的内部扫描链在芯片级单独测试，**不得**拼入顶层扫描链；顶层链只包含 SPI 的 364 个 FF。
4. **IP 分组**：2 个硬核登记为同一个 IP 组 `aes_grp`（顺序 `U_AES_0`、`U_AES_1`）。
5. **重定时**：在顶层 `spi_aes_soc` 插入扫描链重定时寄存器；链首单元按下降沿、链尾单元按上升沿处理（即在扫描输入端插入下降沿重定时寄存器）。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`black_box.rpt`、`dft_ip_group.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；4 条链，每条 91 个单元，insertion_info 中 Scan Chain Cell Bit Count 为 364（AES 内部链未拼入）
- 网表中有 `U_SCAN_RETIMING_1_SI` ~ `U_SCAN_RETIMING_4_SI` 4 个下降沿重定时寄存器
- `dft_ip_group.rpt` 中 `aes_grp` 含 `U_AES_0`、`U_AES_1`
