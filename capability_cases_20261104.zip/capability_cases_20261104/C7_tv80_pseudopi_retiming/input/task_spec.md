# 插链任务说明书

## 任务目标

对 Z80 兼容处理器 `tv80s` 的门级网表执行完整 Scan Insertion：

1. 处理三级级联 ICG 的 DRC 初始化；
2. 把闩锁传出的内部时钟声明为 pseudo primary input，并作为扫描时钟受控；
3. 将闩锁排除出扫描元素；
4. 在 CPU 核层次内为全部扫描链插入首尾重定时寄存器；
5. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | sky130 HD 标准单元库 |
| `input/netlist/tv80.v` | 门级网表（pre-scan，top=`tv80s`，CPU 核实例 `i_tv80_core`） |

## 设计信息

- 主时钟 `clk`，测试时 off_state 为 1
- 36 个 ICG（`SNPS_CLOCK_GATE_HIGH_*`，内部 `sdlclkp_1`），部分三级级联：下级 ICG 的 CLK 由上级 ENCLK 驱动
- `scan_cg_en`：时钟门控旁路端口，扫描模式下使能全部 ICG，同时作为 scan_enable
- 闩锁 `u_clk_latch`（`sky130_fd_sc_hd__dlxtp_1`）：D 接 `clk`，其输出 `u_clk_latch/Q` 驱动一部分寄存器的时钟。工具无法自动推导该时钟，不处理时 DRC 会报 4 个 DFTR1（时钟不受控）
- 共 359 个可扫描 FF

## 配置要求

1. DRC 时钟门控初始化周期设为 2（保证三级级联 ICG 的使能能传播到底）。
2. **闩锁时钟**：本项目规定用 pseudo PI 方式处理——将内部引脚 `u_clk_latch/Q` 声明为 pseudo primary input，并把它声明为扫描时钟（off_state 1）。不要使用 `-associated_internal_clocks` 关联方式。
3. `clk` 声明为扫描时钟（off_state 1）；`scan_cg_en` 为 scan_enable。
4. 扫描链：max_length 100，不按内部时钟分链（`-internal_clock none`），允许混合时钟沿，插 lockup；SI/SO 端口命名 `scan_si_%d` / `scan_so_%d`。
5. `u_clk_latch` 不作为扫描元素。
6. **重定时**：重定时寄存器放在 CPU 核实例 `i_tv80_core` 层次内；链首、链尾都按上升沿处理；首尾重定时寄存器的时钟都指定为 `clk`。

## 输出要求

- 插链后网表 `output/golden/output/post_scan.v`
- 报告（`output/golden/report/`）：`drc.rpt`、`pseudo_pi.rpt`、`insertion_info.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_cfg.rpt`、`scan_signal.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；5 条链共 359 个 FF
- `pseudo_pi.rpt` 中有 `u_clk_latch/Q`；scan_signal 中 `u_clk_latch/Q` 为 pseudo 端口、类型 clock
- 网表中 `tv80_core` 模块内有 10 个 `U_SCAN_RETIMING_*`（每条链首尾各一个），时钟接 `clk`
