# 插链任务说明书

## 任务目标

SPI 控制器 `spi_top` 的插链分两个阶段进行。第一阶段已经由其他同事完成：给时钟分频模块 `clgen` 建好了一条扫描链，并把工程保存成了数据库。本任务是**第二阶段**：在该数据库基础上完成其余部分的插链。

1. 直接加载第一阶段的工程数据库，不要重新读取库和网表；
2. 清理第一阶段遗留的错误配置和调试端口；
3. 新增测试模式端口；
4. 识别已有的 `clgen` 扫描链并保留，为其余触发器建链；
5. 执行 DRC、插链并导出结果（含插链后的数据库）。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/db/spi_stage1.db` | 第一阶段工程数据库（已含标准单元库、部分插链后的网表和部分扫描信号定义） |
| `input/netlist/spi_top_partial.v` | 第一阶段导出的网表，仅供查阅（与数据库中的设计一致） |
| `input/lib/sky130.lib` | sky130 HD 标准单元库，仅供查阅（已包含在数据库中） |

## 设计信息

- 顶层 `spi_top`；时钟 `wb_clk_i`；复位 `wb_rst_i` 高有效（off_state 0）
- 共 364 个时序单元：`clgen` 内 19 个已在第一阶段替换为扫描单元并串成一条链；其余 345 个仍为普通 DFF（`dfrtp_1`、`dfstp_2`）
- 第一阶段已添加的端口：`test_se`（扫描使能）、`scan_in_clgen` / `scan_out_clgen`（clgen 链的扫描输入 / 输出）
- 已有的 clgen 链：`scan_in_clgen` → clgen 内 19 个 SFF → `scan_out_clgen`，使能 `test_se`

## 数据库中的遗留问题

1. 数据库里的扫描信号定义包括 `wb_clk_i`（时钟）、`wb_rst_i`（复位），还有一条**错误**的时钟定义：`wb_we_i` 被误声明为时钟（它是 WISHBONE 写使能，不是时钟），必须撤销；
2. 第一阶段为调试临时加了一个输入端口 `dbg_unused`，未连接任何逻辑，交付前必须从设计中删除。

## 配置要求

1. 新增输入端口 `test_mode`，插链期间保持常量 1。
2. scan_enable 为 `test_se`（`-usage all`，off_state 0）。
3. 已有链必须**按原样保留**：把它标识为一条已存在的扫描链，链名 `clgen_chain`，扫描输入 `scan_in_clgen`、扫描输出 `scan_out_clgen`、使能 `test_se`。不得重新拆分或重新串接 clgen 的 19 个单元。
4. DFF 替换为 SFF：`dfrtp_1`→`sdfrtp_1`，`dfstp_2`→`sdfstp_2`。
5. 扫描链总数 4 条（**含**已有的 `clgen_chain`），不混时钟，插 lockup；新建链的 SI/SO 端口命名为 `scan_data_in_%d` / `scan_data_out_%d`。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`，以及插链后的数据库 `post_scan.db`
- 报告（`output/golden/report/`）：`scan_signal_loaded.rpt`（加载数据库后、修改前的信号报告）、`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；4 条链共 364 个单元
- `clgen_chain` 为 pre_existing，19 个单元，SI/SO 为 `scan_in_clgen` / `scan_out_clgen`；其余 3 条链各 115 个单元
- 最终信号报告中没有 `wb_we_i`，`test_mode` 为 constant 1；插链后网表中没有 `dbg_unused`
