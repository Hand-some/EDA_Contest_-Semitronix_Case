"""消融：逐条删掉 golden 里被验证的命令，确认检查随之失败（证明检查确实依赖该命令）。

用法（在 _capability_cases 目录下）：python tools/ablate.py
结果写入 ablate_result.json。
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import verify_all as V  # noqa: E402
from cap import run  # noqa: E402

ROOT = V.ROOT

# 用例 -> 要消融的命令（按行首命令名删除整条命令，含反斜杠续行）
TARGETS = {
    "C1_eth_skew_lockup": ["remove_scan_signal", "remove_scan_partition", "set_scan_skew_grp", "set_scan_cell_selection"],
    "C2_ac97_userchain_skew": ["remove_scan_chain", "remove_scan_partition", "add_scan_chain", "set_scan_skew_grp"],
    "C3_pico_ordered_retiming": ["remove_scan_chain", "add_scan_chain", "set_scan_chain_retiming"],
    "C4_e902_hardip_wrapper": ["define_dft_ip", "define_dft_ip_group", "remove_wrapper_cfg", "set_scan_drc_rule_handling"],
    "C5_soc_hardip_retiming": ["define_dft_ip", "define_dft_ip_group", "set_scan_chain_retiming"],
    "C6_des3_wrapper_cells": ["remove_wrapper_cfg -port", "remove_wrapper_cfg -exclude", "set_scan_cell_selection"],
    "C7_tv80_pseudopi_retiming": ["add_pseudo_pi", "set_scan_chain_retiming"],
    "C8_spi_incremental": ["set_scan_chain", "remove_scan_signal", "delete_port", "add_port"],
    "C9_usb_db_existing_chain": ["set_scan_chain", "add_port"],
    "C10_led_eco_cleanup": ["delete_inst", "delete_port"],
    "C11_s13207_eco_cleanup": ["delete_inst", "delete_port"],
}


def drop(text: str, cmd: str) -> tuple[str, int]:
    lines, out, n, skip = text.splitlines(), [], 0, False
    pat = re.compile(rf"^\s*{re.escape(cmd)}(\s|$)")
    for l in lines:
        if skip:
            skip = l.rstrip().endswith("\\")
            continue
        if pat.match(l):
            n += 1
            skip = l.rstrip().endswith("\\")
            continue
        out.append(l)
    return "\n".join(out) + "\n", n


def main() -> int:
    res = {}
    for case, cmds in TARGETS.items():
        for cmd in cmds:
            # 每项消融用独立目录：同一路径删了马上重建，Docker Desktop 偶尔挂载失败
            work = ROOT / "_work" / "ablate" / case / re.sub(r"\W+", "_", cmd).strip("_")
            if work.exists():
                shutil.rmtree(work, ignore_errors=True)
            shutil.copytree(ROOT / case / "input", work / "input", symlinks=True)
            g, n = drop((ROOT / case / "input/golden.dofile").read_text(), cmd)
            (work / "input/golden.dofile").write_text(g)
            for _ in range(3):
                r = run(work / "input", "golden.dofile", work / "output")
                if "ScanInsertion version" in r["log"]:   # 工具确实运行了
                    break
            else:
                res[f"{case} / -{cmd}"] = dict(removed_lines=n, detected=None, note="工具未能运行：" + r["log"][-200:])
                print(f"无效  {case:28} 删 {cmd:28} 工具未能运行", flush=True)
                continue
            # 复用 verify_all 的检查，读消融副本的输出
            V.OUT[case] = work / "output" / "golden"
            try:
                items = V.checks(case)
            finally:
                V.OUT.pop(case)
            exp = V.SPEC[case]
            drc_changed = r["drc"] != exp["drc"]
            failed = [f"{a}: {b}" for a, b, ok in items if not ok]
            detected = bool(failed or r["errors"] or drc_changed)
            res[f"{case} / -{cmd}"] = dict(removed_lines=n, detected=detected, errors=len(r["errors"]),
                                           drc=r["drc"], failed_checks=failed)
            why = "; ".join(failed[:2]) or (f"ERROR={len(r['errors'])}" if r["errors"] else f"DRC {exp['drc']}→{r['drc']}" if drc_changed else "")
            print(f"{'检出' if detected else '未检出'}  {case:28} 删 {cmd:28} ({n} 条)  {why[:110]}", flush=True)
    (ROOT / "ablate_result.json").write_text(json.dumps(res, ensure_ascii=False, indent=1))
    miss = [k for k, v in res.items() if not v["detected"]]
    print(f"\n{len(res) - len(miss)}/{len(res)} 项消融被检出" + (f"；未检出：{miss}" if miss else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
