"""从干净状态重跑全部能力用例的 golden.dofile，逐条核对说明书中的验收要点。

用法（在 _capability_cases 目录下）：
    python tools/verify_all.py [C1 C5 ...]

每个用例：
  * 以官方布局运行 input/golden.dofile（input 只读挂载，输出写 <用例>/output/）
  * 通用检查：ERROR=0、DRC 等于预期、说明书列出的报告/产物齐全、链数与上链单元数
  * 专项检查：该用例所验证命令的可观测效果（见 CHECKS）
  * ECO 用例另跑 LEC（tools/lec.sh），并用探测脚本确认 delete_net 真正删除了线网
结果写入 verify_result.json，并打印汇总表。
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from cap import run  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


# 用例 -> golden 运行目录（默认 <用例>/output/golden；消融时指向副本）
OUT: dict[str, Path] = {}


def _golden_dir(case: str) -> Path:
    return OUT.get(case, ROOT / case / "output" / "golden")


def rpt(case: str, name: str) -> str:
    p = _golden_dir(case) / "report" / name
    return p.read_text(errors="replace") if p.is_file() else ""


def outp(case: str, name: str) -> str:
    p = _golden_dir(case) / "output" / name
    return p.read_text(errors="replace") if p.is_file() else ""


def chains(case: str) -> list[list[str]]:
    return [l.split() for l in rpt(case, "scan_chain.rpt").splitlines() if re.match(r"^[IW] ", l)]


def chain_cells(case: str, chain: str) -> list[str]:
    """scan_chain_cell.rpt 中某条链的单元实例名（按位置顺序，含 LOCKUP）。"""
    out, cur = [], None
    for l in rpt(case, "scan_chain_cell.rpt").splitlines():
        m = re.match(r"^([IW])\s+(\S+)\s+(\S+)\s+(\S+)", l)
        if m:
            cur = m.group(2)
            if cur == chain:
                out.append(m.group(4))
            continue
        m = re.match(r"^\s+(\S+)\s+(\S+)\s+\S+\s+\(", l)
        if m and cur == chain:
            out.append(m.group(2))
    return out


def lockup_cells(case: str) -> list[str]:
    return [l.split()[-3] for l in rpt(case, "scan_chain_cell.rpt").splitlines() if "LOCKUP" in l]


def info(case: str, key: str) -> str:
    m = re.search(rf"{re.escape(key)}\s+(\S+)", rpt(case, "insertion_info.rpt"))
    return m.group(1) if m else ""


def wrapper_impl(case: str) -> dict[str, tuple[str, str, str]]:
    """端口 -> (WrapperStyle, DWCType, WrapperInstances)。

    列值可能含空格（如 DedicatedReason 为 "User Specified"），按表头的列起始位置切分。
    """
    res, cols = {}, None
    for l in rpt(case, "wrapper_implementation.rpt").splitlines():
        if l.startswith("No.") and "WrapperStyle" in l:
            cols = {m.group(): m.start() for m in re.finditer(r"\S+", l)}
            continue
        if cols and re.match(r"^\d+\s", l):
            def col(name: str, nxt: str) -> str:
                return l[cols[name]:cols[nxt]].strip()
            port = col("PortName(I/O)", "WrapperStyle").split()[0]
            res[port] = (col("WrapperStyle", "UnWrapperReason"), col("DWCType", "SWCType"),
                         col("WrapperInstances", "ReuseThreshold"))
    return res


def retiming(case: str, netlist: str = "post_scan.v") -> list[str]:
    return sorted(set(re.findall(r"U_SCAN_RETIMING_\w+", outp(case, netlist))))


def module_of(case: str, inst: str, netlist: str = "post_scan.v") -> str:
    mod = ""
    for l in outp(case, netlist).splitlines():
        m = re.match(r"^module\s+(\w+)", l)
        if m:
            mod = m.group(1)
        if re.search(rf"\b{inst}\b\s*\(", l):
            return mod
    return ""


# ── 每个用例的预期 ─────────────────────────────────────────────────────────────
# drc: 预期 DRC 总数；n_chains / cells: 链数与链上单元总数（None 表示不核对）
SPEC = {
    "C1_eth_skew_lockup":        dict(drc=21, n_chains=36, cells=10543),
    "C2_ac97_userchain_skew":    dict(drc=1, n_chains=13, cells=2229),
    "C3_pico_ordered_retiming":  dict(drc=0, n_chains=4, cells=1610),
    "C4_e902_hardip_wrapper":    dict(drc=0, n_chains=70, cells=None),
    "C5_soc_hardip_retiming":    dict(drc=0, n_chains=4, cells=364),
    "C6_des3_wrapper_cells":     dict(drc=0, n_chains=109, cells=None),
    "C7_tv80_pseudopi_retiming": dict(drc=0, n_chains=5, cells=359),
    "C8_spi_incremental":        dict(drc=0, n_chains=4, cells=364),
    "C9_usb_db_existing_chain":  dict(drc=0, n_chains=9, cells=1767),
    "C10_led_eco_cleanup":       dict(drc=0, n_chains=2, cells=42),
    "C11_s13207_eco_cleanup":    dict(drc=0, n_chains=4, cells=638),
}


def checks(case: str) -> list[tuple[str, str, bool]]:
    """返回 [(命令, 检查描述, 是否通过)]"""
    c = case
    ch = {x[1]: x for x in chains(c)}
    R: list[tuple[str, str, bool]] = []
    add = lambda cmd, desc, ok: R.append((cmd, desc, bool(ok)))  # noqa: E731

    if c.startswith("C1_"):
        parts = set(re.findall(r"\b(\w+_partition)\b", rpt(c, "scan_partition.rpt")))
        add("remove_scan_partition", "tx/rx_partition 已移除，仅 wb/mac", {"wb_partition", "mac_partition"} <= parts and not parts & {"tx_partition", "rx_partition"})
        add("remove_scan_signal", "mcoll_pad_i 不再是扫描信号", "mcoll_pad_i" not in rpt(c, "scan_signal.rpt"))
        lk = lockup_cells(c)
        add("set_scan_skew_grp", "mac 链中无跨 TX/RX lockup（仅 2 个链尾 lockup）", len(lk) == 2)
        add("set_scan_cell_selection", "lockup 全部为 dlxtn_2", lk and all(x == "sky130_fd_sc_hd__dlxtn_2" for x in lk))
        add("rpt_scan_cell_selection", "报告列出 dlxtn_2", "dlxtn_2" in rpt(c, "scan_cell_selection.rpt"))
        add("(配置)", "mac 2 条链、wb 34 条链", sum(x[-2] == "mac_partition" for x in chains(c)) == 2 and sum(x[-2] == "wb_partition" for x in chains(c)) == 34)
    elif c.startswith("C2_"):
        soc = ch.get("soc_chain")
        add("remove_scan_chain", "dbg_chain 不存在", "dbg_chain" not in ch)
        add("add_scan_chain", "soc_chain user_defined、35 单元、SI/SO=si_soc/so_soc", soc and soc[2] == "35" and soc[3] == "si_soc" and soc[4] == "so_soc" and "user_defined" in soc)
        add("add_port", "si_soc/so_soc 为网表真实端口", re.search(r"si_soc\s+pre_existing", rpt(c, "scan_signal.rpt")))
        add("set_scan_skew_grp", "soc_chain 内无 lockup", not any("LOCKUP" in x for x in chain_cells(c, "soc_chain")) and not lockup_cells(c))
        parts = set(re.findall(r"\b(\w+_partition)\b", rpt(c, "scan_partition.rpt")))
        add("remove_scan_partition", "rx/tx_serdes 已移除，存在 serdes_partition", "serdes_partition" in parts and not parts & {"rx_serdes_partition", "tx_serdes_partition"})
    elif c.startswith("C3_"):
        pc = ch.get("pc_chain"); cells = chain_cells(c, "pc_chain")
        add("remove_scan_chain", "dbg_cycle_cnt 不存在", "dbg_cycle_cnt" not in ch)
        add("add_scan_chain -ordered_elements", "pc_chain 32 单元，首 reg_pc_reg[31] 末 reg_pc_reg[0]", pc and pc[2] == "32" and cells[:1] == ["reg_pc_reg[31]"] and [x for x in cells if x != "LOCKUP"][-1:] == ["reg_pc_reg[0]"])
        add("add_scan_chain -insert_terminal_lockup", "pc_chain 末尾有 LOCKUP", cells[-1:] == ["LOCKUP"])
        add("set_scan_chain_retiming", "3 个 U_SCAN_RETIMING_*_SO", len(retiming(c)) == 3)
    elif c.startswith("C4_"):
        add("define_dft_ip", "Shared Wrapper Cell Count 为 -，Wrapper Chain Cell Count 594", info(c, "Shared Wrapper Cell Count") == "-" and info(c, "Wrapper Chain Cell Count") == "594")
        g = rpt(c, "dft_ip_group.rpt")
        add("define_dft_ip_group", "aes_grp_a / aes_grp_b 两组", "aes_grp_a" in g and re.search(r"aes_grp_b\s+U_AES_CIPHER_TOP_1, U_AES_CIPHER_TOP_2", g))
        add("remove_wrapper_cfg -port", "中断端口不再 shared（无 shared wrapper）", info(c, "Shared Wrapper Cell Count") == "-")
        add("rpt_black_box", "列出 3 个 AES 黑盒", len(re.findall(r"U_AES_CIPHER_TOP_\d", rpt(c, "black_box.rpt"))) == 3)
        add("rpt_scan_drc_rule_handling", "TIE0/TIE1 为 Ignore", len(re.findall(r"DFTR-TIE[01]\s+\S+\s+Ignore", rpt(c, "scan_drc_rule_handling.rpt"))) == 2)
        add("(配置)", "内部链 55 条、wrapper 链 15 条", sum(x[0] == "I" for x in chains(c)) == 55 and sum(x[0] == "W" for x in chains(c)) == 15)
    elif c.startswith("C5_"):
        add("define_dft_ip", "AES 内部链未拼入：Scan Chain Cell Bit Count 364", info(c, "Scan Chain Cell Bit Count") == "364")
        add("define_dft_ip_group", "aes_grp 含 U_AES_0/1", re.search(r"aes_grp\s+U_AES_0, U_AES_1", rpt(c, "dft_ip_group.rpt")))
        add("set_scan_chain_retiming -si_edge/-so_edge", "4 个 *_SI 重定时、无 *_SO", retiming(c) == [f"U_SCAN_RETIMING_{i}_SI" for i in range(1, 5)])
        add("rpt_black_box", "列出 U_AES_0/1", len(re.findall(r"U_AES_\d", rpt(c, "black_box.rpt"))) == 2)
    elif c.startswith("C6_"):
        w = wrapper_impl(c)
        keys = lambda k: [v for p, v in w.items() if p.startswith(k + "[")]  # noqa: E731
        add("remove_wrapper_cfg -port", "key1 56 位均为 dedicated", len(keys("key1")) == 56 and all(v[0] == "dedicated" for v in keys("key1")))
        add("remove_wrapper_cfg -exclude", "desIn[0..3] 复用 desIn_r_reg 作 shared", all(w.get(f"desIn[{i}]", ("",))[0] == "shared" and w[f"desIn[{i}]"][2] == f"u0/desIn_r_reg[{i}]" for i in range(4)))
        add("set_wrapper_cfg WC_D1", "key3 56 位为 WC_D1", len(keys("key3")) == 56 and all(v[1] == "WC_D1" for v in keys("key3")))
        n_dff = len(re.findall(r"sky130_fd_sc_hd__dfxtp_2 ", outp(c, "post_scan.v")))
        n_mux = len(re.findall(r"sky130_fd_sc_hd__mux2_2 ", outp(c, "post_scan.v")))
        add("set_scan_cell_selection", "WC_D1 由 dfxtp_2/mux2_2 实现（112/224）", n_dff == 112 and n_mux == 224)
        add("rpt_dedicated_wrapper_cell_type", "列出 dedicated_wrp_cell", "dedicated_wrp_cell" in rpt(c, "dedicated_wrapper_cell_type.rpt"))
        add("rpt_scan_cell_selection", "列出 mux2_2、dfxtp_2", all(x in rpt(c, "scan_cell_selection.rpt") for x in ("mux2_2", "dfxtp_2")))
    elif c.startswith("C7_"):
        add("add_pseudo_pi / rpt_pseudo_pi", "pseudo_pi 报告含 u_clk_latch/Q", "u_clk_latch/Q" in rpt(c, "pseudo_pi.rpt"))
        add("add_pseudo_pi", "u_clk_latch/Q 为 pseudo 时钟", re.search(r"u_clk_latch/Q\s+pseudo\s+clock", rpt(c, "scan_signal.rpt")))
        rt = retiming(c)
        add("set_scan_chain_retiming -location", "10 个重定时寄存器，位于 tv80_core", len(rt) == 10 and all(module_of(c, r) == "tv80_core" for r in rt))
        add("set_scan_chain_retiming -si_clk/-so_clk", "重定时寄存器时钟接 clk", re.search(r"U_SCAN_RETIMING_1_SI \(\.CLK_N\(clk\)", outp(c, "post_scan.v")))
    elif c.startswith("C8_"):
        cg = ch.get("clgen_chain")
        add("load_db", "加载数据库后信号报告含遗留的 wb_we_i", "wb_we_i" in rpt(c, "scan_signal_loaded.rpt"))
        add("set_scan_chain", "clgen_chain pre_existing、19 单元", cg and cg[2] == "19" and "pre_existing" in cg)
        add("remove_scan_signal", "最终信号无 wb_we_i", "wb_we_i" not in rpt(c, "scan_signal.rpt"))
        add("add_port", "test_mode 为 constant 1", re.search(r"test_mode\s+pre_existing\s+constant\s+1", rpt(c, "scan_signal.rpt")))
        add("delete_port", "post_scan.v 中无 dbg_unused", "dbg_unused" not in outp(c, "post_scan.v"))
        add("save_db", "产出 post_scan.db", (_golden_dir(c) / "output/post_scan.db").is_dir())
    elif c.startswith("C9_"):
        wb = ch.get("wb_chain")
        add("load_db + set_scan_chain", "wb_chain pre_existing、235 单元", wb and wb[2] == "235" and "pre_existing" in wb)
        add("add_port", "phy_si0..7/phy_so0..7 均为 pre_existing", len(re.findall(r"phy_s[io][0-7]\s+pre_existing", rpt(c, "scan_signal.rpt"))) == 16)
    elif c.startswith("C10_") or c.startswith("C11_"):
        fixed = outp(c, "netlist_fixed.v")
        add("delete_inst / delete_port", "netlist_fixed.v 不含调试单元/端口", not re.search(r"U_DBG|dbg_probe|dbg_sel", fixed))
    return R


def probe_delete_net(case: str, nets_glob: str) -> bool:
    """在 golden 的 delete_inst 与 delete_net 前后查询数据库，确认线网在 delete_net 后才消失。"""
    src = ROOT / case / "input"
    work = ROOT / "_work" / f"probe_{case}"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    shutil.copytree(src, work / "input")
    g = (work / "input" / "golden.dofile").read_text()
    q = 'puts "NETPROBE_{}=[get_obj_name [get_obj_nets {}]]"'
    g = re.sub(r"^(delete_net .*)$", q.format("before", nets_glob) + r"\n\1\n" + q.format("after", nets_glob), g, flags=re.M)
    g = g.replace("output golden", "output probe")
    (work / "input" / "probe.dofile").write_text(g)
    r = run(work / "input", "probe.dofile")
    before = re.search(r"^NETPROBE_before=(.*)$", r["log"], re.M)
    after = re.search(r"^NETPROBE_after=(.*)$", r["log"], re.M)
    return bool(before and before.group(1).strip() and after is not None and not after.group(1).strip())


def lec(case: str, ref: str, top: str) -> bool:
    d = ROOT / case / "verify"
    shutil.copy(ROOT / case / "output/golden/output/netlist_fixed.v", d / "netlist_fixed.v")
    shutil.copy(ROOT / case / "input/lib/sky130.lib", d / "sky130.lib")
    p = subprocess.run([str(ROOT / "tools/lec.sh"), "sky130.lib", ref, "netlist_fixed.v", top],
                       cwd=d, capture_output=True, text=True)
    (d / "sky130.lib").unlink()
    return "LEC: EQUIVALENT" in p.stdout


def main() -> int:
    only = sys.argv[1:]
    results = {}
    for case, exp in SPEC.items():
        if only and not any(case.startswith(o + "_") or case == o for o in only):
            continue
        r = run(ROOT / case / "input", "golden.dofile", ROOT / case / "output")
        n = len(chains(case))
        cells = sum(int(x[2]) for x in chains(case))
        base = [
            ("(通用)", "ERROR=0", not r["errors"]),
            ("(通用)", f"DRC={exp['drc']}", r["drc"] == exp["drc"]),
            ("(通用)", f"链数={exp['n_chains']}", n == exp["n_chains"]),
        ]
        if exp["cells"] is not None:
            base.append(("(通用)", f"链上单元={exp['cells']}", cells == exp["cells"]))
        spec = (ROOT / case / "input/task_spec.md").read_text()
        want = set(re.findall(r"`(\w+\.(?:rpt|v|ctl|def|db))`", spec.split("## 输出要求", 1)[-1].split("## 验收要点", 1)[0]))
        have = set(r["reports"]) | set(r["outputs"])
        base.append(("(通用)", "说明书要求的报告/产物齐全", want <= have))
        base.append(("rpt_scan_version", "日志打印工具版本", "ScanInsertion version" in r["log"]))
        items = base + checks(case)
        if case.startswith("C10_"):
            items.append(("delete_net", "数据库中 dbg_n* 在 delete_net 后才消失", probe_delete_net(case, "dbg_n*")))
            items.append(("ECO/LEC", "netlist_fixed.v ≡ 参考网表（只修缺陷、无调试逻辑）", lec(case, "ref_fixed.v", "led_drv")))
        if case.startswith("C11_"):
            items.append(("delete_net", "数据库中 dbg_w* 在 delete_net 后才消失", probe_delete_net(case, "dbg_w*")))
            items.append(("ECO/LEC", "netlist_fixed.v ≡ 原始网表", lec(case, "s13207_orig.v", "s13207")))
        ok = all(x[2] for x in items)
        results[case] = dict(ok=ok, seconds=r["seconds"], errors=len(r["errors"]), drc=r["drc"], chains=n,
                             cells=cells, checks=[dict(cmd=a, desc=b, ok=c) for a, b, c in items])
        print(f"{'PASS' if ok else 'FAIL'}  {case:28} {r['seconds']:5}s  ERROR={len(r['errors'])} DRC={r['drc']} 链={n} 单元={cells}")
        for a, b, c in items:
            if not c or a not in ("(通用)",):
                print(f"      {'✓' if c else '✗'} {a:42} {b}")
    (ROOT / "verify_result.json").write_text(json.dumps(results, ensure_ascii=False, indent=1))
    bad = [k for k, v in results.items() if not v["ok"]]
    print(f"\n{len(results) - len(bad)}/{len(results)} 通过" + (f"；失败：{bad}" if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
