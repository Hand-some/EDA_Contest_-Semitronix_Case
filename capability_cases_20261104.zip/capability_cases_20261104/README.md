# 扫描命令能力用例（11 个）

覆盖工具文档 71 条扫描命令中**官方 public case 没有用到**的那一批，每个用例都有一份用工具实跑验证过的 `golden.dofile`。
格式与官方任务一相同：`<用例>/input/{task_spec.md, limitations.md, golden.dofile, lib/, netlist/, …}`。

## 用例一览

| 用例 | 设计 | 验证的命令 | 说明书场景 |
|---|---|---|---|
| C1_eth_skew_lockup | 官方 t2c2 ethernet（3 时钟，10,543 FF） | `set_scan_skew_grp -include_clocks`、`set_scan_cell_selection`(latch)、`remove_scan_partition`、`remove_scan_signal`、rpt_scan_cell_selection | 平台模板多了一个错误时钟、旧分区要合并；TX/RX 同 skew 组；lockup 指定 dlxtn_2 |
| C2_ac97_userchain_skew | 官方 t1c2 ac97（2 时钟，2,229 FF） | `add_scan_chain -include_elements`、`set_scan_skew_grp -include_instance`、`remove_scan_chain`、`remove_scan_partition`、`add_port` | 撤销模板调试链、合并 SERDES 分区、Codec 同步控制器用专用端口单独成链 |
| C3_pico_ordered_retiming | 官方 t2c1 picorv32（1,610 FF） | `add_scan_chain -ordered_elements -insert_terminal_lockup`、`set_scan_chain_retiming`(默认)、`remove_scan_chain`、`add_port` | PC 寄存器按 bit31→bit0 有序成链 + 链尾 lockup；其余链 SO 端重定时 |
| C4_e902_hardip_wrapper | 官方 t1c3 e902 + 3 个 AES 黑盒（CTL） | `define_dft_ip`、`define_dft_ip_group`、`remove_wrapper_cfg -port`、rpt_black_box、rpt_dft_ip_group、rpt_scan_drc_rule_handling | 黑盒声明 hard IP 不进 wrapper 链；撤销模板中 3 个中断端口的 shared wrapper |
| C5_soc_hardip_retiming | **新造** spi_aes_soc（SPI + 2 个 AES 黑盒） | `define_dft_ip`、`define_dft_ip_group`、`set_scan_chain_retiming -si_edge/-so_edge`、rpt_black_box、rpt_dft_ip_group | hard IP 内部链不拼入顶层链；SI 端下降沿重定时 |
| C6_des3_wrapper_cells | 官方 t1c6 des3（wrapper + 280 segment） | `set_scan_cell_selection`(mux/dff)、`remove_wrapper_cfg -port`、`remove_wrapper_cfg -exclude`、rpt_dedicated_wrapper_cell_type、rpt_scan_cell_selection | key3 改用 WC_D1 并指定 MUX/DFF 库单元；撤销 key1 的 none 与 4 个寄存器的排除 |
| C7_tv80_pseudopi_retiming | 官方 t2c3 tv80（359 FF） | `add_pseudo_pi`、`set_scan_chain_retiming -location -si_clk -so_clk`、rpt_pseudo_pi | latch 时钟用 pseudo PI 方式处理；重定时放在 i_tv80_core 层次内 |
| C8_spi_incremental | 自建 spi（两阶段插链） | `load_db`、`set_scan_chain`、`remove_scan_signal`、`add_port`、`delete_port`、`save_db` | 加载第一阶段数据库，清理遗留时钟 / 调试端口，保留已有 clgen 链 |
| C9_usb_db_existing_chain | 自建 usb_funct（两阶段插链） | `load_db`、`set_scan_chain`、`add_port` | 加载第一阶段数据库，保留已有 WB 域链；PHY 域用新增的真实端口 |
| C10_led_eco_cleanup | 官方 t2c6 led_drv + 注入调试逻辑 | `delete_inst`、`delete_net`、`delete_port`、`rewire` + 官方 ECO | 修两处网表缺陷 + 清理遗留调试逻辑；`netlist_fixed.v` 过 LEC |
| C11_s13207_eco_cleanup | 自建 iscas s13207 + 注入调试逻辑 | `delete_inst`、`delete_net`、`delete_port`、`rewire` | 清理遗留调试逻辑；`netlist_fixed.v` 与原网表过 LEC |

所有 golden 都在日志里打印工具版本（`rpt_scan_version`）。

### 命令覆盖

| 组 | 命令 | 用例 |
|---|---|---|
| A | add_scan_chain | C2、C3 |
| A | set_scan_chain | C8、C9 |
| A | set_scan_skew_grp | C1（按时钟）、C2（按实例） |
| A | define_dft_ip / define_dft_ip_group | C4、C5 |
| A | set_current_dft_ip_group | **未进 golden**：工具限制，见下文"发现"第 5 条 |
| A | set_scan_cell_selection | C1（latch）、C6（mux/dff） |
| A | set_scan_chain_retiming | C3（默认）、C5（边沿）、C7（层次 + 时钟） |
| D | rpt_black_box / rpt_dft_ip_group | C4、C5 |
| D | rpt_scan_cell_selection | C1、C6 |
| D | rpt_dedicated_wrapper_cell_type | C6 |
| D | rpt_scan_drc_rule_handling | C4 |
| D | rpt_pseudo_pi | C7 |
| D | rpt_scan_version | 全部 |
| B | remove_wrapper_cfg | C4（-port）、C6（-port、-exclude） |
| B | remove_scan_signal | C1、C8 |
| B | remove_scan_partition | C1、C2 |
| B | remove_scan_chain | C2、C3 |
| B | add_port | C2、C3、C8、C9 |
| B | delete_inst / delete_net | C10、C11 |
| B | delete_port | C8、C10、C11 |
| B | rewire | C10、C11（可执行，但未观察到效果，见"发现"第 11 条） |
| B | connect_pg_net | **不可用**：工具里没有这条命令 |
| B | load_db（及 save_db） | C8、C9 |

## 验证方法

`python tools/verify_all.py`：从干净状态重跑全部 golden，逐条核对：

1. **通用项**：ERROR=0；DRC 等于预期（C1 允许 21 个固有 DFTR10、C2 允许 1 个，其余为 0）；链数、链上单元数；说明书"输出要求"列出的每个报告和产物都存在；日志里有工具版本。
2. **命令效果**：每条被验证的命令都对应一条可观测的检查，例如：skew group → 链中无 lockup；cell_selection → lockup 或 WC_D1 用的是指定库单元；set_scan_chain → 链为 `pre_existing`；define_dft_ip → CTL 内部链未拼入（bit 数）；retiming → 寄存器名称、个数、所在模块和时钟。
3. **ECO 用例**：
   - `tools/lec.sh` 用镜像内的 yosys 做等价检查，ICG 建模为 `GCLK = CLK & (GATE|SCE)`。
   - C10 拿 `netlist_fixed.v` 和"原网表只做官方缺陷修复"的参考网表比；C11 拿它和原始网表比。
   - LEC 脚本本身做过反例：改一个门之后，两个用例都会判为不等价。
   - delete_net 用数据库查询确认：线网在 delete_inst 之后仍然存在，直到 delete_net 之后才消失。

`python tools/ablate.py`（消融）：逐条删掉 golden 里被验证的命令再跑，确认对应检查失败。**33/33 项全部检出**，证明每条检查确实依赖该命令。

结果见 `verify_result.json`、`ablate_result.json`。

## 实测发现（对 agent 有用的工具行为）

1. `set_scan_chain` 的作用是**标识网表里已经存在的扫描链**（报告中为 `pre_existing`），不是定义新链；链必须真实存在，否则报 SCAN-2204。定义新链要用 `add_scan_chain`。
2. `add_scan_chain` / `set_scan_chain` 的 SE/SI/SO，以及 `set_scan_chain_retiming -se`，都要求**网表里真实存在**的端口。工具自动新建的端口（如没有 add_port 的 `test_se`）会被拒绝，报 SCAN-1971。需要先 `add_port`。
3. `add_scan_chain` 同时给 `-include_elements` 和 `-clock` 时，`-clock` **不起过滤作用**；只给 `-clock` 时才会按时钟域收集 FF。`-include_elements` 支持通配符（`count_cycle_reg*`）和层次名（`u2`）。
4. `set_scan_skew_grp` 生效后，组内时钟之间不插 lockup。`set_scan_cell_selection` 指定的 latch 只用于同极性的 lockup：链尾 lockup 是低电平透明的，所以要指定 `dlxtn` 类单元并写 `neg`。
5. **IP 组级 wrapper 在本工具版本不可用**：`set_current_dft_ip_group` 之后配置 `set_wrapper_cfg`，试了 4 种配置（dedicated/shared、带或不带链数、有无顶层 wrapper），`insert_dft_logic` 都报 SCAN-1978 拼链失败。`define_dft_ip_group` 本身可用，能在报告中登记分组。
6. `define_dft_ip -type hard` 的效果：带 CTL 的黑盒，其内部链**不再**拼入顶层链，也不再被当作 shared wrapper cell。
7. `remove_wrapper_cfg -port` 对总线端口必须按位写或用通配符（`{key1[*]}`），写总线名报"Nothing matched"；而 `set_wrapper_cfg -port key1` 可以直接写总线名。
8. `set_scan_chain_retiming`：只有链首/链尾单元的边沿不满足指定值时才插入寄存器。`-location` 放到子层次时，工具会在子模块上新建端口传时钟，端口名可能是 `scan_si_2` 这类容易误读的名字，建议同时指定 `-si_clk/-so_clk`。
9. `save_db`：项目未建立时（读网表之前）会报 CMD-3014；保存的数据库用**绝对路径符号链接**引用 liberty（`/work/case/input/lib/...`），换了挂载路径就会失效。本包已把链接替换为真实文件，数据库是自包含的。先 `load_db` 一个只含空设计的库再 `load_netlist`，`present_design` 会找不到新设计，所以"加载空库"不适合做 golden。
10. `delete_inst` 删除单元后，悬空线网在导出的网表里看不到，但**仍留在设计数据库中**，需要 `delete_net` 才会真正删除。
11. `rewire`：可以执行，但在 5 种结构（原始网表、插链后网表、两种手工构造的直通结构、两个 ECO 用例）上都没有观察到网表变化。用例里保留它只是为了覆盖语法，不作为效果验证。
12. `connect_pg_net`：工具文档里有，但执行时报 CMD-0067"Invalid command name"。
13. 平台模板写法（Dofile 先 `source` 只读模板，再用 remove_* 调整）工具支持良好，是让撤销类命令自然出现的场景。

## 怎么跑

需要镜像 `scan-agent-base:ubuntu24`，并且能联网拿 license（`8273@121.40.209.111`）。

```bash
python3 tools/verify_all.py            # 全部重跑 + 核对（约 2 分钟）
python3 tools/verify_all.py C4 C7      # 只跑指定用例
python3 tools/ablate.py                # 消融（约 4 分钟）
python3 tools/cap.py C3_pico_ordered_retiming/input golden.dofile   # 单独跑一个
```

输出写到 `<用例>/output/golden/`。

## 注意

- golden 由我们编写并经工具验收，不是官方答案。说明书是为覆盖这些命令而设计的，场景比官方用例更"刻意"。
- 用来评测 agent 时，请把 `golden.dofile` 移出 `input/`。C10、C11 的 `verify/` 目录是 LEC 参考网表，也不要给 agent。
- C5 的顶层网表和 C10、C11 的调试逻辑是人为构造的；C8、C9 的第一阶段网表和数据库由工具生成。
