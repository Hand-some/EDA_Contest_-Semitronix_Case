# 插链任务说明书

## 任务目标

USB 功能控制器 `usbf_top` 的插链分两个阶段。第一阶段已完成 WB 时钟域（`clk_i`）的插链，结果保存为工程数据库。本任务是**第二阶段**：

1. 直接加载第一阶段的工程数据库，不要重新读取库和网表；
2. 识别并保留第一阶段已建好的 WB 域扫描链；
3. 为 PHY 时钟域新增封装要求的扫描端口，并完成 PHY 域插链；
4. 执行 DRC、插链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/db/usb_stage1.db` | 第一阶段工程数据库（已含标准单元库、第一阶段插链后的网表，以及 `clk_i`、`phy_clk_pad_i` 两个时钟定义，off_state 均为 0） |
| `input/netlist/usbf_top_stage1.v` | 第一阶段导出的网表，仅供查阅（与数据库中的设计一致） |
| `input/lib/sky130.lib` | 标准单元库，仅供查阅（已包含在数据库中） |

## 设计信息

- 顶层 `usbf_top`；时钟 `clk_i`（WB 域）、`phy_clk_pad_i`（PHY 域）；无需声明复位
- 共 1,767 个扫描单元位置：WB 域的单元已在第一阶段替换并串成一条链；PHY 域 1,532 个 `sky130_fd_sc_hd__dfxtp_1` 尚未处理
- 第一阶段已添加的端口：`test_se`（扫描使能）、`si_wb` / `so_wb`（WB 域链的扫描输入 / 输出）
- 已有的 WB 域链：`si_wb` → … → `so_wb`，使能 `test_se`，共 235 个单元

## 配置要求

1. scan_enable 为 `test_se`（`-usage all`，off_state 0）。
2. **已有链**：把 WB 域现有链标识为已存在的扫描链 `wb_chain`（SI `si_wb`、SO `so_wb`、使能 `test_se`），按原样保留，不得重新串接。
3. **PHY 域端口**：封装要求 PHY 域的扫描数据端口必须是网表中真实存在的端口（不能由工具自动生成）。新增输入端口 `phy_si0`~`phy_si7`、输出端口 `phy_so0`~`phy_so7`，作为 PHY 域 8 条链的扫描输入 / 输出。
4. DFF 替换为 SFF：`dfxtp_1`→`sdfxtp_1`；不混时钟；插 lockup。
5. 分区：`wb_partition`（`clk_i`，1 条链，即 `wb_chain`）、`phy_partition`（`phy_clk_pad_i`，8 条链，max_length 200，使用上述 8 对端口）。

## 输出要求

- 产物（`output/golden/output/`）：`post_scan.v`、`post_scan.ctl`、`post_scan.def`
- 报告（`output/golden/report/`）：`drc.rpt`、`scan_chain.rpt`、`scan_chain_cell.rpt`、`scan_signal.rpt`、`scan_partition.rpt`、`scan_cfg.rpt`、`insertion_info.rpt`
- 在日志中打印工具版本信息

## 验收要点

- 报错 0、DRC 0；9 条链共 1,767 个单元
- `wb_chain` 为 pre_existing（235 个单元，`wb_partition`）
- PHY 域 8 条链的 SI/SO 为 `phy_si0..7` / `phy_so0..7`，在 scan_signal 报告中 PortProperty 为 pre_existing
