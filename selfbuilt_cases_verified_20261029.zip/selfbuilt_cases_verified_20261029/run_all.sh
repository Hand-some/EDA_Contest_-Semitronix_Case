#!/usr/bin/env bash
# 在基础镜像里重跑用例，打印 DRC、链数与报错数。用法：./run_all.sh [用例名...]
set -uo pipefail
cd "$(dirname "$0")"
IMAGE=${IMAGE:-scan-agent-base:ubuntu24}
LICENSE=${SCANINSERTION_LICENSE_SERVER:-8273@121.40.209.111}
cases=("$@"); [ ${#cases[@]} -eq 0 ] && cases=($(ls -d */ | tr -d / | grep -v '^out$'))
mkdir -p out
for c in "${cases[@]}"; do
  [ -f "$c/final.dofile" ] || { echo "跳过 $c（没有 final.dofile）"; continue; }
  o="$PWD/out/$c"; mkdir -p "$o"
  docker run --rm --platform linux/amd64 -e SCANINSERTION_LICENSE_SERVER="$LICENSE" \
    -v "$PWD/$c/input:/input:ro" -v "$o:/output" -v "$PWD/$c/final.dofile:/run/final.dofile:ro" \
    --entrypoint dftexp_scan "$IMAGE" -f /run/final.dofile > "$o/run.log" 2>&1
  drc=$(grep -h "Total violations" "$o/reports/drc.rpt" 2>/dev/null | grep -oE '[0-9]+' | tail -1)
  chains=$(grep -cE '^[IW] ' "$o/reports/scan_chain.rpt" 2>/dev/null)
  errs=$(grep -c '\[ERROR\]' "$o/run.log")
  printf '%-14s DRC=%-4s 链数=%-4s ERROR=%s\n' "$c" "${drc:-?}" "${chains:-?}" "$errs"
done
echo "详细输出在 ./out/<用例>/"
