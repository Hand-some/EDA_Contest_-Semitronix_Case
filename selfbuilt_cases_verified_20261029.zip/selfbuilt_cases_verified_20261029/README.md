# 自建用例：经工具校验达标的 Dofile

11 个基于开源设计（ISCAS'89、OpenCores、Faraday）综合成 SKY130 门级网表的 Scan Insertion 用例，
每个都附一份**已在工具上实跑、并按说明书逐项核对达标**的 Dofile。

## 目录

```
<case>/
├── input/            用例输入：lib/sky130.lib、netlist/*.v、task_spec.md、limitations.md
├── final.dofile      可直接运行的 Dofile（输入 /input，输出 /output）
└── verify/           本次校验的结果：drc.rpt、scan_chain.rpt、scan_element.rpt、工具完整日志、result.json
run_all.sh            一键在基础镜像里重跑全部用例并打印结果
```

## 怎么跑

需要：已 `docker load` 的基础镜像 `scan-agent-base:ubuntu24`；能访问 license 服务器 `8273@121.40.209.111`
（工具每条需授权的命令都会联网认证，断网会失败）。

```bash
./run_all.sh                 # 全部
./run_all.sh spi aes_core    # 指定用例
```

单个用例手动运行：

```bash
docker run --rm --platform linux/amd64 \
  -e SCANINSERTION_LICENSE_SERVER=8273@121.40.209.111 \
  -v $PWD/spi/input:/input:ro -v $PWD/out/spi:/output \
  -v $PWD/spi/final.dofile:/run/final.dofile:ro \
  --entrypoint dftexp_scan scan-agent-base:ubuntu24 -f /run/final.dofile
```

产物：`/output/post_scan.v`、`post_scan.ctl`、`post_scan.def`，报告在 `/output/reports/`。
**请以 root 运行容器**（不要加 `--user`）：工具要在 `$HOME` 下建 license 配置目录，非 root 时 `$HOME` 不可写会报 SCAN-1024。

## 校验标准与结果（全部通过）

逐项对照各用例 `task_spec.md` 的「DRC 与验收标准」：工具无 ERROR；**DRC 违例 = 0**；
上链单元数 = 说明书给出的可扫描时序单元数（100% 覆盖）；各扫描分区的链数等于说明书分区表要求、最长链不超过 max_length；
post_scan.v / ctl / def 均已导出。

| 用例 | 要求 FF | 上链单元 | 链数 | 分区（实际 vs 要求） | DRC | ERROR |
|---|---:|---:|---:|---|---:|---:|
| aes_core | 590 | 590 | 4 | main_partition: 4 条（要求 4），最长 148（≤300） | 0 | 0 |
| faraday_dma | 2,266 | 2,266 | 8 | main_partition: 8 条（要求 8），最长 284（≤300） | 0 | 0 |
| iscas_s13207 | 638 | 638 | 4 | main_partition: 4 条（要求 4），最长 160（≤300） | 0 | 0 |
| iscas_s15850 | 534 | 534 | 4 | main_partition: 4 条（要求 4），最长 134（≤300） | 0 | 0 |
| iscas_s35932 | 1,728 | 1,728 | 8 | main_partition: 8 条（要求 8），最长 216（≤300） | 0 | 0 |
| iscas_s38417 | 1,636 | 1,636 | 8 | main_partition: 8 条（要求 8），最长 205（≤300） | 0 | 0 |
| iscas_s38584 | 1,426 | 1,426 | 8 | main_partition: 8 条（要求 8），最长 179（≤300） | 0 | 0 |
| iscas_s9234 | 211 | 211 | 2 | main_partition: 2 条（要求 2），最长 106（≤300） | 0 | 0 |
| spi | 364 | 364 | 4 | wb_partition: 4 条（要求 4），最长 91（≤100） | 0 | 0 |
| systemcaes | 709 | 709 | 4 | ff_partition: 4 条（要求 4），最长 178（≤300） | 0 | 0 |
| usb_funct | 1,767 | 1,767 | 10 | wb_partition: 2 条（要求 2），最长 118（≤300）；phy_partition: 8 条（要求 8），最长 192（≤300） | 0 | 0 |

部分 FF 在链上仍是普通 DFF（未换成 sdf*），它们都属于工具识别出的移位寄存器：一段移位链只需替换首个单元，属正常优化。

## 需要注意

- **这些 Dofile 是我们的 Agent 生成的，不是官方标准答案。** 它们满足了说明书里能机检的要求，但说明书本身是生成用例时由 AI 写的，可能与真实意图有出入。
- 各用例原先附带的 `golden.dofile` **没有放进来**：它同样是 AI 生成的，链数与说明书矛盾（普遍只有说明书要求的一半），部分实跑还有大量 DRC 违例，当参考会误导。
- 另有 5 个自建用例（mem_ctrl、pci_bridge32、vga_lcd、wb_conmax、wb_dma）没有放进来：网表本身带有复位不受控、时钟进数据通路、常量寄存器等结构，DRC 无法清零。
- 校验环境：本地 Docker，基础镜像 `scan-agent-base:ubuntu24`（linux/amd64），License `8273@121.40.209.111`。
