# 插链任务说明书：aes_core

## 任务目标

对 `aes_cipher_top` 的 SKY130 HD 门级 pre-scan 网表执行完整 Scan Insertion：

1. 读取 Liberty 与门级网表并设置顶层；
2. 将所有可扫描普通 DFF 映射为对应扫描 FF；
3. 配置时钟、复位、scan_enable 和扫描数据端口；
4. 按时钟域建立扫描分区，插入 lockup latch（如有跨域边界）；
5. 执行 DFT DRC、构建扫描链并导出结果。

## 输入文件

| 文件 | 说明 |
|------|------|
| `input/lib/sky130.lib` | SKY130 HD 标准单元时序库 |
| `input/netlist/aes_cipher_top.v` | 已转换的门级 pre-scan 网表，顶层 `aes_cipher_top` |

## 设计基本信息

- **设计名称**：AES Cipher Core
- **Top 模块**：`aes_cipher_top`
- **工艺库**：SKY130 HD
- **网表 cell 总数**：9,450
- **可扫描时序单元**：590 个
- **latch**：0 个
- **ICG**：0 个
- **转换/适用性备注**：单时钟 AES 核；无 latch、无 ICG。

## 时序单元与扫描映射

| 普通时序单元 | 数量 | 说明 | 扫描单元 |
|--------------|-----:|------|----------|
| `sky130_fd_sc_hd__dfxtp_1` | 590 | 无复位、正沿 DFF | `sky130_fd_sc_hd__sdfxtp_1` |

### 不参与扫描的 latch

无。

不得把 latch 计入“可扫描 FF 覆盖率”；若工具需要显式约束，应使用 `dont_scan`/等价命令排除。

## 时钟结构

| 扫描分区 | 扫描时钟 | 预计可扫描 FF | 规则 |
|----------|----------|--------------:|------|
| `main_partition` | `clk` | 全部 590 个 FF |

- `set_scan_signal -type clock -port clk -off_state 0`

`mix_clocks=false`、`mix_edges=false`。同一条链不得混合不同时钟域或不同触发沿；多时钟 case 在域边界插入 lockup latch。

## 复位与 DFT 控制信号

- **复位说明**：当前网表时序单元均为无异步复位 dfxtp_1；RTL 中的 reset 行为属于同步/组合功能逻辑，除非 DFT 工具从网表确认，否则不要声明异步 scan reset。
- **scan_enable**：新增顶层端口 `test_se`，`off_state=0`，`usage=all`，同时驱动扫描 FF 的 SE/SCE；本批网表未检测到 ICG，不能把 ICG 数量或 ICG 覆盖率虚报为非零。
- **扫描数据端口**：使用工具自动创建的 `scan_data_in_%d` / `scan_data_out_%d`；如工具版本要求，可在 dofile 中显式指定同名模板。
- **异步控制**：扫描期间保持复位处于非激活电平；复位 pin 极性必须以 Liberty 与实例连接共同核对。

## 扫描分区与链配置

| 分区 | 时钟 | chain_count | max_length | scan_enable |
|------|------|------------:|-----------:|-------------|
| `main_partition` | `clk` | 4 | 300 | `test_se` |

链长上限按当前实测 FF 数配置；如果工具因不可拆分的同步器、wrapper 或既有 scan segment 产生超长链，应在报告中说明并保留 segment 完整性。除明确说明的 latch/同步器外，所有可扫描 FF 的目标覆盖率为 100%。

## 特殊结构与限制

- 不修改 `input/netlist` 原始 pre-scan 网表；所有修改写入 `output/`。
- 未检测到 RAM blackbox；若工具重新识别出 RAM/FIFO 宏，宏内部寄存器不拆链，按工具支持的 macro/segment 规则处理。
- 同步器、CDC 保护寄存器可按工具的 synchronizer 识别结果单独分区或排除，但必须在 `scan_element.rpt` 中列出数量和理由。
- 单时钟 AES 核；无 latch、无 ICG。

## DRC 与验收标准

1. 工具执行无导致流程失败的 ERROR；
2. DFT DRC 中除任务明确允许的固有提示外，不得有扫描时钟、复位极性、SE 未连接、链断裂或跨域混链违例；
3. 所有目标扫描 FF 均替换为对应 SFF，且 100% 纳入扫描链；latch/排除项单独统计；
4. 多时钟域链不跨域，跨域连接存在 lockup latch；单时钟 case 仍保持 `mix_clocks=false`；
5. 插链后网表可被工具重新读入，扫描链报告中的链数、链长与本 spec 一致；
6. 原始功能端口和时钟/复位连接不被意外改写，新增端口仅限 DFT 所需端口。

## 输出要求

- `output/final.dofile`：完整可复现 dofile；
- `output/post_scan.v`：插链后 Verilog 网表；
- `output/post_scan.ctl`：CTL/扫描结构描述（工具支持时）；
- `output/post_scan.def`：SCANDEF 文件（工具支持时）；
- `output/drc.rpt`：DFT DRC 报告；
- `output/scan_chain.rpt`：扫描链汇总；
- `output/scan_chain_cell.rpt`：逐单元链明细；
- `output/scan_element.rpt`：扫描 FF、latch、排除项统计；
- `output/scan_cfg.rpt`、`output/scan_signal.rpt`、`output/insertion_info.rpt`：配置、信号和插入报告；
- `*.log`：每轮工具完整日志；
- `decision_log.json`：Agent 执行摘要与决策记录。
