# 转换限制与扫描前检查

- 这是 SKY130 HD 普通 pre-scan 网表；尚未替换为 `sdf*` 扫描 FF，也尚未插入扫描链。
- 重新用工具统计时，应按实际时序 cell bit 数统计；不要把 latch、RAM blackbox 或明确排除的同步器算入可扫描 FF。
- 转换使用 Yosys 的 `techmap`、`dfflibmap` 和 `abc`。正式比赛运行前应再次用项目工具读取 Liberty 和网表，确认所有 cell 名称、端口极性及异步复位映射。
- 对多时钟 case，必须在 task spec/dofile 中建立时钟分区；除非工具明确支持跨域链，否则在域边界插入 lockup 或禁止混链。
