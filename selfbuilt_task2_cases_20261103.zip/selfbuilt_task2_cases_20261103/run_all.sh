#!/usr/bin/env bash
# 在基础镜像里重跑 golden.dofile / original.dofile，打印报错数、DRC 和链数。
# 用法：./run_all.sh [golden|original|both] [用例名...]（默认 both、全部用例）
# 挂载布局与官方一致：<用例>/input → /work/case/input（只读），输出写到 /work/case/output/<golden|original>/
set -uo pipefail
cd "$(dirname "$0")"
IMAGE=${IMAGE:-scan-agent-base:ubuntu24}
LICENSE=${SCANINSERTION_LICENSE_SERVER:-8273@121.40.209.111}
which=${1:-both}; shift || true
case $which in golden|original) kinds=($which);; both) kinds=(golden original);; *) echo "第一个参数应为 golden|original|both"; exit 1;; esac
cases=("$@"); [ ${#cases[@]} -eq 0 ] && cases=($(ls -d */ | tr -d / | grep -v '^out$'))
mkdir -p out
for c in "${cases[@]}"; do
  [ -f "$c/input/golden.dofile" ] || { echo "跳过 $c"; continue; }
  o="$PWD/out/$c"; mkdir -p "$o"
  for k in "${kinds[@]}"; do
    docker run --rm --platform linux/amd64 -e SCANINSERTION_LICENSE_SERVER="$LICENSE" \
      -v "$PWD/$c/input:/work/case/input:ro" -v "$o:/work/case/output" -w /work/case/output \
      --entrypoint dftexp_scan "$IMAGE" -f /work/case/input/$k.dofile > "$o/$k.log" 2>&1
    drc=$(grep -h "Total violations" "$o/$k/report/drc.rpt" 2>/dev/null | grep -oE '[0-9]+' | tail -1)
    chains=$(grep -cE '^[IW] ' "$o/$k/report/scan_chain.rpt" 2>/dev/null)
    errs=$(grep -c '\[ERROR\]' "$o/$k.log")
    printf '%-14s %-8s ERROR=%-3s DRC=%-5s 链数=%s\n' "$c" "$k" "$errs" "${drc:-?}" "${chains:-?}"
  done
done
echo "详细输出在 ./out/<用例>/"
