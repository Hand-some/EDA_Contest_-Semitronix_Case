# 自建任务二用例（11 个）

由 `selfbuilt_cases_verified_20261029` 里 11 个已验证的任务一用例生成，格式与官方 `public_cases/task_2` 一致。
每个用例：一份能跑通的 `golden.dofile`，一份人为注入 6 个缺陷的 `original.dofile`，以及逐条描述的 `preset_issues.json`（官方 8 个字段）。

## 目录

```
<用例>/input/
  task_spec.md        说明书（比任务一版本多一行：input/original.dofile = 需检查并修复的 Dofile）
  limitations.md      限时 300 s
  lib/  netlist/      与任务一相同
  golden.dofile       修复后的标准答案（官方 public 头部写法：$script_dir / out_rpt_dir / out_res_dir）
  original.dofile     注入缺陷后的 Dofile
  preset_issues.json  问题列表
generation_summary.json  生成记录：缺陷代号、单独注入时的现象、哪些问题被 DRC 遮蔽
run_all.sh               在基础镜像里重跑 golden / original
```

## 缺陷构成（每个用例 6 个：3 执行 + 1 DRC + 2 配置）

| 类型 | 代号 | 注入方式 |
|---|---|---|
| Dofile执行问题 | X_OPT_TYPO | 分区 `set_scan_cfg -max_length` 写成 `-max_lenght` |
| | X_ENUM | `set_scan_signal -usage all` 写成 `both`（非法取值） |
| | X_CMD_TYPO | `rpt_scan_cfg` 写成 `rpt_scan_cgf`，报告缺失 |
| | X_ORDER | `examine_scan_chain` 挪到 `insert_dft_logic` 之后（SCAN-1009） |
| DRC问题 | D_RESET_POLARITY / D_RESET_MISSING / D_CLOCK2_MISSING / D_CLOCK_MISSING | 复位 off_state 反了、漏声明复位、漏声明第二时钟、漏声明唯一时钟（按设计挑一个能真实触发 DRC 的） |
| DFT配置不符合任务要求 | C_CHAIN | 分区 chain_count +2 |
| | C_PORTFMT | SI/SO 命名改成 `scan_in_%d` / `scan_out_%d` |
| | C_EXCLUDE | `set_scan_element false` 排除一个本该上链的 FF（取自 golden 的 scan_chain_cell 报告，层次化和平铺网表都实测生效） |

## 验证方法（全部用真实工具跑过，不靠推断）

1. **golden 验收**：ERROR=0、DRC=0、链数等于说明书要求、可扫描 FF 100% 上链、导出网表等 3 个文件都生成。
2. **单缺陷注入**：每个缺陷单独注入 golden 跑一次，只有工具里真的出现预期现象（报错码 / DRC 规则 / 链数、端口名、上链数变化）才收录，`现象` 字段就是这次实跑的结果。
3. **组合验证**：6 个缺陷一起注入成 original 再跑。执行类问题核对报错行；DRC 类问题核对其单独注入时的规则都出现；配置类问题要求现象与单独注入时完全一致才算可见。
4. **分阶段验证**：DRC 问题会让触发器上不了链，从而遮住配置问题。凡是有 DRC 缺陷的用例，都另外跑一遍「只去掉 DRC 缺陷」的版本，确认被遮住的配置问题在修好 DRC 后确实出现。这类问题在 `现象` 里写明「在 original.dofile 中被 ISSUE-xx 遮蔽……修复后重新运行可见：……」。
5. **独立复查**：最后从打包目录本身重新跑 golden 与 original（不复用生成过程的任何中间文件），结果如下。

| 用例 | golden ERROR / DRC / 链数 | original ERROR / DRC |
|---|---|---|
| aes_core | 0 / 0 / 4 | 3 / 589 |
| faraday_dma | 0 / 0 / 8 | 4 / 1917 |
| iscas_s13207 | 0 / 0 / 4 | 4 / 637 |
| iscas_s15850 | 0 / 0 / 4 | 4 / 533 |
| iscas_s35932 | 0 / 0 / 8 | 3 / 1727 |
| iscas_s38417 | 0 / 0 / 8 | 4 / 1635 |
| iscas_s38584 | 0 / 0 / 8 | 4 / 1425 |
| iscas_s9234 | 0 / 0 / 2 | 4 / 210 |
| spi | 0 / 0 / 4 | 3 / 363 |
| systemcaes | 0 / 0 / 4 | 4 / 1958 |
| usb_funct | 0 / 0 / 10 | 4 / 1531 |

（original 的 ERROR 数是日志里 `[ERROR]` 行的条数，和问题数不是一一对应：一个缺陷可能引出多条报错。每条预设问题对应的报错行已在生成时逐条核对。）

## 怎么跑

需要能联网拿 license（`8273@121.40.209.111`），镜像 `scan-agent-base:ubuntu24`；Apple Silicon 上需要 `--platform linux/amd64`（脚本里已经加了）。

```bash
./run_all.sh                    # 全部用例，golden 和 original 都跑
./run_all.sh golden spi         # 只跑 spi 的 golden
```

输出写到 `out/<用例>/<golden|original>/report|output/`，日志在 `out/<用例>/<golden|original>.log`。
用 agent 跑时，按官方方式把 `<用例>/input` 挂到 `/work/case/input`，**评测前请把 golden.dofile 和 preset_issues.json 移出 input**，否则 agent 能直接看到答案。

## 注意

- 这些不是官方用例。说明书最初由 AI 写，golden 是我们 agent 的达标结果再经工具验收，不保证与官方口径完全一致；只能说明「golden 能跑通且满足说明书，每个预设问题在工具里真实存在」。
- 缺陷是规则化注入的，种类有限（上表 12 种），比官方用例更有规律。用来测问题识别 / 修复流程是否走通合适，用来估分会偏乐观。
- 每个用例只有 1 个 DRC 问题；X_ORDER、C_EXCLUDE 在不同用例里重复出现。

## 各用例问题清单

### aes_core

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-02 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-03 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 clk 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _29232_ } | 是 |

### faraday_dma

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-02 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-03 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-04 | DRC问题 | 复位端口 HRSTn 的 -off_state 取值 |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format |  |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _51119_ } | 是 |

### iscas_s13207

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-02 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-03 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | set_scan_element false { _12858_ } | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |

### iscas_s15850

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-02 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-03 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _15622_ } | 是 |

### iscas_s35932

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-02 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-03 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _34640_ } | 是 |

### iscas_s38417

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-02 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-03 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | set_scan_element false { _40198_ } | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | 分区 main_partition 的 -chain_count | 是 |

### iscas_s38584

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-02 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-03 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _39050_ } | 是 |

### iscas_s9234

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-02 | Dofile执行问题 | 分区 main_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-03 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-04 | DRC问题 | 扫描时钟端口 CK 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _8583_ } | 是 |

### spi

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 分区 wb_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-02 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-03 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-04 | DRC问题 | 复位端口 wb_rst_i 的 DFT 信号声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | set_scan_element false { _1241_ } | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |

### systemcaes

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 全局 scan_enable 信号声明（端口 test_se，-usage both） |  |
| ISSUE-02 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-03 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-04 | DRC问题 | 复位端口 reset 的 -off_state 取值 |  |
| ISSUE-05 | DFT配置不符合任务要求 | 分区 ff_partition 的 -chain_count | 是 |
| ISSUE-06 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format | 是 |

### usb_funct

| 编号 | 类型 | 对象 | 需先修 DRC 才可见 |
|---|---|---|---|
| ISSUE-01 | Dofile执行问题 | 插链配置报告命令 rpt_scan_cgf |  |
| ISSUE-02 | Dofile执行问题 | examine_scan_chain 命令的执行位置（位于 insert_dft_logic 之后） |  |
| ISSUE-03 | Dofile执行问题 | 分区 wb_partition 上下文中的 set_scan_cfg 命令（-max_lenght 参数） |  |
| ISSUE-04 | DRC问题 | 第二时钟域端口 phy_clk_pad_i 的时钟声明（缺失） |  |
| ISSUE-05 | DFT配置不符合任务要求 | 全局 set_scan_cfg 的 -si_port_format / -so_port_format |  |
| ISSUE-06 | DFT配置不符合任务要求 | set_scan_element false { _35828_ } | 是 |

